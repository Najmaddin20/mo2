
export interface AppActivity {
  totalHours: number;
  totalMinutes: number;
  breakdown: {
    name: string;
    time: number; // in hours
    color: string;
  }[];
}

export interface VoiceStats {
    totalSpeakingMinutes: number;
    totalListeningMinutes: number;
    roomsHosted: number;
    roomsJoined: number;
}

export interface User {
  id: number;
  name: string;
  avatar: string;
  profileBanner?: string;
  isHost?: boolean;
  isFriend?: boolean;
  bio?: string;
  friendsCount?: number;
  watchHistory?: { genre: string; hours: number }[];
  appActivity?: AppActivity;
  voiceStats?: VoiceStats;
  isVerified?: boolean;
}

// --- New Dating/Social Types ---

export type Gender = 'male' | 'female' | 'non-binary' | 'other';
export type RelationshipGoal = 'dating' | 'friends' | 'chat' | 'gaming' | 'networking';

export interface UserProfile extends User {
  age: number;
  gender: Gender;
  location: {
    city: string;
    country: string;
    lat?: number;
    lng?: number;
  };
  relationshipGoal?: RelationshipGoal;
  interests: string[];
  photos: string[]; // Array of photo URLs
  matchPercentage?: number; // Mock data for matching
}

export interface FriendRequest {
  id: number;
  user: UserProfile;
  status: 'pending' | 'accepted' | 'rejected';
  timestamp: number;
  message?: string;
}

export type FriendStatus = 'online' | 'offline' | 'ingame';

export interface Friend extends User {
  status: FriendStatus;
  currentRoom?: string; // Name of the room they are in
  isTyping?: boolean;
  friends?: Friend[];
}

export interface AudioTrack {
  id: string; // Unique ID (message ID or file ID)
  url: string;
  title: string;
  artist: string;
  artwork?: string;
  duration: number;
  waveform?: number[];
  contextId?: number; // ID of conversation or room this belongs to
}

export type RepeatMode = 'off' | 'all' | 'one';

export interface DirectMessage {
  id: number;
  senderId: number;
  message: string;
  displayTime: string;
  timestamp: number;
  replyTo?: DirectMessage;
  imageUrl?: string;
  videoUrl?: string;
  caption?: string;
  forwardedFrom?: User;
  roomInvite?: {
    roomId: number;
    roomName: string;
    thumbnail: string;
  };
  voiceRoomInvite?: {
    roomId: number;
    roomTopic: string;
  };
  status?: 'sending' | 'sent' | 'delivered' | 'seen';
  reactions?: { [emoji: string]: number };
  isEdited?: boolean;
  voiceMessage?: {
    url: string;
    duration: number; // in seconds
    waveform?: number[];
  };
  uploadProgress?: number;
  downloadProgress?: number;
  fileInfo?: {
    name: string;
    size: number;
  };
  call?: {
    type: 'voice' | 'video';
    status: 'outgoing' | 'incoming' | 'missed';
    duration?: number; // in seconds
  };
}

export type GroupPermission = 'edit_info' | 'delete_messages' | 'ban_users' | 'invite_users' | 'pin_messages';

export interface Conversation {
  friend: Friend;
  messages: DirectMessage[];
  unreadCount?: number;
  pinnedMessageIds?: number[];
  lastMessageTimestamp?: number;
  isPinned?: boolean;
  isMuted?: boolean;
  isArchived?: boolean;
  lockPin?: string;
  // Group specific
  isGroup?: boolean;
  groupOwnerId?: number;
  adminIds?: number[];
  participants?: User[];
  description?: string;
  voiceChatStarted?: boolean;
  voiceChatParticipants?: User[];
  
  // Advanced Group Features
  inviteLink?: string;
  isPublic?: boolean;
  bannedUsers?: User[];
  memberPermissions?: Record<number, GroupPermission[]>; // UserId -> Permissions
  theme?: string; // Hex color code
}


export interface ChatMessage {
  id: number;
  user: User;
  message: string;
  timestamp: string;
  type: 'user' | 'event';
  eventType?: 'user-join' | 'user-leave' | 'playback-change' | 'video-change' | 'role-change' | 'user-kick' | 'user-block';
  eventDetails?: {
    action?: 'played' | 'paused';
    videoTitle?: string;
    promotedUser?: string;
    newRole?: UserRole;
    affectedUser?: string;
  };
  replyTo?: ChatMessage;
  likes?: number;
  imageUrl?: string;
  videoUrl?: string;
  caption?: string;
  forwardedFrom?: User;
  voiceMessage?: {
    url: string;
    duration: number; // in seconds
    waveform?: number[];
  };
  uploadProgress?: number;
  downloadProgress?: number;
  fileInfo?: {
    name: string;
    size: number;
  };
}

export interface VideoQueueItem {
  id: number;
  title: string;
  url: string;
  thumbnail: string;
  addedBy: User;
  votes: number;
}

export interface SuggestedVideo {
  id: number;
  title: string;
  url: string;
  thumbnail: string;
  channel: string;
}

export type UserRole = 'host' | 'moderator' | 'dj' | 'member';
export type PlaybackPermission = 'host-only' | 'all';

export interface RoomUser extends User {
  role: UserRole;
  isTyping?: boolean;
}

export interface Room {
  id: number;
  name: string;
  thumbnail: string;
  users: RoomUser[];
  nowPlaying: string;
  videoUrl: string;
  isPlaying: boolean;
  playbackPosition: number; // in seconds
  isPublic: boolean;
  password?: string;
  playbackPermissions?: PlaybackPermission;
  blockedUsers?: User[];
  videoQueue?: VideoQueueItem[];
  voiceParticipants?: User[];
  rating?: number;
  totalRatings?: number;
  pinnedMessageId?: number;
  joinRequests?: User[];
  scheduledEventId?: number;
  chatMessages?: ChatMessage[];
}

export interface ScheduledEvent {
  id: number;
  title: string;
  description?: string;
  videoUrl: string;
  thumbnail: string;
  scheduledTime: Date;
  createdBy: User;
  invitedUsers: User[];
  rsvps?: { userId: number; status: 'going' | 'maybe' | 'not-going' }[];
}

export type ChatBackground = {
    type: 'class';
    value: string;
} | {
    type: 'custom';
    value: string; // This will be a `url(...)` string
};

export type AppTheme = 'cosmic' | 'emerald' | 'ocean' | 'crimson' | 'midnight' | 'sunset' | 'lavender' | 'mint' | 'cyber' | 'luxury' | 'slate';

export interface Notification {
    id: number;
    type: 'friend-request' | 'mention' | 'event-reminder' | 'room-invite';
    user?: User;
    message: string;
    timestamp: string;
    isRead: boolean;
    relatedId?: number; // Room ID or Event ID
}

export interface NotificationSettings {
    directMessages: boolean;
    chatMentions: boolean;
    friendRequests: boolean;
    videoInQueue: boolean;
    friendJoins: boolean;
    eventReminders: boolean;
}

export interface ActiveCall {
    friend: Friend;
    state: CallState;
    initialState: CallState;
}

export type CallState = 'outgoing-voice' | 'outgoing-video' | 'incoming-voice' | 'incoming-video' | 'active-voice' | 'active-video';

export interface VoiceRoomUser extends User {
    role: 'host' | 'speaker' | 'listener';
    isMuted?: boolean;
    isMutedByHost?: boolean;
    isSpeaking?: boolean;
    raisedHand?: boolean;
}

export interface InviteLink {
    id: string;
    code: string;
    type: 'one-time' | 'public';
    createdBy: User;
    usedBy: User[]; // Users who joined via this link
    createdAt: number;
    isActive: boolean;
}

export interface BannedDetail {
    userId: number;
    bannedBy: User;
    timestamp: string;
    reason?: string;
}

export interface VoiceRoom {
    id: number;
    ownerId: number; // The creator/owner of the room
    topic: string;
    speakers: VoiceRoomUser[];
    listeners: VoiceRoomUser[];
    raisedHands: User[];
    invitedSpeakerIds?: number[]; // IDs of users invited to speak but haven't accepted yet
    theme?: 'cosmic' | 'sunset' | 'forest' | 'ocean' | 'midnight' | 'rose' | 'amber';
    isPrivate?: boolean;
    password?: string;
    topics?: string[];
    timer?: {
        endsAt: number;
    };
    inviteCode?: string;
    isRecording?: boolean;
    game?: {
        type: 'truth-or-dare' | 'would-you-rather' | 'this-or-that' | 'charades';
        currentPlayer?: VoiceRoomUser;
        currentActor?: VoiceRoomUser;
        currentWord?: string;
        currentChallenge?: { type: 'truth' | 'dare'; text: string };
        question?: string;
        optionA?: { text: string; votes: User[] };
        optionB?: { text: string; votes: User[] };
        scores?: { teamA: number; teamB: number };
        timer?: number;
    };
    joinRequests?: User[];
    blockedUsers?: User[];
    bannedDetails?: BannedDetail[]; // Extra details about bans
    inviteLinks?: InviteLink[]; // Advanced invite links
    openMicMode?: boolean;
}

export interface Toast {
    id: number;
    title: string;
    description?: string;
    type: 'success' | 'error' | 'warning' | 'info';
    duration?: number;
    buttonText?: string;
}