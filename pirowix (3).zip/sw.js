const CACHE_NAME = 'syncwatch-v1';
const urlsToCache = [
  '/',
  './index.html',
  './manifest.json',
  './vite.svg',
  './index.tsx',
  './metadata.json',
  './types.ts',
  './App.tsx',
  './components/icons.tsx',
  './components/AuthPage.tsx',
  './components/Dashboard.tsx',
  './components/WatchRoom.tsx',
  './components/Sidebar.tsx',
  './components/Settings.tsx',
  './components/DashboardSkeleton.tsx',
  './components/FriendsPanel.tsx',
  './components/SchedulePage.tsx',
  './components/PasswordPromptModal.tsx',
  './components/VoiceClubhouse.tsx',
  './components/VoiceRoom.tsx',
  './components/StartVoiceRoomModal.tsx',
  './components/WidgetsPanel.tsx',
  './components/VoiceRoomSettingsModal.tsx',
  './components/EnhancedUserProfileModal.tsx',
  './components/ForwardMessageModal.tsx',
  './components/StartGameModal.tsx',
  './components/LockScreenModal.tsx',
  './components/ConfirmationModal.tsx',
  './components/CreateRoomModal.tsx',
  './components/RoomSettingsModal.tsx',
  './components/VideoSuggestions.tsx',
  './components/NowPlayingManager.tsx',
  './components/EmojiReactions.tsx',
  './components/BannedUsersManager.tsx',
  './components/AdvancedChat.tsx',
  './components/MediaViewerModal.tsx',
  './components/UserProfileModal.tsx',
  './components/RoomChatPanel.tsx',
  './components/RoomRating.tsx',
  './components/AudioPlayer.tsx',
  './components/VoiceMessageRecorder.tsx',
  './components/JumpToLatestButton.tsx',
  './components/ScheduleRoomModal.tsx',
  './components/ChatAppearanceSettings.tsx',
  './components/NotificationsSettings.tsx',
  './components/AppActivityWidget.tsx',
  './components/ImageViewerModal.tsx',
  './components/UserInfoPanel.tsx',
  './components/ChatContextMenu.tsx',
  './components/ChatLocksSettings.tsx',
  './components/DirectMessageItem.tsx',
  './components/MessageActionOverlay.tsx',
  './components/VoiceRoomHeaderMenu.tsx',
  './components/GamesPanel.tsx',
  './components/VoiceRoomReactions.tsx',
  './components/EventDetailsModal.tsx',
  './components/EventDetailsContent.tsx',
  './components/ExpandableEventCard.tsx',
  './components/DayView.tsx',
  './components/DateSeparator.tsx',
  './components/FriendSearchResults.tsx',
  './components/CallManager.tsx',
  './components/FriendRequestsPanel.tsx',
  './components/ToastManager.tsx',
  './components/EventMessage.tsx',
  './components/ImageStudio.tsx',
  './components/PeopleNearby.tsx',
  './assets/world_map.svg',
  './components/VoiceRoomPasswordPromptModal.tsx',
  './components/SoundEffectsPanel.tsx'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        return fetch(event.request).then(
          (response) => {
            if(!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            const responseToCache = response.clone();
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });
            return response;
          }
        );
      })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});