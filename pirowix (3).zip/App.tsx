
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import type { User, Room, SuggestedVideo, Friend, Conversation, DirectMessage, ChatMessage, ScheduledEvent, ChatBackground, NotificationSettings, RoomUser, PlaybackPermission, UserRole, VoiceRoom, VoiceRoomUser, Notification, ActiveCall, CallState, AppTheme } from './types';
import AuthPage from './components/AuthPage';
import Dashboard from './components/Dashboard';
import WatchRoom from './components/WatchRoom';
import Sidebar from './components/Sidebar';
import Settings from './components/Settings';
import DashboardSkeleton from './components/DashboardSkeleton';
import FriendsPanel from './components/FriendsPanel';
import { MenuIcon, BellIcon, UsersIcon, SettingsIcon, ArrowLeftIcon, DownloadIcon, SearchIcon } from './components/icons';
import SchedulePage from './components/SchedulePage';
import PasswordPromptModal from './components/PasswordPromptModal';
import VoiceRoomPasswordPromptModal from './components/VoiceRoomPasswordPromptModal';
import VoiceClubhouse from './components/VoiceClubhouse';
import VoiceRoomComponent from './components/VoiceRoom';
import StartVoiceRoomModal from './components/StartVoiceRoomModal';
import WidgetsPanel from './components/WidgetsPanel';
import VoiceRoomSettingsModal from './components/VoiceRoomSettingsModal';
import EnhancedUserProfileModal from './components/EnhancedUserProfileModal';
import ForwardMessageModal from './components/ForwardMessageModal';
import StartGameModal from './components/StartGameModal';
import LockScreenModal from './components/LockScreenModal';
import ConfirmationModal from './components/ConfirmationModal';
import NotificationsPanel from './components/NotificationsPanel';
import CallManager from './components/CallManager';
import { ToastProvider, useToast } from './components/ToastManager';
import ImageStudio from './components/ImageStudio';
import VideoStudio from './components/VideoStudio';
import PeopleNearby from './components/PeopleNearby';
import { GoogleGenAI } from '@google/genai';
import { AudioPlayerProvider, GlobalAudioPlayer } from './components/AudioPlayerSystem';


// ... (keeping existing mock data and helper functions exactly as they are)
const mockUsersWithDetails: User[] = [
    { 
        id: 101, name: 'Alex', avatar: 'https://i.pravatar.cc/150?u=alex', isHost: true, 
        profileBanner: 'https://picsum.photos/seed/alex-banner/600/200',
        bio: 'Just a cinephile enjoying the show.', friendsCount: 12, 
        watchHistory: [{ genre: 'Sci-Fi', hours: 40 }, { genre: 'Action', hours: 30 }, { genre: 'Comedy', hours: 15 }],
        appActivity: {
          totalHours: 4,
          totalMinutes: 36,
          breakdown: [
            { name: 'Youtube', time: 2.5, color: '#FF4141' },
            { name: 'Telegram', time: 0.8, color: '#31A6F5' },
            { name: 'Twitter', time: 0.5, color: '#1DA1F2' },
            { name: 'Discord', time: 0.3, color: '#7289DA' },
            { name: 'Spotify', time: 0.2, color: '#1DB954' },
            { name: 'Other apps', time: 0.3, color: '#888888' },
          ]
        },
        voiceStats: { totalSpeakingMinutes: 120, totalListeningMinutes: 400, roomsHosted: 5, roomsJoined: 12 }
    },
    { 
        id: 102, name: 'Mia', avatar: 'https://i.pravatar.cc/150?u=mia', 
        profileBanner: 'https://picsum.photos/seed/mia-banner/600/200',
        bio: 'Lover of anime and animated classics.', friendsCount: 25, 
        watchHistory: [{ genre: 'Animation', hours: 80 }, { genre: 'Fantasy', hours: 20 }],
        appActivity: {
          totalHours: 8,
          totalMinutes: 12,
          breakdown: [
            { name: 'Youtube', time: 4, color: '#FF4141' },
            { name: 'Discord', time: 2.2, color: '#7289DA' },
            { name: 'Spotify', time: 1.5, color: '#1DB954' },
            { name: 'Other apps', time: 0.5, color: '#888888' },
          ]
        },
        voiceStats: { totalSpeakingMinutes: 45, totalListeningMinutes: 200, roomsHosted: 1, roomsJoined: 8 }
    },
    { 
        id: 103, name: 'John', avatar: 'https://i.pravatar.cc/150?u=john', 
        bio: 'Action movie aficionado.', friendsCount: 5, 
        watchHistory: [{ genre: 'Action', hours: 90 }, { genre: 'Thriller', hours: 10 }],
         appActivity: {
          totalHours: 2,
          totalMinutes: 5,
          breakdown: [
            { name: 'Youtube', time: 1.8, color: '#FF4141' },
            { name: 'Other apps', time: 0.25, color: '#888888' },
          ]
        },
        voiceStats: { totalSpeakingMinutes: 10, totalListeningMinutes: 50, roomsHosted: 0, roomsJoined: 3 }
    },
    { 
        id: 104, name: 'Zoe', avatar: 'https://i.pravatar.cc/150?u=zoe', isHost: true, 
        profileBanner: 'https://picsum.photos/seed/zoe-banner/600/200',
        bio: 'Exploring the world of indie films.', friendsCount: 18, 
        watchHistory: [{ genre: 'Drama', hours: 50 }, { genre: 'Indie', hours: 50 }],
        voiceStats: { totalSpeakingMinutes: 300, totalListeningMinutes: 100, roomsHosted: 15, roomsJoined: 25 }
    },
    { 
        id: 105, name: 'Leo', avatar: 'https://i.pravatar.cc/150?u=leo', 
        bio: 'Here for the laughs!', friendsCount: 30, 
        watchHistory: [{ genre: 'Comedy', hours: 70 }, { genre: 'Rom-Com', hours: 25 }],
        voiceStats: { totalSpeakingMinutes: 60, totalListeningMinutes: 180, roomsHosted: 2, roomsJoined: 10 }
    },
    { 
        id: 106, name: 'Chloe', avatar: 'https://i.pravatar.cc/150?u=chloe', isHost: true, 
        bio: 'Music and movies are my escape.', friendsCount: 8, 
        watchHistory: [{ genre: 'Musical', hours: 60 }, { genre: 'Documentary', hours: 20 }],
        voiceStats: { totalSpeakingMinutes: 150, totalListeningMinutes: 300, roomsHosted: 8, roomsJoined: 15 }
    },
];

const mockRoom1Chat: ChatMessage[] = [
    { id: 1, user: { id: 102, name: 'Mia', avatar: 'https://i.pravatar.cc/150?u=mia' }, message: "Hey everyone! Ready for this?", timestamp: "22:30", likes: 1, type: 'user' },
    { id: 2, user: { id: 103, name: 'John', avatar: 'https://i.pravatar.cc/150?u=john' }, message: "Born ready! Let's go!", timestamp: "22:31", likes: 3, type: 'user' },
    { id: 3, user: { id: 101, name: 'Alex', avatar: 'https://i.pravatar.cc/150?u=alex' }, message: "Awesome! Let's get this started @John", timestamp: "22:31", replyTo: { id: 2, user: { id: 103, name: 'John', avatar: 'https://i.pravatar.cc/150?u=john' }, message: "Born ready! Let's go!", timestamp: "22:31", type: 'user' }, type: 'user' },
    { id: 4, user: { id: 105, name: 'rewi_bot', avatar: 'https://i.pravatar.cc/150?u=rewi' }, message: "This is a very long message to test how the text wrapping works in the chat bubbles. It should wrap correctly and not break the layout of the chat panel. Let's add even more text to be absolutely sure that it works as expected across multiple lines and different screen sizes.", timestamp: "16:47", type: 'user' },
    { 
      id: 5, 
      user: { id: 102, name: 'Mia', avatar: 'https://i.pravatar.cc/150?u=mia' }, 
      message: '',
      caption: 'Check out this cool clip!',
      videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
      timestamp: "22:35",
      fileInfo: { name: 'cool_clip.mp4', size: 15 * 1024 * 1024 }, // 15MB
      downloadProgress: 0,
      type: 'user'
    }
];

const initialMockRooms: Room[] = [
    {
        id: 1,
        name: 'Sci-Fi Universe',
        thumbnail: 'https://picsum.photos/seed/scifi/500/300',
        users: [
            { ...mockUsersWithDetails[0], role: 'host' },
            { ...mockUsersWithDetails[1], role: 'moderator' },
            { ...mockUsersWithDetails[2], role: 'member' },
        ],
        nowPlaying: 'Big Buck Bunny',
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        isPlaying: true,
        playbackPosition: 0,
        isPublic: true,
        playbackPermissions: 'host-only',
        blockedUsers: [],
        videoQueue: [
            { id: 1, title: 'Elephants Dream', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', thumbnail: 'https://i.ytimg.com/vi/eRsGyueVLvQ/hqdefault.jpg', addedBy: mockUsersWithDetails[1], votes: 2 },
        ],
        voiceParticipants: [ mockUsersWithDetails[0] ],
        rating: 4.5,
        totalRatings: 120,
        chatMessages: mockRoom1Chat,
    },
    {
        id: 2,
        name: 'Animation Showcase',
        thumbnail: 'https://picsum.photos/seed/animation/500/300',
        users: [
            { ...mockUsersWithDetails[3], role: 'host' },
            { ...mockUsersWithDetails[4], role: 'dj' },
        ],
        nowPlaying: 'Elephants Dream',
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
        isPlaying: true,
        playbackPosition: 0,
        isPublic: true,
        playbackPermissions: 'all',
        blockedUsers: [],
        videoQueue: [],
        voiceParticipants: [],
        rating: 4.8,
        totalRatings: 250,
        chatMessages: [],
    },
     {
        id: 3,
        name: 'Private Screening (PW)',
        thumbnail: 'https://picsum.photos/seed/youtube/500/300',
        users: [{ ...mockUsersWithDetails[5], role: 'host' }],
        nowPlaying: 'Secret Cinema',
        videoUrl: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
        isPlaying: true,
        playbackPosition: 0,
        isPublic: false,
        password: '1234',
        playbackPermissions: 'host-only',
        blockedUsers: [],
        videoQueue: [],
        voiceParticipants: [],
        rating: 4.2,
        totalRatings: 80,
        chatMessages: [],
    },
    {
        id: 4,
        name: 'Indie Film Club (Request)',
        thumbnail: 'https://picsum.photos/seed/indie/500/300',
        users: [{ ...mockUsersWithDetails[1], role: 'host' }],
        nowPlaying: 'Coffee and Cigarettes',
        videoUrl: 'https://www.youtube.com/watch?v=H6EZk_F-o-E',
        isPlaying: false,
        playbackPosition: 0,
        isPublic: false, // No password -> request-based
        playbackPermissions: 'all',
        blockedUsers: [],
        videoQueue: [],
        voiceParticipants: [],
        rating: 4.9,
        totalRatings: 50,
        joinRequests: [{ id: 301, name: 'Grace', avatar: 'https://i.pravatar.cc/150?u=grace' }],
        chatMessages: [],
    },
];

const initialVoiceRooms: VoiceRoom[] = [
    {
        id: 1,
        ownerId: 101,
        topic: "Let's talk about the new movie trailers!",
        speakers: [
            { ...mockUsersWithDetails[0], role: 'host', isMuted: false },
            { ...mockUsersWithDetails[1], role: 'speaker', isMuted: false },
        ],
        listeners: [
            { ...mockUsersWithDetails[2], role: 'listener' },
            { ...mockUsersWithDetails[3], role: 'listener' },
            { ...mockUsersWithDetails[4], role: 'listener' },
             { ...mockUsersWithDetails[2], id: 203, name: 'John', avatar: 'https://i.pravatar.cc/150?u=john2' , role: 'listener' },
            { ...mockUsersWithDetails[3], id: 204, name: 'Zoe', avatar: 'https://i.pravatar.cc/150?u=zoe2' , role: 'listener' },
            { ...mockUsersWithDetails[4], id: 205, name: 'Leo', avatar: 'https://i.pravatar.cc/150?u=leo2' , role: 'listener' },
        ],
        raisedHands: [],
        invitedSpeakerIds: [],
        theme: 'cosmic',
        isPrivate: false,
        inviteCode: 'xyz123',
        topics: ['movies', 'trailers', 'discussion'],
    },
    {
        id: 2,
        ownerId: 106,
        topic: 'Weekly Tech News Roundup 🚀',
        speakers: [
            { ...mockUsersWithDetails[5], role: 'host', isMuted: false },
        ],
        listeners: [
            { ...mockUsersWithDetails[3], role: 'listener' },
        ],
        raisedHands: [mockUsersWithDetails[3]],
        invitedSpeakerIds: [],
        theme: 'sunset',
        isPrivate: true,
        password: 'tech',
        inviteCode: 'abc987',
        topics: ['tech', 'news'],
        timer: { endsAt: Date.now() + 1000 * 60 * 30 }, // 30 mins from now
    }
];

// ... (Other Data Arrays)
const truthOrDareData = {
    truths: [ "What's the most embarrassing thing you've ever done?", "What's a secret you've never told anyone?", "What's your biggest fear?", "Have you ever cheated on a test?", "What's the biggest lie you've ever told?" ],
    dares: [ "Sing a song chosen by the group.", "Do your best impression of another player.", "Talk in a funny accent for the next 3 rounds.", "Do 10 push-ups.", "Tell a joke. If no one laughs, you lose." ]
};
const wouldYouRatherData = [ { question: "Would you rather have the ability to fly or be invisible?", optionA: "Fly", optionB: "Be Invisible" }, { question: "Would you rather live in the past or the future?", optionA: "Past", optionB: "Future" }, { question: "Would you rather have more time or more money?", optionA: "More Time", optionB: "More Money" }, { question: "Would you rather be able to talk to animals or speak all human languages?", optionA: "Talk to Animals", optionB: "Speak all Languages" }, { question: "Would you rather control fire or water?", optionA: "Control Fire", optionB: "Control Water" } ];
const thisOrThatData = [ { question: "Cats or Dogs?", optionA: "Cats 🐱", optionB: "Dogs 🐶" }, { question: "Pizza or Tacos?", optionA: "Pizza 🍕", optionB: "Tacos 🌮" }, { question: "Movies or Books?", optionA: "Movies 🎬", optionB: "Books 📚" }, { question: "Coffee or Tea?", optionA: "Coffee ☕", optionB: "Tea 🍵" } ];
const mockSuggestedVideos: SuggestedVideo[] = [ { id: 1, title: 'For the Birds - Pixar Short Film', url: 'https://www.youtube.com/watch?v=oY33qOKiBYg', thumbnail: 'https://i.ytimg.com/vi/oY33qOKiBYg/hqdefault.jpg', channel: 'Pixar' }, { id: 2, title: 'Sintel - Open Movie by Blender Foundation', url: 'https://www.youtube.com/watch?v=eRsGyueVLvQ', thumbnail: 'https://peach.blender.org/wp-content/uploads/title_anouncement.jpg?x11217', channel: 'Blender' }, { id: 3, title: 'Coffee Run - A Short film by Blender', url: 'https://www.youtube.com/watch?v=PVGeM40dABA', thumbnail: 'https://i.ytimg.com/vi/PVGeM40dABA/hqdefault.jpg', channel: 'Blender' }, { id: 4, title: 'Caminandes 3: Llamigos - Blender Open Movie', url: 'https://www.youtube.com/watch?v=SIyFEiHDB1s', thumbnail: 'https://i.ytimg.com/vi/SIyFEiHDB1s/hqdefault.jpg', channel: 'Blender' } ];
const mockFriends: Friend[] = [ { ...mockUsersWithDetails[1], status: 'online', currentRoom: 'Sci-Fi Universe', isTyping: false }, { ...mockUsersWithDetails[3], status: 'ingame', currentRoom: 'Animation Showcase', isTyping: false }, { ...mockUsersWithDetails[4], status: 'online', isTyping: false }, { id: 201, name: 'Dave', avatar: 'https://i.pravatar.cc/150?u=dave', status: 'offline', isTyping: false, bio: 'Offline warrior.', friendsCount: 10, watchHistory: [] }, { id: 202, name: 'Eve', avatar: 'https://i.pravatar.cc/150?u=eve', status: 'offline', isTyping: false, bio: 'Coding and watching.', friendsCount: 15, watchHistory: [] } ];
const mockPendingRequests: User[] = [ { id: 301, name: 'Grace', avatar: 'https://i.pravatar.cc/150?u=grace' } ];
const mockSentRequests: User[] = [ { id: 401, name: 'Kevin', avatar: 'https://i.pravatar.cc/150?u=kevin' }, { id: 402, name: 'Laura', avatar: 'https://i.pravatar.cc/150?u=laura' } ];

const generateRandomWaveform = (length = 60) => {
    return Array.from({ length }, () => Math.random() * 0.8 + 0.1);
};

const dayMillis = 1000 * 60 * 60 * 24;
const now = Date.now();

const mockConversations: Conversation[] = [
    {
        friend: mockFriends[0], // Mia
        messages: [
            { id: 1, senderId: 102, message: "Hey! Let's watch a movie tonight.", timestamp: now - dayMillis * 2, displayTime: "18:30", status: 'seen' },
            { id: 2, senderId: 99, message: "Sure! Any suggestions?", timestamp: now - dayMillis * 2, displayTime: "18:32", status: 'seen' },
            { id: 3, senderId: 102, message: "How about the new sci-fi one?", timestamp: now - dayMillis, displayTime: "20:15", status: 'seen', reactions: { '👍': 1 } },
            { id: 4, senderId: 99, message: "Definitely! I'll be there. The trailer looks insane.", timestamp: now - dayMillis, displayTime: "20:16", status: 'seen' },
            { id: 5, senderId: 99, message: "Ready for tonight?", timestamp: now - 1000 * 60 * 30, displayTime: "09:00", status: 'seen' },
            { id: 6, senderId: 102, message: "", voiceMessage: { url: 'https://actions.google.com/sounds/v1/science_fiction/scifi_pulse_loop.ogg', duration: 12, waveform: generateRandomWaveform() }, timestamp: now - 1000 * 60 * 25, displayTime: "09:05", status: 'seen' }
        ],
        unreadCount: 0,
        pinnedMessageIds: [3],
        lastMessageTimestamp: now - 1000 * 60 * 25,
        isPinned: true,
        isMuted: false,
        lockPin: '1234',
    },
    {
        friend: mockFriends[1], // Zoe
        messages: [
            { id: 6, senderId: 104, message: "That animation short was amazing!", timestamp: now - dayMillis * 3, displayTime: "Yesterday", status: 'seen' },
        ],
        unreadCount: 0,
        pinnedMessageIds: [],
        lastMessageTimestamp: now - dayMillis * 3,
    }
];

const getEventDate = (dayOffset: number, hour: number, minute: number = 0) => {
    const date = new Date();
    date.setDate(date.getDate() + dayOffset);
    date.setHours(hour, minute, 0, 0);
    return date;
}

const mockScheduledEvents: ScheduledEvent[] = [
    { id: 1, title: 'Inception Watch Party', description: 'Join us for a mind-bending experience as we watch Inception together. Bring your own popcorn!', videoUrl: 'https://www.youtube.com/watch?v=YoHD9XEInc0', thumbnail: 'https://i.ytimg.com/vi/YoHD9XEInc0/hqdefault.jpg', scheduledTime: getEventDate(2, 20), createdBy: mockUsersWithDetails[0], invitedUsers: [mockUsersWithDetails[1], mockUsersWithDetails[2]], rsvps: [ { userId: 102, status: 'going' }, { userId: 103, status: 'maybe' } ] },
    { id: 2, title: 'Blender Animation Fest', description: 'A showcase of the best short films from the Blender open movie project. Get ready for some stunning visuals!', videoUrl: 'https://www.youtube.com/watch?v=eRsGyueVLvQ', thumbnail: 'https://peach.blender.org/wp-content/uploads/title_anouncement.jpg?x11217', scheduledTime: getEventDate(4, 18, 30), createdBy: mockUsersWithDetails[3], invitedUsers: [mockUsersWithDetails[0], mockUsersWithDetails[4]], rsvps: [ { userId: 101, status: 'going' } ] },
    { id: 3, title: 'Today\'s Anime Binge', description: 'Let\'s watch the first 3 episodes of the new season!', videoUrl: 'https://www.youtube.com/watch?v=c_1_qBEp-Lk', thumbnail: 'https://i.ytimg.com/vi/c_1_qBEp-Lk/hqdefault.jpg', scheduledTime: getEventDate(0, 19), createdBy: mockUsersWithDetails[1], invitedUsers: [mockUsersWithDetails[3], mockUsersWithDetails[4]], rsvps: [ { userId: 104, status: 'going' }, { userId: 105, status: 'going' } ] },
    { id: 4, title: 'Next Month Planning', description: 'Quick meeting to plan next month\'s watch parties.', videoUrl: 'https://www.youtube.com/watch?v=V74l_zS1x8E', thumbnail: 'https://i.ytimg.com/vi/V74l_zS1x8E/hqdefault.jpg', scheduledTime: getEventDate(10, 12), createdBy: mockUsersWithDetails[0], invitedUsers: [mockUsersWithDetails[3]], rsvps: [] },
];

const mockNotifications: Notification[] = [
    { id: 1, type: 'friend-request', user: { id: 301, name: 'Grace', avatar: 'https://i.pravatar.cc/150?u=grace' }, message: 'sent you a friend request.', timestamp: '5m ago', isRead: false },
    { id: 2, type: 'mention', user: { id: 101, name: 'Alex', avatar: 'https://i.pravatar.cc/150?u=alex' }, message: 'mentioned you in Sci-Fi Universe.', timestamp: '1h ago', isRead: false, relatedId: 1 },
    { id: 3, type: 'event-reminder', message: "Inception Watch Party starts in 30 minutes.", timestamp: '2h ago', isRead: true, relatedId: 1 },
    { id: 4, type: 'room-invite', user: { id: 104, name: 'Zoe', avatar: 'https://i.pravatar.cc/150?u=zoe' }, message: 'invited you to join Animation Showcase.', timestamp: 'Yesterday', isRead: true, relatedId: 2 }
];


type Page = 'dashboard' | 'settings' | 'explore' | 'friends' | 'schedule' | 'voice-clubhouse' | 'image-studio' | 'video-studio' | 'people-nearby';

const pageTitles: Record<Page, string> = {
    'dashboard': 'Watch Party',
    'settings': 'Settings',
    'explore': 'Explore',
    'friends': 'Friends',
    'schedule': 'Schedule',
    'voice-clubhouse': 'Voice Rooms',
    'image-studio': 'Image Studio',
    'video-studio': 'Video Studio',
    'people-nearby': 'People Nearby',
};

const APP_THEMES = {
  cosmic: { name: 'Cosmic', primary: 'rgba(124, 58, 237, 0.15)', secondary: 'rgba(59, 130, 246, 0.15)', accent: '#8A79F7' },
  emerald: { name: 'Emerald', primary: 'rgba(16, 185, 129, 0.15)', secondary: 'rgba(6, 95, 70, 0.15)', accent: '#34D399' },
  ocean: { name: 'Ocean', primary: 'rgba(59, 130, 246, 0.15)', secondary: 'rgba(30, 64, 175, 0.15)', accent: '#60A5FA' },
  crimson: { name: 'Crimson', primary: 'rgba(239, 68, 68, 0.15)', secondary: 'rgba(153, 27, 27, 0.15)', accent: '#F87171' },
  midnight: { name: 'Midnight', primary: 'rgba(99, 102, 241, 0.15)', secondary: 'rgba(49, 46, 129, 0.15)', accent: '#818CF8' },
  sunset: { name: 'Sunset', primary: 'rgba(249, 115, 22, 0.15)', secondary: 'rgba(236, 72, 153, 0.15)', accent: '#F472B6' },
  lavender: { name: 'Lavender', primary: 'rgba(192, 132, 252, 0.15)', secondary: 'rgba(168, 85, 247, 0.15)', accent: '#C084FC' },
  mint: { name: 'Mint', primary: 'rgba(45, 212, 191, 0.15)', secondary: 'rgba(13, 148, 136, 0.15)', accent: '#2DD4BF' },
  cyber: { name: 'Cyber', primary: 'rgba(6, 182, 212, 0.15)', secondary: 'rgba(236, 72, 153, 0.15)', accent: '#06B6D4' },
  luxury: { name: 'Luxury', primary: 'rgba(251, 191, 36, 0.15)', secondary: 'rgba(180, 83, 9, 0.15)', accent: '#FBBF24' },
  slate: { name: 'Slate', primary: 'rgba(148, 163, 184, 0.15)', secondary: 'rgba(71, 85, 105, 0.15)', accent: '#94A3B8' },
};

const hexToRgba = (hex: string, alpha: number) => {
    // Basic hex to rgba conversion
    let r = 0, g = 0, b = 0;
    if (hex.length === 4) {
        r = parseInt("0x" + hex[1] + hex[1]);
        g = parseInt("0x" + hex[2] + hex[2]);
        b = parseInt("0x" + hex[3] + hex[3]);
    } else if (hex.length === 7) {
        r = parseInt("0x" + hex[1] + hex[2]);
        g = parseInt("0x" + hex[3] + hex[4]);
        b = parseInt("0x" + hex[5] + hex[6]);
    }
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

// Fix: Add formatDuration function.
const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
};

const AppContent: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [activeRoom, setActiveRoom] = useState<Room | null>(null);
    const [rooms, setRooms] = useState<Room[]>(initialMockRooms);
    const [showSidebar, setShowSidebar] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [activePage, setActivePage] = useState<Page>('explore');
    const [suggestions] = useState<SuggestedVideo[]>(mockSuggestedVideos);
    const [friends, setFriends] = useState<Friend[]>(mockFriends);
    const [pendingRequests, setPendingRequests] = useState<User[]>(mockPendingRequests);
    const [sentRequests, setSentRequests] = useState<User[]>(mockSentRequests);
    const [conversations, setConversations] = useState<Conversation[]>(mockConversations);
    const [scheduledEvents, setScheduledEvents] = useState<ScheduledEvent[]>(mockScheduledEvents);
    const [passwordPrompt, setPasswordPrompt] = useState<Room | null>(null);
    const [voiceRooms, setVoiceRooms] = useState<VoiceRoom[]>(initialVoiceRooms);
    const [activeVoiceRoom, setActiveVoiceRoom] = useState<VoiceRoom | null>(null);
    const [isStartVoiceRoomModalOpen, setIsStartVoiceRoomModalOpen] = useState(false);
    const [voiceRoomPasswordPrompt, setVoiceRoomPasswordPrompt] = useState<{ room: VoiceRoom, error?: string } | null>(null);
    const [isVoiceRoomSettingsOpen, setIsVoiceRoomSettingsOpen] = useState(false);
    const [viewingProfile, setViewingProfile] = useState<User | null>(null);
    const [sharingVoiceRoom, setSharingVoiceRoom] = useState<VoiceRoom | null>(null);
    const [sharingRoom, setSharingRoom] = useState<Room | null>(null); // New state for sharing standard rooms
    const [isStartGameModalOpen, setIsStartGameModalOpen] = useState(false);
    const [selectedFriendId, setSelectedFriendId] = useState<number | null>(null);
    const [resetPinsConfirmation, setResetPinsConfirmation] = useState(false);
    const [lockScreenState, setLockScreenState] = useState<{
        isOpen: boolean;
        mode: 'setup' | 'enter';
        targetConversation?: Conversation | null;
        onSuccess?: (pin?: string) => void;
    }>({ isOpen: false, mode: 'setup' });
    const [installPrompt, setInstallPrompt] = useState<any>(null);
    const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
    const [showNotificationsPanel, setShowNotificationsPanel] = useState(false);
    const notificationsRef = useRef<HTMLDivElement>(null);
    const [activeCall, setActiveCall] = useState<ActiveCall | null>(null);
    const [showSwitchToVideoConfirm, setShowSwitchToVideoConfirm] = useState(false);
    const [blockedUsers, setBlockedUsers] = useState<User[]>([]);
    const [appTheme, setAppTheme] = useState<AppTheme>('cosmic');
    const [customThemeColor, setCustomThemeColor] = useState<string | null>(null);
    const { addToast } = useToast();
    
    // Mobile Call Minimized State
    const [isCallMinimized, setIsCallMinimized] = useState(false);


    const [chatBackground, setChatBackground] = useState<ChatBackground>(() => {
        try {
            const savedBg = localStorage.getItem('chatBackground');
            return savedBg ? JSON.parse(savedBg) : { type: 'class', value: 'chat-bg-glass' };
        } catch (e) {
            console.error("Failed to parse chat background from localStorage", e);
            return { type: 'class', value: 'chat-bg-glass' };
        }
    });
    const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(() => {
        try {
            const saved = localStorage.getItem('notificationSettings');
            return saved ? JSON.parse(saved) : {
                directMessages: true,
                chatMentions: true,
                friendRequests: true,
                videoInQueue: false,
                friendJoins: false,
                eventReminders: true,
            };
        } catch (e) {
            console.error("Failed to parse notification settings from localStorage", e);
            return {
                directMessages: true,
                chatMentions: true,
                friendRequests: true,
                videoInQueue: false,
                friendJoins: false,
                eventReminders: true,
            };
        }
    });

    useEffect(() => {
        if (customThemeColor) {
            document.documentElement.style.setProperty('--glow-primary', hexToRgba(customThemeColor, 0.15));
            document.documentElement.style.setProperty('--glow-secondary', hexToRgba(customThemeColor, 0.1));
            document.documentElement.style.setProperty('--theme-color', customThemeColor);
        } else {
            const theme = APP_THEMES[appTheme as keyof typeof APP_THEMES];
            if (theme) {
                document.documentElement.style.setProperty('--glow-primary', theme.primary);
                document.documentElement.style.setProperty('--glow-secondary', theme.secondary);
                document.documentElement.style.setProperty('--theme-color', theme.accent);
            }
        }
    }, [appTheme, customThemeColor]);

    const allUsersForSearch = useMemo(() => {
        const userMap = new Map<number, User>();
        const addUser = (user: User) => {
            if (user && !userMap.has(user.id)) {
                userMap.set(user.id, user);
            }
        };

        mockUsersWithDetails.forEach(addUser);
        mockFriends.forEach(addUser);
        mockPendingRequests.forEach(addUser);
        initialMockRooms.forEach(room => room.users.forEach(addUser));
        initialVoiceRooms.forEach(room => {
            room.speakers.forEach(addUser);
            room.listeners.forEach(addUser);
        });

        return Array.from(userMap.values());
    }, []);

    const handleGlobalUserSearch = useCallback((query: string): User[] => {
        if (!query || !currentUser) return [];

        const friendIds = new Set(friends.map(f => f.id));
        const lowerCaseQuery = query.toLowerCase();
        
        return allUsersForSearch.filter(user => 
            user.id !== currentUser.id &&
            !friendIds.has(user.id) &&
            user.name.toLowerCase().includes(lowerCaseQuery)
        ).slice(0, 10); // Limit results for performance
    }, [currentUser, friends, allUsersForSearch]);

    useEffect(() => {
        const handler = (e: Event) => {
            e.preventDefault();
            setInstallPrompt(e);
        };
        window.addEventListener('beforeinstallprompt', handler);

        return () => window.removeEventListener('beforeinstallprompt', handler);
    }, []);
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (showNotificationsPanel && notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
                const bellButton = document.querySelector('[aria-label="Toggle Notifications"]');
                if (bellButton && bellButton.contains(event.target as Node)) {
                    return;
                }
                setShowNotificationsPanel(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [showNotificationsPanel]);

    const handleInstallClick = () => {
        if (!installPrompt) return;
        installPrompt.prompt();
        installPrompt.userChoice.then((choiceResult: { outcome: 'accepted' | 'dismissed' }) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the A2HS prompt');
            } else {
                console.log('User dismissed the A2HS prompt');
            }
            setInstallPrompt(null);
        });
    };

    const totalUnreadCount = useMemo(() => {
        return conversations.reduce((total, conv) => total + (conv.unreadCount || 0), 0);
    }, [conversations]);

    const unreadNotificationsCount = useMemo(() => {
        return notifications.filter(n => !n.isRead).length;
    }, [notifications]);

    const handleNotificationSettingsChange = (settings: NotificationSettings) => {
        setNotificationSettings(settings);
        try {
            localStorage.setItem('notificationSettings', JSON.stringify(settings));
        } catch (e) {
            console.error("Failed to save notification settings", e);
        }
    };

    const handleChatBackgroundChange = (bg: ChatBackground) => {
        setChatBackground(bg);
        try {
            localStorage.setItem('chatBackground', JSON.stringify(bg));
        } catch (e) {
            console.error("Failed to save chat background to localStorage", e);
        }
    };


    useEffect(() => {
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        return () => clearTimeout(timer);
    }, []);

    const handleLogin = useCallback((username: string) => {
        const user: User = { 
            id: 99, 
            name: username, 
            avatar: `https://i.pravatar.cc/150?u=${username}`,
            bio: 'New to SyncWatch! Looking for great movies to watch with friends.',
            friendsCount: Math.floor(Math.random() * 20),
            watchHistory: [
                { genre: 'Action', hours: 5 },
                { genre: 'Comedy', hours: 10 },
            ],
            appActivity: {
              totalHours: 6,
              totalMinutes: 22,
              breakdown: [
                { name: 'Youtube', time: 1.5, color: '#FF4141' },
                { name: 'Telegram', time: 2.8, color: '#31A6F5' },
                { name: 'Twitter', time: 0.5, color: '#1DA1F2' },
                { name: 'Spotify', time: 1.2, color: '#1DB954' },
                { name: 'Other apps', time: 0.3, color: '#888888' },
              ]
            },
            voiceStats: { totalSpeakingMinutes: 0, totalListeningMinutes: 0, roomsHosted: 0, roomsJoined: 0 }
        };
        setCurrentUser(user);
    }, []);

    const handleLogout = useCallback(() => {
        setCurrentUser(null);
        setActiveRoom(null);
        setActivePage('dashboard');
    }, []);
    
    const _joinRoom = useCallback((roomToJoin: Room) => {
        if (!currentUser) return;
        if (roomToJoin.blockedUsers?.some(u => u.id === currentUser.id)) {
            alert("You have been blocked from this room.");
            return;
        }
        const userInRoom = roomToJoin.users.some(u => u.id === currentUser.id);
        let roomWithCurrentUser = roomToJoin;
        if (!userInRoom) {
            const newUser: RoomUser = { ...currentUser, role: roomToJoin.users.length === 0 ? 'host' : 'member' };
            const updatedUsers = [...roomToJoin.users, newUser];

            const joinMessage: ChatMessage = {
                id: Date.now(),
                user: newUser,
                message: `${newUser.name} has joined`,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
                type: 'event',
                eventType: 'user-join',
            };
            const updatedChatMessages = [...(roomToJoin.chatMessages || []), joinMessage];

            roomWithCurrentUser = { ...roomToJoin, users: updatedUsers, chatMessages: updatedChatMessages };
            setRooms(prevRooms => prevRooms.map(r => r.id === roomToJoin.id ? roomWithCurrentUser : r));
        }
        setActiveRoom(roomWithCurrentUser);
        setActivePage('dashboard');
    }, [currentUser]);


    const handleJoinRoom = useCallback((roomToJoin: Room) => {
       if (!roomToJoin.isPublic && roomToJoin.password) {
           setPasswordPrompt(roomToJoin);
       } else if (!roomToJoin.isPublic && !roomToJoin.password) {
           alert("This room requires an invitation or request to join.");
       }
       else {
           _joinRoom(roomToJoin);
       }
    }, [_joinRoom]);
    
    const handlePasswordSubmit = (password: string) => {
        if (passwordPrompt && password === passwordPrompt.password) {
            _joinRoom(passwordPrompt);
            setPasswordPrompt(null);
        } else {
            alert('Incorrect password!');
        }
    };

    const handleStartScheduledParty = useCallback((event: ScheduledEvent) => {
        if (!currentUser) return;
        const existingRoom = rooms.find(r => r.scheduledEventId === event.id);
        if (existingRoom) {
            handleJoinRoom(existingRoom);
        } else {
            const newRoom: Room = {
                id: Date.now(),
                name: event.title,
                thumbnail: event.thumbnail,
                users: [{ ...currentUser, role: 'host' }],
                nowPlaying: event.title,
                videoUrl: event.videoUrl,
                isPlaying: true,
                playbackPosition: 0,
                isPublic: true, 
                playbackPermissions: 'host-only',
                scheduledEventId: event.id,
            };
            setRooms(prevRooms => [newRoom, ...prevRooms]);
            setActiveRoom(newRoom);
            setActivePage('dashboard');
        }
    }, [currentUser, rooms, handleJoinRoom]);

    const handleLeaveRoom = useCallback(() => {
        if (!activeRoom || !currentUser) return;

        const leaveMessage: ChatMessage = {
            id: Date.now(),
            user: currentUser,
            message: `${currentUser.name} has left`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
            type: 'event',
            eventType: 'user-leave',
        };

        setRooms(prevRooms =>
            prevRooms.map(r => {
                if (r.id === activeRoom.id) {
                    return { 
                        ...r, 
                        users: r.users.filter(u => u.id !== currentUser.id),
                        chatMessages: [...(r.chatMessages || []), leaveMessage]
                    };
                }
                return r;
            })
        );
        setActiveRoom(null);
        setActivePage('dashboard');
    }, [activeRoom, currentUser]);
    
    const handleCreateRoom = useCallback((newRoomData: Pick<Room, 'name' | 'nowPlaying' | 'videoUrl' | 'thumbnail' | 'isPublic' | 'password'>) => {
        if (!currentUser) return;
        const newRoom: Room = {
            ...newRoomData,
            id: Date.now(),
            users: [{ ...currentUser, role: 'host' }],
            isPlaying: true,
            playbackPosition: 0,
            playbackPermissions: 'host-only',
            blockedUsers: [],
            videoQueue: [],
            voiceParticipants: [],
            rating: 0,
            totalRatings: 0,
            chatMessages: [],
        };
        setRooms(prevRooms => [newRoom, ...prevRooms]);
        setActiveRoom(newRoom);
        setActivePage('dashboard');
    }, [currentUser]);

    const handleScheduleRoom = useCallback((newEventData: Omit<ScheduledEvent, 'id' | 'createdBy' | 'invitedUsers' | 'rsvps'>) => {
        if (!currentUser) return;
        const newEvent: ScheduledEvent = {
            ...newEventData,
            id: Date.now(),
            createdBy: currentUser,
            invitedUsers: [],
            rsvps: [],
        };
        setScheduledEvents(prev => [newEvent, ...prev].sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime()));
    }, [currentUser]);

    const handleUpdateEvent = useCallback((updatedEvent: ScheduledEvent) => {
        setScheduledEvents(prev => prev.map(e => e.id === updatedEvent.id ? updatedEvent : e));
    }, []);

    const handleCancelEvent = useCallback((eventId: number) => {
        setScheduledEvents(prev => prev.filter(e => e.id !== eventId));
    }, []);

    const handleRsvp = useCallback((eventId: number, status: 'going' | 'maybe' | 'not-going') => {
        if (!currentUser) return;
        setScheduledEvents(prev => prev.map(e => {
            if (e.id === eventId) {
                const rsvps = e.rsvps ? [...e.rsvps.filter(r => r.userId !== currentUser.id)] : [];
                rsvps.push({ userId: currentUser.id, status });
                return { ...e, rsvps };
            }
            return e;
        }));
    }, [currentUser]);

    const handleInviteFriends = useCallback((eventId: number, friendIds: number[]) => {
        const friendsToInvite = friends.filter(f => friendIds.includes(f.id));
        setScheduledEvents(prev => prev.map(e => {
            if (e.id === eventId) {
                const newInvited = [...e.invitedUsers];
                friendsToInvite.forEach(friend => {
                    if (!newInvited.some(u => u.id === friend.id)) {
                        newInvited.push(friend);
                    }
                });
                return { ...e, invitedUsers: newInvited };
            }
            return e;
        }));
    }, [friends]);
    
    const handleBlockUser = useCallback((userIdToBlock: number) => {
        if (!activeRoom || !currentUser) return;
        const userToBlock = activeRoom.users.find(u => u.id === userIdToBlock);
        if (!userToBlock) return;

        const blockMessage: ChatMessage = {
            id: Date.now(),
            user: currentUser,
            message: `${currentUser.name} blocked ${userToBlock.name}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
            type: 'event',
            eventType: 'user-block',
            eventDetails: { affectedUser: userToBlock.name }
        };

        const updatedUsers = activeRoom.users.filter(u => u.id !== userIdToBlock);
        const updatedBlockedUsers = [...(activeRoom.blockedUsers || []), userToBlock];
        const updatedRoom = { 
            ...activeRoom, 
            users: updatedUsers, 
            blockedUsers: updatedBlockedUsers,
            chatMessages: [...(activeRoom.chatMessages || []), blockMessage]
        };
        
        setRooms(prevRooms => prevRooms.map(r => r.id === activeRoom.id ? updatedRoom : r));
        setActiveRoom(updatedRoom);
    }, [activeRoom, currentUser]);
    
    const handleKickUser = useCallback((roomId: number, userId: number) => {
        if (!currentUser) return;
        const room = rooms.find(r => r.id === roomId);
        if (!room) return;
        
        const userToKick = room.users.find(u => u.id === userId);
        if (!userToKick) return;

        const kickMessage: ChatMessage = {
            id: Date.now(),
            user: currentUser,
            message: `${currentUser.name} kicked ${userToKick.name}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
            type: 'event',
            eventType: 'user-kick',
            eventDetails: { affectedUser: userToKick.name }
        };

        const updatedUsers = room.users.filter(u => u.id !== userId);
        const updatedBlockedUsers = [...(room.blockedUsers || []), userToKick];
        const updatedRoom = { 
            ...room, 
            users: updatedUsers, 
            blockedUsers: updatedBlockedUsers,
            chatMessages: [...(room.chatMessages || []), kickMessage]
        };
        
        setRooms(prevRooms => prevRooms.map(r => r.id === roomId ? updatedRoom : r));
        if (activeRoom?.id === roomId) {
            setActiveRoom(updatedRoom);
        }
    }, [rooms, activeRoom, currentUser]);

    const handleUnblockUser = useCallback((userIdToUnblock: number) => {
        if (!activeRoom) return;

        const updatedBlockedUsers = (activeRoom.blockedUsers || []).filter(u => u.id !== userIdToUnblock);
        const updatedRoom = { ...activeRoom, blockedUsers: updatedBlockedUsers };
        
        setRooms(prevRooms => prevRooms.map(r => r.id === activeRoom.id ? updatedRoom : r));
        setActiveRoom(updatedRoom);
    }, [activeRoom]);
    
    const handleRequestToJoin = useCallback((roomId: number) => {
        if (!currentUser) return;
        setRooms(prevRooms => prevRooms.map(r => {
            if (r.id === roomId) {
                const existingRequests = r.joinRequests || [];
                if (existingRequests.some(u => u.id === currentUser.id)) return r;
                return { ...r, joinRequests: [...existingRequests, currentUser] };
            }
            return r;
        }));
        alert("Request to join sent!");
    }, [currentUser]);
    
    const handleManageJoinRequest = useCallback((roomId: number, userId: number, action: 'accept' | 'decline') => {
        const room = rooms.find(r => r.id === roomId);
        const userToJoin = room?.joinRequests?.find(u => u.id === userId);
        if (!room || !userToJoin) return;
        
        const updatedRequests = (room.joinRequests || []).filter(u => u.id !== userId);

        let updatedRoom;
        if (action === 'accept') {
            const updatedUsers = [...room.users, { ...userToJoin, role: 'member' }];
            updatedRoom = { ...room, users: updatedUsers, joinRequests: updatedRequests };
        } else { // decline
            updatedRoom = { ...room, joinRequests: updatedRequests };
        }
        
        setRooms(prevRooms => prevRooms.map(r => r.id === roomId ? updatedRoom : r));
        if (activeRoom?.id === roomId) {
            setActiveRoom(updatedRoom);
        }
    }, [rooms, activeRoom]);

    const handleUpdateRoomSettings = useCallback((roomId: number, newSettings: Partial<Pick<Room, 'isPublic' | 'password' | 'playbackPermissions'>>) => {
        let updatedRoom: Room | null = null;
        setRooms(prevRooms => prevRooms.map(r => {
            if (r.id === roomId) {
                 updatedRoom = { ...r, ...newSettings };
                 if(newSettings.isPublic){
                    delete updatedRoom.password;
                 } else if (newSettings.password === ''){
                    delete updatedRoom.password;
                 }
                return updatedRoom;
            }
            return r;
        }));
        if (activeRoom?.id === roomId && updatedRoom) {
            setActiveRoom(updatedRoom);
        }
    }, [activeRoom]);

    const handleAddFriend = useCallback((userId: number): { status: 'success' } | { status: 'error', message: string } => {
        const allUsers = [...initialMockRooms.flatMap(r => r.users), ...mockFriends, ...mockPendingRequests, ...rooms.flatMap(r => r.users), ...mockUsersWithDetails];
        const user = allUsers.find(u => u.id === userId);
        
        if (user) {
            addToast({ title: 'Request Sent!', description: `Friend request sent to ${user.name}!`, type: 'success', buttonText: 'Got It!' });
            return { status: 'success' };
        } else {
            return { status: 'error', message: 'User not found.' };
        }
    }, [rooms, addToast]);

    const handleAcceptRequest = (userId: number) => {
        const user = pendingRequests.find(u => u.id === userId);
        if (user) {
            setPendingRequests(prev => prev.filter(u => u.id !== userId));
            setFriends(prev => [...prev, { ...user, status: 'offline' }]); // Add as friend, default to offline
            addToast({ title: 'Friend Added', description: `You are now friends with ${user.name}`, type: 'success', buttonText: 'Got It!' });
        }
    };
    
    const handleDeclineRequest = (userId: number) => {
        const user = pendingRequests.find(u => u.id === userId);
        if (user) {
            setPendingRequests(prev => prev.filter(u => u.id !== userId));
            addToast({ title: 'Request Declined', description: `Friend request from ${user.name} declined`, type: 'info', buttonText: 'Okay' });
        }
    };

    const handleCancelRequest = (userId: number) => {
        const user = sentRequests.find(u => u.id === userId);
        if (user) {
            setSentRequests(prev => prev.filter(u => u.id !== userId));
            addToast({ title: 'Request Canceled', description: `Your friend request to ${user.name} was canceled`, type: 'info' });
        }
    };

    const handleBlockFriend = useCallback((userToBlock: User) => {
        setFriends(prev => prev.filter(f => f.id !== userToBlock.id));
        setBlockedUsers(prev => {
            if (prev.some(u => u.id === userToBlock.id)) return prev;
            return [...prev, userToBlock];
        });
        setPendingRequests(prev => prev.filter(u => u.id !== userToBlock.id));
        addToast({ title: 'User Blocked', description: `${userToBlock.name} has been blocked and removed from friends.`, type: 'error', buttonText: 'Undo' });
    }, [addToast]);
    
    const handleUnblockFriend = useCallback((userToUnblock: User) => {
        setBlockedUsers(prev => prev.filter(u => u.id !== userToUnblock.id));
        addToast({ title: 'User Unblocked', description: `${userToUnblock.name} can now contact you again.`, type: 'success' });
    }, [addToast]);


    const updateConversation = (friendId: number, updateFn: (c: Conversation) => Conversation) => {
        setConversations(prev => {
            const convExists = prev.some(c => c.friend.id === friendId);
            if (convExists) {
                return prev.map(c => c.friend.id === friendId ? updateFn(c) : c);
            } else {
                let friend = friends.find(f => f.id === friendId);
                if (!friend) {
                    if (friendId === currentUser?.id) {
                        friend = { ...currentUser, name: 'Saved Messages', status: 'online', isFriend: true } as Friend;
                    } else {
                        return prev;
                    }
                }
                const newConv: Conversation = { friend, messages: [], unreadCount: 0, pinnedMessageIds: [], lastMessageTimestamp: 0 };
                return [...prev, updateFn(newConv)];
            }
        });
    };

    const handleSendMessage = useCallback((friendId: number, message: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'>) => {
        if (!currentUser) return;
        const tempId = Date.now();
        const isMediaUpload = !!(message.videoUrl || message.imageUrl);
        const isGenericFileUpload = !!message.fileInfo && !isMediaUpload;

        const baseMessage: DirectMessage = {
            ...message,
            id: tempId,
            senderId: currentUser.id,
            timestamp: Date.now(),
            displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        };

        if (isMediaUpload || isGenericFileUpload) {
             const initialMessage: DirectMessage = { ...baseMessage, status: 'sending', uploadProgress: 0 };
            updateConversation(friendId, c => ({ ...c, messages: [...c.messages, initialMessage], lastMessageTimestamp: Date.now() }));

            const uploadInterval = setInterval(() => {
                updateConversation(friendId, c => ({
                    ...c,
                    messages: c.messages.map(m => {
                        if (m.id === tempId) {
                            const newProgress = (m.uploadProgress ?? 0) + (10 + Math.random() * 15);
                            if (newProgress >= 100) {
                                clearInterval(uploadInterval);
                                setTimeout(() => { updateConversation(friendId, c => ({...c, messages: c.messages.map(m => m.id === tempId ? {...m, status: 'delivered'} : m)})); }, 1000);
                                setTimeout(() => { updateConversation(friendId, c => ({...c, messages: c.messages.map(m => m.id === tempId ? {...m, status: 'seen'} : m)})); }, 2500);
                                return { ...m, uploadProgress: 100, status: 'sent' };
                            }
                            return { ...m, uploadProgress: newProgress };
                        }
                        return m;
                    })
                }));
            }, 300);
        } else { 
             const newMessage: DirectMessage = { ...baseMessage, status: 'sent' };
             updateConversation(friendId, c => ({ ...c, messages: [...c.messages, newMessage], lastMessageTimestamp: Date.now() }));
             setTimeout(() => { updateConversation(friendId, c => ({...c, messages: c.messages.map(m => m.id === tempId ? {...m, status: 'delivered'} : m)})); }, 1000);
             setTimeout(() => { updateConversation(friendId, c => ({...c, messages: c.messages.map(m => m.id === tempId ? {...m, status: 'seen'} : m)})); }, 2500);
        }
        
        if (friendId !== currentUser.id) {
            setTimeout(() => { setFriends(f => f.map(friend => friend.id === friendId ? {...friend, isTyping: true} : friend)); }, 3000);
            setTimeout(() => {
                 setFriends(f => f.map(friend => friend.id === friendId ? {...friend, isTyping: false} : friend));
                 const replyType = Math.random();
                 if (isGenericFileUpload) return; 
                 if (replyType < 0.25) { 
                     const replyMessage: DirectMessage = { id: Date.now() + 1, senderId: friendId, message: '', timestamp: Date.now(), displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }), voiceMessage: { url: 'https://actions.google.com/sounds/v1/science_fiction/scifi_pulse_loop.ogg', duration: 5, waveform: generateRandomWaveform() } };
                    updateConversation(friendId, c => ({ ...c, messages: [...c.messages, replyMessage], unreadCount: (c.unreadCount || 0) + 1, lastMessageTimestamp: Date.now() }));
                } else if (replyType < 0.5) { 
                     const videoReplyId = Date.now() + 1;
                     const videoMessage: DirectMessage = { id: videoReplyId, senderId: friendId, message: '', caption: 'Check this out!', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', fileInfo: { name: 'ForBiggerFun.mp4', size: 15 * 1024 * 1024 }, timestamp: Date.now(), displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }), downloadProgress: 0, };
                     updateConversation(friendId, c => ({ ...c, messages: [...c.messages, videoMessage], unreadCount: (c.unreadCount || 0) + 1, lastMessageTimestamp: Date.now() }));
                     const downloadInterval = setInterval(() => {
                         updateConversation(friendId, c => ({
                             ...c,
                             messages: c.messages.map(m => {
                                 if (m.id === videoReplyId) {
                                     const newProgress = (m.downloadProgress ?? 0) + 10;
                                     if (newProgress >= 100) { clearInterval(downloadInterval); return { ...m, downloadProgress: 100 }; }
                                     return { ...m, downloadProgress: newProgress };
                                 }
                                 return m;
                             })
                         }));
                     }, 250);
                 } else { 
                    const originalText = message.message || message.caption || "media";
                     const replyMessage: DirectMessage = { id: Date.now() + 1, senderId: friendId, message: `Replying to: "${originalText.substring(0, 20)}..."`, timestamp: Date.now(), displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }), };
                     updateConversation(friendId, c => ({ ...c, messages: [...c.messages, replyMessage], unreadCount: (c.unreadCount || 0) + 1, lastMessageTimestamp: Date.now() }));
                 }
            }, 4500);
        }

    }, [currentUser]);

    const handleDeleteMessage = useCallback((friendId: number, messageIds: number | number[]) => {
        const idsToDelete = Array.isArray(messageIds) ? messageIds : [messageIds];
        updateConversation(friendId, c => ({
            ...c,
            messages: c.messages.filter(m => !idsToDelete.includes(m.id)),
            pinnedMessageIds: (c.pinnedMessageIds || []).filter(id => !idsToDelete.includes(id)),
        }));
    }, []);

    const handleEditMessage = useCallback((friendId: number, messageId: number, newText: string) => {
        updateConversation(friendId, c => ({
            ...c,
            messages: c.messages.map(m => {
                if (m.id === messageId) {
                    const isMedia = m.imageUrl || m.videoUrl;
                    return { 
                        ...m, 
                        message: isMedia ? m.message : newText, 
                        caption: isMedia ? newText : m.caption,
                        isEdited: true, 
                        displayTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) 
                    };
                }
                return m;
            }),
        }));
    }, []);

    const handlePinMessage = useCallback((friendId: number, messageId: number) => {
        updateConversation(friendId, c => {
            const pinnedIds = c.pinnedMessageIds || [];
            const isPinned = pinnedIds.includes(messageId);
            return {
                ...c,
                pinnedMessageIds: isPinned ? pinnedIds.filter(id => id !== messageId) : [...pinnedIds, messageId],
            };
        });
    }, []);

     const handleAddReaction = useCallback((friendId: number, messageId: number, emoji: string) => {
        updateConversation(friendId, c => ({
            ...c,
            messages: c.messages.map(m => {
                if (m.id === messageId) {
                    const reactions = { ...(m.reactions || {}) };
                    if(reactions[emoji]) {
                        delete reactions[emoji];
                    } else {
                        reactions[emoji] = (reactions[emoji] || 0) + 1;
                    }
                    return { ...m, reactions };
                }
                return m;
            }),
        }));
    }, []);
    
    const handleMarkAsRead = useCallback((friendId: number) => {
        updateConversation(friendId, c => ({...c, unreadCount: 0}));
    }, []);

    const handleRateRoom = useCallback((roomId: number, rating: number) => {
        setRooms(prevRooms => prevRooms.map(r => {
            if (r.id === roomId) {
                const currentTotalRating = (r.rating || 0) * (r.totalRatings || 0);
                const newTotalRatings = (r.totalRatings || 0) + 1;
                const newAverageRating = (currentTotalRating + rating) / newTotalRatings;
                return { ...r, rating: parseFloat(newAverageRating.toFixed(1)), totalRatings: newTotalRatings };
            }
            return r;
        }));
    }, []);

    const handleForwardMessage = useCallback((friendIds: number[], message: ChatMessage, comment: string) => {
        if (!currentUser) return;
        friendIds.forEach(friendId => {
            const forwardedMessage: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'> = {
                message: comment || message.message,
                imageUrl: message.imageUrl,
                videoUrl: message.videoUrl,
                caption: message.caption,
                voiceMessage: message.voiceMessage,
                forwardedFrom: message.user,
            };
            if (comment && message.message) {
                 forwardedMessage.message = comment + "\n\nForwarded: " + message.message;
            }
            handleSendMessage(friendId, forwardedMessage);
        });
        addToast({ title: 'Forwarded', description: `Message forwarded to ${friendIds.length} chat(s).`, type: 'success' });
    }, [currentUser, handleSendMessage, addToast]);
    
    const handleForwardDirectMessage = useCallback((toFriendId: number, message: DirectMessage, fromFriend: User) => {
        if (!currentUser) return;
        const originalSender = message.senderId === currentUser.id ? currentUser : fromFriend;
        const forwardedMessage: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'> = {
            message: message.message,
            imageUrl: message.imageUrl,
            videoUrl: message.videoUrl,
            caption: message.caption,
            voiceMessage: message.voiceMessage,
            roomInvite: message.roomInvite,
            forwardedFrom: originalSender,
        };
        handleSendMessage(toFriendId, forwardedMessage);
    }, [currentUser, handleSendMessage]);
    
    const handleForwardMultipleDirectMessages = useCallback((toFriendIds: number[], messages: DirectMessage[]) => {
        if (!currentUser) return;
        toFriendIds.forEach(toFriendId => {
            messages.forEach(message => {
                const forwardedMessage: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'> = {
                    message: message.message,
                    imageUrl: message.imageUrl,
                    videoUrl: message.videoUrl,
                    caption: message.caption,
                    voiceMessage: message.voiceMessage,
                    roomInvite: message.roomInvite,
                    voiceRoomInvite: message.voiceRoomInvite,
                    forwardedFrom: message.forwardedFrom,
                };
                handleSendMessage(toFriendId, forwardedMessage);
            });
        });
        addToast({ title: 'Forwarded', description: `Messages forwarded successfully.`, type: 'success' });
    }, [currentUser, handleSendMessage, addToast]);

    const handleShareRoom = useCallback((friendIds: number[], room: Room, comment: string) => {
        if (!currentUser) return;
        friendIds.forEach(friendId => {
            const roomInviteMessage: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'> = {
                message: comment || `Join me in ${room.name}!`,
                roomInvite: {
                    roomId: room.id,
                    roomName: room.name,
                    thumbnail: room.thumbnail,
                },
            };
            handleSendMessage(friendId, roomInviteMessage);
        });
        addToast({ title: 'Shared', description: `Room shared with ${friendIds.length} friend(s).`, type: 'success' });
    }, [currentUser, handleSendMessage, addToast]);

    const handleShareVoiceRoom = useCallback((friendIds: number[], room: VoiceRoom, comment: string) => {
        if (!currentUser) return;
        friendIds.forEach(friendId => {
            const roomInviteMessage: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'> = {
                message: comment || `Join the conversation: ${room.topic}`,
                voiceRoomInvite: {
                    roomId: room.id,
                    roomTopic: room.topic,
                },
            };
            handleSendMessage(friendId, roomInviteMessage);
        });
        addToast({ title: 'Shared', description: `Voice room shared with ${friendIds.length} friend(s).`, type: 'success' });
    }, [currentUser, handleSendMessage, addToast]);

    // New share item handler that checks type
    const handleShareItem = useCallback((item: Room | VoiceRoom) => {
        if ('speakers' in item) {
            setSharingVoiceRoom(item as VoiceRoom);
        } else {
            setSharingRoom(item as Room);
        }
    }, []);

    const handleUpdateProfile = (updates: Partial<User>) => {
        if (currentUser) {
            setCurrentUser(prev => prev ? { ...prev, ...updates } : null);
            addToast({ title: 'Profile Updated!', description: 'Your changes have been saved.', type: 'success' });
        }
    };
    
    const updateVoiceRoom = (roomId: number, updateFn: (room: VoiceRoom) => VoiceRoom) => {
        setVoiceRooms(prev => prev.map(r => r.id === roomId ? updateFn(r) : r));
        if (activeVoiceRoom?.id === roomId) {
            setActiveVoiceRoom(prev => prev ? updateFn(prev) : null);
        }
    };

    // ... (Voice Room Effects & Logic - same as before)
    // Speaker simulation effect
    useEffect(() => {
        if (!activeVoiceRoom || activeVoiceRoom.speakers.length < 2) return;
        const interval = setInterval(() => {
            updateVoiceRoom(activeVoiceRoom.id, room => {
                const speakers = [...room.speakers];
                const currentlySpeakingIndex = speakers.findIndex(s => s.isSpeaking);
                const nextSpeakerIndex = (currentlySpeakingIndex + 1) % speakers.length;
                return { ...room, speakers: speakers.map((s, i) => ({ ...s, isSpeaking: i === nextSpeakerIndex, })) };
            });
        }, 3000);
        return () => clearInterval(interval);
    }, [activeVoiceRoom]);

    // Voice Room Handlers
    const _joinVoiceRoom = (roomToJoin: VoiceRoom) => {
        if (!currentUser) return;
        const userExists = [...roomToJoin.speakers, ...roomToJoin.listeners].some(u => u.id === currentUser.id);
        if (!userExists) {
            const newUser: VoiceRoomUser = { ...currentUser, role: 'listener' };
            const updatedRoom = { ...roomToJoin, listeners: [...roomToJoin.listeners, newUser] };
            const MIN_USERS_FOR_MOCK = 3;
            if (updatedRoom.speakers.length + updatedRoom.listeners.length < MIN_USERS_FOR_MOCK) {
                const mockUserCount = MIN_USERS_FOR_MOCK - (updatedRoom.speakers.length + updatedRoom.listeners.length);
                const mockListeners: VoiceRoomUser[] = Array.from({ length: mockUserCount }).map((_, i) => ({
                    ...mockUsersWithDetails[0],
                    id: 500 + i,
                    name: `Bot ${i + 1}`,
                    avatar: `https://i.pravatar.cc/150?u=bot${i + 1}`,
                    role: 'listener' as 'listener'
                }));
                updatedRoom.listeners.push(...mockListeners);
            }
            updateVoiceRoom(roomToJoin.id, () => updatedRoom);
            setActiveVoiceRoom(updatedRoom);
        } else {
            setActiveVoiceRoom(roomToJoin);
        }
        setActivePage('voice-clubhouse');
    };
    
    const handleJoinVoiceRoom = (room: VoiceRoom) => {
        if (currentUser?.id === room.ownerId) {
             _joinVoiceRoom(room);
             return;
        }
        if (room.isPrivate && currentUser?.id !== room.ownerId) {
            setVoiceRoomPasswordPrompt({ room });
        } else {
            _joinVoiceRoom(room);
        }
    };

    const handleVoiceRoomPasswordSubmit = (password: string) => {
        if (voiceRoomPasswordPrompt) {
            const { room } = voiceRoomPasswordPrompt;
            if (password === room.password) {
                setVoiceRoomPasswordPrompt(null);
                _joinVoiceRoom(room);
            } else {
                setVoiceRoomPasswordPrompt({ room, error: 'Incorrect password.' });
            }
        }
    };
    
    const handleRequestToJoinVoiceRoom = (roomId: number) => {
        if (!currentUser) return;
        updateVoiceRoom(roomId, room => ({
            ...room,
            joinRequests: [...(room.joinRequests || []).filter(u => u.id !== currentUser.id), currentUser]
        }));
        setVoiceRoomPasswordPrompt(null);
        addToast({ title: 'Request Sent', description: 'Your request to join has been sent to the host.', type: 'info' });
    };

    const handleLeaveVoiceRoom = () => {
        if (!activeVoiceRoom || !currentUser) return;
        
        updateVoiceRoom(activeVoiceRoom.id, room => {
            const updatedRoom = {
                ...room,
                speakers: room.speakers.filter(u => u.id !== currentUser.id),
                listeners: room.listeners.filter(u => u.id !== currentUser.id),
            };
            // Auto close if empty
            if (updatedRoom.speakers.length === 0 && updatedRoom.listeners.length === 0) {
                 setVoiceRooms(prev => prev.filter(r => r.id !== activeVoiceRoom.id));
                 return updatedRoom; // Will unmount
            }
            return updatedRoom;
        });
        setActiveVoiceRoom(null);
    };

    const handleCreateVoiceRoom = (settings: { topic: string; isPrivate: boolean; password?: string; timer?: number, tags?: string; theme?: string; openMicMode?: boolean; isRecording?: boolean }) => {
        if (!currentUser) return;
        const newRoom: VoiceRoom = {
            id: Date.now(),
            ownerId: currentUser.id,
            topic: settings.topic,
            speakers: [{ ...currentUser, role: 'host' }],
            listeners: [
                { ...mockUsersWithDetails[2], id: 601, name: 'Bob', role: 'listener' },
                { ...mockUsersWithDetails[3], id: 602, name: 'Charlie', role: 'listener' },
                { ...mockUsersWithDetails[4], id: 603, name: 'Diana', role: 'listener' },
            ],
            raisedHands: [],
            invitedSpeakerIds: [],
            isPrivate: settings.isPrivate,
            theme: (settings.theme as any) || 'cosmic', 
            password: settings.password,
            topics: settings.tags?.split(',').map(t => t.trim()).filter(Boolean),
            timer: settings.timer ? { endsAt: Date.now() + settings.timer * 60000 } : undefined,
            openMicMode: settings.openMicMode,
            isRecording: settings.isRecording
        };
        setVoiceRooms(prev => [newRoom, ...prev]);
        setActiveVoiceRoom(newRoom);
        setIsStartVoiceRoomModalOpen(false);
    };

    const handleVoiceRoomAction = (action: string, payload?: any) => {
        if (!activeVoiceRoom) return;
        updateVoiceRoom(activeVoiceRoom.id, room => {
            let speakers = [...room.speakers];
            let listeners = [...room.listeners];
            let raisedHands = [...room.raisedHands];
            let invitedSpeakerIds = [...(room.invitedSpeakerIds || [])];
            let newRoom = { ...room };

            const findUser = (userId: number): { list: 'speakers' | 'listeners', user: VoiceRoomUser } | null => {
                const speaker = speakers.find(s => s.id === userId);
                if (speaker) return { list: 'speakers', user: speaker };
                const listener = listeners.find(l => l.id === userId);
                if (listener) return { list: 'listeners', user: listener };
                return null;
            }

            switch (action) {
                case 'raise-hand':
                    if (!raisedHands.some(u => u.id === currentUser.id)) raisedHands.push(currentUser);
                    break;
                case 'invite-to-speak':
                    // Instead of move directly, add to invited list
                    if (!invitedSpeakerIds.includes(payload.userId)) {
                        invitedSpeakerIds.push(payload.userId);
                    }
                    // Remove from raised hands if they were raising hand, so it clears that state
                    raisedHands = raisedHands.filter(u => u.id !== payload.userId);
                    break;
                case 'respond-to-invite':
                    // Payload: { userId, accept: boolean }
                    if (payload.accept) {
                        const userToMove = listeners.find(l => l.id === payload.userId);
                        if (userToMove) {
                            listeners = listeners.filter(l => l.id !== payload.userId);
                            speakers.push({ ...userToMove, role: 'speaker' });
                        }
                    }
                    // Always remove from invited list whether accepted or declined
                    invitedSpeakerIds = invitedSpeakerIds.filter(id => id !== payload.userId);
                    break;
                case 'move-to-audience':
                    const userToMove = speakers.find(s => s.id === payload.userId);
                    if (userToMove && userToMove.role !== 'host') {
                        speakers = speakers.filter(s => s.id !== payload.userId);
                        listeners.push({ ...userToMove, role: 'listener' });
                    }
                    break;
                case 'self-mute':
                    const self = findUser(currentUser.id);
                    if (self) {
                        if (self.list === 'speakers') speakers = speakers.map(s => s.id === currentUser.id ? { ...s, isMuted: payload.isMuted } : s);
                        if (self.list === 'listeners') listeners = listeners.map(l => l.id === currentUser.id ? { ...l, isMuted: payload.isMuted } : l);
                    }
                    break;
                 case 'promote-to-host':
                    speakers = speakers.map(s => s.id === payload.userId ? {...s, role: 'host'} : s);
                    break;
                 case 'mute-user':
                    // Admin can ONLY mute, not unmute (toggle removed, set to true)
                    speakers = speakers.map(s => s.id === payload.userId ? {...s, isMutedByHost: true} : s);
                    listeners = listeners.map(l => l.id === payload.userId ? {...l, isMutedByHost: true} : l);
                    break;
                case 'kick-user':
                     const kickedUser = findUser(payload.userId)?.user;
                     if (kickedUser) {
                         speakers = speakers.filter(s => s.id !== payload.userId);
                         listeners = listeners.filter(l => l.id !== payload.userId);
                         // Add to blocked temporarily for session or permanent banned list
                         newRoom.blockedUsers = [...(newRoom.blockedUsers || []), kickedUser];
                     }
                    break;
                case 'block-user':
                    const userToBlock = findUser(payload.userId)?.user;
                    if(userToBlock) {
                        speakers = speakers.filter(s => s.id !== payload.userId);
                        listeners = listeners.filter(l => l.id !== payload.userId);
                        newRoom.blockedUsers = [...(newRoom.blockedUsers || []), userToBlock];
                        
                        // Handle extended details if present
                        if (payload.details) {
                            newRoom.bannedDetails = [...(newRoom.bannedDetails || []), payload.details];
                        }
                    }
                    break;
                 case 'unblock-user':
                    newRoom.blockedUsers = (newRoom.blockedUsers || []).filter(u => u.id !== payload.userId);
                    break;
                case 'accept-request':
                    const userToAccept = newRoom.joinRequests?.find(u => u.id === payload.userId);
                    if(userToAccept) {
                        listeners.push({...userToAccept, role: 'listener'});
                        newRoom.joinRequests = (newRoom.joinRequests || []).filter(u => u.id !== payload.userId);
                    }
                    break;
                case 'decline-request':
                    newRoom.joinRequests = (newRoom.joinRequests || []).filter(u => u.id !== payload.userId);
                    break;
                case 'decline-speaker-request':
                    // Explicitly remove from raised hands without inviting
                    raisedHands = raisedHands.filter(u => u.id !== payload.userId);
                    break;
                case 'toggle-recording':
                    newRoom.isRecording = !newRoom.isRecording;
                    break;
                case 'end-room':
                    // Close for everyone
                    setVoiceRooms(prev => prev.filter(r => r.id !== room.id));
                    if (activeVoiceRoom?.id === room.id) setActiveVoiceRoom(null);
                    return { ...room };
                case 'update-settings':
                    newRoom = { ...newRoom, ...payload };
                     if (payload.openMicMode) {
                        speakers = [...speakers, ...listeners.map(l => ({ ...l, role: 'speaker' as 'speaker' }))];
                        listeners = [];
                    } else if (payload.openMicMode === false && room.openMicMode === true) {
                        const hosts = speakers.filter(s => s.role === 'host');
                        const others = speakers.filter(s => s.role !== 'host');
                        speakers = hosts;
                        listeners = [...listeners, ...others.map(o => ({...o, role: 'listener' as 'listener'}))];
                    }
                    break;
                case 'update-theme':
                    newRoom.theme = payload.theme;
                    break;
                case 'revoke-host':
                    // Downgrade host to speaker
                    speakers = speakers.map(s => s.id === payload.userId ? {...s, role: 'speaker'} : s);
                    break;
                case 'transfer-host':
                    const oldHostId = currentUser?.id;
                    const newHostId = payload.userId;
                    speakers = speakers.map(s => {
                        if (s.id === oldHostId) return { ...s, role: 'speaker' };
                        if (s.id === newHostId) return { ...s, role: 'host' };
                        return s;
                    });
                    break;
                default:
                    break;
            }
            return { ...newRoom, speakers, listeners, raisedHands, invitedSpeakerIds };
        });
    };
    
    const generateCharadesWord = async (): Promise<string> => {
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: "Give me one random, fun, and medium-difficulty charades word or phrase. Make it a single word or a short phrase. For example: 'pancake' or 'milking a cow'. Do not add any explanation or quotation marks, just the word or phrase."
            });
            return response.text || '';
        } catch (error) {
            console.error("Error generating charades word:", error);
            const fallbackWords = ["Telescope", "Brushing your teeth", "Playing guitar", "Typing on a keyboard", "Sumo wrestler"];
            return fallbackWords[Math.floor(Math.random() * fallbackWords.length)];
        }
    };
    
    const handleGameAction = async (action: 'start' | 'next' | 'end' | 'truth' | 'dare' | 'vote' | 'next-actor' | 'get-word', payload?: any) => {
        if (!activeVoiceRoom) return;
        updateVoiceRoom(activeVoiceRoom.id, room => {
            let game = room.game ? { ...room.game } : null;
            if (!game && action !== 'start') return room;

            if (action === 'start') {
                if (payload.gameType === 'truth-or-dare') {
                    game = { type: 'truth-or-dare' };
                } else if (payload.gameType === 'would-you-rather') {
                    const nextQuestion = wouldYouRatherData[Math.floor(Math.random() * wouldYouRatherData.length)];
                    game = { 
                        type: 'would-you-rather',
                        question: nextQuestion.question,
                        optionA: { text: nextQuestion.optionA, votes: [] },
                        optionB: { text: nextQuestion.optionB, votes: [] },
                    };
                } else if (payload.gameType === 'this-or-that') {
                    const nextQuestion = thisOrThatData[Math.floor(Math.random() * thisOrThatData.length)];
                    game = {
                        type: 'this-or-that',
                        question: nextQuestion.question,
                        optionA: { text: nextQuestion.optionA, votes: [] },
                        optionB: { text: nextQuestion.optionB, votes: [] },
                    };
                } else if (payload.gameType === 'charades') {
                    game = {
                        type: 'charades',
                        scores: { teamA: 0, teamB: 0 },
                        timer: 60,
                    };
                }
            } else if (game) {
                 switch (game.type) {
                    case 'truth-or-dare':
                        if(action === 'truth' || action === 'dare') {
                            game.currentPlayer = room.speakers.find(s => s.id === payload.playerId);
                            const challengeText = action === 'truth'
                                ? truthOrDareData.truths[Math.floor(Math.random() * truthOrDareData.truths.length)]
                                : truthOrDareData.dares[Math.floor(Math.random() * truthOrDareData.dares.length)];
                            game.currentChallenge = { type: action, text: challengeText };
                        } else if (action === 'next') {
                            game.currentPlayer = undefined;
                            game.currentChallenge = undefined;
                        } else if (action === 'end') {
                            game = null;
                        }
                        break;
                    case 'would-you-rather':
                    case 'this-or-that':
                         if (action === 'vote' && currentUser) {
                            const voteOption = payload.option as 'A' | 'B';
                            const otherOption = voteOption === 'A' ? 'optionB' : 'optionA';
                            game[otherOption].votes = game[otherOption].votes.filter(u => u.id !== currentUser.id);
                            const targetOption = voteOption === 'A' ? 'optionA' : 'optionB';
                            const userHasVoted = game[targetOption].votes.some(u => u.id === currentUser.id);
                            if (userHasVoted) {
                                game[targetOption].votes = game[targetOption].votes.filter(u => u.id !== currentUser.id);
                            } else {
                                game[targetOption].votes.push(currentUser);
                            }
                        } else if (action === 'next') {
                             const dataSource = game.type === 'would-you-rather' ? wouldYouRatherData : thisOrThatData;
                             const nextQuestion = dataSource[Math.floor(Math.random() * dataSource.length)];
                             game.question = nextQuestion.question;
                             game.optionA = { text: nextQuestion.optionA, votes: [] };
                             game.optionB = { text: nextQuestion.optionB, votes: [] };
                        } else if (action === 'end') {
                            game = null;
                        }
                        break;
                    case 'charades':
                        if (action === 'next-actor') {
                            game.currentActor = room.speakers.find(s => s.id === payload.playerId);
                            game.currentWord = '...'; 
                            const fetchWord = async () => {
                                const word = await generateCharadesWord();
                                updateVoiceRoom(room.id, r => {
                                    if (r.game?.type === 'charades' && r.game.currentActor?.id === payload.playerId) {
                                        return {...r, game: {...r.game, currentWord: word}};
                                    }
                                    return r;
                                });
                            };
                            fetchWord();

                        } else if (action === 'end') {
                            game = null;
                        }
                        break;
                }
            }
            return { ...room, game };
        });
    };

    const handleCreateGroup = (groupData: { name: string, participantIds: number[], description?: string, theme?: string, avatar?: string, isPrivate?: boolean }) => {
        if (!currentUser) return;
        
        // Create a mock group ID (could be a negative number or just a high number to avoid collision in mock data)
        const groupId = Date.now() + Math.random(); 
        const participants = friends.filter(f => groupData.participantIds.includes(f.id));
        
        const groupFriend: Friend = {
            id: groupId,
            name: groupData.name,
            avatar: groupData.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(groupData.name)}&background=random`, // Or a default group icon
            status: 'online', // Groups are conceptually always "active" for now
            isFriend: true
        };
        
        // Update friends list (Groups are treated like friends in the data model for simplicity here)
        // Ideally you'd separate them, but this fits the existing structure
        setFriends(prev => [...prev, groupFriend]);

        // Create conversation
        const newConversation: Conversation = {
            friend: groupFriend,
            messages: [],
            unreadCount: 0,
            isGroup: true,
            groupOwnerId: currentUser.id,
            participants: [currentUser, ...participants],
            description: groupData.description,
            theme: groupData.theme,
            isPublic: !groupData.isPrivate
        };
        
        setConversations(prev => [newConversation, ...prev]);
        addToast({ title: 'Group Created', description: `"${groupData.name}" has been created successfully.`, type: 'success' });
        
        // Optionally navigate to it
        setSelectedFriendId(groupId);
        setActivePage('friends');
    };
    
    if (!currentUser) {
        return <AuthPage onLogin={handleLogin} />;
    }

    const renderPage = () => {
        if (activeRoom) {
            return <WatchRoom 
                room={activeRoom} 
                currentUser={currentUser} 
                onLeave={handleLeaveRoom}
                onBlockUser={handleBlockUser}
                onUnblockUser={handleUnblockUser}
                onUpdateRoomSettings={handleUpdateRoomSettings}
                onUpdateRoom={(updatedRoom) => setActiveRoom(updatedRoom)}
                onKickUser={(userId) => handleKickUser(activeRoom.id, userId)}
                onAcceptRequest={(userId) => handleManageJoinRequest(activeRoom.id, userId, 'accept')}
                onDeclineRequest={(userId) => handleManageJoinRequest(activeRoom.id, userId, 'decline')}
                suggestedVideos={suggestions}
                friends={friends}
                onAddFriend={handleAddFriend}
                onRateRoom={handleRateRoom}
                onForwardMessage={handleForwardMessage}
                onShareRoom={(friendId, room) => handleShareRoom([friendId], room, '')}
                onViewProfile={setViewingProfile}
            />;
        }
        if (activeVoiceRoom) {
            return <VoiceRoomComponent 
                room={activeVoiceRoom} 
                currentUser={currentUser} 
                onLeave={handleLeaveVoiceRoom}
                onRaiseHand={() => handleVoiceRoomAction('raise-hand')}
                onInviteToSpeak={(userId) => handleVoiceRoomAction('invite-to-speak', { userId })}
                onMoveToAudience={(userId) => handleVoiceRoomAction('move-to-audience', { userId })}
                onPromoteToHost={(userId) => handleVoiceRoomAction('promote-to-host', { userId })}
                onMuteUser={(userId) => handleVoiceRoomAction('mute-user', { userId })}
                onKickUser={(userId) => handleVoiceRoomAction('kick-user', { userId })}
                onBlockUser={(userId) => handleVoiceRoomAction('block-user', { userId })}
                onGameAction={handleGameAction}
                onViewProfile={setViewingProfile}
                onSelfMute={(isMuted) => handleVoiceRoomAction('self-mute', { isMuted })}
                onShare={() => handleShareItem(activeVoiceRoom)}
                onOpenSettingsModal={() => setIsVoiceRoomSettingsOpen(true)}
                onOpenStartGameModal={() => setIsStartGameModalOpen(true)}
                onToggleRecording={() => handleVoiceRoomAction('toggle-recording')}
                onEndRoom={() => handleVoiceRoomAction('end-room')}
                onAcceptRequest={(userId) => handleVoiceRoomAction('accept-request', { userId })}
                onDeclineRequest={(userId) => handleVoiceRoomAction('decline-request', { userId })}
            />;
        }

        switch (activePage) {
            case 'settings':
                return <Settings 
                    user={currentUser} 
                    chatBackground={chatBackground} 
                    onChatBackgroundChange={handleChatBackgroundChange}
                    notificationSettings={notificationSettings}
                    onNotificationSettingsChange={handleNotificationSettingsChange}
                    onLogout={handleLogout} 
                    onUpdateProfile={handleUpdateProfile}
                    conversations={conversations}
                    onUnlockChatRequest={(conv) => setLockScreenState({ isOpen: true, mode: 'enter', targetConversation: conv, onSuccess: () => { /* Handle unlock success */ } })}
                    onChangeChatPinRequest={(conv) => setLockScreenState({ isOpen: true, mode: 'setup', targetConversation: conv, onSuccess: (pin) => { /* Handle pin change */ } })}
                    onResetAllChatPins={() => setResetPinsConfirmation(true)}
                    blockedUsers={blockedUsers}
                    onUnblockUser={handleUnblockFriend}
                    onToggleSidebar={() => setShowSidebar(true)}
                    currentTheme={appTheme}
                    onThemeChange={setAppTheme}
                    onCustomThemeChange={setCustomThemeColor}
                />;
            case 'schedule':
                return <SchedulePage
                    scheduledEvents={scheduledEvents}
                    currentUser={currentUser}
                    friends={friends}
                    onScheduleRoom={handleScheduleRoom}
                    onUpdateEvent={handleUpdateEvent}
                    onCancelEvent={handleCancelEvent}
                    onRsvp={handleRsvp}
                    onInviteFriends={handleInviteFriends}
                    onStartParty={handleStartScheduledParty}
                />;
            case 'voice-clubhouse':
                return <VoiceClubhouse 
                    rooms={voiceRooms} 
                    onJoinRoom={handleJoinVoiceRoom} 
                    onStartRoom={() => setIsStartVoiceRoomModalOpen(true)}
                />;
             case 'image-studio':
                return <ImageStudio onUpdateProfile={handleUpdateProfile} onNavigate={setActivePage} />;
             case 'video-studio':
                return <VideoStudio />;
            case 'people-nearby':
                return <PeopleNearby 
                    currentUser={currentUser} 
                    allUsers={allUsersForSearch} 
                    onViewProfile={setViewingProfile}
                    onAddFriend={handleAddFriend}
                    onStartChat={(userId) => { 
                        setSelectedFriendId(userId); 
                        setActivePage('friends'); 
                    }}
                />;
            case 'explore':
                 return <Dashboard title={null} currentUser={currentUser} onJoinRoom={handleJoinRoom} rooms={rooms} onCreateRoom={handleCreateRoom} scheduledEvents={scheduledEvents} onScheduleRoom={handleScheduleRoom} onRequestToJoin={handleRequestToJoin} isExplorePage voiceRooms={voiceRooms} onJoinVoiceRoom={handleJoinVoiceRoom} onOpenShareModal={handleShareItem} />;
            default:
                return <Dashboard title={null} currentUser={currentUser} onJoinRoom={handleJoinRoom} rooms={rooms} onCreateRoom={handleCreateRoom} scheduledEvents={scheduledEvents} onScheduleRoom={handleScheduleRoom} onRequestToJoin={handleRequestToJoin} onOpenShareModal={handleShareItem} />;
        }
    };
    
    return (
        <AudioPlayerProvider>
        <div className="h-full flex text-white overflow-hidden">
            {isLoading ? (
                <div className="w-full h-full flex items-center justify-center"><DashboardSkeleton /></div>
            ) : (
                <>
                    <Sidebar 
                        user={currentUser} 
                        onLogout={handleLogout} 
                        isVisible={showSidebar}
                        activePage={activePage}
                        onNavigate={(page) => {
                             setActiveRoom(null); // Leave room when navigating
                             setActiveVoiceRoom(null);
                             setActivePage(page);
                             setShowSidebar(false);
                        }}
                        totalUnreadCount={totalUnreadCount}
                        onClose={() => setShowSidebar(false)}
                    />
                    <div className="flex-1 flex flex-col min-h-0 min-w-0 transition-all duration-300">
                         {/* Global Header (Visible on both Desktop and Mobile) */}
                        {!activeRoom && !activeVoiceRoom && (
                             <header className={`flex-shrink-0 p-4 flex items-center justify-between z-10 bg-black/20 backdrop-blur-lg border-b border-white/5 ${(activePage === 'friends' || activePage === 'settings') ? 'hidden md:flex' : 'flex'}`}>
                                 {/* Menu Button - Mobile Only */}
                                 <button onClick={() => setShowSidebar(true)} className="md:hidden text-gray-300 hover:text-white">
                                    <MenuIcon className="h-6 w-6" />
                                </button>
                                
                                {/* Page Title */}
                                <h1 className="text-xl font-bold md:ml-0">{pageTitles[activePage]}</h1>
                                
                                {/* Notifications */}
                                <div className="relative">
                                    <button onClick={() => setShowNotificationsPanel(p => !p)} aria-label="Toggle Notifications" className="text-gray-300 hover:text-white">
                                        <BellIcon className="h-6 w-6" />
                                        {unreadNotificationsCount > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">{unreadNotificationsCount}</span>}
                                    </button>
                                    {showNotificationsPanel && <div ref={notificationsRef}><NotificationsPanel notifications={notifications} onClose={() => setShowNotificationsPanel(false)} onMarkAsRead={(id) => setNotifications(n => n.map(notif => notif.id === id ? {...notif, isRead: true} : notif))} onMarkAllAsRead={() => setNotifications(n => n.map(notif => ({...notif, isRead: true})))} onClearAll={() => setNotifications([])} onFriendRequestAction={(id, action) => { /* TODO */ }} /></div>}
                                </div>
                            </header>
                        )}
                        <main className="flex-1 overflow-y-auto">
                            {activePage === 'friends' ? (
                                <FriendsPanel 
                                    currentUser={currentUser}
                                    friends={friends}
                                    pendingRequests={pendingRequests}
                                    sentRequests={sentRequests}
                                    onAcceptRequest={handleAcceptRequest}
                                    onDeclineRequest={handleDeclineRequest}
                                    onCancelRequest={handleCancelRequest}
                                    conversations={conversations}
                                    selectedFriendId={selectedFriendId}
                                    onAttemptSelectFriend={(id) => setSelectedFriendId(id)}
                                    onSendMessage={handleSendMessage}
                                    onDeleteMessage={handleDeleteMessage}
                                    onEditMessage={handleEditMessage}
                                    onPinMessage={handlePinMessage}
                                    onAddReaction={handleAddReaction}
                                    onAddFriend={handleAddFriend}
                                    onGlobalUserSearch={handleGlobalUserSearch}
                                    onJoinRoom={(roomId) => { const r = rooms.find(r => r.id === roomId); if(r) handleJoinRoom(r); }}
                                    onJoinVoiceRoom={(roomId) => { const r = voiceRooms.find(r => r.id === roomId); if(r) handleJoinVoiceRoom(r); }}
                                    onForwardDirectMessage={handleForwardDirectMessage}
                                    onForwardMultipleDirectMessages={handleForwardMultipleDirectMessages}
                                    chatBackground={chatBackground}
                                    onToggleSidebar={() => setShowSidebar(true)}
                                    onViewProfile={setViewingProfile}
                                    onPinChat={(id) => setConversations(c => c.map(conv => conv.friend.id === id ? {...conv, isPinned: !conv.isPinned} : conv))}
                                    onMuteChat={(id) => setConversations(c => c.map(conv => conv.friend.id === id ? {...conv, isMuted: !conv.isMuted} : conv))}
                                    onArchiveChat={(id) => setConversations(c => c.map(conv => conv.friend.id === id ? {...conv, isArchived: !conv.isArchived} : conv))}
                                    onLockChat={(id) => {
                                        const conv = conversations.find(c => c.friend.id === id);
                                        if (!conv) return;
                                        if (conv.lockPin) {
                                            setLockScreenState({ isOpen: true, mode: 'enter', targetConversation: conv, onSuccess: () => {
                                                setConversations(c => c.map(cv => cv.friend.id === id ? {...cv, lockPin: undefined} : cv));
                                                addToast({title: "Chat Unlocked", description: `Chat with ${conv.friend.name} is now unlocked.`, type: 'success'});
                                            }});
                                        } else {
                                             setLockScreenState({ isOpen: true, mode: 'setup', targetConversation: conv, onSuccess: (pin) => {
                                                setConversations(c => c.map(cv => cv.friend.id === id ? {...cv, lockPin: pin} : cv));
                                                addToast({title: "Chat Locked", description: `Chat with ${conv.friend.name} is now locked.`, type: 'info'});
                                            }});
                                        }
                                    }}
                                    onDeleteChat={(id) => setConversations(c => c.filter(conv => conv.friend.id !== id))}
                                    onStartCall={(friend, type) => {
                                        setActiveCall({ friend, state: type, initialState: type });
                                        setIsCallMinimized(false);
                                    }}
                                    onBlockUser={handleBlockFriend}
                                    onUnblockUser={handleUnblockFriend}
                                    blockedUsers={blockedUsers}
                                    onCreateGroup={handleCreateGroup}
                                />
                            ) : renderPage() }
                        </main>
                        {installPrompt && (
                             <div className="absolute bottom-4 right-4 z-50">
                                <button onClick={handleInstallClick} className="flex items-center gap-2 bg-purple-600 text-white font-semibold px-4 py-2 rounded-lg hover:bg-purple-700 animate-fade-in-up">
                                    <DownloadIcon className="w-5 h-5"/>
                                    Install App
                                </button>
                            </div>
                        )}
                    </div>
                    
                    {/* Global Audio Player Overlay (Shows when NOT in chat if music is playing) */}
                    {!selectedFriendId && <GlobalAudioPlayer hide={!!activeRoom || !!activeVoiceRoom} />}

                    {passwordPrompt && <PasswordPromptModal isOpen={!!passwordPrompt} onClose={() => setPasswordPrompt(null)} onSubmit={handlePasswordSubmit} roomName={passwordPrompt.name}/>}
                    {voiceRoomPasswordPrompt && <VoiceRoomPasswordPromptModal isOpen={!!voiceRoomPasswordPrompt} onClose={() => setVoiceRoomPasswordPrompt(null)} onSubmit={handleVoiceRoomPasswordSubmit} roomName={voiceRoomPasswordPrompt.room.topic} roomId={voiceRoomPasswordPrompt.room.id} error={voiceRoomPasswordPrompt.error} onRequestJoin={handleRequestToJoinVoiceRoom} />}
                    {isStartVoiceRoomModalOpen && <StartVoiceRoomModal isOpen={isStartVoiceRoomModalOpen} onClose={() => setIsStartVoiceRoomModalOpen(false)} onCreate={handleCreateVoiceRoom} currentUser={currentUser!} />}
                    {viewingProfile && <EnhancedUserProfileModal 
                        isOpen={!!viewingProfile} 
                        onClose={() => setViewingProfile(null)} 
                        user={viewingProfile} 
                        onAddFriend={handleAddFriend} 
                        currentUserId={currentUser!.id} 
                        onStartChat={(userId) => { setSelectedFriendId(userId); setActivePage('friends'); setViewingProfile(null); }}
                        context={activeVoiceRoom ? 'voice' : activeRoom ? 'watch' : 'general'}
                    />}
                    {sharingVoiceRoom && <ForwardMessageModal isOpen={!!sharingVoiceRoom} onClose={() => setSharingVoiceRoom(null)} friends={friends} onForward={(friendIds, comment) => { handleShareVoiceRoom(friendIds, sharingVoiceRoom, comment); setSharingVoiceRoom(null); }} isSharingRoom shareTitle={`Share "${sharingVoiceRoom.topic}"`} />}
                    {sharingRoom && <ForwardMessageModal isOpen={!!sharingRoom} onClose={() => setSharingRoom(null)} friends={friends} onForward={(friendIds, comment) => { handleShareRoom(friendIds, sharingRoom, comment); setSharingRoom(null); }} isSharingRoom shareTitle={`Share "${sharingRoom.name}"`} />}
                    {activeVoiceRoom && isStartGameModalOpen && <StartGameModal isOpen={isStartGameModalOpen} onClose={() => setIsStartGameModalOpen(false)} onGameAction={(action, payload) => { if(activeVoiceRoom) handleVoiceRoomAction(action, payload); }} />}
                    {activeVoiceRoom && isVoiceRoomSettingsOpen && <VoiceRoomSettingsModal isOpen={isVoiceRoomSettingsOpen} onClose={() => setIsVoiceRoomSettingsOpen(false)} room={activeVoiceRoom} onUpdateSettings={(s) => handleVoiceRoomAction('update-settings', s)} onUpdateTheme={(theme) => handleVoiceRoomAction('update-theme', { theme })} onTransferHost={(userId) => handleVoiceRoomAction('transfer-host', { userId })} onUnblockUser={(userId) => handleVoiceRoomAction('unblock-user', { userId })} onAcceptRequest={(userId) => handleVoiceRoomAction('accept-request', { userId })} onDeclineRequest={(userId) => handleVoiceRoomAction('decline-request', { userId })} />}
                    <LockScreenModal
                        isOpen={lockScreenState.isOpen}
                        mode={lockScreenState.mode}
                        onClose={() => setLockScreenState({ isOpen: false, mode: 'setup' })}
                        targetChatName={lockScreenState.targetConversation?.friend.name}
                        onPinSet={(pin) => {
                            lockScreenState.onSuccess?.(pin);
                            setLockScreenState({ isOpen: false, mode: 'setup' });
                        }}
                        onPinUnlockAttempt={(pin) => {
                            if (lockScreenState.targetConversation?.lockPin === pin) {
                                lockScreenState.onSuccess?.();
                                setLockScreenState({ isOpen: false, mode: 'setup' });
                                return true;
                            }
                            return false;
                        }}
                    />
                     <ConfirmationModal isOpen={resetPinsConfirmation} onClose={() => setResetPinsConfirmation(false)} onConfirm={() => { setConversations(c => c.map(conv => ({...conv, lockPin: undefined}))); setResetPinsConfirmation(false); }} title="Reset All Chat Locks?" message="Are you sure you want to remove PIN protection from all your locked chats? This action cannot be undone." />
                     {activeCall && <CallManager
                        call={activeCall}
                        currentUser={currentUser!}
                        conversation={conversations.find(c => c.friend.id === activeCall.friend.id)!}
                        onEndCall={(duration) => {
                             if (activeCall.initialState.startsWith('incoming') && duration === 0) {
                                // missed call
                                const messageType: DirectMessage['call'] = activeCall.initialState === 'incoming-voice' ? {type: 'voice', status: 'missed'} : {type: 'video', status: 'missed'};
                                handleSendMessage(activeCall.friend.id, {message: '', call: messageType});
                            } else {
                                const messageType: DirectMessage['call'] = activeCall.initialState.includes('voice') ? {type: 'voice', status: 'outgoing', duration} : {type: 'video', status: 'outgoing', duration};
                                handleSendMessage(activeCall.friend.id, {message: '', call: messageType});
                            }
                            setActiveCall(null);
                        }}
                        onAcceptCall={() => {
                            const nextState = activeCall.state === 'incoming-voice' ? 'active-voice' : 'active-video';
                            setActiveCall(c => c ? {...c, state: nextState} : null);
                        }}
                        onChangeState={(newState) => setActiveCall(c => c ? {...c, state: newState} : null)}
                        onSwitchToVideoRequest={() => setShowSwitchToVideoConfirm(true)}
                        onRecordingComplete={(blob, duration) => {
                            handleSendMessage(activeCall.friend.id, {
                                message: '',
                                videoUrl: URL.createObjectURL(blob),
                                caption: `Call Recording (${formatDuration(duration)})`,
                                fileInfo: { name: 'call-recording.webm', size: blob.size }
                            })
                        }}
                        isMinimized={isCallMinimized}
                        onMinimize={() => setIsCallMinimized(true)}
                        onMaximize={() => setIsCallMinimized(false)}
                     />}
                     {showSwitchToVideoConfirm && activeCall && <ConfirmationModal isOpen={showSwitchToVideoConfirm} onClose={() => setShowSwitchToVideoConfirm(false)} onConfirm={() => { setActiveCall(c => c ? {...c, state: 'active-video'} : null); setShowSwitchToVideoConfirm(false); }} title="Switch to Video Call?" message={`${activeCall.friend.name} would like to switch to a video call.`} confirmText="Yes, Switch" />}

                </>
            )}
        </div>
        </AudioPlayerProvider>
    );
};

const App: React.FC = () => {
    return (
        <ToastProvider>
            <AppContent />
        </ToastProvider>
    );
};
export default App;
