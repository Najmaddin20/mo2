import React from 'react';

interface DateSeparatorProps {
    dateString: string;
}

const DateSeparator: React.FC<DateSeparatorProps> = ({ dateString }) => {
    return (
        <div className="flex items-center justify-center my-4" aria-label={`Messages from ${dateString}`}>
            <span className="bg-black/30 text-xs text-gray-400 font-semibold px-3 py-1 rounded-full">
                {dateString}
            </span>
        </div>
    );
};

export default DateSeparator;
