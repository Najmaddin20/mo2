
import React, { useState, useEffect } from 'react';
import type { Room } from '../types';
import { CloseIcon, YouTubeIcon, PublicIcon, PrivateIcon, GoogleIcon, LinkIcon, ImageIcon, CheckIcon } from './icons';

interface CreateRoomModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCreateRoom: (newRoomData: Pick<Room, 'name' | 'nowPlaying' | 'videoUrl' | 'thumbnail' | 'isPublic' | 'password'>) => void;
}

const CreateRoomModal: React.FC<CreateRoomModalProps> = ({ isOpen, onClose, onCreateRoom }) => {
    const [name, setName] = useState('');
    const [nowPlaying, setNowPlaying] = useState('');
    const [videoUrl, setVideoUrl] = useState('');
    const [thumbnail, setThumbnail] = useState('');
    const [isPublic, setIsPublic] = useState(true);
    const [password, setPassword] = useState('');
    const [detectedThumbnail, setDetectedThumbnail] = useState('');
    const [isYouTube, setIsYouTube] = useState(false);
    const [youtubeConnected, setYoutubeConnected] = useState(false);

    // Auto-detect thumbnail and platform from URL
    useEffect(() => {
        if (!videoUrl) {
            setDetectedThumbnail('');
            setIsYouTube(false);
            return;
        }

        const ytMatch = videoUrl.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
        
        if (ytMatch && ytMatch[1]) {
            setDetectedThumbnail(`https://i.ytimg.com/vi/${ytMatch[1]}/maxresdefault.jpg`);
            setIsYouTube(true);
        } else {
            setDetectedThumbnail('');
            setIsYouTube(false);
        }
    }, [videoUrl]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (isYouTube && !youtubeConnected) {
            alert("Please connect your YouTube account to verify playback permissions.");
            return;
        }

        if (name && videoUrl && (!isPublic ? password : true)) {
            let cleanVideoUrl = videoUrl;
            let finalThumbnail = thumbnail;

            const ytMatch = videoUrl.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
            
            if (ytMatch && ytMatch[1]) {
                const videoId = ytMatch[1];
                cleanVideoUrl = `https://www.youtube.com/watch?v=${videoId}`;
                if (!finalThumbnail) {
                    finalThumbnail = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
                }
            } else if (!finalThumbnail) {
                finalThumbnail = `https://picsum.photos/seed/${Math.random()}/500/300`;
            }

            onCreateRoom({
                name,
                nowPlaying: nowPlaying || "Unknown Title",
                videoUrl: cleanVideoUrl,
                thumbnail: finalThumbnail,
                isPublic,
                password: isPublic ? undefined : password,
            });
            
            // Reset
            setName('');
            setNowPlaying('');
            setVideoUrl('');
            setThumbnail('');
            setIsPublic(true);
            setPassword('');
            setDetectedThumbnail('');
            onClose();
        }
    };

    if (!isOpen) return null;

    const previewImage = thumbnail || detectedThumbnail;

    return (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center sm:p-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity" onClick={onClose} />

            <div className="relative w-full sm:max-w-lg bg-[#121214] sm:rounded-3xl rounded-t-[2rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-slide-in-from-bottom border border-white/10">
                
                {/* Header / Preview */}
                <div className="relative h-44 flex-shrink-0 bg-[#1c1c1e] overflow-hidden group">
                    {previewImage ? (
                        <>
                            <img src={previewImage} alt="Preview" className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" />
                            <div className="absolute inset-0 bg-gradient-to-t from-[#121214] via-transparent to-transparent" />
                        </>
                    ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-600 bg-gradient-to-br from-[#1c1c1e] to-[#2a2a2d] opacity-80">
                            <ImageIcon className="w-12 h-12 mb-2 opacity-50" />
                            <span className="text-xs font-bold uppercase tracking-widest">No Cover</span>
                        </div>
                    )}
                    
                    <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-black/40 hover:bg-black/60 text-white rounded-full backdrop-blur-md transition-colors z-20">
                        <CloseIcon className="w-5 h-5" />
                    </button>

                    <div className="absolute bottom-0 left-0 right-0 p-6 z-10">
                        <h2 className="text-3xl font-bold text-white drop-shadow-lg">{name || 'New Room'}</h2>
                        {nowPlaying && <p className="text-sm text-gray-300 drop-shadow-md truncate mt-1 flex items-center gap-2"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"/> {nowPlaying}</p>}
                    </div>
                </div>

                {/* Form */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                    
                    {/* URL Input */}
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Video Link</label>
                        <div className="bg-white/5 p-1 rounded-xl border border-white/10 focus-within:border-[var(--theme-color)] focus-within:bg-white/10 transition-all flex items-center gap-2">
                            <div className="p-2.5 bg-black/30 rounded-lg text-gray-400">
                                <LinkIcon className="w-5 h-5" />
                            </div>
                            <input 
                                type="url" 
                                value={videoUrl}
                                onChange={(e) => setVideoUrl(e.target.value)}
                                placeholder="Paste YouTube URL..." 
                                className="bg-transparent border-none outline-none text-white placeholder-gray-600 text-sm w-full h-full py-2"
                                autoFocus
                            />
                        </div>
                    </div>

                    {/* YouTube Verification */}
                    {isYouTube && (
                        <div className={`p-3 rounded-xl border transition-all flex items-center justify-between ${youtubeConnected ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                            <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-full ${youtubeConnected ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                                    <YouTubeIcon className="w-4 h-4" />
                                </div>
                                <div className="flex flex-col">
                                    <span className="text-xs font-bold text-white">YouTube Access</span>
                                    <span className="text-[10px] text-gray-400">{youtubeConnected ? 'Verified & Ready' : 'Connection Required'}</span>
                                </div>
                            </div>
                            <button 
                                type="button"
                                onClick={() => setYoutubeConnected(!youtubeConnected)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors ${youtubeConnected ? 'bg-transparent text-green-400 border border-green-500/30' : 'bg-white text-black hover:bg-gray-200'}`}
                            >
                                {youtubeConnected ? <><CheckIcon className="w-3 h-3"/> Connected</> : <><GoogleIcon className="w-3 h-3" /> Connect</>}
                            </button>
                        </div>
                    )}

                    {/* Metadata Inputs */}
                    <div className="grid grid-cols-1 gap-4">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Room Details</label>
                            <input 
                                type="text" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="Room Name (e.g. Movie Night)" 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] transition-colors text-sm"
                            />
                            <input 
                                type="text" 
                                value={nowPlaying}
                                onChange={(e) => setNowPlaying(e.target.value)}
                                placeholder="Video Title (optional)" 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] transition-colors text-sm mt-2"
                            />
                        </div>
                    </div>

                    {/* Privacy */}
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Privacy</label>
                        <div className="bg-white/5 p-1 rounded-xl flex">
                            <button 
                                type="button"
                                onClick={() => setIsPublic(true)}
                                className={`flex-1 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all ${isPublic ? 'bg-[#27272a] text-white shadow-sm ring-1 ring-white/10' : 'text-gray-500 hover:text-gray-300'}`}
                            >
                                <PublicIcon className="w-4 h-4" /> Public
                            </button>
                            <button 
                                type="button"
                                onClick={() => setIsPublic(false)}
                                className={`flex-1 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all ${!isPublic ? 'bg-[#27272a] text-white shadow-sm ring-1 ring-white/10' : 'text-gray-500 hover:text-gray-300'}`}
                            >
                                <PrivateIcon className="w-4 h-4" /> Private
                            </button>
                        </div>
                        
                        {!isPublic && (
                            <div className="animate-fade-in mt-2">
                                <input 
                                    type="password" 
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="Set a 4-digit PIN or Password" 
                                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] transition-colors text-sm"
                                />
                            </div>
                        )}
                    </div>
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-white/10 bg-[#18181b] flex-shrink-0">
                    <button
                        onClick={handleSubmit}
                        disabled={!videoUrl || !name}
                        className="w-full py-4 text-white font-bold rounded-xl shadow-lg transition-all transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
                        style={{
                            background: 'linear-gradient(to right, var(--theme-color), color-mix(in srgb, var(--theme-color), white 20%))',
                            boxShadow: '0 10px 15px -3px color-mix(in srgb, var(--theme-color), transparent 80%)'
                        }}
                    >
                        Create Room
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CreateRoomModal;
