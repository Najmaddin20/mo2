
import React, { useState, useRef, useEffect } from 'react';
import { PlayFilledIcon, PauseFilledIcon } from './icons';

interface AudioPlayerProps {
    src: string;
    duration: number;
    waveform?: number[];
    isSent: boolean;
    senderAvatar?: string;
}

const formatTime = (time: number) => {
    if (!isFinite(time) || isNaN(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
};

const AudioPlayer: React.FC<AudioPlayerProps> = ({ src, duration, waveform = [], isSent, senderAvatar }) => {
    const audioRef = useRef<HTMLAudioElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);

    const togglePlay = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                const playPromise = audioRef.current.play();
                if (playPromise !== undefined) {
                    playPromise.catch(error => {
                        // Prevent error if playback is interrupted by unmounting or pausing
                        if (error.name !== 'AbortError') {
                            console.error("Playback failed:", error);
                        }
                        setIsPlaying(false);
                    });
                }
            }
        }
    };

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;
        
        const handlePlay = () => setIsPlaying(true);
        const handlePause = () => setIsPlaying(false);
        const updateProgress = () => {
            if (audio && !isNaN(audio.duration)) {
                const p = (audio.currentTime / audio.duration) * 100;
                setProgress(p);
                setCurrentTime(audio.currentTime);
            }
        };
        const onEnded = () => {
            setIsPlaying(false);
            setProgress(0);
            setCurrentTime(0);
        };

        audio.addEventListener('play', handlePlay);
        audio.addEventListener('pause', handlePause);
        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('ended', onEnded);

        return () => {
            audio.removeEventListener('play', handlePlay);
            audio.removeEventListener('pause', handlePause);
            audio.removeEventListener('timeupdate', updateProgress);
            audio.removeEventListener('ended', onEnded);
        };
    }, [src]);

    // Generate simulated waveform data if none provided or too short
    const barsCount = 30;
    const displayWaveform = React.useMemo(() => {
        if (waveform.length >= barsCount) {
            // Downsample if too many points
            const step = Math.ceil(waveform.length / barsCount);
            return Array.from({ length: barsCount }).map((_, i) => waveform[i * step] || Math.random() * 0.5 + 0.2);
        }
        return Array.from({ length: barsCount }).map(() => Math.random() * 0.6 + 0.2);
    }, [waveform]);

    const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
        e.stopPropagation();
        const audio = audioRef.current;
        if (!audio) return;
        
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percentage = Math.max(0, Math.min(1, x / rect.width));
        
        const newTime = percentage * audio.duration;
        if(isFinite(newTime)) {
            audio.currentTime = newTime;
            setProgress(percentage * 100);
        }
    };

    const buttonStyle = isSent ? { color: 'var(--theme-color)' } : { backgroundColor: 'var(--theme-color)' };

    return (
        <div className={`flex items-center gap-3 p-2 pr-4 rounded-2xl w-full sm:min-w-[260px] transition-colors ${isSent ? 'bg-white/10' : 'bg-black/20'}`} onClick={(e) => e.stopPropagation()}>
            <audio ref={audioRef} src={src} preload="metadata" />
            
            <button 
                onClick={togglePlay} 
                className={`w-10 h-10 flex-shrink-0 flex items-center justify-center rounded-full shadow-md transition-transform hover:scale-105 active:scale-95 ${isSent ? 'bg-white' : 'text-white'}`}
                style={buttonStyle}
            >
                {isPlaying ? <PauseFilledIcon className="w-4 h-4"/> : <PlayFilledIcon className="w-4 h-4 ml-0.5"/>}
            </button>
            
            <div className="flex-1 flex flex-col justify-center gap-1.5 overflow-hidden">
                 {/* Waveform Visualizer */}
                <div 
                    className="flex items-center justify-between h-8 gap-[2px] cursor-pointer group/waveform"
                    onClick={handleSeek}
                >
                    {displayWaveform.map((value, index) => {
                        const barProgress = (index / displayWaveform.length) * 100;
                        const isActive = progress >= barProgress;
                        return (
                            <div key={index} className="w-1.5 rounded-full transition-all duration-200 ease-out group-hover/waveform:scale-y-110"
                                style={{ 
                                    height: `${Math.max(15, value * 100)}%`,
                                    backgroundColor: isActive 
                                        ? (isSent ? '#ffffff' : 'var(--theme-color)') 
                                        : (isSent ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.15)')
                                }}
                            />
                        );
                    })}
                </div>
                <div className={`flex justify-between text-[10px] font-bold tracking-wider px-1 ${isSent ? 'text-white/80' : 'text-gray-400'}`}>
                     <span>{formatTime(currentTime)}</span>
                     <span>{formatTime(duration)}</span>
                </div>
            </div>
        </div>
    );
};

export default AudioPlayer;
