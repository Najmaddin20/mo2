
import React, { useState, useRef, useEffect } from 'react';
import type { User, ChatBackground, NotificationSettings, Conversation, AppTheme } from '../types';
import ChatAppearanceSettings from './ChatAppearanceSettings';
import NotificationsSettings from './NotificationsSettings';
import ChatLocksSettings from './ChatLocksSettings';
import PremiumModal from './PremiumModal';
import VerificationModal from './VerificationModal';
import EditProfileModal from './EditProfileModal';
import { 
    LogoutIcon, TrashIcon, UserIcon, BellIcon, 
    LockClosedIcon, ShieldIcon, PaletteIcon, 
    CameraIcon, EditIcon, CheckIcon, CloseIcon,
    ArrowLeftIcon, ChevronRightIcon, MenuIcon,
    CrownIcon, SparklesIcon, ShieldCheckIcon,
    VerifiedIcon, AtSymbolIcon, PhoneIcon, CalendarIcon,
    EyeIcon, EyeOffIcon, GlobeIcon, TranslateIcon
} from './icons';

interface SettingsProps {
    user: User;
    chatBackground: ChatBackground;
    onChatBackgroundChange: (bg: ChatBackground) => void;
    notificationSettings: NotificationSettings;
    onNotificationSettingsChange: (settings: NotificationSettings) => void;
    onLogout: () => void;
    onUpdateProfile: (updates: Partial<User>) => void;
    conversations: Conversation[];
    onUnlockChatRequest: (conv: Conversation) => void;
    onChangeChatPinRequest: (conv: Conversation) => void;
    onResetAllChatPins: () => void;
    blockedUsers: User[];
    onUnblockUser: (user: User) => void;
    onToggleSidebar?: () => void;
    currentTheme: AppTheme;
    onThemeChange: (theme: AppTheme) => void;
    onCustomThemeChange: (color: string | null) => void;
}

// --- Shared UI Components ---

const SectionHeader: React.FC<{ title: string; description: string }> = ({ title, description }) => (
    <div className="mb-6 animate-fade-in">
        <h2 className="text-2xl font-bold text-white mb-1">{title}</h2>
        <p className="text-sm text-gray-400">{description}</p>
    </div>
);

// --- Sub-Sections ---

const LanguageSettings: React.FC = () => {
    const [appLang, setAppLang] = useState('en');
    const [transLang, setTransLang] = useState('fa');

    const languages = [
        { code: 'en', name: 'English' },
        { code: 'fa', name: 'Persian (Farsi)' },
        { code: 'es', name: 'Spanish' },
        { code: 'fr', name: 'French' },
        { code: 'de', name: 'German' },
        { code: 'ja', name: 'Japanese' },
    ];

    return (
        <div className="space-y-6">
             <SectionHeader title="Language & Region" description="Manage language preferences for the app and translation features." />
             
             <div className="bg-white/5 border border-white/5 rounded-2xl p-4 space-y-6">
                 <div>
                     <label className="block text-xs font-bold text-gray-400 uppercase mb-2">App Language</label>
                     <div className="relative">
                         <select 
                            value={appLang} 
                            onChange={(e) => setAppLang(e.target.value)}
                            className="w-full bg-black/30 text-white border border-white/10 rounded-xl p-3 appearance-none outline-none focus:border-[var(--theme-color)] transition-colors"
                         >
                             {languages.map(lang => <option key={lang.code} value={lang.code} className="bg-[#1c1c1e]">{lang.name}</option>)}
                         </select>
                         <ChevronRightIcon className="w-4 h-4 absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 rotate-90 pointer-events-none"/>
                     </div>
                     <p className="text-[10px] text-gray-500 mt-2">This will change the interface language.</p>
                 </div>

                 <div className="h-px bg-white/5"></div>

                 <div>
                     <label className="block text-xs font-bold text-gray-400 uppercase mb-2 flex items-center gap-2">
                         <TranslateIcon className="w-3 h-3"/> Translation Target
                     </label>
                     <div className="relative">
                         <select 
                            value={transLang} 
                            onChange={(e) => setTransLang(e.target.value)}
                            className="w-full bg-black/30 text-white border border-white/10 rounded-xl p-3 appearance-none outline-none focus:border-[var(--theme-color)] transition-colors"
                         >
                             {languages.map(lang => <option key={lang.code} value={lang.code} className="bg-[#1c1c1e]">{lang.name}</option>)}
                         </select>
                         <ChevronRightIcon className="w-4 h-4 absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 rotate-90 pointer-events-none"/>
                     </div>
                     <p className="text-[10px] text-gray-500 mt-2">Messages will be translated to this language when you use the translate feature.</p>
                 </div>
             </div>
        </div>
    );
}

const BlockedUsersSettings: React.FC<{
    blockedUsers: User[];
    onUnblockUser: (user: User) => void;
}> = ({ blockedUsers, onUnblockUser }) => {
    return (
        <div>
            <SectionHeader title="Blocked Users" description="Manage users you have blocked. They cannot message or find you." />
            
            <div className="space-y-3">
                {blockedUsers.length > 0 ? (
                    blockedUsers.map(user => (
                        <div key={user.id} className="flex items-center justify-between p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl transition-all group">
                            <div className="flex items-center gap-4">
                                <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full object-cover border-2 border-white/10" />
                                <div>
                                    <p className="font-bold text-white">{user.name}</p>
                                    <p className="text-xs text-gray-500">Blocked</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => onUnblockUser(user)} 
                                className="px-4 py-2 text-xs font-bold text-white bg-white/10 hover:bg-blue-500 rounded-lg transition-colors"
                            >
                                Unblock
                            </button>
                        </div>
                    ))
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 px-4 rounded-2xl bg-white/5 border border-dashed border-white/10 text-center">
                        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                            <ShieldIcon className="w-8 h-8 text-gray-600" />
                        </div>
                        <p className="text-gray-400 font-medium">No blocked users</p>
                        <p className="text-xs text-gray-500 mt-1">Your peace of mind is intact.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

const ProfileSettings: React.FC<{user: User, onUpdateProfile: (updates: Partial<User>) => void}> = ({ user, onUpdateProfile }) => {
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [showVerifyModal, setShowVerifyModal] = useState(false);

    const handleVerifySuccess = () => {
        onUpdateProfile({ isVerified: true });
        setShowVerifyModal(false);
    };
    
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-end mb-2 animate-fade-in">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-1">Profile</h2>
                    <p className="text-sm text-gray-400">Manage your public identity and private details.</p>
                </div>
                <button 
                    onClick={() => setIsEditModalOpen(true)}
                    className="px-5 py-2.5 bg-[var(--theme-color)] hover:brightness-110 text-white text-sm font-bold rounded-xl shadow-lg shadow-[var(--theme-color)]/20 transition-all active:scale-95 flex items-center gap-2"
                >
                    <EditIcon className="w-4 h-4" /> Edit Profile
                </button>
            </div>
            
            {/* Profile Card - Visible mostly on Desktop */}
            <div className="hidden md:block relative rounded-3xl overflow-hidden bg-[#121212] border border-white/10 shadow-2xl">
                {/* Banner */}
                <div 
                    className="h-48 bg-cover bg-center relative"
                    style={{ backgroundImage: `url(${user.profileBanner || 'https://picsum.photos/seed/banner/600/200'})`, backgroundColor: '#2a2a2a' }}
                >
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#121212]/20 to-[#121212]"></div>
                </div>

                {/* Avatar & Info */}
                <div className="px-8 pb-8 relative flex flex-col sm:flex-row items-end gap-6 -mt-16">
                    <div className="relative shrink-0">
                         <div className="w-32 h-32 rounded-full p-1.5 bg-[#121212] relative z-10 ring-1 ring-white/5">
                            <img 
                                src={user.avatar} 
                                alt={user.name} 
                                className="w-full h-full rounded-full object-cover bg-[#1e1e1e]" 
                            />
                        </div>
                        
                        {/* Verification Badge */}
                        <div className="absolute bottom-2 right-2 z-20">
                            {user.isVerified ? (
                                <div className="w-8 h-8 bg-blue-500 rounded-full border-4 border-[#121212] flex items-center justify-center shadow-sm text-white" title="Verified">
                                    <CheckIcon className="w-4 h-4" />
                                </div>
                            ) : (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); setShowVerifyModal(true); }}
                                    className="w-8 h-8 bg-[#1c1c1e] rounded-full border-4 border-[#121212] flex items-center justify-center shadow-sm text-gray-500 hover:text-blue-500 hover:bg-white transition-all group/badge"
                                    title="Get Verified"
                                >
                                     <VerifiedIcon className="w-4 h-4" />
                                </button>
                            )}
                        </div>
                    </div>
                    
                     <div className="flex-1 w-full sm:w-auto text-center sm:text-left mb-3">
                        <div className="flex items-center justify-center sm:justify-start gap-2">
                            <h3 className="text-3xl font-bold text-white tracking-tight">{user.name}</h3>
                            {user.isVerified && <VerifiedIcon className="w-6 h-6 text-blue-500" />}
                        </div>
                        <p className="text-base text-gray-400 font-medium">@{user.name.toLowerCase().replace(/\s/g, '')}</p>
                    </div>
                </div>

                {/* Bio & Stats */}
                <div className="px-8 pb-8">
                    <div className="bg-white/5 rounded-2xl p-5 border border-white/5 mb-6">
                         <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Bio</h4>
                        <p className="text-sm text-gray-200 leading-relaxed">{user.bio || "No biography provided."}</p>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                        <div className="bg-black/20 rounded-xl p-4 text-center border border-white/5">
                             <span className="block text-xl font-bold text-white">{user.friendsCount || 0}</span>
                             <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Friends</span>
                        </div>
                         <div className="bg-black/20 rounded-xl p-4 text-center border border-white/5">
                             <span className="block text-xl font-bold text-white">{user.voiceStats?.roomsHosted || 0}</span>
                             <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Hosted</span>
                        </div>
                         <div className="bg-black/20 rounded-xl p-4 text-center border border-white/5">
                             <span className="block text-xl font-bold text-white">12</span>
                             <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Groups</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Mobile Simplified View */}
            <div className="md:hidden bg-[#1c1c1e] rounded-3xl p-6 flex flex-col items-center text-center border border-white/5">
                 <div className="relative mb-4">
                    <img src={user.avatar} className="w-24 h-24 rounded-full object-cover border-4 border-[#252528]" />
                     {user.isVerified && <div className="absolute bottom-0 right-0 bg-blue-500 text-white p-1 rounded-full border-4 border-[#1c1c1e]"><CheckIcon className="w-3 h-3"/></div>}
                 </div>
                 <h2 className="text-2xl font-bold text-white mb-1">{user.name}</h2>
                 <p className="text-gray-500 text-sm mb-6">@{user.name.toLowerCase().replace(/\s/g, '')}</p>
                 
                 <div className="grid grid-cols-2 gap-3 w-full">
                     <button onClick={() => setIsEditModalOpen(true)} className="py-3 bg-[var(--theme-color)] text-white font-bold rounded-xl text-sm shadow-lg">Edit Profile</button>
                     <button onClick={() => setShowVerifyModal(true)} className="py-3 bg-white/5 text-white font-bold rounded-xl text-sm border border-white/10">Get Verified</button>
                 </div>
            </div>

            <EditProfileModal 
                isOpen={isEditModalOpen} 
                onClose={() => setIsEditModalOpen(false)} 
                user={user} 
                onUpdateProfile={onUpdateProfile} 
            />

            <VerificationModal 
                isOpen={showVerifyModal} 
                onClose={() => setShowVerifyModal(false)} 
                onVerify={handleVerifySuccess}
            />
        </div>
    );
};

const THEMES: { id: AppTheme, name: string, gradient: string, color: string, isPremium: boolean }[] = [
    // Free Themes (Darker, good for white text)
    { id: 'cosmic', name: 'Cosmic', gradient: 'from-indigo-500 to-purple-600', color: '#8A79F7', isPremium: false },
    { id: 'emerald', name: 'Emerald', gradient: 'from-green-600 to-emerald-800', color: '#34D399', isPremium: false },
    { id: 'ocean', name: 'Ocean', gradient: 'from-blue-600 to-cyan-700', color: '#60A5FA', isPremium: false },
    { id: 'crimson', name: 'Crimson', gradient: 'from-red-600 to-orange-700', color: '#F87171', isPremium: false },
    
    // Premium Themes
    { id: 'sunset', name: 'Sunset', gradient: 'from-orange-400 to-pink-500', color: '#F472B6', isPremium: true },
    { id: 'lavender', name: 'Lavender', gradient: 'from-purple-300 to-indigo-400', color: '#C084FC', isPremium: true },
    { id: 'mint', name: 'Mint', gradient: 'from-teal-300 to-emerald-400', color: '#2DD4BF', isPremium: true },
    { id: 'cyber', name: 'Cyber', gradient: 'from-cyan-400 to-blue-500', color: '#06B6D4', isPremium: true },
    { id: 'luxury', name: 'Luxury', gradient: 'from-yellow-400 to-amber-600', color: '#FBBF24', isPremium: true },
    { id: 'midnight', name: 'Midnight', gradient: 'from-indigo-800 to-slate-900', color: '#818CF8', isPremium: true },
    { id: 'slate', name: 'Slate', gradient: 'from-slate-400 to-gray-600', color: '#94A3B8', isPremium: true },
];

const AppearanceSettings: React.FC<{ 
    currentTheme: AppTheme, 
    onThemeChange: (theme: AppTheme) => void,
    onCustomThemeChange: (color: string | null) => void,
    isUserPremium: boolean,
    onOpenPremium: () => void
}> = ({ currentTheme, onThemeChange, onCustomThemeChange, isUserPremium, onOpenPremium }) => {
    
    const [isCustomMode, setIsCustomMode] = useState(false);
    const [customColor, setCustomColor] = useState('#ffffff');
    const colorInputRef = useRef<HTMLInputElement>(null);

    const handlePresetClick = (theme: typeof THEMES[0]) => {
        if (theme.isPremium && !isUserPremium) {
            onOpenPremium();
            return;
        }
        setIsCustomMode(false);
        onCustomThemeChange(null);
        onThemeChange(theme.id);
    };

    const handleCustomColorClick = () => {
        if (!isUserPremium) {
            onOpenPremium();
            return;
        }
        setIsCustomMode(true);
        colorInputRef.current?.click();
    };

    const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const color = e.target.value;
        setCustomColor(color);
        onCustomThemeChange(color);
    };

    return (
        <div className="space-y-8">
            <div className="flex justify-between items-end">
                <SectionHeader title="App Theme" description="Customize the accent color and overall feel." />
                {!isUserPremium && (
                    <button 
                        onClick={onOpenPremium}
                        className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-amber-600 text-white font-bold text-xs rounded-full shadow-lg hover:shadow-amber-500/30 transition-all flex items-center gap-1 mb-6"
                    >
                        <CrownIcon className="w-3 h-3" /> Go Premium
                    </button>
                )}
            </div>
            
            {/* Premium Custom Color Card */}
            <div 
                onClick={handleCustomColorClick}
                className={`relative p-5 rounded-2xl border transition-all cursor-pointer group overflow-hidden ${isCustomMode ? 'bg-gradient-to-br from-yellow-900/20 to-amber-900/10 border-yellow-500/50 ring-1 ring-yellow-500/30' : 'bg-[#1c1c1e] border-white/10 hover:border-white/20'}`}
            >
                <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
                    <CrownIcon className="w-24 h-24 text-yellow-500 rotate-12" />
                </div>
                
                <div className="relative z-10 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div 
                            className="w-12 h-12 rounded-full shadow-lg flex items-center justify-center transition-all"
                            style={{ background: isCustomMode ? customColor : 'linear-gradient(135deg, #FBBF24, #D97706)' }}
                        >
                            {isCustomMode ? (
                                <PaletteIcon className="w-6 h-6 text-white drop-shadow-md" />
                            ) : (
                                <CrownIcon className="w-6 h-6 text-white drop-shadow-md" />
                            )}
                        </div>
                        <div>
                            <h3 className={`font-bold text-lg flex items-center gap-2 ${isCustomMode ? 'text-white' : 'text-yellow-400'}`}>
                                {isCustomMode ? 'Custom Color Active' : 'Premium Custom Color'}
                                {!isUserPremium && <LockClosedIcon className="w-4 h-4 opacity-60" />}
                            </h3>
                            <p className="text-xs text-gray-400">Pick any color from the spectrum.</p>
                        </div>
                    </div>
                    
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${isCustomMode ? 'bg-yellow-500 border-yellow-500' : 'border-gray-600'}`}>
                        {isCustomMode && <CheckIcon className="w-4 h-4 text-black" />}
                    </div>
                </div>
                
                <input 
                    type="color" 
                    ref={colorInputRef} 
                    value={customColor} 
                    onChange={handleColorChange}
                    className="absolute opacity-0 pointer-events-none" 
                />
            </div>

            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mt-8 mb-4 pl-1">Preset Themes</h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {THEMES.map((theme) => {
                    const isActive = !isCustomMode && currentTheme === theme.id;
                    const isLocked = theme.isPremium && !isUserPremium;
                    
                    return (
                        <button 
                            key={theme.id}
                            onClick={() => handlePresetClick(theme)}
                            className={`relative group rounded-2xl transition-all overflow-hidden ${isActive ? 'ring-2 ring-white scale-[1.02] shadow-xl' : 'hover:scale-[1.02] hover:shadow-lg'}`}
                        >
                            {/* Gradient Preview */}
                            <div className={`h-24 bg-gradient-to-br ${theme.gradient} p-3 flex flex-col justify-end relative`}>
                                <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors"></div>
                                <div className="relative z-10 flex justify-between items-end w-full">
                                    <span className="font-bold text-white text-shadow drop-shadow-md">{theme.name}</span>
                                    {isLocked && (
                                        <div className="bg-black/40 backdrop-blur-sm p-1 rounded-full text-white/80">
                                            <LockClosedIcon className="w-3.5 h-3.5" />
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            {/* Active Check */}
                            {isActive && (
                                <div className="absolute top-2 right-2 bg-white text-black p-1 rounded-full shadow-sm animate-bounce-in">
                                    <CheckIcon className="w-3 h-3" />
                                </div>
                            )}
                        </button>
                    )
                })}
            </div>
        </div>
    );
};

const AccountSettings: React.FC<{onLogout: () => void}> = ({ onLogout }) => (
    <div className="space-y-8">
        <SectionHeader title="Account" description="Manage your login session and data." />
        
        <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-5 flex items-center justify-between border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                <div>
                    <p className="font-bold text-white">Log Out</p>
                    <p className="text-xs text-gray-400 mt-0.5">End your current session on this device.</p>
                </div>
                <button
                    onClick={onLogout}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-bold rounded-lg text-white bg-white/10 hover:bg-white/20 transition-colors"
                >
                    <LogoutIcon className="w-4 h-4" />
                    <span>Logout</span>
                </button>
            </div>
        </div>

        <div className="border border-red-500/30 bg-red-500/5 rounded-2xl p-6">
            <h3 className="text-red-400 font-bold flex items-center gap-2 mb-2"><ShieldIcon className="w-5 h-5"/> Danger Zone</h3>
            <p className="text-gray-400 text-sm mb-6">Once you delete your account, there is no going back. Please be certain.</p>
            <button
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-bold rounded-xl text-white bg-red-600 hover:bg-red-700 transition-all shadow-lg shadow-red-600/20 opacity-50 cursor-not-allowed"
                disabled
            >
                <TrashIcon className="w-4 h-4" />
                <span>Delete Account</span>
            </button>
        </div>
    </div>
);

// --- Main Component ---

const Settings: React.FC<SettingsProps> = (props) => {
    const { user, chatBackground, onChatBackgroundChange, notificationSettings, onNotificationSettingsChange, onLogout, onUpdateProfile, conversations, onUnlockChatRequest, onChangeChatPinRequest, onResetAllChatPins, blockedUsers, onUnblockUser, onToggleSidebar, currentTheme, onThemeChange, onCustomThemeChange } = props;
    
    const [activeTab, setActiveTab] = useState('profile');
    const [showMobileDetail, setShowMobileDetail] = useState(false);
    
    // Premium State Mock
    const [isUserPremium, setIsUserPremium] = useState(false);
    const [showPremiumModal, setShowPremiumModal] = useState(false);
    
    // Config for premium modal texts
    const [premiumModalConfig, setPremiumModalConfig] = useState({
        title: '',
        description: ''
    });

    const settingsSections = [
        {
            title: "Account & Profile",
            items: [
                { id: 'profile', label: 'Profile', icon: <UserIcon className="w-5 h-5" /> },
                { id: 'account', label: 'Account', icon: <LogoutIcon className="w-5 h-5" /> },
            ]
        },
        {
            title: "Appearance",
            items: [
                 { id: 'appearance', label: 'App Theme', icon: <EditIcon className="w-5 h-5" /> },
                 { id: 'chat', label: 'Chat Appearance', icon: <PaletteIcon className="w-5 h-5" /> },
            ]
        },
        {
             title: "General",
             items: [
                 { id: 'language', label: 'Language', icon: <GlobeIcon className="w-5 h-5" /> },
                 { id: 'notifications', label: 'Notifications', icon: <BellIcon className="w-5 h-5" /> },
             ]
        },
        {
            title: "Privacy & Safety",
            items: [
                { id: 'chat-locks', label: 'Privacy & Locks', icon: <LockClosedIcon className="w-5 h-5" /> },
                { id: 'blocked', label: 'Blocked Users', icon: <ShieldIcon className="w-5 h-5" /> },
            ]
        }
    ];

    const handleTabSelect = (id: string) => {
        setActiveTab(id);
        setShowMobileDetail(true);
    };

    const handleBack = () => {
        setShowMobileDetail(false);
    };

    const handleUpgrade = () => {
        setIsUserPremium(true);
        setShowPremiumModal(false);
    };
    
    const triggerPremium = (type: 'general' | 'chat-appearance') => {
        if (type === 'chat-appearance') {
            setPremiumModalConfig({
                title: 'Unlock Chat Themes',
                description: 'Customize your chats with premium gradients and patterns.'
            });
        } else {
            setPremiumModalConfig({
                title: '',
                description: ''
            });
        }
        setShowPremiumModal(true);
    };

    return (
        <div className="h-full flex flex-col md:flex-row md:p-6 max-w-7xl mx-auto w-full">
            
            {/* Navigation List (Mobile: Full screen list, Desktop: Sidebar) */}
            <aside className={`
                flex-col w-full md:w-72 md:mr-6 
                bg-black/20 backdrop-blur-xl border-r border-white/5 md:border md:border-white/10 md:rounded-3xl 
                overflow-y-auto z-10 h-full
                ${showMobileDetail ? 'hidden md:flex' : 'flex'}
            `}>
                
                {/* Mobile Top Header - Transparent Glass */}
                <div className="flex items-center justify-between px-4 py-4 md:hidden border-b border-white/5 sticky top-0 bg-black/20 backdrop-blur-xl z-20">
                    <button onClick={onToggleSidebar} className="text-gray-400">
                         <MenuIcon className="w-6 h-6" />
                    </button>
                    <span className="font-bold text-white text-lg">Settings</span>
                    <div className="relative">
                        <BellIcon className="w-6 h-6 text-gray-400" />
                        <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                    </div>
                </div>

                {/* Desktop Title */}
                <div className="p-6 pb-4 hidden md:block">
                    <h1 className="text-3xl md:text-2xl font-bold text-white">Settings</h1>
                </div>
                
                {/* Mobile Big Title */}
                <div className="px-4 py-6 md:hidden">
                    <h1 className="text-3xl font-bold text-white">Settings</h1>
                </div>

                <nav className="flex-1 px-4 pb-4 space-y-6">
                    {settingsSections.map((section, idx) => (
                        <div key={idx}>
                            <h3 className="px-4 text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">{section.title}</h3>
                            <div className="space-y-1">
                                {section.items.map((item) => (
                                    <button
                                        key={item.id}
                                        onClick={() => handleTabSelect(item.id)}
                                        className={`
                                            w-full flex items-center justify-between p-3 rounded-xl transition-all group
                                            bg-white/5 backdrop-blur-md border border-white/5 shadow-sm active:scale-[0.98] text-white
                                            md:border-none md:shadow-none md:active:scale-100
                                            ${activeTab === item.id 
                                                ? 'md:bg-[var(--theme-color)] md:text-white md:shadow-lg md:shadow-[var(--theme-color)]/20' 
                                                : 'md:bg-transparent md:text-gray-400 md:hover:text-white md:hover:bg-white/5'
                                            }
                                        `}
                                    >
                                        <div className="flex items-center gap-4">
                                            <div className={`
                                                text-gray-400
                                                ${activeTab === item.id ? 'md:text-white' : 'md:text-gray-500 md:group-hover:text-white'}
                                            `}>
                                                {item.icon}
                                            </div>
                                            <span className="font-semibold text-sm">{item.label}</span>
                                        </div>
                                        <ChevronRightIcon className={`w-4 h-4 text-gray-600 ${activeTab === item.id ? 'md:text-white' : ''}`} />
                                    </button>
                                ))}
                            </div>
                        </div>
                    ))}
                </nav>
                
                {/* User Mini Profile at bottom of nav */}
                <div className="p-4 mt-auto">
                    <div className={`flex items-center gap-4 p-4 rounded-2xl border border-white/5 ${window.innerWidth < 768 ? 'bg-white/5 backdrop-blur-md' : 'bg-white/5'}`}>
                        <img src={user.avatar} className="w-12 h-12 rounded-full object-cover" alt={user.name} />
                        <div className="min-w-0">
                            <p className="text-base font-bold text-white truncate flex items-center gap-1">
                                {user.name}
                                {user.isVerified && <VerifiedIcon className="w-3.5 h-3.5 text-blue-400" />}
                            </p>
                            <p className="text-sm text-gray-500 truncate">{isUserPremium ? 'Premium Member' : 'Free Member'}</p>
                        </div>
                    </div>
                </div>
            </aside>

            {/* Detail View (Mobile: Slide-in overlay, Desktop: Content area) */}
            <main className={`
                flex-1 min-w-0 flex-col
                md:bg-black/20 md:backdrop-blur-xl md:border md:border-white/10 md:rounded-3xl 
                relative overflow-hidden
                ${showMobileDetail 
                    ? 'flex fixed inset-0 z-50 bg-black/40 backdrop-blur-3xl animate-slide-in-right md:static md:bg-transparent md:z-auto md:animate-none' 
                    : 'hidden md:flex'}
            `}>
                {/* Mobile Detail Header - Transparent */}
                <div className="flex items-center gap-3 p-4 md:hidden bg-transparent sticky top-0 z-20">
                    <button onClick={handleBack} className="p-2 -ml-2 text-blue-400 hover:text-blue-300 active:scale-95 transition-transform flex items-center gap-1 bg-black/20 backdrop-blur-md rounded-full pr-4">
                        <ArrowLeftIcon className="w-6 h-6" />
                        <span className="text-base font-medium">Back</span>
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-10 custom-scrollbar">
                    <div key={activeTab} className="animate-fade-in-up max-w-3xl mx-auto md:mx-0 min-h-full pb-20 md:pb-0">
                        {activeTab === 'profile' && <ProfileSettings user={user} onUpdateProfile={onUpdateProfile} />}
                        {activeTab === 'appearance' && (
                            <AppearanceSettings 
                                currentTheme={currentTheme} 
                                onThemeChange={onThemeChange} 
                                onCustomThemeChange={onCustomThemeChange}
                                isUserPremium={isUserPremium}
                                onOpenPremium={() => triggerPremium('general')}
                            />
                        )}
                        {activeTab === 'chat' && (
                            <ChatAppearanceSettings 
                                currentBackground={chatBackground} 
                                onBackgroundChange={onChatBackgroundChange}
                                isUserPremium={isUserPremium}
                                onOpenPremium={() => triggerPremium('chat-appearance')}
                            />
                        )}
                        {activeTab === 'chat-locks' && (
                            <ChatLocksSettings 
                                lockedConversations={conversations.filter(c => !!c.lockPin)}
                                onUnlockRequest={onUnlockChatRequest}
                                onChangePinRequest={onChangeChatPinRequest}
                                onResetAllPins={onResetAllChatPins}
                            />
                        )}
                        {activeTab === 'notifications' && <NotificationsSettings settings={notificationSettings} onSettingsChange={onNotificationSettingsChange} />}
                        {activeTab === 'blocked' && <BlockedUsersSettings blockedUsers={blockedUsers} onUnblockUser={onUnblockUser} />}
                        {activeTab === 'account' && <AccountSettings onLogout={onLogout} />}
                        {activeTab === 'language' && <LanguageSettings />}
                    </div>
                </div>
            </main>
            
            <PremiumModal 
                isOpen={showPremiumModal} 
                onClose={() => setShowPremiumModal(false)} 
                onUpgrade={handleUpgrade}
                customTitle={premiumModalConfig.title}
                customDescription={premiumModalConfig.description}
            />
            
            <style>{`
                @keyframes slideInRight {
                    from { transform: translateX(100%); }
                    to { transform: translateX(0); }
                }
                .animate-slide-in-right {
                    animation: slideInRight 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                @keyframes bounce-in { 0% { transform: scale(0.5); opacity: 0; } 60% { transform: scale(1.1); opacity: 1; } 100% { transform: scale(1); } }
                .animate-bounce-in { animation: bounce-in 0.3s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default Settings;
