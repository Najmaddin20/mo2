
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import type { User, Conversation, DirectMessage, Friend, ChatBackground, CallState, AudioTrack } from '../types';
import { SendIcon, ArrowLeftIcon, PinIcon, ReplyIcon, TrashIcon, CloseIcon, AttachmentIcon, EmojiIcon, MicrophoneIcon, ForwardIcon, CheckIcon, ChevronDownIcon, PhoneIcon, VideoCameraIcon, IncomingCallIcon, OutgoingCallIcon, MissedVoiceCallIcon, MissedVideoCallIcon, OutgoingVideoCallIcon, IncomingVideoCallIcon, PlayIcon, BlockUserIcon, ShieldIcon, SearchIcon, VerifiedIcon } from './icons';
import VoiceMessageRecorder from './VoiceMessageRecorder';
import AdvancedForwardModal from './AdvancedForwardModal';
import JumpToLatestButton from './JumpToLatestButton';
import { DirectMessageItem } from './DirectMessageItem';
import MessageActionOverlay from './MessageActionOverlay';
import DateSeparator from './DateSeparator';
import { ChatHeaderMiniPlayer, useAudioPlayer, PlaylistBottomSheet } from './AudioPlayerSystem';
import ImageEditorModal from './ImageEditorModal';
import { GoogleGenAI } from "@google/genai";

// ... (Helper functions formatCallDuration, CallStatusIcon, CallMessageItem remain unchanged)
const isSameDay = (d1: Date, d2: Date) => {
    return d1.getFullYear() === d2.getFullYear() &&
           d1.getMonth() === d2.getMonth() &&
           d1.getDate() === d2.getDate();
};

const formatDateSeparator = (date: Date): string => {
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    if (isSameDay(date, today)) return 'Today';
    if (isSameDay(date, yesterday)) return 'Yesterday';
    
    return date.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};

const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0) return `${mins} min ${secs} sec`;
    return `${secs} sec`;
};

const CallStatusIcon: React.FC<{ call: NonNullable<DirectMessage['call']>, isSent: boolean }> = ({ call, isSent }) => {
    const isMissed = call.status === 'missed';
    const isOutgoing = call.status === 'outgoing';
    const isVideo = call.type === 'video';

    const iconColor = isMissed ? 'text-red-500' : 'text-white';
    const iconSize = "w-5 h-5";
    
    // If the bubble is red for a missed call, the icon inside should be white for contrast
    const missedIconColor = !isSent ? 'text-white' : 'text-red-300';

    if (isMissed) {
        return isVideo 
            ? <MissedVideoCallIcon className={`${iconSize} ${missedIconColor}`} /> 
            : <MissedVoiceCallIcon className={`${iconSize} ${missedIconColor}`} />;
    }
    if (isOutgoing) {
        return isVideo 
            ? <OutgoingVideoCallIcon className={`${iconSize} text-white`} /> 
            : <OutgoingCallIcon className={`${iconSize} text-white`} />;
    }
    // Incoming
    return isVideo 
        ? <IncomingVideoCallIcon className={`${iconSize} text-white`} /> 
        : <IncomingCallIcon className={`${iconSize} text-white`} />;
};


const CallMessageItem: React.FC<{ message: DirectMessage; friend: Friend; onStartCall: (friend: Friend, type: CallState) => void; isSent: boolean }> = ({ message, friend, onStartCall, isSent }) => {
    const { call } = message;
    if (!call) return null;

    const isMissed = call.status === 'missed';
    const isVideo = call.type === 'video';

    let title = '';
    if (isVideo) {
        title = isMissed ? 'Missed video call' : 'Video call';
    } else {
        title = isMissed ? 'Missed voice call' : 'Voice call';
    }

    let subtitle = '';
    if (isMissed) {
        subtitle = 'Tap to call back';
    } else if (call.duration) {
        subtitle = formatCallDuration(call.duration);
    } else {
        subtitle = call.status === 'outgoing' ? 'Unanswered' : 'Cancelled';
    }

    const handleCallback = () => {
        if (isMissed) {
            onStartCall(friend, isVideo ? 'outgoing-video' : 'outgoing-voice');
        }
    };

    const bubbleClasses = isSent
        ? '' // Background handled by style for theme color
        : 'bg-[#2f2b43]';
    
    const titleClasses = isMissed && !isSent ? 'text-red-400' : 'text-white';
    const subtitleClasses = isSent ? 'text-gray-200' : 'text-gray-400';

    return (
        <div className={`flex items-start gap-3 my-2 ${isSent ? 'flex-row-reverse' : ''}`} onClick={handleCallback}>
            {false && <img src={friend.avatar} alt={friend.name} className="w-10 h-10 rounded-full self-start" />}
            
            <div className={`flex flex-col ${isSent ? 'items-end' : 'items-start'}`}>
                <div 
                    className={`flex items-center gap-3 p-2.5 rounded-xl max-w-xs ${bubbleClasses} ${isMissed ? 'cursor-pointer' : ''}`}
                    style={isSent ? { backgroundColor: 'var(--theme-color)' } : {}}
                >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isMissed ? (isSent ? 'bg-red-500/50' : 'bg-red-500') : (isSent ? 'bg-white/20' : 'bg-black/20')}`}>
                        <CallStatusIcon call={call} isSent={isSent} />
                    </div>
                    <div>
                        <p className={`font-semibold ${titleClasses}`}>{title}</p>
                        <p className={`text-sm ${subtitleClasses}`}>{subtitle}</p>
                    </div>
                </div>
                <span className={`text-xs mt-1 px-1 ${isSent ? 'text-gray-500' : 'text-gray-500'}`}>{message.displayTime}</span>
            </div>
        </div>
    );
};

interface AdvancedChatProps {
    currentUser: User;
    conversation: Conversation;
    friends: Friend[];
    onSendMessage: (message: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'>) => void;
    onDeleteMessage: (messageIds: number | number[]) => void;
    onEditMessage: (messageId: number, newText: string) => void;
    onPinMessage: (messageId: number) => void;
    onAddReaction: (messageId: number, emoji: string) => void;
    onBack: () => void;
    onJoinRoom: (roomId: number) => void;
    onJoinVoiceRoom: (roomId: number) => void;
    onForwardMultipleMessages: (toFriendIds: number[], messages: DirectMessage[]) => void; 
    onViewMedia: (media: DirectMessage) => void;
    chatBackground: ChatBackground;
    onHeaderClick: () => void;
    onStartCall: (friend: Friend, type: CallState) => void;
    blockedUsers: User[];
    onUnblockUser?: (user: User) => void;
    onViewProfile?: (user: User) => void; 
}

const AdvancedChat: React.FC<AdvancedChatProps> = (props) => {
    const { currentUser, conversation, friends, onSendMessage, onDeleteMessage, onEditMessage, onPinMessage, onAddReaction, onBack, onJoinRoom, onJoinVoiceRoom, onForwardMultipleMessages, onViewMedia, chatBackground, onHeaderClick, onStartCall, blockedUsers, onUnblockUser, onViewProfile } = props;
    
    const [replyingTo, setReplyingTo] = useState<DirectMessage | null>(null);
    const [editingMessage, setEditingMessage] = useState<DirectMessage | null>(null);
    const [actionMenuMessage, setActionMenuMessage] = useState<DirectMessage | null>(null);
    const [selectionMode, setSelectionMode] = useState(false);
    const [selectedMessages, setSelectedMessages] = useState<Set<number>>(new Set());
    const [isForwarding, setIsForwarding] = useState(false);
    const messagesToForward = useRef<DirectMessage[]>([]);
    const { isPlaylistOpen, setIsPlaylistOpen, expandPlayer } = useAudioPlayer();
    const [translations, setTranslations] = useState<Record<number, string>>({});
        
    const [showScrollToBottom, setShowScrollToBottom] = useState(false);
    const [newMessagesCount, setNewMessagesCount] = useState(0);
    const [isMobileView, setIsMobileView] = useState(window.innerWidth < 768);

    // Search State
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<number[]>([]); // Indices of messages
    const [currentResultIndex, setCurrentResultIndex] = useState(0);
    const searchInputRef = useRef<HTMLInputElement>(null);

    const chatEndRef = useRef<HTMLDivElement>(null);
    const messageRefs = useRef<Map<number, HTMLDivElement>>(new Map());
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const isScrolledUp = useRef(false);
    const prevMessageCount = useRef(conversation.messages.length);

    const isBlocked = useMemo(() => blockedUsers.some(u => u.id === conversation.friend.id), [blockedUsers, conversation.friend.id]);

    useEffect(() => {
        const handleResize = () => setIsMobileView(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);
    
    // Listen for locate-audio-message event
    useEffect(() => {
        const handleLocateMessage = (e: CustomEvent) => {
            const messageId = parseInt(e.detail.messageId);
            if (messageId) {
                scrollToMessage(messageId);
            }
        };
        window.addEventListener('locate-audio-message', handleLocateMessage as EventListener);
        return () => window.removeEventListener('locate-audio-message', handleLocateMessage as EventListener);
    }, []);

    // Search Logic
    useEffect(() => {
        if (isSearchOpen) {
            setTimeout(() => searchInputRef.current?.focus(), 100);
        } else {
            setSearchQuery('');
            setSearchResults([]);
        }
    }, [isSearchOpen]);

    useEffect(() => {
        if (!searchQuery.trim()) {
            setSearchResults([]);
            setCurrentResultIndex(0);
            return;
        }

        const results: number[] = [];
        conversation.messages.forEach((msg, idx) => {
            const content = (msg.message || msg.caption || '').toLowerCase();
            if (content.includes(searchQuery.toLowerCase())) {
                results.push(idx);
            }
        });

        setSearchResults(results);
        setCurrentResultIndex(results.length > 0 ? results.length - 1 : 0); // Default to latest match
        
        if (results.length > 0) {
            scrollToMessage(conversation.messages[results[results.length - 1]].id);
        }
    }, [searchQuery, conversation.messages]);

    const scrollToMessage = (messageId: number) => {
        const el = messageRefs.current.get(messageId);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.classList.add('bg-white/10', 'transition-colors', 'duration-500');
            setTimeout(() => el.classList.remove('bg-white/10'), 1500);
        }
    };

    const handleNextResult = () => {
        if (searchResults.length === 0) return;
        const nextIndex = (currentResultIndex + 1) % searchResults.length;
        setCurrentResultIndex(nextIndex);
        scrollToMessage(conversation.messages[searchResults[nextIndex]].id);
    };

    const handlePrevResult = () => {
        if (searchResults.length === 0) return;
        const prevIndex = (currentResultIndex - 1 + searchResults.length) % searchResults.length;
        setCurrentResultIndex(prevIndex);
        scrollToMessage(conversation.messages[searchResults[prevIndex]].id);
    };

    // Build Audio Queue
    const audioQueue: AudioTrack[] = useMemo(() => {
        const tracks: AudioTrack[] = [];
        conversation.messages.forEach(msg => {
            if (msg.voiceMessage) {
                tracks.push({
                    id: msg.id.toString(),
                    url: msg.voiceMessage.url,
                    title: 'Voice Message',
                    artist: msg.senderId === currentUser.id ? 'You' : conversation.friend.name,
                    duration: msg.voiceMessage.duration,
                    waveform: msg.voiceMessage.waveform,
                    contextId: conversation.friend.id
                });
            }
        });
        return tracks;
    }, [conversation.messages, currentUser.id, conversation.friend.name, conversation.friend.id]);

    const getReplyPreviewText = useCallback((msg: DirectMessage): string => {
        const truncateText = (text: string): string => {
            const maxLength = isMobileView ? 25 : 40;
            const cleanedText = text.replace(/\s+/g, ' ').trim();
            if (cleanedText.length > maxLength) {
                return cleanedText.substring(0, maxLength) + '...';
            }
            return cleanedText;
        };
        if (msg.message) return truncateText(msg.message);
        if (msg.caption) return truncateText(msg.caption);
        if (msg.voiceMessage) return "🎤 Voice Message";
        if (msg.imageUrl) return "🖼️ Image";
        if (msg.videoUrl && !msg.fileInfo?.name?.endsWith('mp3')) return "🎬 Video";
        if (msg.roomInvite) return "🚪 Room Invite";
        if (msg.voiceRoomInvite) return "🔊 Voice Room Invite";
        if (msg.fileInfo && (msg.fileInfo.name.endsWith('mp3') || msg.fileInfo.name.endsWith('wav'))) return "🎵 Audio File";
        return "Attachment";
    }, [isMobileView]);

    const scrollToBottom = useCallback((behavior: 'smooth' | 'auto' = 'auto') => {
        chatEndRef.current?.scrollIntoView({ behavior });
        isScrolledUp.current = false;
        setShowScrollToBottom(false);
        setNewMessagesCount(0);
    }, []);

    const handleScroll = useCallback(() => {
        const container = chatContainerRef.current;
        if (container) {
            const atBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 150;
            if(atBottom) {
                isScrolledUp.current = false;
                setShowScrollToBottom(false);
                setNewMessagesCount(0);
            } else {
                isScrolledUp.current = true;
                setShowScrollToBottom(true);
            }
        }
    }, []);
    
    useEffect(() => {
        const newTotalMessages = conversation.messages.length;
        if (newTotalMessages > prevMessageCount.current) {
            const newCount = newTotalMessages - prevMessageCount.current;
            if (!isScrolledUp.current && !isSearchOpen) {
                scrollToBottom('smooth');
            } else {
                 setNewMessagesCount(prev => prev + newCount);
            }
        }
        prevMessageCount.current = newTotalMessages;
    }, [conversation.messages, scrollToBottom, isSearchOpen]);


    useEffect(() => {
        if (!isSearchOpen) {
            scrollToBottom('auto');
        }
        const container = chatContainerRef.current;
        container?.addEventListener('scroll', handleScroll);
        return () => container?.removeEventListener('scroll', handleScroll);
    }, [conversation.friend.id, handleScroll, scrollToBottom, isSearchOpen]);
    
    const handleToggleSelection = (messageId: number) => {
        setSelectedMessages(prev => {
            const newSet = new Set(prev);
            if (newSet.has(messageId)) newSet.delete(messageId);
            else newSet.add(messageId);
            if (newSet.size === 0) setSelectionMode(false);
            return newSet;
        });
    };

    const handleOpenContextMenu = (event: React.MouseEvent | React.TouchEvent, message: DirectMessage) => {
        if (selectionMode) {
            handleToggleSelection(message.id);
            return;
        };
        event.preventDefault();
        event.stopPropagation();
        setActionMenuMessage(message);
    };

    const handleTranslate = async (message: DirectMessage) => {
        if (!message.message && !message.caption) return;
        const textToTranslate = message.message || message.caption || "";
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Translate the following text to Persian (Farsi). Only return the translated text. Text: "${textToTranslate}"`,
            });
            if (response.text) {
                setTranslations(prev => ({ ...prev, [message.id]: response.text }));
            }
        } catch (e) {
            console.error("Translation failed", e);
        }
    };
    
    const handleSendVoiceMessage = (blobUrl: string, duration: number, waveform: number[]) => {
        onSendMessage({
            message: '',
            voiceMessage: { url: blobUrl, duration: Math.round(duration), waveform },
            replyTo: replyingTo || undefined,
        });
        setReplyingTo(null);
    };

    const pinnedMessages = (conversation.pinnedMessageIds || [])
        .map(id => conversation.messages.find(m => m.id === id))
        .filter((m): m is DirectMessage => !!m);

    const friendStatus = {
        online: { text: 'Online', color: 'text-green-400' },
        ingame: { text: 'In a room', color: 'text-purple-400' },
        offline: { text: 'Offline', color: 'text-gray-400' },
    }[conversation.friend.status];
    
    const getSender = useCallback((senderId: number) => senderId === currentUser.id ? currentUser : conversation.friend, [currentUser, conversation.friend]);

    const messagesWithSeparators = useMemo(() => {
        const result: (DirectMessage | { type: 'date-separator', date: string })[] = [];
        let lastDate: Date | null = null;

        conversation.messages.forEach(message => {
            const messageDate = new Date(message.timestamp);
            if (!lastDate || !isSameDay(lastDate, messageDate)) {
                result.push({ type: 'date-separator', date: formatDateSeparator(messageDate) });
                lastDate = messageDate;
            }
            result.push(message);
        });

        return result;
    }, [conversation.messages]);

    const handleForwardSubmit = (friendIds: number[], options: { hideSender: boolean }) => {
        // Prepare messages with or without sender info
        const messagesToSend = messagesToForward.current.map(msg => {
            if (options.hideSender) {
                // Create a copy without forwardedFrom to anonymize
                const { forwardedFrom, ...rest } = msg;
                return rest;
            } else {
                // Logic for "Forward Chain":
                // If message is ALREADY forwarded (has forwardedFrom), preserve it.
                // If message is original (no forwardedFrom), set forwardedFrom to the current sender (msg.senderId).
                
                const originalSender = msg.senderId === currentUser.id ? currentUser : conversation.friend;
                return { 
                    ...msg, 
                    forwardedFrom: msg.forwardedFrom || originalSender 
                };
            }
        });

        onForwardMultipleMessages(friendIds, messagesToSend);
        setIsForwarding(false);
        setSelectionMode(false);
        setSelectedMessages(new Set());
    };

    return (
        <div className="relative flex flex-col h-full bg-transparent overflow-hidden">
             <style>{`
                @keyframes slide-in-up { 0% { opacity: 0; transform: translateY(20px); } 100% { opacity: 1; transform: translateY(0); } }
                .animate-slide-in-up { animation: slide-in-up 0.3s ease-out forwards; }
                @keyframes bounce-in { 0% { transform: scale(0.5); opacity: 0; } 60% { transform: scale(1.1); opacity: 1; } 100% { transform: scale(1); } }
                .animate-bounce-in { animation: bounce-in 0.3s ease-out forwards; }
                .custom-scrollbar::-webkit-scrollbar { width: 6px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #4a4a6a; border-radius: 3px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6C5DD3; }
            `}</style>

            {selectionMode ? (
                <SelectionHeader 
                    count={selectedMessages.size} 
                    onCancel={() => { setSelectionMode(false); setSelectedMessages(new Set()); }}
                    onDelete={() => {
                        onDeleteMessage(Array.from(selectedMessages));
                        setSelectionMode(false);
                        setSelectedMessages(new Set());
                    }}
                    onForward={() => {
                        messagesToForward.current = conversation.messages.filter(m => selectedMessages.has(m.id));
                        setIsForwarding(true);
                    }}
                />
            ) : (
                <header className="flex-shrink-0 flex items-center justify-between gap-3 p-3 border-b border-white/5 bg-black/30 backdrop-blur-md z-10 h-16">
                    <div className="flex items-center gap-3 min-w-0 w-full">
                        {isSearchOpen ? (
                            <div className="flex-1 flex items-center gap-3 animate-fade-in">
                                <button onClick={() => setIsSearchOpen(false)} className="p-2 -ml-2 text-gray-400 hover:text-white rounded-full hover:bg-white/10 transition-colors">
                                    <ArrowLeftIcon className="w-5 h-5" />
                                </button>
                                <div className="flex-1 relative group">
                                    <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-[var(--theme-color)]" />
                                    <input 
                                        ref={searchInputRef}
                                        type="text" 
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        placeholder="Search..." 
                                        className="w-full bg-black/20 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-[var(--theme-color)] transition-all"
                                    />
                                </div>
                                {searchResults.length > 0 && (
                                    <div className="flex items-center gap-2 pl-2">
                                        <span className="text-xs font-mono text-gray-400 whitespace-nowrap min-w-[40px] text-center">
                                            {currentResultIndex + 1} of {searchResults.length}
                                        </span>
                                        <div className="flex bg-black/20 rounded-lg border border-white/10">
                                            <button onClick={handlePrevResult} className="p-1.5 hover:bg-white/10 rounded-l-lg text-gray-300 hover:text-white border-r border-white/10">
                                                <ChevronDownIcon className="w-4 h-4 rotate-180" />
                                            </button>
                                            <button onClick={handleNextResult} className="p-1.5 hover:bg-white/10 rounded-r-lg text-gray-300 hover:text-white">
                                                <ChevronDownIcon className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <>
                                <div className="flex items-center gap-3 min-w-0">
                                    <button onClick={onBack} className="md:hidden p-1 -ml-1 text-gray-300 hover:text-white"><ArrowLeftIcon className="w-6 h-6" /></button>
                                    <div onClick={onHeaderClick} className="flex items-center gap-3 cursor-pointer group">
                                        <img src={conversation.friend.avatar} alt={conversation.friend.name} className="w-10 h-10 rounded-full border-2 border-transparent group-hover:border-white/20 transition-all" />
                                        <div className="min-w-0">
                                            <h3 className="font-bold truncate text-white group-hover:text-purple-300 transition-colors flex items-center gap-1">
                                                {conversation.friend.name}
                                                {conversation.friend.isVerified && <VerifiedIcon className="w-3.5 h-3.5 text-blue-400" />}
                                            </h3>
                                            <p className={`text-sm ${friendStatus.color}`}>
                                                {conversation.friend.isTyping ? <TypingIndicator inline /> : friendStatus.text}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1 ml-auto">
                                    <button onClick={() => setIsSearchOpen(true)} className="p-2 text-gray-400 hover:text-white rounded-full hover:bg-white/5 transition-colors">
                                        <SearchIcon className="w-6 h-6" />
                                    </button>
                                    <button onClick={() => !isBlocked && onStartCall(conversation.friend, 'outgoing-video')} disabled={isBlocked} className="p-2 text-gray-300 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"><VideoCameraIcon className="w-6 h-6" /></button>
                                    <button onClick={() => !isBlocked && onStartCall(conversation.friend, 'outgoing-voice')} disabled={isBlocked} className="p-2 text-gray-300 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"><PhoneIcon className="w-6 h-6" /></button>
                                </div>
                            </>
                        )}
                    </div>
                </header>
            )}

            {/* In-Chat Mini Player */}
            <ChatHeaderMiniPlayer activeContextId={conversation.friend.id} />

            {pinnedMessages.length > 0 && !selectionMode && !isSearchOpen && <PinnedMessagesBar messages={pinnedMessages} onSelect={scrollToMessage} getSender={getSender} getReplyPreviewText={getReplyPreviewText} />}
            
            <div 
                ref={chatContainerRef}
                className={`flex-1 overflow-y-auto p-4 pb-32 space-y-1 custom-scrollbar ${
                    chatBackground.type === 'class' ? chatBackground.value : ''
                }`}
                style={
                    chatBackground.type === 'custom'
                      ? { backgroundImage: chatBackground.value, backgroundSize: 'cover', backgroundPosition: 'center' }
                      : {}
                }
            >
                {conversation.messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full min-h-[50vh] text-center animate-fade-in">
                        <div className="relative mb-6 group cursor-pointer" onClick={() => onSendMessage({ message: "👋" })}>
                             <div className="absolute inset-0 blur-2xl rounded-full group-hover:opacity-100 transition-all duration-500" style={{ backgroundColor: 'var(--theme-color)', opacity: 0.2 }}></div>
                            <img src={conversation.friend.avatar} alt={conversation.friend.name} className="w-24 h-24 rounded-full object-cover border-4 border-white/10 relative z-10 shadow-2xl transform group-hover:scale-105 transition-transform duration-300" />
                             <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-green-500 border-4 border-[#0E0E10] rounded-full z-20"></div>
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">No messages yet...</h3>
                        <p className="text-gray-400 max-w-xs mb-8 text-sm leading-relaxed">
                            Start the conversation with <span className="font-bold" style={{ color: 'var(--theme-color)' }}>{conversation.friend.name}</span> by sending a message below.
                        </p>
                        <button 
                            onClick={() => onSendMessage({ message: "👋" })}
                            className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-white font-medium transition-all hover:scale-105 active:scale-95 flex items-center gap-2 backdrop-blur-md shadow-lg"
                        >
                            <span className="text-xl animate-wave origin-bottom-right">👋</span> Say Hello
                        </button>
                        <style>{`@keyframes wave { 0% { transform: rotate(0deg); } 20% { transform: rotate(15deg); } 40% { transform: rotate(-10deg); } 60% { transform: rotate(5deg); } 100% { transform: rotate(0deg); } } .animate-wave { animation: wave 1.5s infinite; }`}</style>
                    </div>
                ) : (
                     messagesWithSeparators.map((item, index) => {
                        if ('type' in item && item.type === 'date-separator') {
                            return <DateSeparator key={`sep-${item.date}-${index}`} dateString={item.date} />;
                        }
                        const msg = item as DirectMessage;
                        if (msg.call) {
                            const isSent = msg.senderId === currentUser.id;
                            return <CallMessageItem key={msg.id} message={msg} onStartCall={onStartCall} friend={conversation.friend} isSent={isSent} />;
                        }
                        const isSent = msg.senderId === currentUser.id;
                        const isSelected = selectedMessages.has(msg.id);
                        return (
                            <div 
                                key={msg.id} 
                                className={`flex items-start gap-2.5 group transition-colors duration-200 rounded-lg ${isSent ? 'justify-end' : 'justify-start'} ${selectionMode ? 'cursor-pointer p-1' : ''} ${isSelected ? 'bg-white/10' : ''}`} 
                                onClick={() => selectionMode && handleToggleSelection(msg.id)}
                            >
                                {selectionMode && <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all self-center ${isSent ? 'order-2' : 'order-1'}`} style={{borderColor: isSelected ? 'var(--theme-color)' : '#4A4A6A', backgroundColor: isSelected ? 'var(--theme-color)' : 'transparent'}}>{isSelected && <CheckIcon className="w-4 h-4 text-white"/>}</div>}
                                <DirectMessageItem 
                                    message={msg}
                                    isSent={isSent} 
                                    friend={conversation.friend}
                                    currentUser={currentUser}
                                    selectionMode={selectionMode}
                                    onOpenContextMenu={(e) => handleOpenContextMenu(e, msg)}
                                    onAddReaction={(emoji) => onAddReaction(msg.id, emoji)}
                                    onJoinRoom={onJoinRoom}
                                    onJoinVoiceRoom={onJoinVoiceRoom}
                                    onReplyClick={scrollToMessage}
                                    onViewMedia={onViewMedia}
                                    onCancelUpload={() => onDeleteMessage([msg.id])}
                                    getReplyPreviewText={getReplyPreviewText}
                                    onReplyRequest={setReplyingTo}
                                    ref={(el: HTMLDivElement) => { if (el) messageRefs.current.set(msg.id, el); }}
                                    audioContextQueue={audioQueue}
                                    onViewProfile={onViewProfile}
                                    translation={translations[msg.id]}
                                />
                            </div>
                        )
                     })
                )}
                <div ref={chatEndRef}></div>
            </div>
            
            
            {isBlocked ? (
                 <div className="absolute bottom-0 left-0 right-0 z-20 flex justify-center pb-6 px-4 pointer-events-none">
                    <div className="pointer-events-auto bg-red-500/10 backdrop-blur-md border border-red-500/20 rounded-2xl p-4 w-full max-w-md flex items-center justify-between shadow-lg animate-fade-in-up">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                                <ShieldIcon className="w-5 h-5 text-red-500" />
                            </div>
                            <div>
                                <p className="text-white font-bold text-sm">You blocked this user</p>
                                <p className="text-xs text-red-300/80">You can't send messages.</p>
                            </div>
                        </div>
                        {onUnblockUser && (
                            <button 
                                onClick={() => onUnblockUser(conversation.friend)}
                                className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold text-white transition-colors border border-white/10"
                            >
                                Unblock
                            </button>
                        )}
                    </div>
                </div>
            ) : !selectionMode && (
                 /* Floating Footer with Gradient */
                <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center pointer-events-none">
                    <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />

                    <div className="w-full max-w-4xl flex flex-col gap-2 pb-4 px-4 relative z-10">
                        {/* Jump to Latest */}
                        <div className="flex justify-end pointer-events-none">
                             <div className="pointer-events-auto">
                                <JumpToLatestButton 
                                    isVisible={showScrollToBottom}
                                    newMessagesCount={newMessagesCount}
                                    onClick={() => scrollToBottom('smooth')}
                                />
                             </div>
                        </div>

                        {/* Input Area */}
                        <div className="pointer-events-auto">
                            <MessageInput 
                                onSendMessage={onSendMessage}
                                onEditMessage={onEditMessage}
                                editingMessage={editingMessage}
                                onCancelEdit={() => setEditingMessage(null)}
                                replyingTo={replyingTo} 
                                onCancelReply={() => setReplyingTo(null)} 
                                friendName={conversation.friend.name}
                                currentUser={currentUser}
                                getReplyPreviewText={getReplyPreviewText}
                                onSendVoice={handleSendVoiceMessage}
                            />
                        </div>
                    </div>
                </div>
            )}
            
            {actionMenuMessage && (
                 <MessageActionOverlay
                    message={actionMenuMessage}
                    isSent={actionMenuMessage.senderId === currentUser.id}
                    isPinned={(conversation.pinnedMessageIds || []).includes(actionMenuMessage.id)}
                    onClose={() => setActionMenuMessage(null)}
                    onReply={() => setReplyingTo(actionMenuMessage)}
                    onEdit={() => setEditingMessage(actionMenuMessage)}
                    onCopy={() => navigator.clipboard.writeText(actionMenuMessage.message || actionMenuMessage.caption || '')}
                    onPin={() => onPinMessage(actionMenuMessage.id)}
                    onDelete={() => onDeleteMessage([actionMenuMessage.id])}
                    onForward={() => {
                        messagesToForward.current = [actionMenuMessage];
                        setIsForwarding(true);
                    }}
                    onSelect={() => {
                        setSelectionMode(true);
                        setSelectedMessages(new Set([actionMenuMessage.id]));
                    }}
                    onTranslate={() => handleTranslate(actionMenuMessage)}
                    onAddReaction={(emoji) => onAddReaction(actionMenuMessage.id, emoji)}
                    currentUser={currentUser}
                    friend={conversation.friend}
                    onJoinRoom={onJoinRoom}
                    onJoinVoiceRoom={onJoinVoiceRoom}
                    onReplyClick={scrollToMessage}
                    onViewMedia={onViewMedia}
                    getReplyPreviewText={getReplyPreviewText}
                />
            )}
            
            {isForwarding && (
                <AdvancedForwardModal 
                    isOpen={isForwarding}
                    onClose={() => setIsForwarding(false)}
                    friends={friends}
                    currentUser={currentUser}
                    selectedCount={messagesToForward.current.length}
                    onSend={handleForwardSubmit}
                />
            )}
            
            <PlaylistBottomSheet 
                isOpen={isPlaylistOpen} 
                onClose={() => setIsPlaylistOpen(false)} 
                onExpand={() => {
                    setIsPlaylistOpen(false);
                    expandPlayer();
                }}
            />
        </div>
    );
};


// Subcomponents
const PinnedMessagesBar: React.FC<{ messages: DirectMessage[], onSelect: (id: number) => void, getSender: (id: number) => User, getReplyPreviewText: (msg: DirectMessage) => string }> = ({ messages, onSelect, getSender, getReplyPreviewText }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    if (messages.length === 0) return null;
    const latestMessage = messages[messages.length - 1];

    return (
        <div className="flex-shrink-0 bg-black/20 border-b border-white/5 cursor-pointer">
            <div className="p-2" onClick={() => setIsExpanded(!isExpanded)}>
                <div className="flex items-center gap-2">
                    <PinIcon className="w-4 h-4 text-[var(--theme-color)] flex-shrink-0" />
                    <div className="text-xs text-gray-300 truncate flex-1" onClick={(e) => { e.stopPropagation(); onSelect(latestMessage.id); }}>
                        <p className="font-bold" style={{ color: 'var(--theme-color)' }}>
                            {messages.length} Pinned Message{messages.length > 1 ? 's' : ''}
                        </p>
                        <p className="truncate">{latestMessage.message || latestMessage.caption || 'Media'}</p>
                    </div>
                    <ChevronDownIcon className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                </div>
            </div>
            {isExpanded && (
                <div className="max-h-40 overflow-y-auto border-t border-white/10 p-1">
                    {messages.slice().reverse().map((msg) => (
                        <div key={msg.id} onClick={() => onSelect(msg.id)} className="flex items-start gap-2 p-1.5 rounded-md hover:bg-white/10">
                            <img src={getSender(msg.senderId).avatar} alt={getSender(msg.senderId).name} className="w-6 h-6 rounded-full" />
                            <div className="text-xs text-gray-300 truncate flex-1">
                                <p className="font-bold truncate" style={{ color: 'var(--theme-color)' }}>{getSender(msg.senderId).name}</p>
                                <p className="truncate">{getReplyPreviewText(msg)}</p>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const SelectionHeader: React.FC<{count: number, onCancel: ()=>void, onDelete:()=>void, onForward:()=>void}> = ({ count, onCancel, onDelete, onForward }) => (
    <header className="flex-shrink-0 flex items-center justify-between p-3 border-b border-white/5 bg-black/30 backdrop-blur-md z-10">
        <button onClick={onCancel} className="p-1 text-gray-300 hover:text-white"><CloseIcon className="w-6 h-6" /></button>
        <h3 className="font-bold">{count} Selected</h3>
        <div className="flex items-center gap-2">
            <button onClick={onDelete} className="p-2 text-gray-300 hover:text-white" title="Delete"><TrashIcon className="w-6 h-6"/></button>
            <button onClick={onForward} className="p-2 text-gray-300 hover:text-white" title="Forward"><ForwardIcon className="w-6 h-6"/></button>
        </div>
    </header>
);

const TypingIndicator: React.FC<{inline?: boolean}> = ({ inline }) => {
    if(inline) return <span className="flex items-center gap-0.5"><span className="w-1.5 h-1.5 bg-current rounded-full animate-bounce"></span><span className="w-1.5 h-1.5 bg-current rounded-full animate-bounce delay-150"></span><span className="w-1.5 h-1.5 bg-current rounded-full animate-bounce delay-300"></span><style>{`.animate-bounce { animation: bounce 1.2s infinite; } @keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }`}</style></span>
    return null;
};

const MessageInput: React.FC<{
    onSendMessage: (message: Omit<DirectMessage, 'id'|'senderId'|'timestamp'|'displayTime'>) => void, 
    onEditMessage: (id: number, text: string) => void, 
    editingMessage: DirectMessage | null, 
    onCancelEdit: () => void, 
    replyingTo: DirectMessage | null, 
    onCancelReply: () => void, 
    friendName: string, 
    currentUser: User,
    getReplyPreviewText: (msg: DirectMessage) => string,
    onSendVoice: (blobUrl: string, duration: number, waveform: number[]) => void
}> = (props) => {
    const { onSendMessage, onEditMessage, editingMessage, onCancelEdit, replyingTo, onCancelReply, friendName, currentUser, getReplyPreviewText, onSendVoice } = props;
    const [text, setText] = useState('');
    const [voiceMode, setVoiceMode] = useState<'idle' | 'recording' | 'review'>('idle');
    const [pendingAttachment, setPendingAttachment] = useState<{ file: File, previewUrl: string, type: 'image' | 'video' | 'audio' } | null>(null);
    const [editingImage, setEditingImage] = useState<File | null>(null);
    
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (editingMessage) {
            setText(editingMessage.message || editingMessage.caption || '');
            textareaRef.current?.focus();
        } else {
            setText('');
        }
    }, [editingMessage]);
    
    useEffect(() => {
        if(textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            const scrollHeight = textareaRef.current.scrollHeight;
            textareaRef.current.style.height = `${Math.min(scrollHeight, 120)}px`;
        }
    }, [text]);

    const handleSend = () => {
        if (pendingAttachment) {
            const message: Omit<DirectMessage, 'id'|'senderId'|'timestamp'|'displayTime'> = {
                message: '',
                caption: text.trim(),
                fileInfo: { name: pendingAttachment.file.name, size: pendingAttachment.file.size },
                replyTo: replyingTo || undefined,
            };
            if (pendingAttachment.type === 'image') {
                message.imageUrl = pendingAttachment.previewUrl;
            } else if (pendingAttachment.type === 'video') {
                message.videoUrl = pendingAttachment.previewUrl;
            } else if (pendingAttachment.type === 'audio') {
                message.videoUrl = pendingAttachment.previewUrl; // Storing audio URL in videoUrl for simplicity in this structure, handled by display logic
            }
            onSendMessage(message);
            setPendingAttachment(null);
            setText('');
            if (replyingTo) onCancelReply();
            return;
        }

        if (text.trim() === '') return;

        if (editingMessage) {
            onEditMessage(editingMessage.id, text.trim());
        } else {
            onSendMessage({
                message: text.trim(),
                replyTo: replyingTo || undefined,
            });
        }

        setText('');
        if (replyingTo) onCancelReply();
        if (editingMessage) onCancelEdit();
        if(textareaRef.current) textareaRef.current.style.height = 'auto';
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };
    
    const handleAttachFile = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        
        let type: 'image' | 'video' | 'audio' = 'image';
        if (file.type.startsWith('video/')) type = 'video';
        else if (file.type.startsWith('audio/')) type = 'audio';
        
        if (type === 'image') {
            setEditingImage(file);
        } else {
            const objectUrl = URL.createObjectURL(file);
            setPendingAttachment({ file, previewUrl: objectUrl, type });
            setText('');
        }
        
        // Reset input
        e.target.value = '';
    };

    const cancelAttachment = () => {
        if (pendingAttachment) {
            URL.revokeObjectURL(pendingAttachment.previewUrl);
            setPendingAttachment(null);
            if (fileInputRef.current) fileInputRef.current.value = '';
            setText('');
        }
    }

    const handleImageEditorSave = (editedFile: File) => {
        const objectUrl = URL.createObjectURL(editedFile);
        setPendingAttachment({ file: editedFile, previewUrl: objectUrl, type: 'image' });
        setText('');
        setEditingImage(null);
    };

    // --- Voice Interaction Logic (Simplified to Click-to-Toggle) ---
    const handleMicClick = () => {
        setVoiceMode('recording');
    };

    if (pendingAttachment) {
         return (
            <div className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-lg flex flex-col animate-fade-in">
                <div className="flex-1 flex items-center justify-center p-4 relative overflow-hidden">
                    <button onClick={cancelAttachment} className="absolute top-4 right-4 p-2 bg-white/10 rounded-lg hover:bg-white/20 text-white z-20 transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                    <div className="relative max-w-full max-h-[80vh] shadow-2xl rounded-xl overflow-hidden bg-black flex justify-center">
                        {pendingAttachment.type === 'image' ? (
                            <img src={pendingAttachment.previewUrl} alt="Preview" className="max-w-full max-h-[80vh] object-contain" />
                        ) : pendingAttachment.type === 'video' ? (
                            <video src={pendingAttachment.previewUrl} controls className="max-w-full max-h-[80vh]" />
                        ) : (
                            // Audio Preview
                            <div className="p-8 flex flex-col items-center justify-center bg-zinc-900 rounded-xl">
                                <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mb-4 text-[var(--theme-color)]">
                                    <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
                                </div>
                                <p className="text-white font-bold">{pendingAttachment.file.name}</p>
                                <audio controls src={pendingAttachment.previewUrl} className="mt-4" />
                            </div>
                        )}
                    </div>
                </div>
                <div className="bg-[#1e1e24] p-4 border-t border-white/10 pb-8 safe-area-bottom">
                    <div className="max-w-3xl mx-auto flex items-end gap-3">
                        <div className="flex-1 bg-black/30 rounded-xl p-1 border border-white/10 focus-within:border-[var(--theme-color)] transition-colors">
                            <textarea 
                                ref={textareaRef} 
                                value={text} 
                                onChange={(e) => setText(e.target.value)} 
                                onKeyDown={handleKeyDown} 
                                placeholder={`Add a caption for this ${pendingAttachment.type}...`} 
                                rows={1} 
                                autoFocus
                                className="w-full bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none py-3 px-4 text-base max-h-32 custom-scrollbar" 
                            />
                        </div>
                        <button 
                            onClick={handleSend} 
                            className="w-12 h-12 text-white rounded-lg flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95 flex-shrink-0 mb-0.5"
                            style={{ backgroundColor: 'var(--theme-color)' }}
                        >
                            <SendIcon className="w-6 h-6 ml-0.5" />
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="w-full">
             <div className={`bg-black/40 backdrop-blur-2xl border border-white/10 rounded-xl shadow-2xl transition-all duration-300 focus-within:ring-1 focus-within:ring-[var(--theme-color)] focus-within:bg-black/60 relative flex flex-col overflow-hidden ${voiceMode !== 'idle' ? 'min-h-[52px] justify-center' : ''}`}>
                
                {/* Internal Context Banner (Reply/Edit) - Always visible if there is a reply/edit context, regardless of voice mode */}
                {(replyingTo || editingMessage) && (
                    <div className="w-full px-4 pt-3 pb-2 flex justify-between items-center gap-3 bg-white/5 border-b border-white/5 animate-slide-in-up">
                        <div className="flex-1 min-w-0 border-l-2 pl-2" style={{ borderColor: 'var(--theme-color)' }}>
                            <p className="text-xs font-bold truncate" style={{ color: 'var(--theme-color)' }}>
                                {editingMessage ? 'Editing Message' : (replyingTo?.senderId === currentUser.id ? 'You' : friendName)}
                            </p>
                            <p className="text-xs text-gray-400 truncate">
                                {editingMessage ? getReplyPreviewText(editingMessage) : (replyingTo ? getReplyPreviewText(replyingTo) : '')}
                            </p>
                        </div>
                        <button onClick={editingMessage ? onCancelEdit : onCancelReply} className="p-1 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors">
                            <CloseIcon className="w-4 h-4" />
                        </button>
                    </div>
                )}

                {voiceMode !== 'idle' ? (
                    // Inline Voice Recorder UI
                    <VoiceMessageRecorder 
                        isRecording={voiceMode === 'recording'}
                        onCancel={() => setVoiceMode('idle')}
                        onSend={(url, dur, wave) => {
                            onSendVoice(url, dur, wave);
                            setVoiceMode('idle');
                        }}
                    />
                ) : (
                    // Standard Input UI
                    <div className="flex items-end gap-2 p-1.5 pl-3 w-full">
                        <button className="p-2 text-gray-400 hover:text-yellow-400 hover:bg-white/5 rounded-lg transition-colors flex-shrink-0">
                            <EmojiIcon className="w-6 h-6" />
                        </button>
                         
                        {!text.trim() && (
                             <>
                                <input type="file" ref={fileInputRef} onChange={handleAttachFile} className="hidden" accept="image/*,video/*,audio/*" />
                                <button onClick={() => fileInputRef.current?.click()} className="p-2 text-gray-400 hover:text-blue-400 hover:bg-white/5 rounded-lg transition-colors flex-shrink-0">
                                    <AttachmentIcon className="w-6 h-6" />
                                </button>
                             </>
                        )}

                        <textarea 
                            ref={textareaRef} 
                            value={text} 
                            onChange={(e) => setText(e.target.value)} 
                            onKeyDown={handleKeyDown} 
                            placeholder={`Message ${friendName}...`}
                            rows={1} 
                            className="flex-1 bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none py-2 text-[15px] max-h-[120px] leading-relaxed custom-scrollbar" 
                        />

                        <div className="flex-shrink-0">
                            {text.trim() || editingMessage ? (
                                <button 
                                    onClick={handleSend} 
                                    className="p-2 text-white rounded-lg shadow-lg transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center animate-bounce-in" 
                                    style={{ backgroundColor: 'var(--theme-color)' }}
                                >
                                    <SendIcon className="w-5 h-5" />
                                </button>
                            ) : (
                                <button 
                                    onClick={handleMicClick}
                                    className="p-2 bg-white/5 border border-white/10 backdrop-blur-md rounded-lg transition-all transform hover:scale-105 active:scale-95 group flex items-center justify-center"
                                >
                                    <MicrophoneIcon className="w-6 h-6 text-[var(--theme-color)]" />
                                </button>
                            )}
                        </div>
                    </div>
                )}
            </div>
            
            {editingImage && (
                <ImageEditorModal
                    isOpen={!!editingImage}
                    imageFile={editingImage}
                    onClose={() => setEditingImage(null)}
                    onSave={handleImageEditorSave}
                />
            )}
        </div>
    );
};

export default AdvancedChat;
