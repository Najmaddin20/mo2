import React from 'react';
import type { AppActivity } from '../types';

interface AppActivityWidgetProps {
    activity: AppActivity;
}

const AppActivityWidget: React.FC<AppActivityWidgetProps> = ({ activity }) => {
    const totalTime = activity.breakdown.reduce((acc, curr) => acc + curr.time, 0) || 1;

    return (
        <div 
            className="bg-zinc-900/50 backdrop-blur-2xl border border-white/10 rounded-3xl p-5 space-y-4 text-white relative overflow-hidden"
            style={{
                background: `
                    radial-gradient(circle at 15% 25%, rgba(255, 65, 65, 0.15), transparent 45%),
                    radial-gradient(circle at 85% 65%, rgba(49, 166, 245, 0.1), transparent 45%),
                    #18181b
                `
            }}
        >
            <h3 className="text-base text-gray-300 font-medium">Apps Activity</h3>

            <div className="flex items-start gap-3">
                <div>
                    <span className="text-5xl font-bold tracking-tight">{String(activity.totalHours).padStart(2, '0')}</span>
                    <p className="text-gray-400 font-medium text-sm -mt-1">Hours</p>
                </div>
                <span className="text-5xl font-bold text-gray-500 mt-[-2px]">:</span>
                <div>
                    <span className="text-5xl font-bold tracking-tight">{String(activity.totalMinutes).padStart(2, '0')}</span>
                    <p className="text-gray-400 font-medium text-sm -mt-1">Minutes</p>
                </div>
            </div>

            <div className="flex h-2.5 rounded-full overflow-hidden bg-zinc-700/50 shadow-inner">
                {activity.breakdown.map((item, index) => (
                    <div
                        key={index}
                        className="h-full"
                        style={{
                            width: `${(item.time / totalTime) * 100}%`,
                            backgroundColor: item.color,
                        }}
                        title={`${item.name}: ${item.time.toFixed(1)} hours`}
                    />
                ))}
            </div>

            <div className="grid grid-cols-2 gap-x-6 gap-y-2 pt-2">
                {activity.breakdown.map((item, index) => (
                    <div key={index} className="flex items-center gap-2.5">
                        <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: item.color }}></div>
                        <span className="text-sm text-gray-200">{item.name}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AppActivityWidget;
