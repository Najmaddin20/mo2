
import React from 'react';
import type { VoiceRoom, User } from '../types';
import { CloseIcon, GameControllerIcon, TrashIcon } from './icons';

interface WidgetsPanelProps {
    room: VoiceRoom;
    currentUser: User;
    onGameAction: (action: string, payload?: any) => void;
    isOpen: boolean;
    onClose: () => void;
}

const WidgetsPanel: React.FC<WidgetsPanelProps> = ({ room, currentUser, onGameAction, isOpen, onClose }) => {
    const isHost = room.speakers.some(s => s.id === currentUser.id && s.role === 'host');

    return (
        <aside className={`
            ${isOpen ? 'flex' : 'hidden'} lg:flex 
            fixed lg:relative inset-0 lg:inset-auto z-40
            flex-col w-full lg:w-80 
            bg-black/80 lg:bg-black/20 
            backdrop-blur-xl border-l border-white/10 p-6 space-y-6 flex-shrink-0
            animate-fade-in
        `}>
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
                <h2 className="text-lg font-bold text-white">Room Activities</h2>
                <button onClick={onClose} className="lg:hidden p-2 bg-white/10 rounded-full">
                    <CloseIcon className="w-5 h-5 text-white" />
                </button>
            </div>
            
            <div className="flex-1 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar">
                {room.game ? (
                    <div className="space-y-4">
                        <div className="bg-purple-500/10 border border-purple-500/30 p-4 rounded-xl">
                            <h3 className="font-bold text-purple-300 flex items-center gap-2">
                                <GameControllerIcon className="w-5 h-5" />
                                Game in Progress
                            </h3>
                            <p className="text-sm text-gray-400 mt-1">
                                A game of <span className="font-bold text-white">{room.game.type.replace(/-/g, ' ')}</span> is currently running on the stage.
                            </p>
                        </div>
                        
                        {isHost && (
                            <button 
                                onClick={() => onGameAction('end')} 
                                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 rounded-xl transition-colors font-bold text-sm"
                            >
                                <TrashIcon className="w-4 h-4" /> End Current Game
                            </button>
                        )}
                    </div>
                ) : (
                    <div className="space-y-4">
                        <p className="text-sm text-gray-400">Start a game to play with everyone in the room.</p>
                        {/* The Start Game modal is triggered from the header menu, but could be added here too if needed. 
                            For now, keeping it clean as an informational panel when idle. */}
                        <div className="text-center p-8 border-2 border-dashed border-white/10 rounded-xl">
                            <GameControllerIcon className="w-12 h-12 text-gray-600 mx-auto mb-2" />
                            <p className="text-gray-500 font-medium">No active games</p>
                        </div>
                    </div>
                )}
            </div>
            <style>{`
                .custom-scrollbar::-webkit-scrollbar { width: 4px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #4a4a6a; border-radius: 2px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #6C5DD3; }
            `}</style>
        </aside>
    );
};

export default WidgetsPanel;
