
import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { CloseIcon, SparklesIcon, CheckIcon, CrownIcon, StarIcon, MagicWandIcon } from './icons';

const DiamondSvg = ({ className }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 3h12l4 6-10 13L2 9z" />
    </svg>
);

const LightningSvg = ({ className }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
    </svg>
);

interface TokenPurchaseModalProps {
    isOpen: boolean;
    onClose: () => void;
    onPurchase: (amount: number) => void;
}

const PLANS = [
    { 
        id: 'starter',
        amount: 10, 
        price: '$1.99', 
        label: 'Starter', 
        tag: null,
        color: 'from-blue-500 to-cyan-500', 
        shadow: 'shadow-blue-500/20',
        icon: <StarIcon className="w-5 h-5 text-white" />
    },
    { 
        id: 'creator',
        amount: 50, 
        price: '$4.99', 
        label: 'Creator', 
        tag: 'MOST POPULAR',
        color: 'from-purple-500 to-indigo-600', 
        shadow: 'shadow-purple-500/40',
        icon: <SparklesIcon className="w-5 h-5 text-white" />
    },
    { 
        id: 'pro',
        amount: 200, 
        price: '$14.99', 
        label: 'Pro', 
        tag: 'BEST VALUE',
        color: 'from-orange-500 to-red-600', 
        shadow: 'shadow-orange-500/20',
        icon: <DiamondSvg className="w-5 h-5 text-white" />
    },
];

interface PlanCardProps {
    plan: typeof PLANS[0];
    compact?: boolean;
    isProcessing: boolean;
    onPurchase: (planId: string, amount: number) => void;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, compact = false, isProcessing, onPurchase }) => {
    const isPopular = plan.tag === 'MOST POPULAR';
    const isBestValue = plan.tag === 'BEST VALUE';

    return (
        <button
            onClick={() => onPurchase(plan.id, plan.amount)}
            disabled={isProcessing}
            className={`
                relative w-full flex items-center p-4 rounded-2xl border transition-all duration-300 group text-left
                ${isPopular 
                    ? 'bg-gradient-to-r from-[#1c1c1e] to-[#252528] border-purple-500/50 shadow-lg shadow-purple-900/10 scale-[1.02] z-10' 
                    : 'bg-[#1c1c1e] border-white/5 hover:border-white/20 hover:bg-[#232326]'
                }
                ${isProcessing ? 'opacity-80 cursor-wait' : 'active:scale-[0.98]'}
                ${compact ? 'mb-3' : ''}
            `}
        >
            {/* Tag Badge */}
            {plan.tag && (
                <div className={`absolute -top-2.5 left-1/2 -translate-x-1/2 text-[9px] font-black px-3 py-0.5 rounded-full text-white shadow-lg uppercase tracking-wide flex items-center gap-1 ${isPopular ? 'bg-gradient-to-r from-purple-500 to-indigo-500' : 'bg-gradient-to-r from-orange-500 to-red-500'}`}>
                    {isPopular ? <SparklesIcon className="w-2.5 h-2.5" /> : <LightningSvg className="w-2.5 h-2.5" />}
                    {plan.tag}
                </div>
            )}

            {/* Icon Circle */}
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner bg-gradient-to-br ${plan.color} mr-4 shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                {isProcessing ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                    plan.icon
                )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2">
                    <h4 className={`text-sm font-bold ${isPopular ? 'text-white' : 'text-gray-200 group-hover:text-white'}`}>
                        {plan.label} Pack
                    </h4>
                </div>
                <p className="text-xs text-gray-500 mt-0.5 flex items-center gap-1">
                    <span className="text-white font-bold text-lg">{plan.amount}</span> 
                    Generations
                </p>
            </div>

            {/* Price Button Look */}
            <div className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${isPopular ? 'bg-white text-black' : 'bg-white/5 text-white group-hover:bg-white group-hover:text-black'}`}>
                {plan.price}
            </div>
        </button>
    );
};

const TokenPurchaseModal: React.FC<TokenPurchaseModalProps> = ({ isOpen, onClose, onPurchase }) => {
    const [isVisible, setIsVisible] = useState(false);
    const [processingPlanId, setProcessingPlanId] = useState<string | null>(null); // ID of plan being processed

    // Mobile Drag State
    const [isDragging, setIsDragging] = useState(false);
    const [translateY, setTranslateY] = useState(0);
    const dragStartY = useRef<number>(0);
    const sheetRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
            setTranslateY(0);
            document.body.style.overflow = 'hidden';
        } else {
            const timer = setTimeout(() => setIsVisible(false), 400);
            document.body.style.overflow = '';
            return () => clearTimeout(timer);
        }
        return () => { document.body.style.overflow = ''; };
    }, [isOpen]);

    const handlePurchase = (planId: string, amount: number) => {
        setProcessingPlanId(planId);
        setTimeout(() => {
            onPurchase(amount);
            setProcessingPlanId(null);
            onClose();
        }, 1500);
    };

    // Mobile Touch Handlers
    const handleTouchStart = (e: React.TouchEvent) => {
        if (sheetRef.current && sheetRef.current.scrollTop > 0) return;
        setIsDragging(true);
        dragStartY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const deltaY = e.touches[0].clientY - dragStartY.current;
        if (deltaY > 0) setTranslateY(deltaY);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (translateY > 100) onClose();
        else setTranslateY(0);
    };

    if (!isVisible && !isOpen) return null;

    return createPortal(
        <div className={`fixed inset-0 z-[200] flex items-end md:items-center justify-center transition-all duration-500 ${isOpen ? 'visible' : 'invisible'}`}>
            
            {/* Backdrop */}
            <div 
                className={`absolute inset-0 bg-black/70 backdrop-blur-xl transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
                onClick={onClose}
            />

            {/* --- DESKTOP LAYOUT (Landscape Card) --- */}
            <div 
                className={`
                    hidden md:flex relative w-[850px] h-[520px] bg-[#0f0f0f] rounded-3xl shadow-2xl border border-white/10 overflow-hidden
                    transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)
                    ${isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-95 opacity-0 translate-y-8'}
                `}
                onClick={e => e.stopPropagation()}
            >
                {/* Close Button */}
                <button 
                    onClick={onClose} 
                    className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-black/40 rounded-full text-gray-400 hover:text-white z-50 transition-colors backdrop-blur-md"
                >
                    <CloseIcon className="w-5 h-5" />
                </button>

                {/* Left Panel: Visual & Info */}
                <div className="w-[40%] relative bg-[#0a0a0a] flex flex-col justify-between p-10 overflow-hidden border-r border-white/5">
                    {/* Dynamic Background */}
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-900/20 via-[#0a0a0a] to-blue-900/20"></div>
                    
                    {/* Floating Orbs */}
                    <div className="absolute top-10 left-10 w-32 h-32 bg-purple-600/20 rounded-full blur-[60px] animate-pulse-slow"></div>
                    <div className="absolute bottom-10 right-10 w-40 h-40 bg-blue-600/20 rounded-full blur-[60px] animate-pulse-slow" style={{ animationDelay: '1s' }}></div>

                    <div className="relative z-10 mt-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-purple-500/30 mb-6 rotate-3">
                            <MagicWandIcon className="w-8 h-8 text-white" />
                        </div>
                        <h2 className="text-3xl font-black text-white mb-3 leading-tight">
                            Unleash Your <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Creativity</span>
                        </h2>
                        <p className="text-sm text-gray-400 leading-relaxed max-w-xs">
                            Tokens allow you to generate high-quality AI images and videos instantly.
                        </p>
                    </div>

                    <div className="relative z-10">
                        <div className="flex items-center gap-3 text-xs text-gray-500 font-medium">
                            <div className="flex -space-x-2">
                                <div className="w-6 h-6 rounded-full bg-purple-500 border-2 border-[#0a0a0a]"></div>
                                <div className="w-6 h-6 rounded-full bg-blue-500 border-2 border-[#0a0a0a]"></div>
                                <div className="w-6 h-6 rounded-full bg-indigo-500 border-2 border-[#0a0a0a]"></div>
                            </div>
                            <span>Trusted by 10k+ creators</span>
                        </div>
                    </div>
                </div>

                {/* Right Panel: Plans Grid */}
                <div className="flex-1 bg-[#121212] p-10 relative flex flex-col">
                    <div className="absolute top-0 right-0 w-full h-32 bg-gradient-to-b from-[#121212] to-transparent pointer-events-none z-10"></div>
                    
                    <div className="flex-1 flex flex-col justify-center space-y-4 relative z-0">
                        {PLANS.map((plan) => (
                            <PlanCard 
                                key={plan.id} 
                                plan={plan} 
                                isProcessing={processingPlanId === plan.id}
                                onPurchase={handlePurchase}
                            />
                        ))}
                    </div>

                    <div className="mt-auto text-center pt-6">
                        <p className="text-[10px] text-gray-600">
                            Secure payment via Stripe. Tokens do not expire.
                            <br />
                            By purchasing, you agree to our Terms.
                        </p>
                    </div>
                </div>
            </div>

            {/* --- MOBILE LAYOUT (Bottom Sheet) --- */}
            <div 
                className={`
                    md:hidden relative w-full bg-[#0f0f0f] border-t border-white/10 
                    rounded-t-[2.5rem] shadow-[0_-10px_50px_rgba(0,0,0,0.9)] flex flex-col
                    max-h-[90vh] h-auto
                    transition-transform duration-300 ease-out
                    ${isOpen ? 'translate-y-0' : 'translate-y-full'}
                `}
                style={{ 
                    transform: isOpen && isDragging ? `translateY(${translateY}px)` : undefined,
                }}
                onClick={e => e.stopPropagation()}
            >
                {/* Drag Handle */}
                <div 
                    className="w-full h-12 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none z-30 flex-shrink-0"
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
                </div>

                <div 
                    ref={sheetRef}
                    className="flex-1 overflow-y-auto custom-scrollbar px-5 pb-safe"
                >
                    {/* Mobile Header */}
                    <div className="text-center mb-8">
                        <div className="w-16 h-16 mx-auto bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-purple-500/20 rotate-6 mb-4">
                            <MagicWandIcon className="w-8 h-8 text-white" />
                        </div>
                        <h2 className="text-2xl font-black text-white mb-1">Get Tokens</h2>
                        <p className="text-sm text-gray-400">Choose a pack to start creating.</p>
                    </div>

                    {/* Plans List */}
                    <div className="space-y-4 mb-8">
                        {PLANS.map((plan) => (
                            <PlanCard 
                                key={plan.id} 
                                plan={plan} 
                                compact 
                                isProcessing={processingPlanId === plan.id}
                                onPurchase={handlePurchase}
                            />
                        ))}
                    </div>

                    {/* Footer */}
                    <div className="text-center pb-6">
                         <button onClick={onClose} className="text-xs font-bold text-gray-500 hover:text-white transition-colors uppercase tracking-wide px-4 py-2">
                            Maybe Later
                        </button>
                        <p className="text-[10px] text-gray-700 mt-4">
                            One-time payment. Non-refundable.
                        </p>
                    </div>
                </div>
            </div>
            
             <style>{`
                .cursor-wait { cursor: wait; }
                .pb-safe { padding-bottom: env(safe-area-inset-bottom, 20px); }
            `}</style>
        </div>,
        document.body
    );
};

export default TokenPurchaseModal;
