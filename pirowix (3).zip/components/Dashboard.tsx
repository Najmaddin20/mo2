
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import type { User, Room, ScheduledEvent, VoiceRoom } from '../types';
import { PlayIcon, CalendarIcon, PrivateIcon, UsersIcon, MicrophoneIcon, StarIcon, HeartIcon, PlusIcon, SearchIcon, PlayFilledIcon, WaveIcon, ListBulletIcon, ChevronDownIcon, FireIcon, ClockIcon, ShareIcon, MoreHorizIcon, MoreVertIcon, HandIcon, TrophyIcon, CloseIcon, ShieldIcon, DoorOutIcon, LinkIcon } from './icons';
import CreateRoomModal from './CreateRoomModal';
import RoomRating from './RoomRating';
import ScheduleRoomModal from './ScheduleRoomModal';
import ActiveUsersLeaderboard from './ActiveUsersLeaderboard';

interface DashboardProps {
    title: string | null;
    currentUser: User;
    onJoinRoom: (room: Room) => void;
    rooms: Room[];
    onCreateRoom: (newRoomData: Pick<Room, 'name' | 'nowPlaying' | 'videoUrl' | 'thumbnail' | 'isPublic' | 'password'>) => void;
    scheduledEvents: ScheduledEvent[];
    onScheduleRoom: (newEventData: Omit<ScheduledEvent, 'id' | 'createdBy' | 'invitedUsers'>) => void;
    onRequestToJoin: (roomId: number) => void;
    isExplorePage?: boolean;
    voiceRooms?: VoiceRoom[];
    onJoinVoiceRoom?: (room: VoiceRoom) => void;
    onOpenShareModal?: (room: Room | VoiceRoom) => void; // Added prop
}

type FeaturedItem = Room | VoiceRoom;

// Helper for Context Menu Position
const adjustMenuPosition = (x: number, y: number, menuW: number, menuH: number) => {
    const screenW = window.innerWidth;
    const screenH = window.innerHeight;
    let left = x;
    let top = y;
    if (x + menuW > screenW) left = screenW - menuW - 10;
    if (y + menuH > screenH) top = screenH - menuH - 10;
    return { top, left };
};

const RoomContextMenu: React.FC<{
    x: number;
    y: number;
    onClose: () => void;
    onJoin: () => void;
    onShare: () => void;
    onReport: () => void;
}> = ({ x, y, onClose, onJoin, onShare, onReport }) => {
    const menuRef = useRef<HTMLDivElement>(null);
    const [pos, setPos] = useState({ top: y, left: x });

    useEffect(() => {
        if (menuRef.current) {
            setPos(adjustMenuPosition(x, y, 200, 150));
        }
    }, [x, y]);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(e.target as Node)) onClose();
        };
        window.addEventListener('mousedown', handleClickOutside);
        return () => window.removeEventListener('mousedown', handleClickOutside);
    }, [onClose]);

    const MenuItem = ({ icon, label, onClick, danger = false }: any) => (
        <button 
            onClick={(e) => { e.stopPropagation(); onClick(); onClose(); }} 
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm transition-all hover:bg-white/10 ${danger ? 'text-red-400' : 'text-white'}`}
        >
            <span className="opacity-70">{icon}</span> <span className="font-medium">{label}</span>
        </button>
    );

    return createPortal(
        <div className="fixed inset-0 z-[9999]" style={{ pointerEvents: 'auto' }}>
            <div className="fixed inset-0 bg-transparent" onClick={onClose}></div>
            <div 
                ref={menuRef}
                className="fixed w-48 bg-[#18181b]/95 backdrop-blur-2xl border border-white/10 rounded-xl shadow-2xl overflow-hidden animate-fade-in-up ring-1 ring-white/5 transform origin-top-left"
                style={{ top: pos.top, left: pos.left }}
            >
                <MenuItem icon={<DoorOutIcon className="w-4 h-4" />} label="Open Room" onClick={onJoin} />
                <MenuItem icon={<ShareIcon className="w-4 h-4" />} label="Share Room" onClick={onShare} />
                <div className="h-px bg-white/10 my-1" />
                <MenuItem icon={<ShieldIcon className="w-4 h-4" />} label="Report" onClick={onReport} danger />
            </div>
        </div>,
        document.body
    );
};

const isVoiceRoom = (item: FeaturedItem): item is VoiceRoom => {
    return (item as VoiceRoom).speakers !== undefined;
};

const FeaturedCarousel: React.FC<{ items: FeaturedItem[]; onJoin: (item: FeaturedItem) => void; onShare: (item: FeaturedItem) => void; onContextMenu: (e: React.MouseEvent, item: FeaturedItem) => void }> = ({ items, onJoin, onShare, onContextMenu }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const touchStartX = useRef<number | null>(null);

    useEffect(() => {
        setCurrentIndex(0);
    }, [items]);

    useEffect(() => {
        if (items.length <= 1) return;
        const interval = setInterval(() => {
            setCurrentIndex((prev) => (prev + 1) % items.length);
        }, 6000);
        return () => clearInterval(interval);
    }, [items.length]);

    const handleTouchStart = (e: React.TouchEvent) => {
        touchStartX.current = e.touches[0].clientX;
    };

    const handleTouchEnd = (e: React.TouchEvent) => {
        if (touchStartX.current === null) return;
        const diff = touchStartX.current - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) { // Swipe left -> next
                setCurrentIndex((prev) => (prev + 1) % items.length);
            } else { // Swipe right -> prev
                setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
            }
        }
        touchStartX.current = null;
    };

    if (items.length === 0) return null;

    const getThemeGradient = (theme?: string) => {
        switch (theme) {
            case 'sunset': return 'bg-gradient-to-br from-orange-900 via-red-900 to-black';
            case 'forest': return 'bg-gradient-to-br from-green-900 via-teal-900 to-black';
            case 'ocean': return 'bg-gradient-to-br from-blue-900 via-cyan-900 to-black';
            case 'midnight': return 'bg-gradient-to-br from-slate-900 via-indigo-900 to-black';
            case 'rose': return 'bg-gradient-to-br from-rose-900 via-pink-900 to-black';
            case 'amber': return 'bg-gradient-to-br from-amber-900 via-yellow-900 to-black';
            case 'cosmic': 
            default: return 'bg-gradient-to-br from-indigo-900 via-purple-900 to-black';
        }
    };

    return (
        <div 
            className="relative w-full h-full group"
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
        >
            <div className="grid grid-cols-1 grid-rows-1 h-full">
                {items.map((item, index) => {
                    const isActive = index === currentIndex;
                    const isVoice = isVoiceRoom(item);
                    const userCount = isVoice ? item.speakers.length + item.listeners.length : item.users.length;
                    const hostName = isVoice ? item.speakers.find(s => s.role === 'host')?.name : item.users.find(u => u.role === 'host')?.name;
                    const hostAvatar = isVoice ? item.speakers.find(s => s.role === 'host')?.avatar : item.users.find(u => u.role === 'host')?.avatar;
                    
                    return (
                        <div 
                            key={item.id}
                            className={`col-start-1 row-start-1 transition-opacity duration-700 ease-in-out h-full ${isActive ? 'opacity-100 z-10 relative' : 'opacity-0 z-0 pointer-events-none absolute inset-0'}`}
                        >
                            <div 
                                className="relative w-full h-full min-h-[350px] md:min-h-full rounded-3xl overflow-hidden shadow-2xl border border-white/10 cursor-pointer"
                                onClick={() => isActive && onJoin(item)}
                                onContextMenu={(e) => { e.preventDefault(); onContextMenu(e, item); }}
                            >
                                {isVoice ? (
                                    <div className={`w-full h-full ${getThemeGradient(item.theme)}`}>
                                        <div className="absolute top-[-20%] right-[-20%] w-[80%] h-[80%] bg-white/5 rounded-full blur-[100px] animate-pulse-slow"></div>
                                        <div className="absolute bottom-[-10%] left-[-10%] w-[60%] h-[60%] bg-black/30 rounded-full blur-[80px]"></div>
                                        <div className="absolute inset-0 flex items-center justify-center opacity-20">
                                            <div className="flex gap-1 items-end h-32">
                                                {[...Array(10)].map((_, i) => (
                                                    <div key={i} className="w-4 bg-white rounded-full animate-music-bar" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.1}s` }}></div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <img 
                                        src={(item as Room).thumbnail} 
                                        alt={(item as Room).name} 
                                        className="w-full h-full object-cover transition-transform duration-[10s] scale-105 group-hover:scale-110"
                                    />
                                )}
                                
                                <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/90" />
                                <div className="absolute bottom-0 left-0 right-0 h-3/4 bg-gradient-to-t from-black via-black/60 to-transparent" />
                                
                                {/* Top Right Controls - Redesigned */}
                                <div className="absolute top-6 right-6 flex items-center gap-3 z-30">
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); onShare(item); }}
                                        className="h-10 w-10 flex items-center justify-center bg-white/20 hover:bg-white/30 backdrop-blur-xl text-white rounded-full transition-all active:scale-95 shadow-lg"
                                        title="Share"
                                    >
                                        <ShareIcon className="w-5 h-5" />
                                    </button>
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); onContextMenu(e, item); }}
                                        className="h-10 w-10 flex items-center justify-center bg-white/20 hover:bg-white/30 backdrop-blur-xl text-white rounded-full transition-all active:scale-95 shadow-lg"
                                    >
                                        <MoreVertIcon className="w-5 h-5" />
                                    </button>
                                </div>

                                {/* Tags */}
                                <div className="absolute top-4 left-4 md:top-8 md:left-8 flex flex-wrap items-center gap-2 z-30">
                                    <span className="bg-red-600/90 backdrop-blur-md text-white text-[10px] md:text-xs font-bold px-2.5 py-1 rounded-lg uppercase tracking-wider animate-pulse shadow-lg shadow-red-600/20">
                                        Live
                                    </span>
                                    <span className="bg-white/10 backdrop-blur-md border border-white/10 text-gray-100 text-[10px] md:text-xs font-bold px-2.5 py-1 rounded-lg uppercase tracking-wider flex items-center gap-1.5">
                                        {isVoice ? <WaveIcon className="w-3 h-3" /> : <PlayFilledIcon className="w-3 h-3" />}
                                        {isVoice ? 'Voice' : 'Watch Party'}
                                    </span>
                                    <span className="bg-black/40 backdrop-blur-md border border-white/10 text-gray-200 text-[10px] md:text-xs font-bold px-2.5 py-1 rounded-lg uppercase tracking-wider flex items-center gap-1">
                                        <UsersIcon className="w-3 h-3" /> {userCount}
                                    </span>
                                </div>

                                {/* Content Bottom - Redesigned Layout */}
                                <div className="absolute bottom-0 left-0 w-full p-5 md:p-10 flex justify-between items-end z-20">
                                    <div className="flex flex-col flex-1 mr-4">
                                        <h1 className="text-2xl md:text-4xl font-black text-white mb-2 md:mb-3 leading-tight drop-shadow-xl line-clamp-2 max-w-4xl">
                                            {isVoice ? (item as VoiceRoom).topic : (item as Room).nowPlaying}
                                        </h1>
                                        <div className="flex items-center gap-3">
                                            <img src={hostAvatar || 'https://i.pravatar.cc/150'} className="w-6 h-6 md:w-8 md:h-8 rounded-full border border-white/30" alt="Host" />
                                            <p className="text-xs md:text-base text-gray-300 font-medium">
                                                Hosted by <span className="text-white font-bold">{hostName || 'Unknown'}</span>
                                            </p>
                                        </div>
                                    </div>
                                    
                                    {/* Join Button - Bottom Right for easy access */}
                                    <button 
                                        className="h-12 md:h-14 px-6 md:px-8 bg-[var(--theme-color)] text-white rounded-2xl font-bold text-sm md:text-base flex items-center justify-center gap-2 hover:brightness-110 transition-all active:scale-95 shadow-xl shadow-[var(--theme-color)]/20"
                                        onClick={(e) => { e.stopPropagation(); onJoin(item); }}
                                    >
                                        {isVoice ? <MicrophoneIcon className="w-5 h-5" /> : <PlayFilledIcon className="w-5 h-5" />} 
                                        <span>{isVoice ? 'Join' : 'Watch'}</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>

            <div className="absolute bottom-[6rem] right-6 md:bottom-[5.5rem] md:right-10 z-30 flex gap-2">
                {items.map((_, idx) => (
                    <div 
                        key={idx} 
                        className={`h-1.5 rounded-full transition-all duration-500 cursor-pointer shadow-sm ${idx === currentIndex ? 'w-6 bg-white' : 'w-1.5 bg-white/30 hover:bg-white/60'}`} 
                        onClick={(e) => { e.stopPropagation(); setCurrentIndex(idx); }}
                    />
                ))}
            </div>
            
            <style>{`
                @keyframes music-bar {
                    0% { height: 10%; }
                    50% { height: 100%; }
                    100% { height: 10%; }
                }
                .animate-music-bar {
                    animation: music-bar 1s ease-in-out infinite;
                }
            `}</style>
        </div>
    );
};

const RoomCard: React.FC<{ room: Room; currentUser: User; onJoinRoom: (room: Room) => void; onRequestToJoin: (roomId: number) => void; onContextMenu: (e: React.MouseEvent, room: Room) => void }> = ({ room, currentUser, onJoinRoom, onRequestToJoin, onContextMenu }) => {
    const isPrivate = !room.isPublic;
    const hasRequested = room.joinRequests?.some(u => u.id === currentUser.id);
    const [isHovered, setIsHovered] = useState(false);

    const handleAction = () => {
        if (isPrivate && !room.password && !hasRequested) {
            onRequestToJoin(room.id);
        } else {
            onJoinRoom(room);
        }
    };
    
    return (
        <div 
            className="group relative bg-[#18181b]/60 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl cursor-pointer flex flex-col h-full"
            onClick={handleAction}
            onContextMenu={(e) => { e.preventDefault(); onContextMenu(e, room); }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            style={{
                boxShadow: isHovered ? '0 25px 50px -12px color-mix(in srgb, var(--theme-color), transparent 80%)' : undefined
            }}
        >
            <div className="relative aspect-video w-full overflow-hidden">
                <img 
                    src={room.thumbnail} 
                    alt={room.name} 
                    className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${isPrivate ? 'blur-[2px] grayscale-[50%]' : ''}`} 
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                <div className="absolute top-3 left-3 flex gap-2">
                    {room.isPlaying && !isPrivate && (
                        <div className="flex items-center gap-1.5 bg-red-500/90 backdrop-blur-md px-2 py-1 rounded-lg shadow-lg">
                            <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></div>
                            <span className="text-[10px] font-bold text-white tracking-wide">LIVE</span>
                        </div>
                    )}
                    {isPrivate && (
                        <div className="bg-black/60 backdrop-blur-md p-1.5 rounded-lg text-gray-300">
                            <PrivateIcon className="w-3.5 h-3.5" />
                        </div>
                    )}
                </div>
                
                <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg flex items-center gap-1 text-white/90">
                    <UsersIcon className="w-3 h-3" />
                    <span className="text-xs font-bold">{room.users.length}</span>
                </div>

                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 bg-black/20 backdrop-blur-[2px]">
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-2xl transform scale-50 group-hover:scale-100 transition-transform duration-300">
                        <PlayIcon className="w-5 h-5 text-black ml-0.5" />
                    </div>
                </div>
            </div>

            <div className="p-4 flex flex-col gap-2 flex-1">
                <div className="flex justify-between items-start">
                    <h3 className="text-white font-bold text-lg leading-tight line-clamp-1 group-hover:text-[var(--theme-color)] transition-colors">{room.name}</h3>
                    <div className="flex items-center gap-1 text-yellow-400 bg-yellow-400/10 px-1.5 py-0.5 rounded">
                        <StarIcon className="w-3 h-3" filled />
                        <span className="text-xs font-bold">{room.rating?.toFixed(1) || 'New'}</span>
                    </div>
                </div>
                
                <p className="text-gray-400 text-xs font-medium uppercase tracking-wider line-clamp-1">Now Playing</p>
                <p className="text-gray-200 text-sm font-medium line-clamp-1">{room.nowPlaying}</p>

                <div className="mt-auto pt-4 flex items-center justify-between border-t border-white/5">
                    <div className="flex items-center gap-2">
                        <img src={room.users.find(u => u.role === 'host')?.avatar || 'https://i.pravatar.cc/150'} className="w-6 h-6 rounded-full border border-white/20" />
                        <span className="text-xs text-gray-400 truncate max-w-[100px]">Hosted by {room.users.find(u => u.role === 'host')?.name}</span>
                    </div>
                    <span className="text-[10px] text-white/50 bg-white/5 px-2 py-1 rounded border border-white/5">
                        Movie
                    </span>
                </div>
            </div>
        </div>
    );
}

const getVoiceCardTheme = (theme: string = 'cosmic') => {
    switch (theme) {
        case 'sunset': return { text: 'text-orange-400', border: 'hover:border-orange-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(249,115,22,0.3)]', tag: 'text-orange-300 border-orange-500/20 bg-orange-500/10' };
        case 'forest': return { text: 'text-emerald-400', border: 'hover:border-emerald-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(16,185,129,0.3)]', tag: 'text-emerald-300 border-emerald-500/20 bg-emerald-500/10' };
        case 'ocean': return { text: 'text-cyan-400', border: 'hover:border-cyan-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(6,182,212,0.3)]', tag: 'text-cyan-300 border-cyan-500/20 bg-cyan-500/10' };
        case 'midnight': return { text: 'text-indigo-400', border: 'hover:border-indigo-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(99,102,241,0.3)]', tag: 'text-indigo-300 border-indigo-500/20 bg-indigo-500/10' };
        case 'rose': return { text: 'text-rose-400', border: 'hover:border-rose-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(244,63,94,0.3)]', tag: 'text-rose-300 border-rose-500/20 bg-rose-500/10' };
        case 'amber': return { text: 'text-amber-400', border: 'hover:border-amber-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(245,158,11,0.3)]', tag: 'text-amber-300 border-amber-500/20 bg-amber-500/10' };
        case 'cosmic': default: return { text: 'text-purple-400', border: 'hover:border-purple-500/50', shadow: 'hover:shadow-[0_0_30px_-10px_rgba(168,85,247,0.3)]', tag: 'text-purple-300 border-purple-500/20 bg-purple-500/10' };
    }
}

const VoiceRoomCard: React.FC<{ room: VoiceRoom; onJoin: () => void; onContextMenu: (e: React.MouseEvent, room: VoiceRoom) => void }> = ({ room, onJoin, onContextMenu }) => {
    const speakers = room.speakers;
    const styles = getVoiceCardTheme(room.theme);

    return (
        <div 
            onClick={onJoin}
            onContextMenu={(e) => { e.preventDefault(); onContextMenu(e, room); }}
            className={`bg-[#1e1e24]/40 backdrop-blur-md border border-white/5 rounded-2xl p-5 flex flex-col transition-all duration-300 shadow-lg transform hover:-translate-y-1 relative group cursor-pointer overflow-hidden ${styles.border} ${styles.shadow}`}
        >
            <div className="relative z-10 flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                    <div className="flex flex-wrap gap-2">
                        {room.topics?.slice(0, 2).map(tag => (
                            <span key={tag} className={`text-[10px] font-bold px-2 py-1 rounded-md border ${styles.tag}`}>{tag}</span>
                        ))}
                    </div>
                    {room.isPrivate && <PrivateIcon className="w-4 h-4 text-gray-500" />}
                </div>

                <h3 className={`text-xl font-bold text-white leading-tight mb-2 transition-colors line-clamp-2 ${styles.text}`}>{room.topic}</h3>
                
                <div className="mt-auto space-y-4">
                    <div className="flex items-center gap-3">
                        <div className="flex -space-x-2 overflow-hidden py-1 pl-1">
                            {speakers.slice(0, 3).map(speaker => (
                                <div key={speaker.id} className="relative">
                                    <img src={speaker.avatar} className={`w-9 h-9 rounded-full border-2 border-[#1e1931] object-cover ${speaker.isSpeaking ? 'ring-2 ring-green-500' : ''}`} />
                                    {speaker.isSpeaking && <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-[#1e1931] rounded-full"></div>}
                                </div>
                            ))}
                             {speakers.length > 3 && (
                                <div className="w-9 h-9 rounded-full bg-[#2a2a35] flex items-center justify-center text-xs font-bold text-white border-2 border-[#1e1931]">
                                    +{speakers.length - 3}
                                </div>
                            )}
                        </div>
                        <div className="h-8 w-px bg-white/10"></div>
                        <div className="flex flex-col">
                            <span className="text-xs text-gray-400">Speakers</span>
                            <span className="text-sm font-bold text-white">{speakers.length}</span>
                        </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-xs font-medium text-gray-400 pt-3 border-t border-white/5">
                        <div className="flex items-center gap-1">
                            <UsersIcon className="w-3.5 h-3.5" />
                            {speakers.length + room.listeners.length} Listening
                        </div>
                        <div className={`flex items-center gap-1 px-2 py-0.5 rounded border ${room.openMicMode ? 'text-green-400 border-green-500/30 bg-green-500/10' : 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10'}`}>
                            {room.openMicMode ? (
                                <>
                                    <MicrophoneIcon className="w-3 h-3" />
                                    <span className="text-[9px] font-bold uppercase">Open</span>
                                </>
                            ) : (
                                <>
                                    <HandIcon className="w-3 h-3" />
                                    <span className="text-[9px] font-bold uppercase">Raise Hand</span>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const FilterTab: React.FC<{ label: string, active: boolean, onClick: () => void, icon?: React.ReactNode, isMobile?: boolean }> = ({ label, active, onClick, icon, isMobile }) => (
    <button 
        onClick={onClick} 
        className={`
            relative rounded-lg font-bold transition-all duration-300 flex items-center gap-2 whitespace-nowrap
            ${isMobile ? 'px-4 py-2 text-xs' : 'px-5 py-2 text-sm'}
            ${active 
                ? 'text-white shadow-lg' 
                : 'text-gray-400 hover:text-white ' + (isMobile ? 'bg-white/5' : 'hover:bg-white/5')
            }
        `}
        style={active ? { 
            backgroundColor: 'var(--theme-color)',
            boxShadow: '0 10px 15px -3px color-mix(in srgb, var(--theme-color), transparent 70%)'
        } : undefined}
    >
        {icon}
        <span>{label}</span>
    </button>
);

const Dashboard: React.FC<DashboardProps> = ({ title, currentUser, onJoinRoom, rooms, onCreateRoom, scheduledEvents, onScheduleRoom, onRequestToJoin, isExplorePage, voiceRooms, onJoinVoiceRoom, onOpenShareModal }) => {
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
    const [activeCategory, setActiveCategory] = useState<'All' | 'WatchParty' | 'Voice'>('All');
    const [sortMode, setSortMode] = useState<'popular' | 'new'>('popular');
    const [showLeaderboardMobile, setShowLeaderboardMobile] = useState(false);
    const [contextMenu, setContextMenu] = useState<{x: number, y: number, item: FeaturedItem} | null>(null);

    // Featured items logic
    const featuredItems = useMemo(() => {
        const items: FeaturedItem[] = [];
        if (activeCategory === 'All' || activeCategory === 'WatchParty') items.push(...rooms);
        if ((activeCategory === 'All' || activeCategory === 'Voice') && voiceRooms) items.push(...voiceRooms);

        return items.sort((a, b) => {
            const countA = isVoiceRoom(a) ? a.speakers.length + a.listeners.length : a.users.length;
            const countB = isVoiceRoom(b) ? b.speakers.length + b.listeners.length : b.users.length;
            return countB - countA;
        }).slice(0, 5); 
    }, [rooms, voiceRooms, activeCategory]);

    const activeUsers = useMemo(() => {
        const allUsers = new Map<number, User>();
        rooms.forEach(room => room.users.forEach(u => allUsers.set(u.id, u)));
        voiceRooms?.forEach(room => {
            room.speakers.forEach(u => allUsers.set(u.id, u));
            room.listeners.forEach(u => allUsers.set(u.id, u));
        });
        if (!allUsers.has(currentUser.id)) allUsers.set(currentUser.id, currentUser);
        return Array.from(allUsers.values());
    }, [rooms, voiceRooms, currentUser]);

    const showVoiceRooms = isExplorePage && (activeCategory === 'All' || activeCategory === 'Voice');
    const showWatchParties = !isExplorePage || (activeCategory === 'All' || activeCategory === 'WatchParty');

    const sortedRooms = useMemo(() => {
        let r = [...rooms];
        if (sortMode === 'popular') r.sort((a, b) => b.users.length - a.users.length);
        else r.sort((a, b) => b.id - a.id);
        return r;
    }, [rooms, sortMode]);

    const renderSortButton = (isMobile = false) => (
        <button 
            onClick={() => setSortMode(prev => prev === 'popular' ? 'new' : 'popular')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all text-xs font-bold text-gray-300 hover:text-white flex-shrink-0 ${isMobile ? 'h-8 py-0 px-3' : ''}`}
            title={`Sort by: ${sortMode === 'popular' ? 'Trending' : 'Newest'}`}
        >
            {!isMobile && <span className="text-gray-500 uppercase tracking-wider hidden sm:inline">Sort:</span>}
            {sortMode === 'popular' ? (
                <div className="flex items-center gap-1.5">
                    <FireIcon className="w-4 h-4 text-orange-500" />
                    <span className={isMobile ? '' : 'hidden sm:inline'}>Trending</span>
                </div>
            ) : (
                <div className="flex items-center gap-1.5">
                    <ClockIcon className="w-4 h-4 text-blue-500" />
                    <span className="text-blue-500 hidden sm:inline">Newest</span>
                </div>
            )}
        </button>
    );

    const renderFilterTabs = (isMobile = false) => (
        <div className={`flex items-center ${isMobile ? 'gap-2 overflow-x-auto hide-scrollbar w-full' : 'p-1 bg-white/5 border border-white/5 rounded-xl w-fit'}`}>
            <FilterTab label="All" active={activeCategory === 'All'} onClick={() => setActiveCategory('All')} isMobile={isMobile} />
            <FilterTab label="Watch" active={activeCategory === 'WatchParty'} onClick={() => setActiveCategory('WatchParty')} icon={<PlayFilledIcon className="w-3 h-3"/>} isMobile={isMobile} />
            <FilterTab label="Voice" active={activeCategory === 'Voice'} onClick={() => setActiveCategory('Voice')} icon={<MicrophoneIcon className="w-3 h-3"/>} isMobile={isMobile} />
        </div>
    );

    const handleFeaturedJoin = (item: FeaturedItem) => {
        if (isVoiceRoom(item)) onJoinVoiceRoom?.(item);
        else onJoinRoom(item);
    };

    const handleContextMenu = (e: React.MouseEvent, item: FeaturedItem) => {
        setContextMenu({ x: e.clientX, y: e.clientY, item });
    };

    return (
        <div className="min-h-full w-full bg-transparent p-4 md:p-8 pb-24 relative">
            <div className="max-w-[1600px] mx-auto">
                
                {isExplorePage && (
                    <div className="md:hidden flex items-center justify-between mb-6 gap-3 sticky top-0 z-30 py-3 -mx-4 px-4 -mt-4 bg-black/80 backdrop-blur-xl border-b border-white/5 shadow-lg">
                        <div className="flex-1 min-w-0">{renderFilterTabs(true)}</div>
                        <div className="flex items-center gap-2 shrink-0">
                            <button onClick={() => setShowLeaderboardMobile(true)} className="h-8 w-8 flex items-center justify-center bg-[#6C5DD3]/20 text-[#8A79F7] rounded-lg border border-[#6C5DD3]/50 active:scale-95 transition-transform" title="View Leaderboard"><TrophyIcon className="w-4 h-4" /></button>
                            {renderSortButton(true)}
                        </div>
                    </div>
                )}

                <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-6 md:mb-8 gap-6">
                    <div>
                        <div className="flex items-center gap-3">
                            <h1 className="text-3xl md:text-4xl font-black text-white mb-1 tracking-tight drop-shadow-lg">
                                {title || (isExplorePage ? "Explore" : "Dashboard")}
                            </h1>
                        </div>
                        <p className="text-gray-400 text-base font-medium">
                            {isExplorePage ? "Discover what's trending right now." : "Welcome back to your space."}
                        </p>
                    </div>
                    
                    <div className="w-full md:w-auto">
                        {!isExplorePage ? (
                            <div className="flex gap-3 w-full md:w-auto">
                                <button onClick={() => setIsScheduleModalOpen(true)} className="flex-1 md:flex-none bg-white/5 hover:bg-white/10 backdrop-blur-md text-white font-bold px-5 py-3 rounded-2xl transition-colors flex items-center justify-center gap-2 border border-white/10">
                                <CalendarIcon className="w-5 h-5"/> Schedule
                                </button>
                                <button onClick={() => setIsCreateModalOpen(true)} className="flex-1 md:flex-none bg-white text-black font-bold px-6 py-3 rounded-2xl hover:bg-gray-200 transition-all shadow-lg shadow-white/10 transform active:scale-95 flex items-center justify-center gap-2">
                                    <PlayIcon className="w-5 h-5"/> Create Room
                                </button>
                            </div>
                        ) : (
                            <div className="hidden md:flex items-center gap-3">
                                {renderFilterTabs()}
                                {renderSortButton()}
                            </div>
                        )}
                    </div>
                </div>

                {isExplorePage && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12 md:mb-10 animate-fade-in-up items-start">
                        <div className="lg:col-span-2 w-full h-[350px] md:h-[400px] mb-6 md:mb-0">
                            {featuredItems.length > 0 ? (
                                <FeaturedCarousel 
                                    items={featuredItems} 
                                    onJoin={handleFeaturedJoin} 
                                    onShare={(item) => onOpenShareModal?.(item)}
                                    onContextMenu={handleContextMenu}
                                />
                            ) : (
                                <div className="w-full h-full min-h-[350px] bg-white/5 rounded-3xl flex items-center justify-center border border-dashed border-white/10">
                                    <p className="text-gray-500">No featured items yet.</p>
                                </div>
                            )}
                        </div>
                        <div className="hidden md:block lg:col-span-1 h-[400px]">
                            <ActiveUsersLeaderboard users={activeUsers} />
                        </div>
                    </div>
                )}

                {showVoiceRooms && voiceRooms && voiceRooms.length > 0 && (
                    <div className="mb-12 animate-fade-in-up">
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                <span className="p-2 rounded-xl" style={{ backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 80%)', color: 'var(--theme-color)' }}><WaveIcon className="w-5 h-5"/></span>
                                Live Voice Conversations
                            </h2>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {voiceRooms.map(room => (
                                <VoiceRoomCard 
                                    key={room.id} 
                                    room={room} 
                                    onJoin={() => onJoinVoiceRoom?.(room)} 
                                    onContextMenu={handleContextMenu}
                                />
                            ))}
                        </div>
                    </div>
                )}

                {showWatchParties && (
                    <div className="animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                <span className="p-2 rounded-xl" style={{ backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 80%)', color: 'var(--theme-color)' }}><PlayIcon className="w-5 h-5"/></span>
                                Watch Parties
                            </h2>
                        </div>
                        {sortedRooms.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                                {sortedRooms.map(room => (
                                    <RoomCard 
                                        key={room.id} 
                                        room={room} 
                                        currentUser={currentUser} 
                                        onJoinRoom={onJoinRoom} 
                                        onRequestToJoin={onRequestToJoin} 
                                        onContextMenu={handleContextMenu}
                                    />
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-24 bg-white/5 rounded-[2.5rem] border border-dashed border-white/10 backdrop-blur-sm">
                                <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <PlayIcon className="w-10 h-10 text-gray-500" />
                                </div>
                                <p className="text-gray-400 font-medium text-lg">No active watch parties found.</p>
                                {!isExplorePage && <button onClick={() => setIsCreateModalOpen(true)} className="mt-6 text-white font-bold bg-white/10 hover:bg-white/20 px-6 py-3 rounded-xl transition-colors">Start the first one</button>}
                            </div>
                        )}
                    </div>
                )}
            </div>

            <CreateRoomModal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} onCreateRoom={onCreateRoom} />
            <ScheduleRoomModal isOpen={isScheduleModalOpen} onClose={() => setIsScheduleModalOpen(false)} onScheduleRoom={onScheduleRoom} />
            
            {showLeaderboardMobile && (
                <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6" onClick={() => setShowLeaderboardMobile(false)}>
                    <div 
                        className="w-full h-[85vh] sm:h-[600px] sm:max-w-md bg-black/30 backdrop-blur-3xl border-t border-white/20 sm:border sm:rounded-3xl rounded-t-3xl overflow-hidden flex flex-col shadow-2xl animate-slide-in-from-bottom" 
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-end p-4 pb-0">
                            <button onClick={() => setShowLeaderboardMobile(false)} className="p-2 bg-white/10 rounded-full text-gray-300 hover:text-white backdrop-blur-md">
                                <CloseIcon className="w-5 h-5" />
                            </button>
                        </div>
                        <div className="flex-1 overflow-hidden p-4 pt-0">
                            <ActiveUsersLeaderboard users={activeUsers} isMobile />
                        </div>
                    </div>
                </div>
            )}

            {contextMenu && (
                <RoomContextMenu 
                    x={contextMenu.x} 
                    y={contextMenu.y} 
                    onClose={() => setContextMenu(null)}
                    onJoin={() => handleFeaturedJoin(contextMenu.item)}
                    onShare={() => onOpenShareModal?.(contextMenu.item)}
                    onReport={() => alert('Room reported')}
                />
            )}
        </div>
    );
};

export default Dashboard;
