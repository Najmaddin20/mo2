
import React, { useState, useEffect } from 'react';
import type { ScheduledEvent } from '../types';
import { CloseIcon, CalendarIcon, ClockIcon, LinkIcon, FileIcon, PlayIcon, ChevronDownIcon } from './icons';

interface ScheduleRoomModalProps {
    isOpen: boolean;
    onClose: () => void;
    onScheduleRoom: (newEventData: Omit<ScheduledEvent, 'id' | 'createdBy' | 'invitedUsers' | 'rsvps'>) => void;
}

const ScheduleRoomModal: React.FC<ScheduleRoomModalProps> = ({ isOpen, onClose, onScheduleRoom }) => {
    const [title, setTitle] = useState('');
    const [videoUrl, setVideoUrl] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [description, setDescription] = useState('');
    const [thumbnail, setThumbnail] = useState('');

    useEffect(() => {
        if (isOpen) {
            setTitle('');
            setVideoUrl('');
            setDate('');
            setTime('');
            setDescription('');
            setThumbnail('');
        }
    }, [isOpen]);

    // Auto-detect thumbnail
    useEffect(() => {
        if (!videoUrl) {
            setThumbnail('');
            return;
        }
        const ytMatch = videoUrl.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
        if (ytMatch && ytMatch[1]) {
            setThumbnail(`https://i.ytimg.com/vi/${ytMatch[1]}/maxresdefault.jpg`);
        } else {
             // Fallback logic if needed
        }
    }, [videoUrl]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (title && videoUrl && date && time) {
            onScheduleRoom({
                title,
                description,
                videoUrl,
                thumbnail: thumbnail || `https://picsum.photos/seed/${Date.now()}/800/450`, // Fallback random image
                scheduledTime: new Date(`${date}T${time}`),
            });
            onClose();
        }
    };

    if (!isOpen) return null;

    const previewImage = thumbnail || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80';

    return (
        <div className="fixed inset-0 z-[100] flex sm:items-center justify-center sm:p-4">
            {/* Backdrop */}
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose}></div>

            {/* Modal Container */}
            <div 
                className="relative bg-[#121214]/90 backdrop-blur-3xl w-full h-full sm:h-[600px] sm:max-w-4xl sm:rounded-3xl shadow-2xl border border-white/10 overflow-hidden flex flex-col sm:flex-row animate-fade-in-up"
                onClick={e => e.stopPropagation()}
            >
                {/* Mobile Header (Only visible on mobile) */}
                <div className="sm:hidden absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-20 bg-gradient-to-b from-black/80 to-transparent">
                    <button onClick={onClose} className="p-2 bg-black/60 rounded-full text-white border border-white/10 active:scale-95 transition-transform">
                        <ChevronDownIcon className="w-6 h-6" />
                    </button>
                </div>

                {/* Left/Top: Preview Section */}
                <div className="relative w-full sm:w-[45%] h-64 sm:h-full bg-black/50 overflow-hidden group flex-shrink-0">
                    <div 
                        className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" 
                        style={{ backgroundImage: `url(${previewImage})` }}
                    ></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-[#121214] via-black/40 to-transparent sm:bg-gradient-to-r sm:from-transparent sm:via-black/40 sm:to-[#121214]"></div>
                    
                    <div className="absolute top-4 left-4 hidden sm:block">
                        <div className="px-3 py-1 rounded-full bg-black/80 border border-white/10 text-[10px] font-bold text-white uppercase tracking-wider shadow-lg">
                            Preview
                        </div>
                    </div>

                    <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 flex flex-col justify-end z-10">
                        <h2 className="text-2xl sm:text-3xl font-bold text-white leading-tight mb-3 line-clamp-2 shadow-black drop-shadow-md">
                            {title || "Event Title"}
                        </h2>
                        <div className="flex items-center gap-2 text-sm font-medium text-gray-200">
                            {/* Icons are wrapped in divs with solid backgrounds to prevent blur issues */}
                            <div className="flex items-center gap-1.5 bg-[#27272a] px-2.5 py-1.5 rounded-lg border border-white/10 shadow-sm">
                                <span className="text-[var(--theme-color)] flex items-center justify-center"><CalendarIcon className="w-4 h-4" /></span>
                                <span className="text-xs font-bold">{date ? new Date(date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'Date'}</span>
                            </div>
                            <div className="flex items-center gap-1.5 bg-[#27272a] px-2.5 py-1.5 rounded-lg border border-white/10 shadow-sm">
                                <span className="text-[var(--theme-color)] flex items-center justify-center"><ClockIcon className="w-4 h-4" /></span>
                                <span className="text-xs font-bold">{time || 'Time'}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right/Bottom: Form Section */}
                <div className="flex-1 flex flex-col relative h-full overflow-hidden bg-[#121214]">
                    {/* Desktop Header */}
                    <div className="hidden sm:flex p-6 border-b border-white/5 justify-between items-center bg-white/[0.02]">
                        <h3 className="text-xl font-bold text-white">Schedule Event</h3>
                        <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
                            <CloseIcon className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 custom-scrollbar">
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">What are we watching?</label>
                            <input 
                                type="text" 
                                value={title}
                                onChange={e => setTitle(e.target.value)}
                                placeholder="Event Title"
                                className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] transition-colors shadow-inner"
                                autoFocus
                            />
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Video Link</label>
                            <div className="relative">
                                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none flex items-center justify-center">
                                    <LinkIcon className="w-5 h-5" />
                                </div>
                                <input 
                                    type="url" 
                                    value={videoUrl}
                                    onChange={e => setVideoUrl(e.target.value)}
                                    placeholder="Paste YouTube URL..."
                                    className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] transition-colors shadow-inner"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Date</label>
                                <div className="relative">
                                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none flex items-center justify-center">
                                        <CalendarIcon className="w-5 h-5" />
                                    </div>
                                    <input 
                                        type="date" 
                                        value={date}
                                        onChange={e => setDate(e.target.value)}
                                        className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-gray-500 focus:outline-none focus:border-[var(--theme-color)] transition-colors appearance-none shadow-inner [&::-webkit-calendar-picker-indicator]:invert"
                                    />
                                </div>
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Time</label>
                                <div className="relative">
                                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none flex items-center justify-center">
                                        <ClockIcon className="w-5 h-5" />
                                    </div>
                                    <input 
                                        type="time" 
                                        value={time}
                                        onChange={e => setTime(e.target.value)}
                                        className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-gray-500 focus:outline-none focus:border-[var(--theme-color)] transition-colors appearance-none shadow-inner [&::-webkit-calendar-picker-indicator]:invert"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">Description <span className="opacity-50 normal-case font-normal">(Optional)</span></label>
                            <textarea 
                                value={description}
                                onChange={e => setDescription(e.target.value)}
                                placeholder="Tell everyone what this event is about..."
                                rows={3}
                                className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] transition-colors resize-none shadow-inner"
                            />
                        </div>
                    </div>

                    <div className="p-5 sm:p-6 border-t border-white/5 bg-[#18181b] mt-auto sticky bottom-0">
                        <button 
                            onClick={handleSubmit}
                            disabled={!title || !videoUrl || !date || !time}
                            className="w-full py-4 rounded-2xl text-white font-bold text-sm shadow-lg transition-all transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                            style={{ backgroundColor: 'var(--theme-color)' }}
                        >
                            <CalendarIcon className="w-5 h-5" />
                            Schedule Event
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ScheduleRoomModal;
