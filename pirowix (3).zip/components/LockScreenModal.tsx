
import React, { useState, useEffect, useCallback } from 'react';
import { LockClosedIcon, CloseIcon } from './icons';

interface LockScreenModalProps {
    isOpen: boolean;
    mode: 'setup' | 'enter';
    onClose: () => void;
    onPinSet: (pin: string) => void;
    onPinUnlockAttempt: (pin: string) => boolean;
    targetChatName?: string;
}

const LockScreenModal: React.FC<LockScreenModalProps> = ({ isOpen, mode, onClose, onPinSet, onPinUnlockAttempt, targetChatName }) => {
    const [internalMode, setInternalMode] = useState<'setup' | 'confirmSetup' | 'enter'>(mode);
    const [pin, setPin] = useState<string>('');
    const [tempPin, setTempPin] = useState<string>('');
    const [error, setError] = useState<boolean>(false);
    const [shake, setShake] = useState(false);

    useEffect(() => {
        setInternalMode(mode);
        setPin('');
        setTempPin('');
        setError(false);
    }, [isOpen, mode]);

    const handleNumberClick = (num: number) => {
        if (pin.length < 4) {
            const newPin = pin + num;
            setPin(newPin);
            if (newPin.length === 4) {
                setTimeout(() => handleSubmit(newPin), 300);
            }
        }
    };

    const handleBackspace = () => {
        setPin(prev => prev.slice(0, -1));
        setError(false);
    };

    const triggerError = () => {
        setError(true);
        setShake(true);
        setPin('');
        setTimeout(() => setShake(false), 500);
    };

    const handleSubmit = (fullPin: string) => {
        if (internalMode === 'setup') {
            setTempPin(fullPin);
            setInternalMode('confirmSetup');
            setPin('');
        } else if (internalMode === 'confirmSetup') {
            if (fullPin === tempPin) {
                onPinSet(fullPin);
            } else {
                triggerError();
                setInternalMode('setup');
                setTempPin('');
            }
        } else if (internalMode === 'enter') {
            const success = onPinUnlockAttempt(fullPin);
            if (!success) {
                triggerError();
            }
        }
    };

    if (!isOpen) return null;

    const titles = {
        setup: "Set a PIN",
        confirmSetup: "Confirm PIN",
        enter: "Enter PIN"
    };

    const subtitles = {
        setup: `Secure your chat with ${targetChatName}`,
        confirmSetup: "Please re-enter your PIN",
        enter: targetChatName ? `Unlock chat with ${targetChatName}` : "Enter your PIN to access"
    };

    return (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex items-center justify-center z-[100]" onClick={e => e.stopPropagation()}>
            <div className={`w-full max-w-xs flex flex-col items-center p-6 ${shake ? 'animate-shake' : ''}`}>
                
                {/* Header */}
                <div className="flex flex-col items-center mb-10">
                    <div className="w-12 h-12 bg-[#1c1c1e] rounded-full flex items-center justify-center mb-4 shadow-inner">
                        <LockClosedIcon className={`w-6 h-6 ${error ? 'text-red-500' : 'text-[var(--theme-color)]'}`} />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">{error ? "Incorrect PIN" : titles[internalMode]}</h2>
                    <p className={`text-sm text-center ${error ? 'text-red-400' : 'text-gray-400'}`}>
                        {error ? "Try again" : subtitles[internalMode]}
                    </p>
                </div>

                {/* Dots */}
                <div className="flex gap-4 mb-12">
                    {[0, 1, 2, 3].map((i) => (
                        <div 
                            key={i} 
                            className={`w-4 h-4 rounded-full transition-all duration-300 ${
                                i < pin.length 
                                    ? error ? 'bg-red-500' : 'bg-[var(--theme-color)] scale-110' 
                                    : 'bg-white/20'
                            }`}
                        />
                    ))}
                </div>

                {/* Keypad */}
                <div className="grid grid-cols-3 gap-x-8 gap-y-6 mb-8">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                        <button
                            key={num}
                            onClick={() => handleNumberClick(num)}
                            className="w-16 h-16 rounded-full bg-white/5 hover:bg-white/20 text-2xl font-semibold text-white transition-all active:scale-90 flex items-center justify-center"
                        >
                            {num}
                        </button>
                    ))}
                    <div className="w-16 h-16 flex items-center justify-center">
                        {/* Placeholder for Biometric or Empty */}
                        {internalMode === 'enter' && (
                            <button onClick={() => alert("Biometric Scan...")} className="text-gray-500 hover:text-white">
                                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.2-2.858.59-4.175m0 0c1.144-3.854 4.567-6.679 8.736-7.012M6.345 11.218A1.992 1.992 0 0012 9.625v-1.75m-1.689 2.125a2.25 2.25 0 00-4.231-1.122m1.61 5.235A2.25 2.25 0 0112 13.125" />
                                </svg>
                            </button>
                        )}
                    </div>
                    <button
                        onClick={() => handleNumberClick(0)}
                        className="w-16 h-16 rounded-full bg-white/5 hover:bg-white/20 text-2xl font-semibold text-white transition-all active:scale-90 flex items-center justify-center"
                    >
                        0
                    </button>
                    <button
                        onClick={handleBackspace}
                        className="w-16 h-16 flex items-center justify-center text-gray-400 hover:text-white transition-colors active:scale-90"
                    >
                        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.414 6.414a2 2 0 001.414.586H19a2 2 0 002-2V7a2 2 0 00-2-2h-8.172a2 2 0 00-1.414.586L3 12z" />
                        </svg>
                    </button>
                </div>

                <button onClick={onClose} className="text-sm font-medium text-gray-500 hover:text-white mt-4">
                    Cancel
                </button>
            </div>
            <style>{`
                @keyframes shake {
                    0%, 100% { transform: translateX(0); }
                    25% { transform: translateX(-5px); }
                    75% { transform: translateX(5px); }
                }
                .animate-shake { animation: shake 0.3s ease-in-out; }
            `}</style>
        </div>
    );
};

export default LockScreenModal;
