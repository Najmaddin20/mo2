
import React, { useState, useEffect } from 'react';
import { EyeIcon, EyeOffIcon, GoogleIcon, ArrowRightIcon, SpinnerIcon, AtSymbolIcon, LockClosedIcon, UserAddIcon, PlayFilledIcon, FilmIcon, ChatIcon, HeartIcon } from './icons';

interface AuthPageProps {
    onLogin: (username: string) => void;
}

// --- Mock Data for the "Wall of Entertainment" ---
const POSTERS = [
    "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&q=80", // Movie 1
    "https://images.unsplash.com/photo-1616530940355-351fabd9524b?auto=format&fit=crop&w=400&q=80", // Movie 2
    "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&w=400&q=80", // Movie 3
    "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?auto=format&fit=crop&w=400&q=80", // Movie 4
    "https://images.unsplash.com/photo-1574267432553-4b4628081c31?auto=format&fit=crop&w=400&q=80", // Movie 5
    "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=400&q=80", // Abstract
    "https://images.unsplash.com/photo-1614728853911-7944d193f971?auto=format&fit=crop&w=400&q=80", // Space
    "https://images.unsplash.com/photo-1515634928627-2a4e0dae3ddf?auto=format&fit=crop&w=400&q=80", // Concert
    "https://images.unsplash.com/photo-1535016120720-40c6874c3b1c?auto=format&fit=crop&w=400&q=80", // Party
];

// --- Components ---

const ScrollingPosterWall = () => {
    // Create 3 columns of scrolling images
    return (
        <div className="absolute inset-0 overflow-hidden flex gap-4 opacity-40 transform rotate-6 scale-110 pointer-events-none">
            {[0, 1, 2].map((colIndex) => (
                <div key={colIndex} className="flex-1 flex flex-col gap-4 animate-scroll-vertical" style={{ animationDuration: `${40 + colIndex * 10}s`, animationDirection: colIndex % 2 === 0 ? 'normal' : 'reverse' }}>
                    {[...POSTERS, ...POSTERS, ...POSTERS].map((src, i) => (
                        <div key={i} className="relative aspect-[2/3] rounded-xl overflow-hidden shadow-2xl bg-zinc-900">
                            <img src={src} className="w-full h-full object-cover" alt="" loading="lazy" />
                            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
                        </div>
                    ))}
                </div>
            ))}
        </div>
    );
};

interface FloatingWidgetProps { 
    children: React.ReactNode; 
    className?: string; 
    delay?: number; 
}

const FloatingWidget: React.FC<FloatingWidgetProps> = ({ children, className, delay = 0 }) => (
    <div 
        className={`absolute backdrop-blur-xl bg-white/10 border border-white/20 shadow-2xl rounded-2xl p-3 animate-float ${className}`}
        style={{ animationDelay: `${delay}s` }}
    >
        {children}
    </div>
);

const InputField = ({ id, type, placeholder, icon, value, onChange, error }: any) => (
    <div className="relative group">
        <input
            id={id}
            type={type}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className={`
                w-full pl-10 pr-4 py-3 bg-black/40 border border-white/10 rounded-lg text-white placeholder-gray-400 text-sm font-medium outline-none transition-all shadow-inner backdrop-blur-md
                ${error ? 'border-red-500/50 focus:border-red-500' : 'focus:border-white/30 focus:bg-black/50 hover:bg-black/50'}
            `}
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400 group-focus-within:text-white transition-colors z-30">
            {icon}
        </div>
    </div>
);

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
    const [isLogin, setIsLogin] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    
    const [formData, setFormData] = useState({ username: '', email: '', password: '', confirmPassword: '' });
    const [errors, setErrors] = useState({ username: '', email: '', password: '', confirmPassword: '' });
    const [showPassword, setShowPassword] = useState(false);

    const validate = () => {
        let isValid = true;
        const newErrors = { username: '', email: '', password: '', confirmPassword: '' };

        if (!formData.username.trim()) { newErrors.username = 'Required'; isValid = false; }
        if (!isLogin && !formData.email.includes('@')) { newErrors.email = 'Invalid Email'; isValid = false; }
        if (formData.password.length < 6) { newErrors.password = 'Min 6 chars'; isValid = false; }
        if (!isLogin && formData.password !== formData.confirmPassword) { newErrors.confirmPassword = 'Passwords do not match'; isValid = false; }

        setErrors(newErrors);
        return isValid;
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!validate()) return;
        setIsLoading(true);
        setTimeout(() => {
            setIsLoading(false);
            onLogin(formData.username);
        }, 1500);
    };

    const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [field]: e.target.value });
        setErrors({ ...errors, [field]: '' });
    };

    return (
        <div className="fixed inset-0 flex bg-[#050505] font-sans overflow-hidden">
            <style>{`
                @keyframes scroll-vertical {
                    0% { transform: translateY(0); }
                    100% { transform: translateY(-33.33%); }
                }
                .animate-scroll-vertical {
                    animation: scroll-vertical linear infinite;
                }
                @keyframes float {
                    0%, 100% { transform: translateY(0px); }
                    50% { transform: translateY(-15px); }
                }
                .animate-float {
                    animation: float 6s ease-in-out infinite;
                }
            `}</style>

            {/* LEFT PANEL: FORM (Desktop/Tablet) / CENTERED CARD (Mobile) */}
            <div className={`
                flex-1 flex flex-col relative z-20 transition-all duration-500 
                md:w-[450px] lg:w-[480px] md:flex-none md:static 
                /* Dark Gradient for Desktop */
                md:bg-gradient-to-b md:from-[#121212] md:to-[#000000]
                md:border-r md:border-white/5
                fixed inset-0 bg-transparent
            `}>
                {/* Background for Mobile Only (Hidden on md/tablet and up) */}
                <div className="md:hidden absolute inset-0 z-0 bg-black">
                    <ScrollingPosterWall />
                    <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]"></div>
                </div>

                <div className="relative z-10 flex-1 flex flex-col justify-center px-6 md:px-12 lg:px-16 py-8 overflow-y-auto custom-scrollbar">
                    
                    {/* Logo Area */}
                    <div className="mb-8 text-center md:text-left">
                        <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-white to-gray-400 flex items-center justify-center shadow-lg">
                                <FilmIcon className="w-6 h-6 text-black" />
                            </div>
                        </div>
                        <h1 className="text-2xl font-bold tracking-tight text-white mb-1 drop-shadow-md">
                            {isLogin ? 'Welcome back' : 'Join the club'}
                        </h1>
                        <p className="text-gray-400 text-sm font-medium">
                            {isLogin ? 'Enter your details to access your account.' : 'Start your cinematic journey today.'}
                        </p>
                    </div>

                    {/* Form Container */}
                    {/* Mobile: Glassmorphism with sharp corners. Desktop: Transparent */}
                    <div className="w-full max-w-sm mx-auto md:mx-0 md:max-w-md bg-black/40 backdrop-blur-xl md:bg-transparent md:backdrop-blur-none border border-white/10 md:border-none p-8 md:p-0 rounded-lg md:rounded-none shadow-2xl md:shadow-none transition-all duration-500">
                        
                        {/* Toggle Switcher */}
                        <div className="relative flex bg-black/50 md:bg-[#18181b] p-1 rounded-lg border border-white/10 md:border-white/5 w-full shadow-inner mb-6">
                            <div 
                                className={`absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-md shadow-md transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${isLogin ? 'left-1' : 'left-[calc(50%+2px)]'}`}
                            ></div>
                            <button 
                                onClick={() => setIsLogin(true)} 
                                className={`flex-1 relative z-10 py-2 text-xs font-bold transition-colors duration-300 ${isLogin ? 'text-black' : 'text-gray-400 hover:text-gray-200'}`}
                            >
                                Log In
                            </button>
                            <button 
                                onClick={() => setIsLogin(false)} 
                                className={`flex-1 relative z-10 py-2 text-xs font-bold transition-colors duration-300 ${!isLogin ? 'text-black' : 'text-gray-400 hover:text-gray-200'}`}
                            >
                                Sign Up
                            </button>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-3">
                            <div className="transition-all duration-300">
                                <InputField 
                                    id="username" type="text" placeholder="Username" 
                                    icon={<UserAddIcon className="w-4 h-4"/>}
                                    value={formData.username} onChange={handleChange('username')} error={errors.username}
                                />
                            </div>
                            
                            <div className={`transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] overflow-hidden ${!isLogin ? 'max-h-20 opacity-100' : 'max-h-0 opacity-0'}`}>
                                <InputField 
                                    id="email" type="email" placeholder="Email Address" 
                                    icon={<AtSymbolIcon className="w-4 h-4"/>}
                                    value={formData.email} onChange={handleChange('email')} error={errors.email}
                                />
                            </div>

                            <div className="relative group transition-all duration-300">
                                <input 
                                    id="password" type={showPassword ? "text" : "password"} placeholder="Password" 
                                    value={formData.password} onChange={handleChange('password')}
                                    className={`w-full pl-10 pr-10 py-3 bg-black/40 border border-white/10 rounded-lg text-white placeholder-gray-400 text-sm font-medium outline-none transition-all shadow-inner backdrop-blur-md ${errors.password ? 'border-red-500/50 focus:border-red-500' : 'focus:border-white/30 focus:bg-black/50 hover:bg-black/50'}`}
                                />
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400 group-focus-within:text-white transition-colors z-30">
                                    <LockClosedIcon className="w-4 h-4"/>
                                </div>
                                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-white transition-colors z-30 cursor-pointer">
                                    {showPassword ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                                </button>
                            </div>

                            <div className={`transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] overflow-hidden ${!isLogin ? 'max-h-20 opacity-100' : 'max-h-0 opacity-0'}`}>
                                <InputField 
                                    id="confirmPassword" type="password" placeholder="Confirm Password" 
                                    icon={<LockClosedIcon className="w-4 h-4"/>}
                                    value={formData.confirmPassword} onChange={handleChange('confirmPassword')} error={errors.confirmPassword}
                                />
                            </div>

                            {isLogin && (
                                <div className="flex justify-end">
                                    <button type="button" className="text-[10px] font-bold text-gray-400 hover:text-white transition-colors">
                                        Forgot Password?
                                    </button>
                                </div>
                            )}

                            <button 
                                disabled={isLoading}
                                className="w-full py-3 mt-4 bg-white text-black hover:bg-gray-200 font-bold rounded-lg shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                            >
                                {isLoading ? <SpinnerIcon className="w-4 h-4 animate-spin text-black"/> : (
                                    <>
                                        <span>{isLogin ? 'Sign In' : 'Create Account'}</span>
                                        <ArrowRightIcon className="w-4 h-4" />
                                    </>
                                )}
                            </button>
                        </form>

                        <div className="mt-6">
                            <button onClick={() => onLogin('Google User')} className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold rounded-lg transition-all flex items-center justify-center gap-2 text-xs active:scale-95">
                                <GoogleIcon className="w-4 h-4" /> Continue with Google
                            </button>
                        </div>
                    </div>
                    
                    <p className="mt-8 text-center text-[10px] text-gray-500 font-medium md:text-left">
                        By continuing, you agree to our Terms & Privacy Policy.
                    </p>
                </div>
            </div>

            {/* RIGHT PANEL: VISUAL SHOWCASE (Desktop/Tablet Only) */}
            <div className="hidden md:flex flex-1 relative bg-[#050505] overflow-hidden items-center justify-center">
                <ScrollingPosterWall />
                <div className="absolute inset-0 bg-gradient-to-l from-[#050505]/20 via-[#050505]/60 to-[#000000]"></div>
                <div className="relative z-10 w-full h-full max-w-4xl flex items-center justify-center">
                    {/* ... Desktop Visuals ... */}
                     <div className="relative w-[600px] bg-[#121214]/80 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden animate-fade-in-up transform hover:scale-[1.02] transition-transform duration-500">
                        <div className="h-12 border-b border-white/10 flex items-center px-4 gap-2">
                            <div className="flex gap-1.5">
                                <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                                <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                                <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
                            </div>
                            <div className="flex-1 text-center">
                                <div className="w-32 h-2 bg-white/10 rounded-full mx-auto"></div>
                            </div>
                        </div>
                        <div className="aspect-video bg-black relative group">
                            <img src="https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&w=800&q=80" className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity" alt="Preview" />
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center shadow-xl ring-1 ring-white/50 group-hover:scale-110 transition-transform">
                                    <PlayFilledIcon className="w-6 h-6 text-white ml-1" />
                                </div>
                            </div>
                            <div className="absolute bottom-4 left-4 right-4">
                                <div className="flex justify-between text-[10px] text-white font-bold mb-1">
                                    <span>Cyberpunk: Edgerunners</span>
                                    <span className="text-red-400">LIVE</span>
                                </div>
                                <div className="h-1 bg-white/30 rounded-full overflow-hidden">
                                    <div className="h-full w-2/3 bg-red-500 rounded-full"></div>
                                </div>
                            </div>
                        </div>
                        <div className="p-4 space-y-3 bg-[#0f0f11]">
                            <div className="flex gap-3 items-center">
                                <div className="w-8 h-8 rounded-full bg-blue-500/20 border border-blue-500/30"></div>
                                <div className="h-2 w-24 bg-white/10 rounded-full"></div>
                            </div>
                            <div className="flex gap-3 items-center">
                                <div className="w-8 h-8 rounded-full bg-purple-500/20 border border-purple-500/30"></div>
                                <div className="h-2 w-40 bg-white/10 rounded-full"></div>
                            </div>
                        </div>
                    </div>
                    <FloatingWidget className="top-20 left-10" delay={0}>
                        <div className="flex items-center gap-3">
                            <div className="flex -space-x-2">
                                {[1,2,3].map(i => (
                                    <div key={i} className="w-8 h-8 rounded-full border-2 border-[#1e1e24] bg-gray-700"></div>
                                ))}
                            </div>
                            <div>
                                <p className="text-white text-xs font-bold">12 Friends</p>
                                <p className="text-green-400 text-[10px] font-bold">Online Now</p>
                            </div>
                        </div>
                    </FloatingWidget>
                    <FloatingWidget className="bottom-32 -right-4" delay={1.5}>
                        <div className="flex items-center gap-3 pr-2">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-500 to-orange-500 flex items-center justify-center text-white shadow-lg">
                                <ChatIcon className="w-5 h-5" />
                            </div>
                            <div>
                                <p className="text-white text-xs font-bold">Sarah added a video</p>
                                <p className="text-gray-400 text-[10px]">"You have to watch this!"</p>
                            </div>
                        </div>
                    </FloatingWidget>
                    <FloatingWidget className="top-1/2 -right-12" delay={2.5}>
                        <div className="flex items-center gap-2 text-pink-500">
                            <HeartIcon className="w-6 h-6" filled />
                            <span className="text-white font-bold">+142</span>
                        </div>
                    </FloatingWidget>
                </div>
            </div>
        </div>
    );
};

export default AuthPage;