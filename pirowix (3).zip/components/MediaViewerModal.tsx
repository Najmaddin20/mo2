
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactPlayer from 'react-player';
import type { DirectMessage } from '../types';
import { CloseIcon, PlayIcon, PauseIcon, DownloadIcon } from './icons';

const formatTime = (time: number) => {
    if (isNaN(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
};

const VoiceMessageViewer: React.FC<{ voiceMessage: NonNullable<DirectMessage['voiceMessage']> }> = ({ voiceMessage }) => {
    const audioRef = useRef<HTMLAudioElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
    const animationFrameRef = useRef<number | undefined>(undefined);

    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);

    const draw = useCallback(() => {
        const analyser = analyserRef.current;
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');

        if (!analyser || !canvas || !ctx) return;
        
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteFrequencyData(dataArray);

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const barWidth = (canvas.width / bufferLength) * 2.5;
        let x = 0;
        
        for (let i = 0; i < bufferLength; i++) {
            const barHeight = dataArray[i] / 2;
            
            ctx.fillStyle = `rgba(255, 255, 255, ${barHeight / 200})`;
            ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
            
            x += barWidth + 1;
        }
        
        animationFrameRef.current = requestAnimationFrame(draw);
    }, []);
    
    const setupAudioContext = () => {
        if (!audioRef.current || audioContextRef.current) return;
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = audioContext;
        
        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;
        
        if (!sourceRef.current) {
            sourceRef.current = audioContext.createMediaElementSource(audioRef.current);
        }
        
        sourceRef.current.connect(analyser);
        analyser.connect(audioContext.destination);
    };

    const togglePlay = () => {
        if (!audioRef.current) return;
        
        if (!audioContextRef.current) {
            setupAudioContext();
        }

        const audioCtx = audioContextRef.current;
        if (audioCtx?.state === 'suspended') {
            audioCtx.resume();
        }

        if (isPlaying) {
            audioRef.current.pause();
        } else {
            const playPromise = audioRef.current.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.error("Playback failed:", error);
                    setIsPlaying(false);
                });
            }
        }
    };
    
    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;
        
        const handlePlay = () => {
            setIsPlaying(true);
            animationFrameRef.current = requestAnimationFrame(draw);
        };
        const handlePause = () => {
            setIsPlaying(false);
            if (animationFrameRef.current !== undefined) cancelAnimationFrame(animationFrameRef.current);
        };
        const handleEnded = () => {
            setIsPlaying(false);
            setProgress(0);
            setCurrentTime(0);
            if (animationFrameRef.current !== undefined) cancelAnimationFrame(animationFrameRef.current);
        };
         const updateProgress = () => {
            if (audio && !isNaN(audio.duration)) {
                setProgress((audio.currentTime / audio.duration) * 100);
                setCurrentTime(audio.currentTime);
            }
        };

        audio.addEventListener('play', handlePlay);
        audio.addEventListener('pause', handlePause);
        audio.addEventListener('ended', handleEnded);
        audio.addEventListener('timeupdate', updateProgress);
        
        return () => {
            audio.removeEventListener('play', handlePlay);
            audio.removeEventListener('pause', handlePause);
            audio.removeEventListener('ended', handleEnded);
            audio.removeEventListener('timeupdate', updateProgress);
            if (animationFrameRef.current !== undefined) cancelAnimationFrame(animationFrameRef.current);
            if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
                audioContextRef.current.close();
            }
            audioContextRef.current = null;
        };
    }, [draw]);

    return (
        <div className="w-full max-w-sm flex flex-col items-center gap-4 text-white p-4 rounded-lg bg-white/5 backdrop-blur-md">
             <audio ref={audioRef} src={voiceMessage.url} preload="metadata" />
             <canvas ref={canvasRef} width="300" height="100" />
             <div className="flex items-center gap-4 w-full">
                <button onClick={togglePlay} className="flex-shrink-0 text-white bg-white/20 rounded-full p-2">
                    {isPlaying ? <PauseIcon className="w-6 h-6" /> : <PlayIcon className="w-6 h-6" />}
                </button>
                <div className="flex-1 bg-white/20 rounded-full h-1.5">
                    <div className="bg-white h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
                <span className="text-sm font-mono">{formatTime(isPlaying ? currentTime : voiceMessage.duration)}</span>
             </div>
        </div>
    );
};

interface MediaViewerModalProps {
    isOpen: boolean;
    onClose: () => void;
    mediaItem: DirectMessage | null;
}

const MediaViewerModal: React.FC<MediaViewerModalProps> = ({ isOpen, onClose, mediaItem }) => {
    if (!isOpen || !mediaItem) return null;

    const isImage = !!mediaItem.imageUrl;
    const isVoice = !!mediaItem.voiceMessage;
    const isVideo = !!mediaItem.videoUrl;

    const isTransferComplete = (mediaItem.uploadProgress ?? 100) >= 100 && (mediaItem.downloadProgress ?? 100) >= 100;

    const handleContentClick = (e: React.MouseEvent) => {
        e.stopPropagation();
    };

    return (
        <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-lg flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
        >
             <div className="absolute top-4 left-4 z-20 flex gap-2">
                 {isTransferComplete && (isImage || isVideo) && (
                    <a
                        href={mediaItem.videoUrl || mediaItem.imageUrl!}
                        download={mediaItem.fileInfo?.name || (isImage ? 'image.jpg' : 'video.mp4')}
                        className="bg-black/40 backdrop-blur-sm rounded-lg p-2 text-white flex items-center gap-2 hover:bg-black/60 transition-colors"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <DownloadIcon className="w-5 h-5"/>
                        <span className="text-sm font-semibold">Download</span>
                    </a>
                 )}
            </div>
            <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white bg-black/40 backdrop-blur-sm rounded-full p-1.5 z-20">
                <CloseIcon className="w-6 h-6" />
            </button>
            <div className="w-full h-full flex flex-col items-center justify-center" onClick={handleContentClick}>
                <div className="w-full max-w-4xl max-h-[80vh] aspect-video flex items-center justify-center animate-fade-in-up">
                    {isImage && (
                        <img 
                            src={mediaItem.imageUrl} 
                            alt="Media content" 
                            className="max-w-full max-h-full object-contain rounded-lg"
                        />
                    )}
                    {isVoice && (
                        <div>
                            <VoiceMessageViewer voiceMessage={mediaItem.voiceMessage!} />
                        </div>
                    )}
                    {isVideo && (
                         <ReactPlayer
                            url={mediaItem.videoUrl}
                            playing
                            controls
                            width="100%"
                            height="100%"
                        />
                    )}
                </div>
                 {mediaItem.caption && (
                    <div className="mt-4 p-2 bg-black/30 rounded-lg text-white text-center animate-fade-in-up">
                        {mediaItem.caption}
                    </div>
                 )}
            </div>
        </div>
    );
};

export default MediaViewerModal;
