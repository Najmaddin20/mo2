
import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { Friend } from '../types';
import { CloseIcon, SendIcon, SearchIcon, CheckIcon, UserIcon } from './icons';

interface ForwardMessageModalProps {
    isOpen: boolean;
    onClose: () => void;
    friends: Friend[];
    onForward: (friendIds: number[], comment: string) => void;
    isSharingRoom?: boolean;
    shareTitle?: string;
}

const ForwardMessageModal: React.FC<ForwardMessageModalProps> = ({ isOpen, onClose, friends, onForward, isSharingRoom, shareTitle }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedFriendIds, setSelectedFriendIds] = useState<Set<number>>(new Set());
    const [comment, setComment] = useState('');
    const [isAnimating, setIsAnimating] = useState(false);
    const [isClosing, setIsClosing] = useState(false);
    
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (isOpen) {
            setIsAnimating(true);
            setIsClosing(false);
            // Clear previous state
            setSearchTerm('');
            setSelectedFriendIds(new Set());
            setComment('');
        }
    }, [isOpen]);

    const filteredFriends = useMemo(() => 
        friends.filter(friend => 
            friend.name.toLowerCase().includes(searchTerm.toLowerCase())
        ), [friends, searchTerm]);

    const showSavedMessages = 'saved messages'.includes(searchTerm.toLowerCase()) || 'me'.includes(searchTerm.toLowerCase()) || searchTerm === '';

    const handleClose = () => {
        setIsClosing(true);
        setTimeout(() => {
            setIsAnimating(false);
            onClose();
        }, 300);
    };

    const toggleSelection = (id: number) => {
        setSelectedFriendIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) newSet.delete(id);
            else newSet.add(id);
            return newSet;
        });
    };

    const handleSend = () => {
        if (selectedFriendIds.size > 0) {
            onForward(Array.from(selectedFriendIds), comment);
            handleClose();
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey && selectedFriendIds.size > 0) {
            e.preventDefault();
            handleSend();
        }
    };

    if (!isOpen && !isAnimating) return null;

    const totalSelected = selectedFriendIds.size;

    return (
        <div className={`fixed inset-0 z-[150] flex items-end sm:items-center justify-center p-0 sm:p-4 transition-opacity duration-300 ${isClosing ? 'opacity-0' : 'opacity-100'}`}>
            {/* Backdrop */}
            <div 
                className="absolute inset-0 bg-black/60 backdrop-blur-md transition-opacity" 
                onClick={handleClose}
            />

            {/* Modal Card */}
            <div 
                className={`
                    relative w-full max-w-md bg-[#121214]/80 backdrop-blur-3xl border-t sm:border border-white/10 
                    rounded-t-[2rem] sm:rounded-[2rem] shadow-2xl flex flex-col max-h-[90vh] sm:max-h-[650px] overflow-hidden 
                    transition-transform duration-500 cubic-bezier(0.19, 1, 0.22, 1) ring-1 ring-white/5
                    ${isClosing ? 'translate-y-full sm:translate-y-10 sm:scale-95' : 'translate-y-0 scale-100'}
                `}
                onClick={e => e.stopPropagation()}
            >
                {/* Decorative Glow */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-24 bg-[var(--theme-color)] opacity-20 blur-[80px] pointer-events-none"></div>

                {/* Header */}
                <div className="flex-shrink-0 px-6 py-5 border-b border-white/5 bg-white/[0.01] relative z-10">
                    <div className="flex justify-between items-center mb-5">
                        <div>
                            <h2 className="text-xl font-bold text-white tracking-tight leading-none">
                                {shareTitle || 'Share'}
                            </h2>
                            <p className="text-xs text-gray-400 mt-1.5 font-medium">
                                {totalSelected === 0 ? 'Select recipients' : `${totalSelected} selected`}
                            </p>
                        </div>
                        <button 
                            onClick={handleClose} 
                            className="p-2 -mr-2 text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-full transition-all active:scale-95"
                        >
                            <CloseIcon className="w-5 h-5" />
                        </button>
                    </div>

                    {/* Search Bar */}
                    <div className="relative group">
                        <SearchIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-[var(--theme-color)] transition-colors" />
                        <input 
                            type="text" 
                            placeholder="Search people..." 
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full bg-black/20 text-white pl-10 pr-4 py-3 text-sm rounded-xl border border-white/10 focus:outline-none focus:border-[var(--theme-color)]/50 focus:bg-black/40 focus:ring-1 focus:ring-[var(--theme-color)]/50 transition-all placeholder-gray-500"
                        />
                    </div>
                </div>

                {/* Friend List */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1 bg-transparent relative z-10">
                    {showSavedMessages && (
                        <div 
                            onClick={() => toggleSelection(-1)} // -1 for Self/Saved
                            className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-all border group ${selectedFriendIds.has(-1) ? 'bg-[var(--theme-color)]/10 border-[var(--theme-color)]/30' : 'hover:bg-white/5 border-transparent'}`}
                        >
                            <div className="flex items-center gap-3.5">
                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20 ring-2 ring-black/20">
                                    <div className="p-1.5 bg-white/20 rounded-full backdrop-blur-sm">
                                        <UserIcon className="w-5 h-5 text-white" />
                                    </div>
                                </div>
                                <div>
                                    <p className={`font-bold text-sm transition-colors ${selectedFriendIds.has(-1) ? 'text-[var(--theme-color)]' : 'text-white'}`}>Saved Messages</p>
                                    <p className="text-xs text-gray-500 group-hover:text-gray-400 font-medium">Forward to yourself</p>
                                </div>
                            </div>
                            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${selectedFriendIds.has(-1) ? 'bg-[var(--theme-color)] border-[var(--theme-color)] scale-110' : 'border-gray-600 group-hover:border-gray-400 scale-100'}`}>
                                <CheckIcon className={`w-3.5 h-3.5 text-white transition-transform duration-300 ${selectedFriendIds.has(-1) ? 'scale-100' : 'scale-0'}`} />
                            </div>
                        </div>
                    )}

                    {filteredFriends.length > 0 ? (
                        filteredFriends.map(friend => {
                            const isSelected = selectedFriendIds.has(friend.id);
                            return (
                                <div 
                                    key={friend.id} 
                                    onClick={() => toggleSelection(friend.id)}
                                    className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-all border group ${isSelected ? 'bg-[var(--theme-color)]/10 border-[var(--theme-color)]/30' : 'hover:bg-white/5 border-transparent'}`}
                                >
                                    <div className="flex items-center gap-3.5">
                                        <div className="relative">
                                            <img 
                                                src={friend.avatar} 
                                                alt={friend.name} 
                                                className={`w-12 h-12 rounded-full object-cover bg-[#1e1e1e] border-2 transition-colors ${isSelected ? 'border-[var(--theme-color)]' : 'border-transparent group-hover:border-white/10'}`} 
                                            />
                                            {friend.status === 'online' && (
                                                <span className="absolute bottom-0.5 right-0.5 w-3 h-3 bg-green-500 border-2 border-[#121214] rounded-full shadow-sm"></span>
                                            )}
                                        </div>
                                        <div>
                                            <p className={`font-bold text-sm transition-colors ${isSelected ? 'text-[var(--theme-color)]' : 'text-white'}`}>{friend.name}</p>
                                            <p className="text-xs text-gray-500 group-hover:text-gray-400 font-medium">{friend.status === 'ingame' ? 'In a room' : friend.status}</p>
                                        </div>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${isSelected ? 'bg-[var(--theme-color)] border-[var(--theme-color)] scale-110' : 'border-gray-600 group-hover:border-gray-400 scale-100'}`}>
                                        <CheckIcon className={`w-3.5 h-3.5 text-white transition-transform duration-300 ${isSelected ? 'scale-100' : 'scale-0'}`} />
                                    </div>
                                </div>
                            );
                        })
                    ) : !showSavedMessages && (
                        <div className="flex flex-col items-center justify-center h-40 text-gray-500">
                            <div className="p-4 bg-white/5 rounded-full mb-3">
                                <SearchIcon className="w-6 h-6 opacity-50" />
                            </div>
                            <p className="text-sm font-medium">No friends found.</p>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="flex-shrink-0 p-4 bg-[#121214]/80 border-t border-white/10 backdrop-blur-xl z-20 pb-safe">
                    <div className="flex gap-3 items-end bg-black/40 border border-white/10 rounded-2xl p-1.5 focus-within:border-[var(--theme-color)]/50 focus-within:ring-1 focus-within:ring-[var(--theme-color)]/30 transition-all shadow-lg">
                        <input
                            ref={inputRef}
                            type="text"
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder={isSharingRoom ? "Add a message..." : "Add a comment..."}
                            className="flex-1 bg-transparent text-white px-3 py-2.5 text-sm placeholder-gray-500 focus:outline-none min-w-0"
                        />
                        <button 
                            onClick={handleSend}
                            disabled={selectedFriendIds.size === 0}
                            className={`
                                h-10 px-4 rounded-xl font-bold text-white text-xs shadow-lg flex items-center justify-center gap-2 transition-all transform flex-shrink-0
                                ${selectedFriendIds.size > 0 
                                    ? 'opacity-100 hover:scale-105 active:scale-95' 
                                    : 'opacity-50 cursor-not-allowed grayscale'
                                }
                            `}
                            style={{ 
                                background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' 
                            }}
                        >
                            <span>Send</span>
                            <SendIcon className="w-3.5 h-3.5" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ForwardMessageModal;
