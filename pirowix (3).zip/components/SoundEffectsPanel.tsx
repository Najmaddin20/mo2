import React, { useRef, useCallback } from 'react';
import { CloseIcon } from './icons';

interface SoundEffectsPanelProps {
    onClose: () => void;
}

// Base64 encoded audio data (short, low-quality to keep size down)
const sfxData = {
    applause: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAAABkYXRhAAAAAA==', // Placeholder
    drumroll: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAAABkYXRhAAAAAA==', // Placeholder
    laugh: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAAABkYXRhAAAAAA==', // Placeholder
    sad: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAAABkYXRhAAAAAA==', // Placeholder
};

const sfxLibrary = [
    { id: 'applause', emoji: '👏', label: 'Applause' },
    { id: 'drumroll', emoji: '🥁', label: 'Drum Roll' },
    { id: 'laugh', emoji: '😂', label: 'Laughter' },
    { id: 'sad', emoji: ' trombone', label: 'Sad Trombone' },
];

const SoundEffectsPanel: React.FC<SoundEffectsPanelProps> = ({ onClose }) => {
    const audioContextRef = useRef<AudioContext | null>(null);

    const playSound = useCallback((sfxId: keyof typeof sfxData) => {
        if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        const audioContext = audioContextRef.current;
        
        // A real implementation would have actual audio data.
        // For this mock, we'll just generate a simple tone.
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        switch(sfxId) {
            case 'applause': 
                oscillator.type = 'sawtooth';
                oscillator.frequency.setValueAtTime(440, audioContext.currentTime);
                gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.5);
                break;
            case 'drumroll':
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(220, audioContext.currentTime);
                gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.3);
                break;
             case 'laugh':
                oscillator.type = 'square';
                oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.2);
                break;
             case 'sad':
                oscillator.type = 'triangle';
                oscillator.frequency.setValueAtTime(330, audioContext.currentTime);
                gainNode.gain.setValueAtTime(0.25, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.6);
                break;
        }

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 1);

    }, []);


    return (
        <div 
            className="absolute bottom-full left-0 right-0 p-4 bg-black/50 backdrop-blur-xl border-t border-white/10 rounded-t-2xl z-20 animate-slide-in-from-bottom"
            onClick={e => e.stopPropagation()}
        >
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold">Sound Effects</h3>
                <button onClick={onClose} className="p-1 text-gray-400 hover:text-white"><CloseIcon className="w-5 h-5"/></button>
            </div>
            <div className="grid grid-cols-4 gap-2">
                {sfxLibrary.map(sfx => (
                     <button 
                        key={sfx.id} 
                        onClick={() => playSound(sfx.id as keyof typeof sfxData)}
                        className="flex flex-col items-center justify-center gap-1 p-2 bg-white/5 rounded-lg hover:bg-white/10 transition-colors transform active:scale-90"
                    >
                        <span className="text-2xl">{sfx.emoji}</span>
                        <span className="text-xs text-gray-300">{sfx.label}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default SoundEffectsPanel;