
import React, { useState } from 'react';
import type { User } from '../types';
import { CheckIcon, XIcon, ClockIcon, UserAddIcon, ArrowLeftIcon, ArrowRightIcon } from './icons';

interface FriendRequestsPanelProps {
    incoming: User[];
    sent: User[];
    onAccept: (id: number) => void;
    onDecline: (id: number) => void;
    onCancel: (id: number) => void;
}

const FriendRequestCard: React.FC<{ user: User; type: 'incoming' | 'sent'; onAccept?: () => void; onDecline?: () => void; onCancel?: () => void }> = ({ user, type, onAccept, onDecline, onCancel }) => (
    <div className="relative flex flex-col bg-[#1e1e24]/40 backdrop-blur-xl border border-white/5 hover:border-white/10 p-4 rounded-2xl transition-all animate-fade-in-up group hover:shadow-lg hover:shadow-black/20">
        {/* Visual indicator strip */}
        <div className={`absolute left-0 top-4 bottom-4 w-1 rounded-r-full ${type === 'incoming' ? 'bg-blue-500' : 'bg-orange-500'} opacity-0 group-hover:opacity-100 transition-opacity`} />

        <div className="flex items-start justify-between mb-4 pl-2">
            <div className="flex items-center gap-4">
                <img src={user.avatar} alt={user.name} className="w-14 h-14 rounded-full object-cover border-2 border-white/5 group-hover:border-white/10 transition-colors bg-[#111] shadow-md" />
                <div>
                    <h4 className="font-bold text-white text-base leading-tight mb-1">{user.name}</h4>
                    <p className="text-xs text-gray-400 line-clamp-1 mb-2">{user.bio || 'New user on SyncWatch'}</p>
                    {type === 'incoming' ? (
                        <div className="inline-flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded-full">
                            <UserAddIcon className="w-3 h-3 text-blue-400"/>
                            <span className="text-[10px] text-blue-300 font-bold uppercase tracking-wide">Incoming</span>
                        </div>
                    ) : (
                        <div className="inline-flex items-center gap-1.5 bg-orange-500/10 border border-orange-500/20 px-2 py-0.5 rounded-full">
                            <ClockIcon className="w-3 h-3 text-orange-400"/>
                            <span className="text-[10px] text-orange-300 font-bold uppercase tracking-wide">Pending</span>
                        </div>
                    )}
                </div>
            </div>
        </div>

        <div className="flex gap-3 mt-auto pl-2">
            {type === 'incoming' ? (
                <>
                    <button 
                        onClick={onAccept} 
                        className="flex-1 h-10 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-blue-900/20 transition-all transform active:scale-95"
                    >
                        <CheckIcon className="w-4 h-4" /> Accept
                    </button>
                    <button 
                        onClick={onDecline} 
                        className="flex-1 h-10 bg-[#2a2a2d] hover:bg-[#3f3f42] text-gray-300 hover:text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 border border-white/5 transition-all active:scale-95"
                    >
                        <XIcon className="w-4 h-4" /> Decline
                    </button>
                </>
            ) : (
                <button 
                    onClick={onCancel} 
                    className="w-full h-10 bg-[#2a2a2d] hover:bg-red-500/10 text-gray-400 hover:text-red-400 text-xs font-bold rounded-xl flex items-center justify-center gap-2 border border-white/5 hover:border-red-500/30 transition-all active:scale-95"
                >
                    <XIcon className="w-4 h-4" /> Cancel Request
                </button>
            )}
        </div>
    </div>
);

const FriendRequestsPanel: React.FC<FriendRequestsPanelProps> = ({ incoming, sent, onAccept, onDecline, onCancel }) => {
    const [activeTab, setActiveTab] = useState<'received' | 'sent'>('received');

    return (
        <div className="flex flex-col h-full bg-transparent">
            {/* Modern Tab Switcher */}
            <div className="p-4 pb-2">
                <div className="bg-[#121214] p-1 rounded-2xl flex relative border border-white/5">
                    <div 
                        className={`absolute top-1 bottom-1 w-[calc(50%-4px)] bg-[#27272a] rounded-xl shadow-sm transition-all duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] border border-white/10 ${activeTab === 'received' ? 'left-1' : 'left-[calc(50%+2px)]'}`}
                    ></div>
                    
                    <button 
                        onClick={() => setActiveTab('received')}
                        className={`flex-1 py-2.5 text-xs font-bold text-center relative z-10 transition-colors flex items-center justify-center gap-2 ${activeTab === 'received' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        Received 
                        {incoming.length > 0 && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded-full transition-colors min-w-[18px] ${activeTab === 'received' ? 'bg-blue-500 text-white' : 'bg-white/10 text-gray-500'}`}>
                                {incoming.length}
                            </span>
                        )}
                    </button>
                    <button 
                        onClick={() => setActiveTab('sent')}
                        className={`flex-1 py-2.5 text-xs font-bold text-center relative z-10 transition-colors flex items-center justify-center gap-2 ${activeTab === 'sent' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                        Sent
                        {sent.length > 0 && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded-full transition-colors min-w-[18px] ${activeTab === 'sent' ? 'bg-orange-500 text-white' : 'bg-white/10 text-gray-500'}`}>
                                {sent.length}
                            </span>
                        )}
                    </button>
                </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 pt-2">
                {activeTab === 'received' ? (
                    incoming.length > 0 ? (
                        <div className="grid grid-cols-1 gap-4">
                            {incoming.map(user => (
                                <FriendRequestCard 
                                    key={user.id} 
                                    user={user} 
                                    type="incoming" 
                                    onAccept={() => onAccept(user.id)} 
                                    onDecline={() => onDecline(user.id)} 
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-64 text-center opacity-60">
                            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4 border border-dashed border-white/20">
                                <UserAddIcon className="w-8 h-8 text-gray-500" />
                            </div>
                            <p className="text-white font-bold text-base">All caught up</p>
                            <p className="text-gray-500 text-xs mt-1">You have no pending friend requests.</p>
                        </div>
                    )
                ) : (
                    sent.length > 0 ? (
                        <div className="grid grid-cols-1 gap-4">
                            {sent.map(user => (
                                <FriendRequestCard 
                                    key={user.id} 
                                    user={user} 
                                    type="sent" 
                                    onCancel={() => onCancel(user.id)} 
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-64 text-center opacity-60">
                            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4 border border-dashed border-white/20">
                                <ClockIcon className="w-8 h-8 text-gray-500" />
                            </div>
                            <p className="text-white font-bold text-base">No sent requests</p>
                            <p className="text-gray-500 text-xs mt-1">Add friends to see your pending requests here.</p>
                        </div>
                    )
                )}
            </div>
        </div>
    );
};

export default FriendRequestsPanel;
