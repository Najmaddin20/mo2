
import React, { useState, useRef, useEffect, useMemo } from 'react';
import type { User, Conversation, DirectMessage, Friend, ChatBackground, AudioTrack } from '../types';
import { SendIcon, ArrowLeftIcon, MicrophoneIcon, MoreVertIcon, WaveIcon, CloseIcon, ReplyIcon, AttachmentIcon, EmojiIcon, CrownIcon, SearchIcon, ChevronDownIcon } from './icons';
import VoiceMessageRecorder from './VoiceMessageRecorder';
import { DirectMessageItem } from './DirectMessageItem';
import MessageActionOverlay from './MessageActionOverlay';
import { ChatHeaderMiniPlayer, useAudioPlayer, PlaylistBottomSheet } from './AudioPlayerSystem';
import DateSeparator from './DateSeparator';
import JumpToLatestButton from './JumpToLatestButton';
import GroupProfilePage from './GroupProfilePage'; // Import the new component

interface GroupChatProps {
    currentUser: User;
    conversation: Conversation;
    onSendMessage: (message: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'>) => void;
    onBack: () => void;
    chatBackground: ChatBackground;
    onUpdateGroup: (updates: Partial<Conversation>) => void;
    onDeleteGroup: () => void;
    onLeaveGroup: () => void;
    onDeleteMessage: (msgIds: number[]) => void;
    onJoinVoiceRoom: (roomId: number) => void;
    onViewMedia: (media: DirectMessage) => void;
    onForwardMessage: (toFriendId: number, message: DirectMessage) => void;
}

// Helper to generate consistent colors for usernames
const getUserColor = (userId: number) => {
    const colors = [
        'text-red-400', 'text-orange-400', 'text-amber-400', 'text-yellow-400', 
        'text-lime-400', 'text-green-400', 'text-emerald-400', 'text-teal-400',
        'text-cyan-400', 'text-sky-400', 'text-blue-400', 'text-indigo-400',
        'text-violet-400', 'text-purple-400', 'text-fuchsia-400', 'text-pink-400', 'text-rose-400'
    ];
    return colors[userId % colors.length];
};

const GroupChat: React.FC<GroupChatProps> = (props) => {
    const { currentUser, conversation, onSendMessage, onBack, chatBackground, onUpdateGroup, onDeleteGroup, onLeaveGroup, onDeleteMessage, onViewMedia, onForwardMessage } = props;

    const [view, setView] = useState<'chat' | 'profile'>('chat'); // View state
    const [text, setText] = useState('');
    const [voiceMode, setVoiceMode] = useState<'idle' | 'recording'>('idle');
    const [replyingTo, setReplyingTo] = useState<DirectMessage | null>(null);
    const [actionMenuMessage, setActionMenuMessage] = useState<DirectMessage | null>(null);
    
    // Search State
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<number[]>([]); // Indices of messages
    const [currentResultIndex, setCurrentResultIndex] = useState(0);
    const searchInputRef = useRef<HTMLInputElement>(null);

    const chatEndRef = useRef<HTMLDivElement>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const messageRefs = useRef<Map<number, HTMLDivElement>>(new Map());
    const { isPlaylistOpen, setIsPlaylistOpen, expandPlayer } = useAudioPlayer();
    const [showScrollButton, setShowScrollButton] = useState(false);

    const amIOwner = conversation.groupOwnerId === currentUser.id;
    const amIAdmin = amIOwner || (conversation.adminIds || []).includes(currentUser.id);
    const themeColor = conversation.theme || '#6C5DD3';

    // Admin Actions Handlers
    const handlePromote = (userId: number) => {
        const newAdmins = [...(conversation.adminIds || []), userId];
        onUpdateGroup({ adminIds: newAdmins });
    };
    const handleDemote = (userId: number) => {
        const newAdmins = (conversation.adminIds || []).filter(id => id !== userId);
        onUpdateGroup({ adminIds: newAdmins });
    };
    const handleKick = (userId: number) => {
        const newParticipants = (conversation.participants || []).filter(p => p.id !== userId);
        const newAdmins = (conversation.adminIds || []).filter(id => id !== userId);
        onUpdateGroup({ participants: newParticipants, adminIds: newAdmins });
    };
    const handleBan = (userId: number) => {
        const userToBan = conversation.participants?.find(u => u.id === userId);
        if (userToBan) {
             const newBanned = [...(conversation.bannedUsers || []), userToBan];
             handleKick(userId);
             onUpdateGroup({ bannedUsers: newBanned });
        }
    };
    const handleUnban = (userId: number) => {
        const newBanned = (conversation.bannedUsers || []).filter(u => u.id !== userId);
        onUpdateGroup({ bannedUsers: newBanned });
    };

    // --- Chat View Logic ---

    const scrollToBottom = (smooth = true) => {
        chatEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
        setShowScrollButton(false);
    };

    useEffect(() => {
        // Only auto-scroll if we are in chat view and search is closed
        if (view === 'chat' && !isSearchOpen) {
            scrollToBottom(false);
        }
    }, [conversation.friend.id, view, isSearchOpen]);

    // Search Logic
    useEffect(() => {
        if (isSearchOpen) {
            setTimeout(() => searchInputRef.current?.focus(), 100);
        } else {
            setSearchQuery('');
            setSearchResults([]);
        }
    }, [isSearchOpen]);

    useEffect(() => {
        if (!searchQuery.trim()) {
            setSearchResults([]);
            setCurrentResultIndex(0);
            return;
        }

        const results: number[] = [];
        conversation.messages.forEach((msg, idx) => {
            const content = (msg.message || msg.caption || '').toLowerCase();
            if (content.includes(searchQuery.toLowerCase())) {
                results.push(idx);
            }
        });

        setSearchResults(results);
        setCurrentResultIndex(results.length > 0 ? results.length - 1 : 0); // Default to latest match
        
        if (results.length > 0) {
            scrollToMessage(conversation.messages[results[results.length - 1]].id);
        }
    }, [searchQuery, conversation.messages]);

    const scrollToMessage = (messageId: number) => {
        const el = messageRefs.current.get(messageId);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Optional highlight effect
            el.classList.add('bg-white/10', 'transition-colors', 'duration-500');
            setTimeout(() => el.classList.remove('bg-white/10'), 1500);
        }
    };

    const handleNextResult = () => {
        if (searchResults.length === 0) return;
        const nextIndex = (currentResultIndex + 1) % searchResults.length;
        setCurrentResultIndex(nextIndex);
        scrollToMessage(conversation.messages[searchResults[nextIndex]].id);
    };

    const handlePrevResult = () => {
        if (searchResults.length === 0) return;
        const prevIndex = (currentResultIndex - 1 + searchResults.length) % searchResults.length;
        setCurrentResultIndex(prevIndex);
        scrollToMessage(conversation.messages[searchResults[prevIndex]].id);
    };

    const handleScroll = () => {
        if (chatContainerRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
            setShowScrollButton(scrollHeight - scrollTop - clientHeight > 150);
        }
    };

    const handleSend = () => {
        if (!text.trim()) return;
        onSendMessage({ message: text.trim(), replyTo: replyingTo || undefined });
        setText('');
        setReplyingTo(null);
    };
    
    const handleSendVoice = (url: string, duration: number, waveform: number[]) => {
        onSendMessage({ message: '', voiceMessage: { url, duration, waveform }, replyTo: replyingTo || undefined });
        setVoiceMode('idle');
    }

    const handleToggleVoiceChat = () => {
        const isActive = conversation.voiceChatStarted;
        if (isActive) {
            alert("Joining Group Voice Chat... (Feature Hook)");
        } else {
            onUpdateGroup({ voiceChatStarted: true, voiceChatParticipants: [currentUser] });
        }
    };

    const audioQueue: AudioTrack[] = useMemo(() => {
        return conversation.messages
            .filter(msg => msg.voiceMessage)
            .map(msg => {
                const sender = conversation.participants?.find(p => p.id === msg.senderId);
                return {
                    id: msg.id.toString(),
                    url: msg.voiceMessage!.url,
                    title: 'Voice Message',
                    artist: sender ? sender.name : 'Unknown',
                    duration: msg.voiceMessage!.duration,
                    waveform: msg.voiceMessage!.waveform,
                    contextId: conversation.friend.id
                };
            });
    }, [conversation.messages, conversation.participants]);

    const messagesWithSeparators = useMemo(() => {
        const result: (DirectMessage | { type: 'date-separator', date: string })[] = [];
        let lastDate: Date | null = null;
        conversation.messages.forEach(message => {
            const messageDate = new Date(message.timestamp);
            const isSame = lastDate && 
                lastDate.getFullYear() === messageDate.getFullYear() &&
                lastDate.getMonth() === messageDate.getMonth() &&
                lastDate.getDate() === messageDate.getDate();
            if (!isSame) {
                const dateStr = messageDate.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
                result.push({ type: 'date-separator', date: dateStr });
                lastDate = messageDate;
            }
            result.push(message);
        });
        return result;
    }, [conversation.messages]);

    // If in profile view, render the full page component
    // IMPORTANT: This return is placed AFTER all hooks to prevent React Hook Error #300
    if (view === 'profile') {
        return (
            <GroupProfilePage 
                conversation={conversation}
                currentUser={currentUser}
                onBack={() => setView('chat')}
                onUpdateGroup={onUpdateGroup}
                onDeleteGroup={onDeleteGroup}
                onLeaveGroup={onLeaveGroup}
                onKickMember={handleKick}
                onBanMember={handleBan}
                onUnbanMember={handleUnban}
                onPromoteMember={handlePromote}
                onDemoteMember={handleDemote}
                onForwardInvite={() => {}}
            />
        );
    }

    return (
        <div className="flex flex-col h-full relative bg-[#0f0f0f]">
             {/* Header */}
            <header className="flex-shrink-0 flex flex-col bg-[#1c1c1e] border-b border-white/5 z-10 shadow-sm h-16 justify-center">
                <div className="flex items-center justify-between px-3">
                    {isSearchOpen ? (
                        <div className="flex-1 flex items-center gap-3 animate-fade-in">
                            <button onClick={() => setIsSearchOpen(false)} className="p-2 -ml-2 text-gray-400 hover:text-white rounded-full hover:bg-white/10 transition-colors">
                                <ArrowLeftIcon className="w-5 h-5" />
                            </button>
                            <div className="flex-1 relative group">
                                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-[var(--theme-color)]" />
                                <input 
                                    ref={searchInputRef}
                                    type="text" 
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    placeholder="Search..." 
                                    className="w-full bg-black/20 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-[var(--theme-color)] transition-all"
                                />
                            </div>
                            {searchResults.length > 0 && (
                                <div className="flex items-center gap-2 pl-2">
                                    <span className="text-xs font-mono text-gray-400 whitespace-nowrap min-w-[40px] text-center">
                                        {currentResultIndex + 1} of {searchResults.length}
                                    </span>
                                    <div className="flex bg-black/20 rounded-lg border border-white/10">
                                        <button onClick={handlePrevResult} className="p-1.5 hover:bg-white/10 rounded-l-lg text-gray-300 hover:text-white border-r border-white/10">
                                            <ChevronDownIcon className="w-4 h-4 rotate-180" />
                                        </button>
                                        <button onClick={handleNextResult} className="p-1.5 hover:bg-white/10 rounded-r-lg text-gray-300 hover:text-white">
                                            <ChevronDownIcon className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    ) : (
                        <>
                            <div className="flex items-center gap-3 overflow-hidden cursor-pointer hover:opacity-80 transition-opacity flex-1" onClick={() => setView('profile')}>
                                <button onClick={(e) => { e.stopPropagation(); onBack(); }} className="md:hidden p-1 -ml-1 text-gray-300"><ArrowLeftIcon className="w-6 h-6" /></button>
                                <div className="relative">
                                    <img src={conversation.friend.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" />
                                    {/* Optional: Theme ring */}
                                    <div className="absolute inset-0 rounded-full border-2 opacity-50" style={{ borderColor: themeColor }}></div>
                                </div>
                                <div className="min-w-0">
                                    <h3 className="font-bold text-white truncate flex items-center gap-1">
                                        {conversation.friend.name}
                                        {conversation.isMuted && <span className="text-gray-500 text-xs italic">(Muted)</span>}
                                    </h3>
                                    <p className="text-xs text-gray-400 truncate">
                                        {conversation.participants?.length || 0} members
                                        {conversation.voiceChatStarted && <span className="text-green-400 ml-2 font-bold">• Voice Chat</span>}
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-center gap-1">
                                <button onClick={() => setIsSearchOpen(true)} className="p-2 text-gray-400 hover:text-white rounded-full hover:bg-white/5 transition-colors">
                                    <SearchIcon className="w-6 h-6" />
                                </button>
                                {(amIAdmin || conversation.voiceChatStarted) && (
                                    <button 
                                        onClick={handleToggleVoiceChat}
                                        className={`flex items-center gap-2 px-3 py-1.5 rounded-full font-bold text-xs transition-all shadow-lg ml-1 ${conversation.voiceChatStarted ? 'bg-green-500 text-white animate-pulse' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`}
                                    >
                                        <WaveIcon className="w-4 h-4" />
                                        {conversation.voiceChatStarted ? 'JOIN' : 'START'}
                                    </button>
                                )}
                                <button onClick={() => setView('profile')} className="p-2 text-gray-400 hover:text-white"><MoreVertIcon className="w-6 h-6" /></button>
                            </div>
                        </>
                    )}
                </div>
                
                {conversation.voiceChatStarted && !isSearchOpen && (
                    <div className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 px-4 py-1.5 flex justify-between items-center cursor-pointer hover:brightness-110 transition-all" onClick={handleToggleVoiceChat}>
                        <div className="flex items-center gap-2 text-green-400 text-xs font-bold">
                            <WaveIcon className="w-4 h-4" />
                            <span>Voice Chat Active</span>
                        </div>
                        <div className="flex -space-x-1">
                            {(conversation.voiceChatParticipants || []).slice(0, 3).map(p => (
                                <img key={p.id} src={p.avatar} className="w-5 h-5 rounded-full border border-black" />
                            ))}
                        </div>
                    </div>
                )}
            </header>

            <ChatHeaderMiniPlayer activeContextId={conversation.friend.id} />

            <div 
                ref={chatContainerRef}
                className={`flex-1 overflow-y-auto p-4 pb-32 space-y-1 custom-scrollbar ${chatBackground.type === 'class' ? chatBackground.value : ''}`}
                style={chatBackground.type === 'custom' ? { backgroundImage: chatBackground.value, backgroundSize: 'cover' } : {}}
                onScroll={handleScroll}
            >
                {conversation.messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full min-h-[50vh] text-center animate-fade-in select-none">
                        <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-2xl mb-6 rotate-3 border-4 border-white/10">
                             <span className="text-4xl font-bold text-white">{conversation.friend.name.charAt(0).toUpperCase()}</span>
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">Welcome to {conversation.friend.name}</h3>
                        <p className="text-gray-400 max-w-xs mb-6 text-sm">
                            This group is fresh and new! Be the first to break the ice.
                        </p>
                        <button 
                            onClick={() => onSendMessage({ message: "Hello everyone! 👋" })}
                            className="px-6 py-2.5 bg-white/10 hover:bg-white/20 border border-white/10 rounded-full text-white font-medium transition-all hover:scale-105 active:scale-95 backdrop-blur-md"
                        >
                            Start Conversation
                        </button>
                    </div>
                ) : (
                    messagesWithSeparators.map((item, idx) => {
                        if ('type' in item && item.type === 'date-separator') {
                            return <DateSeparator key={`sep-${idx}`} dateString={item.date} />;
                        }
                        const msg = item as DirectMessage;
                        const isSentByMe = msg.senderId === currentUser.id;
                        const sender = conversation.participants?.find(p => p.id === msg.senderId);
                        const isGroupStart = idx === 0 || (messagesWithSeparators[idx - 1] as DirectMessage).senderId !== msg.senderId;
                        const senderColor = getUserColor(sender?.id || 0);
    
                        return (
                            <div key={msg.id} className={`flex gap-3 group ${isSentByMe ? 'justify-end' : 'justify-start'} ${isGroupStart ? 'mt-2' : 'mt-0.5'}`}>
                                {!isSentByMe && (
                                    <div className="w-8 flex-shrink-0 flex flex-col justify-end">
                                        {isGroupStart ? (
                                            <img src={sender?.avatar} className="w-8 h-8 rounded-full bg-gray-700 object-cover cursor-pointer hover:opacity-80" title={sender?.name} onClick={() => {/* View Member Profile */}}/>
                                        ) : <div className="w-8" />}
                                    </div>
                                )}
                                
                                <div 
                                    ref={(el) => { if (el) messageRefs.current.set(msg.id, el); }}
                                    className={`flex flex-col max-w-[75%] ${isSentByMe ? 'items-end' : 'items-start'}`}
                                >
                                    {!isSentByMe && isGroupStart && (
                                        <span className={`text-[11px] font-bold ml-3 mb-0.5 ${senderColor}`}>
                                            {sender?.name}
                                            {(conversation.adminIds || []).includes(sender?.id || 0) && <span className="ml-1 text-[9px] bg-gray-700 text-gray-300 px-1 rounded">ADMIN</span>}
                                            {conversation.groupOwnerId === sender?.id && <span className="ml-1 text-[9px] bg-yellow-500/20 text-yellow-500 px-1 rounded"><CrownIcon className="w-2 h-2 inline -mt-0.5"/> OWNER</span>}
                                        </span>
                                    )}
                                    
                                    <div onContextMenu={(e) => { e.preventDefault(); setActionMenuMessage(msg); }}>
                                        <DirectMessageItem 
                                            message={msg} 
                                            isSent={isSentByMe} 
                                            friend={conversation.friend}
                                            currentUser={currentUser}
                                            selectionMode={false}
                                            onOpenContextMenu={() => setActionMenuMessage(msg)}
                                            onAddReaction={() => {}}
                                            onJoinRoom={() => {}}
                                            onJoinVoiceRoom={() => {}}
                                            onReplyClick={scrollToMessage}
                                            onViewMedia={onViewMedia}
                                            onCancelUpload={() => {}}
                                            getReplyPreviewText={(m) => m.message}
                                            onReplyRequest={setReplyingTo}
                                            audioContextQueue={audioQueue}
                                        />
                                    </div>
                                </div>
                            </div>
                        );
                    })
                )}
                <div ref={chatEndRef} />
            </div>

             <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center pointer-events-none">
                 <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/90 to-transparent pointer-events-none" />
                 <div className="w-full max-w-4xl flex flex-col gap-2 pb-4 px-4 relative z-10 pointer-events-auto">
                    <div className="flex justify-end mb-2">
                        <JumpToLatestButton isVisible={showScrollButton} newMessagesCount={0} onClick={() => scrollToBottom()} />
                    </div>

                    {replyingTo && (
                        <div className="bg-[#1e1e24] border-l-4 p-2 rounded-r-lg flex justify-between items-center mb-1 shadow-lg animate-slide-in-up" style={{ borderLeftColor: themeColor }}>
                            <div className="text-xs text-gray-300">
                                <span className="font-bold block" style={{ color: themeColor }}>Replying to message</span>
                                <span className="truncate block max-w-xs">{replyingTo.message || 'Media'}</span>
                            </div>
                            <button onClick={() => setReplyingTo(null)}><CloseIcon className="w-4 h-4 text-gray-400" /></button>
                        </div>
                    )}

                    <div className="bg-[#1e1e24] border border-white/10 rounded-xl p-2 shadow-2xl flex items-end gap-2 ring-1 ring-white/5 focus-within:ring-1 focus-within:bg-[#23232a] transition-all" style={{ '--tw-ring-color': themeColor } as React.CSSProperties}>
                        {voiceMode === 'recording' ? (
                            <VoiceMessageRecorder isRecording={true} onCancel={() => setVoiceMode('idle')} onSend={handleSendVoice} />
                        ) : (
                            <>
                                <button className="p-2 text-gray-400 hover:text-blue-400 hover:bg-white/5 rounded-lg transition-colors"><AttachmentIcon className="w-6 h-6" /></button>
                                <textarea 
                                    value={text} 
                                    onChange={e => setText(e.target.value)}
                                    placeholder="Message group..."
                                    className="flex-1 bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none py-2.5 px-2 text-[15px] max-h-[100px] min-h-[44px]"
                                    rows={1}
                                    onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                                />
                                <button className="p-2 text-gray-400 hover:text-yellow-400 hover:bg-white/5 rounded-lg transition-colors"><EmojiIcon className="w-6 h-6" /></button>
                                {text.trim() ? (
                                    <button onClick={handleSend} className="w-10 h-10 text-white rounded-lg flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all" style={{ background: `linear-gradient(to bottom right, ${themeColor}, ${themeColor}dd)` }}><SendIcon className="w-5 h-5 ml-0.5" /></button>
                                ) : (
                                    <button onClick={() => setVoiceMode('recording')} className="w-10 h-10 bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg flex items-center justify-center transition-all"><MicrophoneIcon className="w-5 h-5" /></button>
                                )}
                            </>
                        )}
                    </div>
                 </div>
             </div>

            {actionMenuMessage && (
                <MessageActionOverlay 
                    message={actionMenuMessage} 
                    isSent={actionMenuMessage.senderId === currentUser.id}
                    isPinned={false}
                    onClose={() => setActionMenuMessage(null)}
                    onReply={() => setReplyingTo(actionMenuMessage)}
                    onEdit={() => {}}
                    onCopy={() => navigator.clipboard.writeText(actionMenuMessage.message)}
                    onPin={() => {}}
                    onDelete={() => onDeleteMessage([actionMenuMessage.id])}
                    onForward={() => onForwardMessage(0, actionMenuMessage)}
                    onSelect={() => {}}
                    onAddReaction={() => {}}
                    currentUser={currentUser}
                    friend={conversation.friend}
                    onJoinRoom={() => {}}
                    onJoinVoiceRoom={() => {}}
                    onReplyClick={scrollToMessage}
                    onViewMedia={onViewMedia}
                    getReplyPreviewText={(m) => m.message}
                />
            )}

            <PlaylistBottomSheet 
                isOpen={isPlaylistOpen} 
                onClose={() => setIsPlaylistOpen(false)} 
                onExpand={() => {
                    setIsPlaylistOpen(false);
                    expandPlayer();
                }}
            />
        </div>
    );
};

export default GroupChat;
