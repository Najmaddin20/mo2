
import React, { useState, useEffect } from 'react';
import type { VoiceRoom, User } from '../types';
import { UsersIcon, PrivateIcon, MicrophoneIcon, ClockIcon, HandIcon } from './icons';

interface VoiceClubhouseProps {
    rooms: VoiceRoom[];
    onJoinRoom: (room: VoiceRoom) => void;
    onStartRoom: () => void;
}

// Helper component for card timer
const CardTimer: React.FC<{ endsAt: number }> = ({ endsAt }) => {
    const [timeLeft, setTimeLeft] = useState("");

    useEffect(() => {
        const update = () => {
            const now = Date.now();
            const diff = Math.ceil((endsAt - now) / 1000);
            if (diff <= 0) {
                setTimeLeft("Ended");
                return;
            }
            const m = Math.floor(diff / 60);
            const s = diff % 60;
            setTimeLeft(`${m}:${s.toString().padStart(2, '0')}`);
        };
        update();
        const interval = setInterval(update, 1000);
        return () => clearInterval(interval);
    }, [endsAt]);

    return (
        <div className="flex items-center gap-1 text-[10px] font-bold text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded-md border border-yellow-400/20">
            <ClockIcon className="w-3 h-3" />
            <span className="font-mono">{timeLeft}</span>
        </div>
    );
};

const getThemeStyles = (theme: string = 'cosmic') => {
    switch (theme) {
        case 'sunset':
            return {
                text: 'text-orange-400',
                border: 'hover:border-orange-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(249,115,22,0.3)]',
                tag: 'text-orange-300 border-orange-500/20 bg-orange-500/10'
            };
        case 'forest':
            return {
                text: 'text-emerald-400',
                border: 'hover:border-emerald-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(16,185,129,0.3)]',
                tag: 'text-emerald-300 border-emerald-500/20 bg-emerald-500/10'
            };
        case 'ocean':
             return {
                text: 'text-cyan-400',
                border: 'hover:border-cyan-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(6,182,212,0.3)]',
                tag: 'text-cyan-300 border-cyan-500/20 bg-cyan-500/10'
            };
        case 'midnight':
             return {
                text: 'text-indigo-400',
                border: 'hover:border-indigo-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(99,102,241,0.3)]',
                tag: 'text-indigo-300 border-indigo-500/20 bg-indigo-500/10'
            };
        case 'rose':
             return {
                text: 'text-rose-400',
                border: 'hover:border-rose-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(244,63,94,0.3)]',
                tag: 'text-rose-300 border-rose-500/20 bg-rose-500/10'
            };
        case 'amber':
             return {
                text: 'text-amber-400',
                border: 'hover:border-amber-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(245,158,11,0.3)]',
                tag: 'text-amber-300 border-amber-500/20 bg-amber-500/10'
            };
        case 'cosmic':
        default:
            return {
                text: 'text-purple-400',
                border: 'hover:border-purple-500/50',
                shadow: 'hover:shadow-[0_0_30px_-10px_rgba(168,85,247,0.3)]',
                tag: 'text-purple-300 border-purple-500/20 bg-purple-500/10'
            };
    }
};

const VoiceRoomCard: React.FC<{ room: VoiceRoom; onJoin: () => void; }> = ({ room, onJoin }) => {
    const speakers = room.speakers;
    const activeSpeaker = speakers.find(s => s.isSpeaking);
    const styles = getThemeStyles(room.theme);

    return (
        <div 
            onClick={onJoin}
            className={`bg-[#1e1e24]/40 backdrop-blur-md border border-white/5 rounded-2xl p-5 flex flex-col transition-all duration-300 shadow-lg transform hover:-translate-y-1 relative group cursor-pointer overflow-hidden ${styles.border} ${styles.shadow}`}
        >
            <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                    {room.isPrivate && (
                        <div className="bg-black/20 p-1.5 rounded-lg text-gray-400">
                            <PrivateIcon className="w-4 h-4" />
                        </div>
                    )}
                    {room.timer && <CardTimer endsAt={room.timer.endsAt} />}
                </div>

                {room.isRecording && (
                    <div className="flex items-center gap-1.5 bg-red-500/10 px-2 py-1 rounded-full text-red-400 text-[10px] font-bold tracking-wider border border-red-500/20 ml-auto">
                         <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                         REC
                    </div>
                )}
            </div>

            <h3 className={`text-lg font-bold leading-snug mb-4 line-clamp-2 transition-colors ${styles.text}`}>{room.topic}</h3>
            
            <div className="flex-1 space-y-4">
                <div className="flex items-center gap-3">
                    <div className="flex -space-x-3">
                        {speakers.slice(0, 3).map(speaker => (
                            <img key={speaker.id} src={speaker.avatar} alt={speaker.name} className={`w-10 h-10 rounded-full border-2 border-[#25252b] object-cover ${speaker.isSpeaking ? 'ring-2 ring-green-500 z-10' : ''}`} />
                        ))}
                         {speakers.length > 3 && (
                            <div className="w-10 h-10 rounded-full bg-[#2a2a35] flex items-center justify-center text-xs font-bold text-gray-400 border-2 border-[#25252b]">
                                +{speakers.length - 3}
                            </div>
                        )}
                    </div>
                    <div className="flex-1 min-w-0">
                        {activeSpeaker ? (
                             <div className="flex items-center gap-2 text-green-400 text-xs font-medium animate-pulse">
                                <MicrophoneIcon className="w-3 h-3"/>
                                <span className="truncate">{activeSpeaker.name} is speaking</span>
                            </div>
                        ) : (
                            <p className="text-xs text-gray-400 truncate">
                                {speakers.map(s => s.name).slice(0, 2).join(', ')} {speakers.length > 2 ? '& others' : ''}
                            </p>
                        )}
                    </div>
                </div>

                {room.topics && room.topics.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                        {room.topics.slice(0, 3).map(tag => (
                            <span key={tag} className={`text-[10px] uppercase font-bold tracking-wide px-2 py-1 rounded-md border ${styles.tag}`}>{tag}</span>
                        ))}
                    </div>
                )}
            </div>
            
            <div className="flex justify-between items-center pt-4 mt-2 border-t border-white/5">
                <div className="flex items-center gap-1.5 text-gray-400 bg-black/20 px-2 py-1 rounded-lg">
                    <UsersIcon className="w-4 h-4" />
                    <span className="text-xs font-bold">{speakers.length + room.listeners.length}</span>
                </div>
                
                {/* Mic / Hand Status Indicator */}
                <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border ${room.openMicMode ? 'text-green-400 bg-green-500/10 border-green-500/20' : 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20'}`}>
                    {room.openMicMode ? (
                        <>
                            <MicrophoneIcon className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-bold uppercase">Open Mic</span>
                        </>
                    ) : (
                        <>
                            <HandIcon className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-bold uppercase">Raise Hand</span>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

const VoiceClubhouse: React.FC<VoiceClubhouseProps> = ({ rooms, onJoinRoom, onStartRoom }) => {
    return (
        <div className="p-4 md:p-8 h-full overflow-y-auto hide-scrollbar">
            <div className="max-w-7xl mx-auto">
                <div className="flex flex-row justify-between items-center mb-6 md:mb-8 gap-4">
                    <div>
                        <h2 className="text-2xl md:text-3xl font-bold text-white mb-1 md:mb-2">Voice Rooms</h2>
                        <p className="text-xs md:text-base text-gray-400">Drop into live audio conversations.</p>
                    </div>
                    <button 
                        onClick={onStartRoom}
                        className="bg-white text-black font-bold px-4 py-2 md:px-6 md:py-3 rounded-full hover:bg-gray-200 transition-all shadow-lg transform active:scale-95 flex items-center gap-2 text-xs md:text-base whitespace-nowrap"
                    >
                        <span className="text-lg md:text-xl leading-none">+</span>
                        <span className="hidden md:inline">Start a Room</span>
                        <span className="md:hidden">Start</span>
                    </button>
                </div>

                {rooms.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {rooms.map(room => (
                            <VoiceRoomCard key={room.id} room={room} onJoin={() => onJoinRoom(room)} />
                        ))}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-20 px-4 text-center bg-white/5 rounded-3xl border border-dashed border-white/10">
                         <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4">
                            <MicrophoneIcon className="w-10 h-10 text-gray-500" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-2">It's quiet in here...</h3>
                        <p className="text-gray-400 max-w-md">Be the first to start a conversation! Create a room to talk about movies, games, or just hang out.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default VoiceClubhouse;
