
import React, { useState, FormEvent } from 'react';
import type { User } from '../types';
import { CloseIcon, UserAddIcon, CheckIcon } from './icons';

interface AddFriendModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSearchUser: (userId: string) => { status: 'found', user: User } | { status: 'error', message: string };
    onAddFriend: (userId: number) => { status: 'success' } | { status: 'error', message: string };
}

const AddFriendModal: React.FC<AddFriendModalProps> = ({ isOpen, onClose, onSearchUser, onAddFriend }) => {
    const [userIdInput, setUserIdInput] = useState('');
    const [searchResult, setSearchResult] = useState<User | null>(null);
    const [statusMessage, setStatusMessage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleSearch = (e: FormEvent) => {
        e.preventDefault();
        if (!userIdInput.trim()) return;
        
        setIsLoading(true);
        setSearchResult(null);
        setStatusMessage(null);
        
        // Simulate network delay
        setTimeout(() => {
            const result = onSearchUser(userIdInput.trim());
            if (result.status === 'found') {
                setSearchResult(result.user);
            } else {
                setStatusMessage(result.message);
            }
            setIsLoading(false);
        }, 500);
    };
    
    const handleAddFriendClick = () => {
        if (!searchResult) return;
        onAddFriend(searchResult.id);
        setStatusMessage(`Friend request sent to ${searchResult.name}!`);
        setSearchResult(null);
        setUserIdInput('');
    }

    const handleClose = () => {
        setUserIdInput('');
        setSearchResult(null);
        setStatusMessage(null);
        setIsLoading(false);
        onClose();
    }

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={handleClose}
        >
            <div 
                className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl p-8 space-y-6 w-full max-w-md animate-fade-in-up"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">Add Friend</h2>
                    <button onClick={handleClose} className="text-gray-400 hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <p className="text-sm text-gray-300">Enter your friend's user ID to send them a friend request.</p>
                <form onSubmit={handleSearch} className="flex gap-2">
                    <input
                        type="text"
                        value={userIdInput}
                        onChange={(e) => setUserIdInput(e.target.value)}
                        className="flex-1 appearance-none rounded-lg w-full px-4 py-3 bg-black/30 border border-white/20 placeholder-gray-400 text-white focus:outline-none focus:ring-2 focus:ring-[#6C5DD3] sm:text-sm"
                        placeholder="Enter User ID (e.g., 102)"
                        required
                    />
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="px-4 py-3 text-sm font-semibold rounded-lg text-white bg-white/10 hover:bg-white/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? 'Searching...' : 'Search'}
                    </button>
                </form>

                <div className="min-h-[100px] flex items-center justify-center">
                    {searchResult && (
                        <div className="w-full flex items-center justify-between p-3 rounded-lg bg-white/5 animate-fade-in">
                            <div className="flex items-center gap-3">
                                <img src={searchResult.avatar} alt={searchResult.name} className="w-12 h-12 rounded-full" />
                                <div>
                                    <p className="font-bold text-white">{searchResult.name}</p>
                                    <p className="text-xs text-gray-400">User ID: {searchResult.id}</p>
                                </div>
                            </div>
                            <button
                                onClick={handleAddFriendClick}
                                className="flex items-center justify-center gap-2 px-3 py-2 text-sm font-semibold rounded-lg text-white bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] hover:bg-gradient-to-l transform active:scale-95"
                            >
                                <UserAddIcon className="w-4 h-4" />
                                Add
                            </button>
                        </div>
                    )}
                    {statusMessage && (
                        <div className={`text-sm text-center animate-fade-in ${statusMessage.startsWith('Friend request sent') ? 'text-green-400' : 'text-red-400'}`}>
                            {statusMessage}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AddFriendModal;