import React, { useState, useEffect, useCallback } from 'react';

const EMOJIS = ['😊', '😂', '😍', '👍', '🔥', '❤️'];

interface Reaction {
  id: number;
  emoji: string;
  x: number;
  y: number;
}

const EmojiReactions: React.FC<{}> = () => {
  const [reactions, setReactions] = useState<Reaction[]>([]);

  const addReaction = useCallback((emoji: string) => {
    const newReaction: Reaction = {
      id: Date.now() + Math.random(),
      emoji,
      x: Math.random() * 80 + 10, // position from 10% to 90%
      y: 100,
    };
    setReactions(prev => [...prev.slice(-15), newReaction]); // Keep max 15 reactions
  }, []);

  useEffect(() => {
    if (reactions.length > 0) {
      const timer = setTimeout(() => {
        setReactions(prev => prev.slice(1));
      }, 3000); // Reactions disappear after 3 seconds
      return () => clearTimeout(timer);
    }
  }, [reactions]);

  return (
    <>
      <div className="absolute bottom-20 right-4 lg:bottom-24 lg:left-1/2 lg:-translate-x-1/2 z-20 group-hover:opacity-100 opacity-0 transition-opacity duration-300">
          <div className="flex items-center gap-2 bg-black/40 backdrop-blur-lg border border-white/10 p-2 rounded-full">
              {EMOJIS.map(emoji => (
                  <button key={emoji} onClick={() => addReaction(emoji)} className="text-2xl hover:scale-125 transition-transform duration-200">
                      {emoji}
                  </button>
              ))}
          </div>
      </div>
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
        {reactions.map(r => (
          <span
            key={r.id}
            className="absolute text-4xl animate-float-up"
            style={{ left: `${r.x}%`, bottom: '-10%' }}
          >
            {r.emoji}
          </span>
        ))}
        <style>{`
          @keyframes float-up {
            0% {
              transform: translateY(0) scale(1);
              opacity: 1;
            }
            100% {
              transform: translateY(-400px) scale(0.5);
              opacity: 0;
            }
          }
          .animate-float-up {
            animation: float-up 3s ease-out forwards;
          }
        `}</style>
      </div>
    </>
  );
};

export default EmojiReactions;
