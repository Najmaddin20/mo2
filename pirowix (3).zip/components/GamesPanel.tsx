
import React from 'react';
import type { VoiceRoom, User } from '../types';
import { GameControllerIcon, QuestionMarkCircleIcon, SparklesIcon, CrownIcon, TrashIcon, SkipNextIcon, CheckIcon, CloseIcon, PlayIcon } from './icons';

interface GamesPanelProps {
    room: VoiceRoom;
    currentUser: User;
    onGameAction: (action: string, payload?: any) => void;
    onClose: () => void;
    isMobile?: boolean;
}

const AVAILABLE_GAMES = [
    {
        id: 'truth-or-dare',
        title: 'Truth or Dare',
        description: 'Spin the bottle and face the truth or take a dare.',
        icon: <GameControllerIcon className="w-6 h-6 text-purple-400" />,
        color: 'bg-purple-500/10 border-purple-500/20',
        btnColor: 'bg-purple-600 hover:bg-purple-500'
    },
    {
        id: 'would-you-rather',
        title: 'Would You Rather',
        description: 'Choose between two difficult scenarios.',
        icon: <QuestionMarkCircleIcon className="w-6 h-6 text-cyan-400" />,
        color: 'bg-cyan-500/10 border-cyan-500/20',
        btnColor: 'bg-cyan-600 hover:bg-cyan-500'
    },
    {
        id: 'this-or-that',
        title: 'This or That',
        description: 'Quick polls to find out who agrees with you.',
        icon: <SparklesIcon className="w-6 h-6 text-yellow-400" />,
        color: 'bg-yellow-500/10 border-yellow-500/20',
        btnColor: 'bg-yellow-600 hover:bg-yellow-500'
    },
    {
        id: 'charades',
        title: 'Charades',
        description: 'Act out AI-generated words for the room to guess.',
        icon: <SparklesIcon className="w-6 h-6 text-orange-400" />,
        color: 'bg-orange-500/10 border-orange-500/20',
        btnColor: 'bg-orange-600 hover:bg-orange-500'
    }
];

// --- Shared Components ---

const PanelHeader: React.FC<{ title: string; icon: React.ReactNode; onClose: () => void; isLive?: boolean }> = ({ title, icon, onClose, isLive }) => (
    <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/5 flex-shrink-0">
        <div className="flex items-center gap-3">
            <div className="p-2 bg-white/5 rounded-lg text-gray-300">
                {icon}
            </div>
            <div>
                <h2 className="text-base font-bold text-white leading-tight">{title}</h2>
                {isLive ? (
                    <span className="text-[10px] font-bold text-green-400 uppercase tracking-wider flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span> Live
                    </span>
                ) : (
                    <span className="text-[10px] font-medium text-gray-500">Game Center</span>
                )}
            </div>
        </div>
        <button onClick={onClose} className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors">
            <CloseIcon className="w-5 h-5" />
        </button>
    </div>
);

const HostControls: React.FC<{ onNext: () => void; onEnd: () => void; label?: string }> = ({ onNext, onEnd, label = "Next Round" }) => (
    <div className="p-4 border-t border-white/10 bg-[#18181b] mt-auto sticky bottom-0 z-10">
        <div className="flex items-center gap-2 text-[10px] font-bold text-yellow-500 uppercase tracking-widest mb-3">
            <CrownIcon className="w-3 h-3" /> Host Controls
        </div>
        <div className="grid grid-cols-2 gap-2">
            <button 
                onClick={onEnd} 
                className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-xs font-bold text-red-400 bg-red-500/10 hover:bg-red-500/20 transition-colors border border-red-500/20"
            >
                <TrashIcon className="w-3.5 h-3.5" /> End Game
            </button>
            <button 
                onClick={onNext} 
                className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-xs font-bold bg-white text-black hover:bg-gray-200 transition-colors shadow-lg"
            >
                {label} <SkipNextIcon className="w-3.5 h-3.5" />
            </button>
        </div>
    </div>
);

// --- Game Selection View ---

const GameSelectionView: React.FC<{ isHost: boolean; onStart: (type: string) => void }> = ({ isHost, onStart }) => (
    <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">
        <div className="text-center py-2">
            <h3 className="text-lg font-bold text-white">Start a Activity</h3>
            <p className="text-sm text-gray-400">Choose a game to play with the room.</p>
        </div>

        <div className="space-y-3">
            {AVAILABLE_GAMES.map(game => (
                <div key={game.id} className={`p-4 rounded-2xl border transition-all ${game.color} group`}>
                    <div className="flex items-start justify-between mb-2">
                        <div className="p-2 bg-black/20 rounded-lg">{game.icon}</div>
                        {isHost && (
                            <button 
                                onClick={() => onStart(game.id)}
                                className={`px-4 py-1.5 rounded-full text-xs font-bold text-white shadow-lg transition-transform active:scale-95 flex items-center gap-1 ${game.btnColor}`}
                            >
                                <PlayIcon className="w-3 h-3" /> Start
                            </button>
                        )}
                    </div>
                    <h4 className="font-bold text-white">{game.title}</h4>
                    <p className="text-xs text-gray-300 mt-1 leading-relaxed">{game.description}</p>
                </div>
            ))}
        </div>
        
        {!isHost && (
            <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-center mt-4">
                <p className="text-xs text-gray-500">Only the Host can start a game.</p>
            </div>
        )}
    </div>
);

// --- Game Sub-Components ---

const CharadesGame: React.FC<{ room: VoiceRoom; currentUser: User; isHost: boolean; onGameAction: (action: string, payload?: any) => void; }> = ({ room, currentUser, isHost, onGameAction }) => {
    const game = room.game;
    if (game?.type !== 'charades') return null;

    const isActor = game.currentActor?.id === currentUser.id;
    
    return (
        <div className="flex flex-col h-full">
            <div className="flex-1 p-4 space-y-6 overflow-y-auto custom-scrollbar">
                {game.currentActor ? (
                    <div className="text-center space-y-4 animate-fade-in-up">
                        <div className="flex flex-col items-center gap-2">
                            <img src={game.currentActor.avatar} alt={game.currentActor.name} className="w-14 h-14 rounded-full border-2 border-[#8A79F7] shadow-lg" />
                            <p className="text-sm text-gray-300">
                                <span className="font-bold text-white">{isActor ? 'Your' : `${game.currentActor.name}'s`}</span> turn to act!
                            </p>
                        </div>

                        <div className="py-6 px-4 bg-gradient-to-br from-purple-900/30 to-blue-900/30 rounded-xl border border-white/10 relative overflow-hidden">
                            {isActor ? (
                                <div className="relative z-10">
                                    <p className="text-[10px] font-bold text-purple-300 uppercase tracking-widest mb-1">Secret Word</p>
                                    <p className="text-2xl font-black text-white drop-shadow-sm">{game.currentWord}</p>
                                    <button 
                                        onClick={() => onGameAction('get-word')} 
                                        className="mt-4 text-[10px] font-semibold bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-full transition-colors"
                                    >
                                        Reroll Word
                                    </button>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center py-2">
                                    <div className="text-4xl mb-2 opacity-50">🤫</div>
                                    <p className="text-sm font-bold text-gray-400">Guess the word!</p>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-4">
                        <p className="text-gray-400 text-sm mb-4">Waiting for the next actor...</p>
                        {isHost && (
                            <div className="space-y-2">
                                <p className="text-xs font-bold text-gray-500 uppercase">Choose Actor</p>
                                <div className="grid grid-cols-2 gap-2">
                                    {room.speakers.map(speaker => (
                                        <button 
                                            key={speaker.id} 
                                            onClick={() => onGameAction('next-actor', { playerId: speaker.id })}
                                            className="flex items-center gap-2 p-2 rounded-lg bg-white/5 hover:bg-purple-500/20 border border-white/5 hover:border-purple-500/30 transition-all group text-left"
                                        >
                                            <img src={speaker.avatar} className="w-6 h-6 rounded-full" />
                                            <span className="text-xs font-medium text-gray-300 group-hover:text-white truncate">{speaker.name}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {isHost && game.currentActor && (
                <HostControls onNext={() => onGameAction('next-actor', { playerId: null })} onEnd={() => onGameAction('end')} label="Next Actor" />
            )}
        </div>
    );
}

const VotingGame: React.FC<{ room: VoiceRoom; currentUser: User; isHost: boolean; onGameAction: (action: string, payload?: any) => void; }> = ({ room, currentUser, isHost, onGameAction }) => {
    const game = room.game;
    if (game?.type !== 'would-you-rather' && game?.type !== 'this-or-that') return null;

    const userVote = game.optionA.votes.some(u => u.id === currentUser.id) ? 'A' :
                     game.optionB.votes.some(u => u.id === currentUser.id) ? 'B' : null;
    
    const totalVotes = game.optionA.votes.length + game.optionB.votes.length;
    const percentA = totalVotes > 0 ? (game.optionA.votes.length / totalVotes) * 100 : 50;
    const percentB = 100 - percentA;

    return (
        <div className="flex flex-col h-full">
            <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-6">
                <div className="text-center px-2">
                    <h3 className="text-lg font-bold text-white leading-snug">{game.question}</h3>
                </div>
                
                <div className="space-y-3">
                    <VoteOption 
                        optionText={game.optionA.text}
                        votes={game.optionA.votes}
                        percentage={percentA}
                        isVoted={userVote === 'A'}
                        onVote={() => onGameAction('vote', { option: 'A' })}
                        color="blue"
                    />
                    
                    <div className="flex items-center justify-center gap-4 opacity-40">
                        <div className="h-px bg-white flex-1"></div>
                        <span className="text-[10px] font-bold uppercase">OR</span>
                        <div className="h-px bg-white flex-1"></div>
                    </div>

                    <VoteOption 
                        optionText={game.optionB.text}
                        votes={game.optionB.votes}
                        percentage={percentB}
                        isVoted={userVote === 'B'}
                        onVote={() => onGameAction('vote', { option: 'B' })}
                        color="pink"
                    />
                </div>
            </div>

            {isHost && (
                <HostControls onNext={() => onGameAction('next')} onEnd={() => onGameAction('end')} label="Next Question" />
            )}
        </div>
    );
};

const TruthOrDareGame: React.FC<{ room: VoiceRoom; currentUser: User; isHost: boolean; onGameAction: (action: string, payload?: any) => void; }> = ({ room, currentUser, isHost, onGameAction }) => {
    const game = room.game;
    if (game?.type !== 'truth-or-dare') return null;

    return (
        <div className="flex flex-col h-full">
            <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
                {game.currentChallenge ? (
                    <div className="space-y-6 animate-fade-in-up text-center">
                        <div className="flex flex-col items-center gap-2">
                            <img src={game.currentPlayer?.avatar} className="w-14 h-14 rounded-full border-2 border-white/20" />
                            <p className="text-sm text-gray-300"><span className="font-bold text-white">{game.currentPlayer?.name}</span> chose <span className={`font-bold uppercase ${game.currentChallenge.type === 'truth' ? 'text-cyan-400' : 'text-red-400'}`}>{game.currentChallenge.type}</span></p>
                        </div>

                        <div className={`p-6 rounded-2xl border ${game.currentChallenge.type === 'truth' ? 'bg-cyan-500/10 border-cyan-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                            <p className="text-lg font-bold text-white leading-relaxed">"{game.currentChallenge.text}"</p>
                        </div>
                    </div>
                ) : (
                    <div className="py-4">
                        <p className="text-sm font-bold text-gray-400 mb-4 text-center">Host, select a player!</p>
                        {isHost && (
                            <div className="space-y-3">
                                {room.speakers.map(speaker => (
                                    <div key={speaker.id} className="bg-white/5 p-2 rounded-xl flex items-center justify-between border border-white/5">
                                        <div className="flex items-center gap-2 min-w-0">
                                            <img src={speaker.avatar} className="w-8 h-8 rounded-full" />
                                            <p className="text-xs font-bold text-white truncate">{speaker.name}</p>
                                        </div>
                                        <div className="flex gap-1">
                                            <button onClick={() => onGameAction('truth', { playerId: speaker.id })} className="px-2 py-1 bg-cyan-500/20 text-cyan-400 text-[10px] font-bold rounded hover:bg-cyan-500/30">TRUTH</button>
                                            <button onClick={() => onGameAction('dare', { playerId: speaker.id })} className="px-2 py-1 bg-red-500/20 text-red-400 text-[10px] font-bold rounded hover:bg-red-500/30">DARE</button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {isHost && game.currentChallenge && (
                <HostControls onNext={() => onGameAction('next')} onEnd={() => onGameAction('end')} label="Next Player" />
            )}
        </div>
    );
};

// --- Main Component ---

const GamesPanel: React.FC<GamesPanelProps> = ({ room, currentUser, onGameAction, onClose, isMobile }) => {
    const game = room.game;
    const isHost = room.speakers.some(s => s.id === currentUser.id && s.role === 'host');
    
    const getGameConfig = () => {
        if (!game) return { title: 'Activities', icon: <GameControllerIcon className="w-5 h-5" /> };
        switch (game.type) {
            case 'charades': return { title: 'Charades', icon: <SparklesIcon className="w-5 h-5" /> };
            case 'would-you-rather': return { title: 'Would You Rather', icon: <QuestionMarkCircleIcon className="w-5 h-5" /> };
            case 'this-or-that': return { title: 'This or That', icon: <SparklesIcon className="w-5 h-5" /> };
            case 'truth-or-dare': return { title: 'Truth or Dare', icon: <GameControllerIcon className="w-5 h-5" /> };
            default: return { title: 'Game', icon: <GameControllerIcon className="w-5 h-5" /> };
        }
    };

    const config = getGameConfig();

    return (
        <div className="flex flex-col h-full bg-[#18181b] text-white">
            <PanelHeader title={config.title} icon={config.icon} onClose={onClose} isLive={!!game} />
            
            <div className="flex-1 overflow-hidden relative">
                {!game && (
                    <GameSelectionView 
                        isHost={isHost} 
                        onStart={(type) => onGameAction('start', { gameType: type })} 
                    />
                )}
                {game?.type === 'charades' && <CharadesGame room={room} currentUser={currentUser} isHost={isHost} onGameAction={onGameAction} />}
                {(game?.type === 'would-you-rather' || game?.type === 'this-or-that') && <VotingGame room={room} currentUser={currentUser} isHost={isHost} onGameAction={onGameAction} />}
                {game?.type === 'truth-or-dare' && <TruthOrDareGame room={room} currentUser={currentUser} isHost={isHost} onGameAction={onGameAction} />}
            </div>
        </div>
    );
};

const VoteOption: React.FC<{
    optionText: string;
    votes: User[];
    percentage: number;
    isVoted: boolean;
    onVote: () => void;
    color: 'blue' | 'pink';
}> = ({ optionText, votes, percentage, isVoted, onVote, color }) => {
    const colorClass = color === 'blue' ? 'bg-blue-600' : 'bg-pink-600';
    const borderClass = color === 'blue' ? 'border-blue-500' : 'border-pink-500';
    const textClass = color === 'blue' ? 'text-blue-400' : 'text-pink-400';

    return (
        <div className="relative group">
            <button
                onClick={onVote}
                className={`relative w-full text-left h-14 rounded-xl border-2 transition-all duration-300 overflow-hidden ${isVoted ? borderClass : 'border-white/10 hover:border-white/30'}`}
            >
                {/* Progress Bar */}
                <div 
                    className={`absolute inset-y-0 left-0 ${colorClass} opacity-20 transition-all duration-700 ease-out`} 
                    style={{ width: `${percentage}%` }}
                ></div>
                
                {/* Content */}
                <div className="absolute inset-0 flex items-center justify-between px-3 z-10">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                        <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center ${isVoted ? `${borderClass} ${colorClass} text-white` : 'border-gray-500 text-transparent'}`}>
                            <CheckIcon className="w-3 h-3" />
                        </div>
                        <span className="font-bold text-sm text-white truncate">{optionText}</span>
                    </div>
                    <span className={`font-black text-lg ${textClass}`}>{Math.round(percentage)}%</span>
                </div>
            </button>
            
            {/* Avatars */}
            {votes.length > 0 && (
                <div className="flex -space-x-1.5 mt-1.5 px-1 h-6 items-center">
                    {votes.slice(0, 5).map(user => (
                        <img key={user.id} src={user.avatar} alt={user.name} title={user.name} className="w-5 h-5 rounded-full border border-[#18181b] object-cover" />
                    ))}
                    {votes.length > 5 && (
                        <span className="text-[10px] text-gray-500 ml-1">+{votes.length - 5}</span>
                    )}
                </div>
            )}
        </div>
    );
};

export default GamesPanel;
