
import React, { useState, useEffect } from 'react';
import type { GroupPermission, User } from '../types';
import { CloseIcon, CheckIcon, ShieldIcon } from './icons';

// Add ShieldIcon to icons.tsx if missing, using a placeholder here for compilation
const ShieldIconPlaceholder = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

interface GroupPermissionsModalProps {
    isOpen: boolean;
    onClose: () => void;
    targetUser: User;
    currentPermissions: GroupPermission[];
    onSave: (permissions: GroupPermission[]) => void;
}

const PERMISSIONS: { id: GroupPermission; label: string; description: string }[] = [
    { id: 'edit_info', label: 'Change Group Info', description: 'Can change name, picture, and description.' },
    { id: 'delete_messages', label: 'Delete Messages', description: 'Can delete messages sent by others.' },
    { id: 'ban_users', label: 'Ban Users', description: 'Can remove and ban users from the group.' },
    { id: 'invite_users', label: 'Invite Users', description: 'Can create invite links and add members.' },
    { id: 'pin_messages', label: 'Pin Messages', description: 'Can pin messages to the top of the chat.' },
];

const GroupPermissionsModal: React.FC<GroupPermissionsModalProps> = ({ isOpen, onClose, targetUser, currentPermissions, onSave }) => {
    const [selectedPermissions, setSelectedPermissions] = useState<Set<GroupPermission>>(new Set(currentPermissions));

    useEffect(() => {
        setSelectedPermissions(new Set(currentPermissions));
    }, [currentPermissions, isOpen]);

    const togglePermission = (perm: GroupPermission) => {
        setSelectedPermissions(prev => {
            const newSet = new Set(prev);
            if (newSet.has(perm)) newSet.delete(perm);
            else newSet.add(perm);
            return newSet;
        });
    };

    const handleSave = () => {
        onSave(Array.from(selectedPermissions));
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
            <div className="bg-[#1c1c1e] w-full max-w-md rounded-2xl shadow-2xl border border-white/10 overflow-hidden animate-fade-in-up" onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b border-white/10 flex justify-between items-center">
                    <h2 className="text-xl font-bold text-white">Admin Permissions</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6" /></button>
                </div>
                
                <div className="p-6 bg-[#151517]">
                    <div className="flex items-center gap-3 mb-6">
                        <img src={targetUser.avatar} alt={targetUser.name} className="w-12 h-12 rounded-full" />
                        <div>
                            <h3 className="font-bold text-white">{targetUser.name}</h3>
                            <p className="text-sm text-blue-400">Administrator</p>
                        </div>
                    </div>

                    <p className="text-sm text-gray-400 mb-4 uppercase font-bold tracking-wider">What can this admin do?</p>

                    <div className="space-y-3">
                        {PERMISSIONS.map(perm => {
                            const isEnabled = selectedPermissions.has(perm.id);
                            return (
                                <div 
                                    key={perm.id} 
                                    className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 cursor-pointer transition-colors"
                                    onClick={() => togglePermission(perm.id)}
                                >
                                    <div>
                                        <p className="text-white font-medium">{perm.label}</p>
                                        <p className="text-xs text-gray-400">{perm.description}</p>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${isEnabled ? 'bg-green-500 border-green-500' : 'border-gray-500'}`}>
                                        {isEnabled && <CheckIcon className="w-4 h-4 text-white" />}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="p-4 border-t border-white/10 flex justify-end gap-3">
                    <button onClick={onClose} className="px-4 py-2 rounded-lg text-white hover:bg-white/10">Cancel</button>
                    <button onClick={handleSave} className="px-6 py-2 rounded-lg bg-blue-600 text-white font-bold hover:bg-blue-500">Save</button>
                </div>
            </div>
        </div>
    );
};

export default GroupPermissionsModal;
