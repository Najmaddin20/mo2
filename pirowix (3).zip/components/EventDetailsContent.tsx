
import React, { useMemo, useState } from 'react';
import type { ScheduledEvent, User } from '../types';
import { CalendarIcon, ClockIcon, UserAddIcon, EditIcon, TrashIcon, PlayIcon, CheckIcon, QuestionMarkCircleIcon, XIcon, LinkIcon, ShareIcon } from './icons';

interface EventDetailsContentProps {
    event: ScheduledEvent;
    currentUser: User;
    onRsvp: (eventId: number, status: 'going' | 'maybe' | 'not-going') => void;
    onInvite: () => void;
    onEdit: (event: ScheduledEvent) => void;
    onCancel: () => void;
    onStartParty: (event: ScheduledEvent) => void;
}

// Helper to format date for .ics file (YYYYMMDDTHHMMSSZ)
const toICSDate = (date: Date) => {
    return date.toISOString().replace(/-|:|\.\d+/g, '');
}

const generateICS = (event: ScheduledEvent) => {
    const startTime = toICSDate(event.scheduledTime);
    // Assuming a 2-hour duration for events
    const endTime = toICSDate(new Date(event.scheduledTime.getTime() + 2 * 60 * 60 * 1000));

    const icsContent = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//SyncWatch//Event//EN',
        'BEGIN:VEVENT',
        `UID:${event.id}@syncwatch.app`,
        `DTSTAMP:${toICSDate(new Date())}`,
        `DTSTART:${startTime}`,
        `DTEND:${endTime}`,
        `SUMMARY:${event.title}`,
        `DESCRIPTION:${event.description || ''}\\nVideo URL: ${event.videoUrl}`,
        'END:VEVENT',
        'END:VCALENDAR'
    ].join('\r\n');

    return icsContent;
};

const EventDetailsContent: React.FC<EventDetailsContentProps> = ({ event, currentUser, onRsvp, onInvite, onEdit, onCancel, onStartParty }) => {
    const [copyButtonText, setCopyButtonText] = useState('Copy Link');

    const { going, maybe, notGoing, invited } = useMemo(() => {
        const allInvited = [event.createdBy, ...event.invitedUsers];
        const rsvpMap = new Map(event.rsvps?.map(r => [r.userId, r.status]));
        
        const going = allInvited.filter(u => rsvpMap.get(u.id) === 'going');
        const maybe = allInvited.filter(u => rsvpMap.get(u.id) === 'maybe');
        const notGoing = allInvited.filter(u => rsvpMap.get(u.id) === 'not-going');
        const invited = allInvited.filter(u => !rsvpMap.has(u.id));

        return { going, maybe, notGoing, invited };
    }, [event.rsvps, event.invitedUsers, event.createdBy]);

    const currentUserRsvp = useMemo(() => 
        event.rsvps?.find(r => r.userId === currentUser.id)?.status, 
    [event.rsvps, currentUser.id]);

    const isCreator = event.createdBy.id === currentUser.id;

    const handleAddToCalendar = () => {
        const icsData = generateICS(event);
        const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${event.title.replace(/ /g, '_')}.ics`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleCopyLink = () => {
        const eventUrl = `${window.location.origin}?eventId=${event.id}`;
        navigator.clipboard.writeText(eventUrl).then(() => {
            setCopyButtonText('Copied!');
            setTimeout(() => setCopyButtonText('Copy Link'), 2000);
        });
    };
    
    return (
        <>
            <div className="p-6 space-y-4 overflow-y-auto hide-scrollbar flex-1">
                {event.description && <p className="text-gray-300">{event.description}</p>}

                <div className="flex flex-col sm:flex-row gap-4 text-sm text-gray-300">
                    <div className="flex items-center gap-2">
                        <span style={{ color: 'var(--theme-color)' }}><CalendarIcon className="w-5 h-5" /></span> 
                        {event.scheduledTime.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
                    </div>
                    <div className="flex items-center gap-2">
                        <span style={{ color: 'var(--theme-color)' }}><ClockIcon className="w-5 h-5" /></span> 
                        {event.scheduledTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                </div>
                
                <div className="flex items-center gap-2">
                    <p className="text-sm text-gray-400">Created by:</p>
                    <img src={event.createdBy.avatar} alt={event.createdBy.name} className="w-6 h-6 rounded-full" />
                    <span className="font-semibold">{event.createdBy.name}</span>
                </div>

                <div className="pt-2">
                    <h3 className="font-semibold mb-2">Are you going?</h3>
                    <div className="flex flex-col sm:flex-row gap-2">
                        <RsvpButton label="Going" count={going.length} icon={<CheckIcon className="w-4 h-4"/>} active={currentUserRsvp === 'going'} onClick={() => onRsvp(event.id, 'going')} />
                        <RsvpButton label="Maybe" count={maybe.length} icon={<QuestionMarkCircleIcon className="w-4 h-4"/>} active={currentUserRsvp === 'maybe'} onClick={() => onRsvp(event.id, 'maybe')} />
                        <RsvpButton label="Not Going" count={notGoing.length} icon={<XIcon className="w-4 h-4"/>} active={currentUserRsvp === 'not-going'} onClick={() => onRsvp(event.id, 'not-going')} />
                    </div>
                </div>

                <div className="pt-2">
                    <h3 className="font-semibold mb-2">Guests ({going.length + maybe.length + invited.length})</h3>
                    <div className="space-y-3">
                        {going.length > 0 && <GuestList category="Going" users={going} />}
                        {maybe.length > 0 && <GuestList category="Maybe" users={maybe} />}
                        {invited.length > 0 && <GuestList category="Invited" users={invited} />}
                    </div>
                </div>
            </div>

            <div className="p-4 border-t border-white/10 flex flex-wrap gap-2 justify-end">
                <button onClick={handleCopyLink} className="action-button bg-white/10 hover:bg-white/20"><LinkIcon className="w-5 h-5 sm:mr-2"/> <span className="hidden sm:inline">{copyButtonText}</span></button>
                <button onClick={handleAddToCalendar} className="action-button bg-white/10 hover:bg-white/20"><ShareIcon className="w-5 h-5 sm:mr-2"/> <span className="hidden sm:inline">Add to Calendar</span></button>
                <button onClick={onInvite} className="action-button bg-white/10 hover:bg-white/20"><UserAddIcon className="w-5 h-5 sm:mr-2"/> <span className="hidden sm:inline">Invite</span></button>
                {isCreator && <>
                    <button onClick={() => onEdit(event)} className="action-button bg-white/10 hover:bg-white/20"><EditIcon className="w-5 h-5 sm:mr-2"/> <span className="hidden sm:inline">Edit</span></button>
                    <button onClick={onCancel} className="action-button bg-red-500/80 hover:bg-red-500"><TrashIcon className="w-5 h-5 sm:mr-2"/> <span className="hidden sm:inline">Cancel</span></button>
                </>}
                <button 
                    onClick={() => onStartParty(event)} 
                    className="action-button text-white hover:opacity-90"
                    style={{ background: 'linear-gradient(to right, var(--theme-color), color-mix(in srgb, var(--theme-color), #4f46e5 50%))' }}
                >
                    <PlayIcon className="w-5 h-5 sm:mr-2"/> <span className="hidden sm:inline">Start Party</span>
                </button>
            </div>
            <style>{`.action-button { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem; sm:padding: 0.5rem 1rem; font-size: 0.875rem; font-weight: 600; border-radius: 0.5rem; transition: all 0.2s; } @media (min-width: 640px) { .action-button { padding: 0.5rem 1rem; } }`}</style>
        </>
    );
};

const RsvpButton: React.FC<{label: string, count: number, icon: React.ReactNode, active: boolean, onClick: () => void}> = ({ label, count, icon, active, onClick }) => (
    <button 
        onClick={onClick} 
        className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all ${active ? 'bg-white/10 border-[var(--theme-color)] text-[var(--theme-color)]' : 'bg-white/5 border-transparent hover:border-white/20'}`}
        style={active ? { borderColor: 'var(--theme-color)', color: 'var(--theme-color)', backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 90%)' } : {}}
    >
        {icon}
        <span className="font-semibold text-sm">{label}</span>
        <span className="text-xs bg-black/30 px-1.5 py-0.5 rounded-full text-white">{count}</span>
    </button>
);

const GuestList: React.FC<{ category: string, users: User[] }> = ({ category, users }) => (
    <div>
        <p className="text-xs font-bold uppercase text-gray-400">{category}</p>
        <div className="flex flex-wrap gap-2 mt-1">
            {users.map(user => (
                <div key={user.id} className="flex items-center gap-2 p-1.5 pr-3 bg-white/10 rounded-full" title={user.name}>
                    <img src={user.avatar} alt={user.name} className="w-7 h-7 rounded-full"/>
                    <span className="text-sm font-medium">{user.name}</span>
                </div>
            ))}
        </div>
    </div>
);

export default EventDetailsContent;
