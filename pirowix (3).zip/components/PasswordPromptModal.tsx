import React, { useState } from 'react';
import { CloseIcon } from './icons';

interface PasswordPromptModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (password: string) => void;
    roomName: string;
}

const PasswordPromptModal: React.FC<PasswordPromptModalProps> = ({ isOpen, onClose, onSubmit, roomName }) => {
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(password);
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={onClose}
        >
            <div 
                className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl p-8 space-y-6 w-full max-w-sm"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">Enter Password</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <p className="text-gray-300">The room "{roomName}" is private. Please enter the password to join.</p>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="room-password" className="text-sm font-medium text-gray-300 sr-only">Password</label>
                        <input
                            id="room-password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="appearance-none rounded-lg relative block w-full px-4 py-3 bg-black/30 border border-white/20 placeholder-gray-400 text-white focus:outline-none focus:ring-2 focus:ring-[#6C5DD3] sm:text-sm"
                            placeholder="Room Password"
                            autoFocus
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full flex justify-center py-3 px-4 text-sm font-semibold rounded-lg text-white bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] hover:bg-gradient-to-l transition-all duration-300 transform active:scale-95"
                    >
                        Join Room
                    </button>
                </form>
            </div>
        </div>
    );
};

export default PasswordPromptModal;
