
import React, { useState, useRef, useEffect } from 'react';
import type { User } from '../types';
import { 
    SettingsIcon, PlusCircleIcon, PlanetIcon, FilmReelIcon, 
    VoiceWaveIcon, RadarIcon, UserGroupIcon, CalendarStarIcon, 
    MagicPhotoIcon, ClapperboardIcon, ChevronRightIcon, LogoutIcon, VerifiedIcon
} from './icons';

type Page = 'dashboard' | 'settings' | 'explore' | 'friends' | 'schedule' | 'voice-clubhouse' | 'image-studio' | 'video-studio' | 'people-nearby';

interface SidebarProps {
    user: User;
    onLogout: () => void;
    isVisible: boolean;
    activePage: Page;
    onNavigate: (page: Page) => void;
    totalUnreadCount: number;
    onClose: () => void;
}

const NavItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void; badgeCount?: number; isCollapsed?: boolean }> = ({ icon, label, active, onClick, badgeCount, isCollapsed }) => (
    <a
        href="#"
        onClick={(e) => { e.preventDefault(); onClick?.(); }}
        className={`
            flex items-center 
            ${isCollapsed ? 'md:justify-center md:px-2' : 'md:px-4'} 
            px-4 py-3 rounded-xl transition-all duration-200 ease-out group relative
            ${active 
                ? 'bg-white/10 text-white shadow-lg backdrop-blur-md border border-white/10' 
                : 'text-gray-400 hover:text-gray-100 hover:bg-white/5 active:scale-95'
            }
        `}
    >
        <div className={`flex-shrink-0 transition-all duration-300 relative z-10 ${isCollapsed ? 'md:mr-0' : 'md:mr-3'} mr-3 ${active ? 'text-[var(--theme-color)]' : 'group-hover:text-white'}`}>
            {icon}
        </div>
        
        <span className={`
            font-medium truncate transition-all duration-300 ease-in-out relative z-10
            ${isCollapsed ? 'md:w-0 md:opacity-0 md:overflow-hidden' : 'md:w-auto md:opacity-100'}
        `}>
            {label}
        </span>
        
        {active && !isCollapsed && (
             <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[var(--theme-color)] rounded-r-full shadow-[0_0_10px_var(--theme-color)] hidden md:block"></div>
        )}

        {(badgeCount || 0) > 0 && (
            <>
                {/* Full Badge (Mobile & Desktop Expanded) */}
                <span className={`
                    ml-auto bg-[var(--theme-color)] text-white text-[10px] font-bold rounded-full h-5 min-w-[1.25rem] px-1 flex items-center justify-center transition-all duration-300 shadow-lg
                    ${isCollapsed ? 'md:hidden' : ''}
                `}>
                    {badgeCount! > 99 ? '99+' : badgeCount}
                </span>

                {/* Dot Badge (Desktop Collapsed only) */}
                <span className={`
                    absolute top-2 right-2 w-2.5 h-2.5 bg-[var(--theme-color)] rounded-full border-2 border-[#121214]
                    hidden ${isCollapsed ? 'md:block' : ''}
                `}></span>
            </>
        )}

        {/* Tooltip for collapsed state (Desktop Only) */}
        <div className={`
            absolute left-full top-1/2 -translate-y-1/2 ml-4 px-3 py-2 bg-[#18181b]/90 backdrop-blur-xl text-white text-xs font-semibold rounded-xl opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-white/10 shadow-xl transition-all duration-200 translate-x-2 group-hover:translate-x-0
            hidden ${isCollapsed ? 'md:block' : ''}
        `}>
            {label}
            {/* Triangle Tip */}
            <div className="absolute right-full top-1/2 -translate-y-1/2 border-8 border-transparent border-r-[#18181b]/90"></div>
        </div>
    </a>
);

const UserProfileSection: React.FC<{ user: User; onNavigate: (page: Page) => void; isCollapsed?: boolean; onExpand?: () => void; }> = ({ user, onNavigate, isCollapsed, onExpand }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const menuRef = useRef<HTMLDivElement>(null);
    const buttonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        const handleOnline = () => setIsOnline(true);
        const handleOffline = () => setIsOnline(false);
        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);
        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node) && buttonRef.current && !buttonRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleProfileClick = () => {
        // If collapsed on desktop, expand sidebar first
        if (isCollapsed && window.innerWidth >= 768 && onExpand) {
            onExpand(); 
            setIsOpen(true);
        } else {
            setIsOpen(!isOpen);
        }
    };

    return (
        <div className={`mt-auto p-4 border-t border-white/5 relative transition-all duration-300 ${isCollapsed ? 'md:flex md:justify-center md:px-2' : ''}`}>
            {isOpen && (
                <div ref={menuRef} className="absolute bottom-[calc(100%+12px)] left-4 right-4 bg-[#18181b]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up z-50 w-56 ring-1 ring-black/50">
                    {/* Account Switcher Header */}
                    <div className="p-3 bg-white/5 border-b border-white/5">
                        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2 px-2">Account</p>
                        <div className="space-y-1">
                            <button className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors text-gray-400 hover:text-white">
                                <div className="w-8 h-8 rounded-full border-2 border-dashed border-gray-600 flex items-center justify-center">
                                    <PlusCircleIcon className="w-4 h-4" />
                                </div>
                                <span className="text-xs font-bold">Add Account</span>
                            </button>
                        </div>
                    </div>

                    {/* Settings Link */}
                    <div className="p-2">
                        <button 
                            onClick={() => { setIsOpen(false); onNavigate('settings'); }} 
                            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-gray-300 hover:text-white transition-colors"
                        >
                            <SettingsIcon className="w-5 h-5" />
                            <span className="font-bold text-sm">Settings</span>
                        </button>
                    </div>
                </div>
            )}

            {/* Main User Button */}
            <button 
                ref={buttonRef}
                onClick={handleProfileClick} 
                className={`flex items-center gap-3 rounded-2xl transition-all duration-300 group ${isOpen ? 'bg-white/10' : 'hover:bg-white/5'} ${isCollapsed ? 'md:p-0 md:justify-center md:w-10 md:h-10 w-full p-2' : 'w-full p-2'}`}
                title={user.name}
            >
                <div className="relative flex-shrink-0">
                    <img src={user.avatar} className="w-10 h-10 rounded-full object-cover ring-2 ring-transparent group-hover:ring-white/10 transition-all" />
                    <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[#0f0f0f] ${isOnline ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                </div>
                
                <div className={`flex-1 text-left min-w-0 overflow-hidden transition-all duration-300 ${isCollapsed ? 'md:w-0 md:opacity-0 md:hidden' : 'opacity-100'}`}>
                    <p className="font-bold text-sm text-white truncate flex items-center gap-1">
                        {user.name}
                        {user.isVerified && <VerifiedIcon className="w-3.5 h-3.5 text-blue-400" />}
                    </p>
                    <p className="text-xs text-gray-400 truncate flex items-center gap-1">
                        {isOnline ? 'Online' : 'Offline'}
                    </p>
                </div>
                <div className={`text-gray-500 group-hover:text-white transition-colors ${isCollapsed ? 'md:hidden' : ''}`}>
                    <SettingsIcon className="w-5 h-5" />
                </div>
            </button>
        </div>
    );
};

const Sidebar: React.FC<SidebarProps> = ({ user, onLogout, isVisible, activePage, onNavigate, totalUnreadCount, onClose }) => {
    const [isCollapsed, setIsCollapsed] = useState(false);

    // Auto-collapse on smaller desktop screens
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 768 && window.innerWidth < 1280) {
                setIsCollapsed(true);
            } else if (window.innerWidth >= 1280) {
                setIsCollapsed(false);
            }
        };
        
        // Initial check
        handleResize();

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    return (
        <>
            {/* Mobile Backdrop */}
            <div 
                className={`
                    fixed inset-0 bg-black/60 backdrop-blur-sm z-[50] md:hidden transition-opacity duration-300
                    ${isVisible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}
                `}
                onClick={onClose}
                aria-hidden="true"
            />
            
            <aside 
                className={`
                    fixed inset-y-0 left-0 z-[60] md:static
                    bg-black/30 backdrop-blur-2xl border-r border-white/5 text-white h-full flex flex-col 
                    transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1)
                    ${isVisible ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 
                    w-72 md:w-auto
                    ${isCollapsed ? 'md:w-[88px]' : 'md:w-72'}
                    flex-shrink-0 shadow-2xl md:shadow-none
                `}
            >
                {/* Logo Area */}
                <div className={`flex items-center h-20 flex-shrink-0 transition-all duration-300 px-6 ${isCollapsed ? 'md:justify-center md:px-0' : ''}`}>
                    <div className="flex items-center gap-3 overflow-hidden">
                        <div className="w-10 h-10 rounded-xl bg-[var(--theme-color)] flex items-center justify-center shadow-lg flex-shrink-0">
                            <span className="font-bold text-white text-lg">P</span>
                        </div>
                        {/* Always show text on mobile/expanded, only hide on desktop collapse */}
                        <span className={`text-xl font-bold tracking-tight whitespace-nowrap transition-all duration-300 w-auto opacity-100 ${isCollapsed ? 'md:w-0 md:opacity-0 md:overflow-hidden' : ''}`}>
                            Pirowix
                        </span>
                    </div>
                </div>
                
                {/* Navigation */}
                <div className="flex-1 flex flex-col min-h-0 px-3 space-y-0.5 overflow-y-auto hide-scrollbar">
                    <div className={`px-4 pt-2 pb-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest transition-opacity duration-300 ${isCollapsed ? 'md:hidden' : 'block'}`}>Menu</div>
                    
                    <NavItem icon={<PlanetIcon className="w-5 h-5" />} label="Explore" active={activePage === 'explore'} onClick={() => onNavigate('explore')} isCollapsed={isCollapsed} />
                    <NavItem icon={<FilmReelIcon className="w-5 h-5" />} label="Watch Party" active={activePage === 'dashboard'} onClick={() => onNavigate('dashboard')} isCollapsed={isCollapsed} />
                    <NavItem icon={<VoiceWaveIcon className="w-5 h-5" />} label="Voice Chat" active={activePage === 'voice-clubhouse'} onClick={() => onNavigate('voice-clubhouse')} isCollapsed={isCollapsed} />
                    <NavItem icon={<RadarIcon className="w-5 h-5" />} label="Nearby" active={activePage === 'people-nearby'} onClick={() => onNavigate('people-nearby')} isCollapsed={isCollapsed} />
                    
                    <div className={`px-4 pt-4 pb-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest transition-opacity duration-300 ${isCollapsed ? 'md:hidden' : 'block'}`}>Social</div>
                    {isCollapsed && <div className="hidden md:block h-4"></div>}

                    <NavItem 
                        icon={<UserGroupIcon className="w-5 h-5" />} 
                        label="Friends" 
                        active={activePage === 'friends'} 
                        onClick={() => onNavigate('friends')}
                        badgeCount={totalUnreadCount} 
                        isCollapsed={isCollapsed}
                    />
                    
                    <div className={`px-4 pt-4 pb-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest transition-opacity duration-300 ${isCollapsed ? 'md:hidden' : 'block'}`}>Tools</div>
                    {isCollapsed && <div className="hidden md:block h-4"></div>}

                    <NavItem icon={<CalendarStarIcon className="w-5 h-5" />} label="Schedule" active={activePage === 'schedule'} onClick={() => onNavigate('schedule')} isCollapsed={isCollapsed} />
                    <NavItem icon={<MagicPhotoIcon className="w-5 h-5" />} label="Image Studio" active={activePage === 'image-studio'} onClick={() => onNavigate('image-studio')} isCollapsed={isCollapsed} />
                    <NavItem icon={<ClapperboardIcon className="w-5 h-5" />} label="Video Studio" active={activePage === 'video-studio'} onClick={() => onNavigate('video-studio')} isCollapsed={isCollapsed} />
                </div>

                {/* Collapse Button (Desktop Only) */}
                <div className="hidden md:flex justify-center p-4">
                    <button 
                        onClick={() => setIsCollapsed(!isCollapsed)} 
                        className={`
                            w-full py-2 flex items-center justify-center rounded-xl 
                            bg-white/5 hover:bg-[var(--theme-color)] hover:bg-opacity-20 text-gray-400 hover:text-[var(--theme-color)]
                            border border-white/5 hover:border-[var(--theme-color)] hover:border-opacity-40
                            transition-all duration-300 group
                            ${isCollapsed ? 'h-10 w-10 p-0' : ''}
                        `}
                        title={isCollapsed ? "Expand" : "Collapse"}
                    >
                        <ChevronRightIcon className={`w-5 h-5 transition-transform duration-300 ${isCollapsed ? 'rotate-0' : 'rotate-180'}`} />
                    </button>
                </div>

                {/* Advanced User Profile Section */}
                <UserProfileSection user={user} onNavigate={onNavigate} isCollapsed={isCollapsed} onExpand={() => setIsCollapsed(false)} />
            </aside>
        </>
    );
};

export default Sidebar;