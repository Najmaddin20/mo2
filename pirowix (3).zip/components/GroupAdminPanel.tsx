
import React, { useState, useRef } from 'react';
import type { Conversation, User } from '../types';
import { EditIcon, TrashIcon, LinkIcon, PublicIcon, PrivateIcon, CopyIcon, BlockUserIcon, CheckIcon } from './icons';

interface GroupAdminPanelProps {
    conversation: Conversation;
    onUpdateGroup: (updates: Partial<Conversation>) => void;
    onDeleteGroup: () => void;
    onUnbanUser: (userId: number) => void;
}

const THEME_COLORS = [
    { id: 'purple', hex: '#8A79F7', gradient: 'from-purple-600 to-indigo-600' },
    { id: 'blue', hex: '#3B82F6', gradient: 'from-blue-500 to-cyan-500' },
    { id: 'green', hex: '#10B981', gradient: 'from-emerald-500 to-teal-500' },
    { id: 'red', hex: '#EF4444', gradient: 'from-red-500 to-orange-500' },
    { id: 'pink', hex: '#EC4899', gradient: 'from-pink-500 to-rose-500' },
    { id: 'gold', hex: '#F59E0B', gradient: 'from-amber-500 to-yellow-600' },
];

const GroupAdminPanel: React.FC<GroupAdminPanelProps> = ({ conversation, onUpdateGroup, onDeleteGroup, onUnbanUser }) => {
    const [name, setName] = useState(conversation.friend.name);
    const [desc, setDesc] = useState(conversation.description || '');
    const [isPublic, setIsPublic] = useState(conversation.isPublic || false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            onUpdateGroup({ friend: { ...conversation.friend, avatar: url } });
        }
    };

    const handleSaveInfo = () => {
        onUpdateGroup({
            friend: { ...conversation.friend, name },
            description: desc,
            isPublic
        });
    };
    
    const generateLink = () => {
        const link = `https://syncwatch.app/join/${Math.random().toString(36).substring(7)}`;
        onUpdateGroup({ inviteLink: link });
    };

    const revokeLink = () => {
        onUpdateGroup({ inviteLink: undefined });
    };

    return (
        <div className="flex flex-col h-full bg-[#121214] overflow-y-auto p-6 space-y-8 pb-20">
            
            {/* General Info Section */}
            <section className="space-y-4">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">General Information</h3>
                <div className="flex items-center gap-4">
                    <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                        <img src={conversation.friend.avatar} className="w-20 h-20 rounded-full object-cover border-2 border-white/10 group-hover:opacity-50 transition-opacity" />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100">
                            <EditIcon className="w-6 h-6 text-white" />
                        </div>
                        <input type="file" ref={fileInputRef} className="hidden" onChange={handleAvatarChange} accept="image/*" />
                    </div>
                    <div className="flex-1 space-y-2">
                        <input 
                            value={name} 
                            onChange={e => setName(e.target.value)} 
                            className="w-full bg-[#27272a] border border-white/10 rounded-lg px-3 py-2 text-white focus:border-purple-500 outline-none"
                            placeholder="Group Name"
                        />
                    </div>
                </div>
                <textarea 
                    value={desc} 
                    onChange={e => setDesc(e.target.value)} 
                    className="w-full bg-[#27272a] border border-white/10 rounded-lg px-3 py-2 text-white focus:border-purple-500 outline-none resize-none h-24"
                    placeholder="Description..."
                />
                <button onClick={handleSaveInfo} className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-sm font-bold transition-colors">
                    Save Info
                </button>
            </section>

            {/* Theme Section */}
            <section className="space-y-4">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Appearance</h3>
                <div className="grid grid-cols-6 gap-2">
                    {THEME_COLORS.map(theme => (
                        <button 
                            key={theme.id} 
                            onClick={() => onUpdateGroup({ theme: theme.hex })}
                            className={`w-10 h-10 rounded-full bg-gradient-to-br ${theme.gradient} flex items-center justify-center ring-2 ring-offset-2 ring-offset-[#121214] transition-all ${conversation.theme === theme.hex ? 'ring-white scale-110' : 'ring-transparent'}`}
                        >
                            {conversation.theme === theme.hex && <CheckIcon className="w-4 h-4 text-white" />}
                        </button>
                    ))}
                </div>
            </section>

            {/* Privacy & Links */}
            <section className="space-y-4">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Privacy & Links</h3>
                
                <div className="flex bg-[#27272a] p-1 rounded-lg">
                    <button onClick={() => setIsPublic(true)} className={`flex-1 py-2 rounded-md text-sm font-bold transition-colors flex items-center justify-center gap-2 ${isPublic ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}>
                        <PublicIcon className="w-4 h-4" /> Public
                    </button>
                    <button onClick={() => setIsPublic(false)} className={`flex-1 py-2 rounded-md text-sm font-bold transition-colors flex items-center justify-center gap-2 ${!isPublic ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}>
                        <PrivateIcon className="w-4 h-4" /> Private
                    </button>
                </div>

                <div className="bg-[#27272a] border border-white/10 rounded-xl p-4">
                    <div className="flex justify-between items-center mb-2">
                        <span className="font-bold text-white flex items-center gap-2"><LinkIcon className="w-4 h-4" /> Invite Link</span>
                        {conversation.inviteLink && <button onClick={revokeLink} className="text-xs text-red-400 hover:underline">Revoke</button>}
                    </div>
                    
                    {conversation.inviteLink ? (
                        <div className="flex gap-2">
                            <input readOnly value={conversation.inviteLink} className="flex-1 bg-black/30 rounded px-2 py-1 text-sm text-gray-300" />
                            <button onClick={() => navigator.clipboard.writeText(conversation.inviteLink || '')} className="p-1.5 bg-white/10 rounded hover:bg-white/20"><CopyIcon className="w-4 h-4" /></button>
                        </div>
                    ) : (
                        <button onClick={generateLink} className="text-sm text-blue-400 hover:underline">Generate Invite Link</button>
                    )}
                </div>
            </section>

            {/* Banned Users */}
            <section className="space-y-4">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">Banned Users</h3>
                <div className="bg-[#27272a] border border-white/10 rounded-xl overflow-hidden">
                    {(conversation.bannedUsers || []).length === 0 ? (
                        <p className="p-4 text-sm text-gray-500 text-center">No banned users.</p>
                    ) : (
                        <div className="divide-y divide-white/5">
                            {(conversation.bannedUsers || []).map(user => (
                                <div key={user.id} className="p-3 flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <img src={user.avatar} className="w-8 h-8 rounded-full grayscale" />
                                        <span className="text-sm font-medium text-gray-300">{user.name}</span>
                                    </div>
                                    <button onClick={() => onUnbanUser(user.id)} className="text-xs bg-green-500/10 text-green-400 px-2 py-1 rounded hover:bg-green-500/20">Unban</button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </section>

            {/* Danger Zone */}
            <section className="pt-4 border-t border-white/10">
                <button onClick={onDeleteGroup} className="w-full py-3 bg-red-500/10 border border-red-500/20 text-red-500 font-bold rounded-xl hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2">
                    <TrashIcon className="w-5 h-5" /> Delete Group
                </button>
            </section>
        </div>
    );
};

export default GroupAdminPanel;
