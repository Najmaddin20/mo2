import React, { useState } from 'react';
import type { SuggestedVideo } from '../types';
import { PlusIcon, YouTubeIcon, VimeoIcon } from './icons';

interface VideoSuggestionsProps {
  suggestions: SuggestedVideo[];
  onAddToQueue: (video: SuggestedVideo) => void;
}

const platforms = [{ name: 'YouTube', icon: <YouTubeIcon className="w-5 h-5"/> }, { name: 'Vimeo', icon: <VimeoIcon className="w-4 h-4"/> }];

const VideoSuggestions: React.FC<VideoSuggestionsProps> = ({ suggestions, onAddToQueue }) => {
  const [activePlatform, setActivePlatform] = useState('YouTube');

  return (
    <div className="flex flex-col h-full p-1">
      <h3 className="font-bold text-white mb-3 px-1">Suggestions</h3>
      
       <div className="flex items-center gap-2 mb-3 px-1">
        {platforms.map(p => (
            <button 
                key={p.name}
                onClick={() => setActivePlatform(p.name)}
                className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${activePlatform === p.name ? 'bg-white/20 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
            >
                {p.icon}
                {p.name}
            </button>
        ))}
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto pr-2 pb-4">
        {suggestions.map(video => (
          <div key={video.id} className="flex items-center gap-3 bg-white/5 p-2 rounded-lg">
            <img src={video.thumbnail} alt={video.title} className="w-24 h-14 object-cover rounded flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-white truncate">{video.title}</p>
              <p className="text-xs text-gray-400">{video.channel}</p>
            </div>
            <button
              onClick={() => onAddToQueue(video)}
              className="p-2 rounded-lg hover:bg-white/10 text-gray-300"
              title="Add to Queue"
            >
              <PlusIcon className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VideoSuggestions;