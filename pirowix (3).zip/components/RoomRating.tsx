
import React, { useState } from 'react';
import { StarIcon } from './icons';

interface RoomRatingProps {
    rating?: number;
    totalRatings?: number;
    interactive?: boolean;
    onRate?: (rating: number) => void;
    size?: 'sm' | 'md' | 'lg';
}

const RoomRating: React.FC<RoomRatingProps> = ({ rating = 0, totalRatings, interactive = false, onRate, size = 'md' }) => {
    const [hoverRating, setHoverRating] = useState(0);
    const [currentRating, setCurrentRating] = useState(0);

    const handleRate = (rate: number) => {
        if (!interactive) return;
        setCurrentRating(rate);
        onRate?.(rate);
    }

    const starSize = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-8 h-8' : 'w-5 h-5';
    
    if (interactive) {
        return (
            <div className="flex flex-col items-center gap-2">
                <div className="flex items-center gap-1" onMouseLeave={() => setHoverRating(0)}>
                    {[1, 2, 3, 4, 5].map(star => (
                        <button 
                            key={star} 
                            onClick={() => handleRate(star)}
                            onMouseEnter={() => setHoverRating(star)}
                            className="transition-transform hover:scale-110 active:scale-95 p-1"
                        >
                            <StarIcon 
                                className={`${size === 'lg' ? 'w-8 h-8' : 'w-6 h-6'} transition-colors duration-200 ${ (hoverRating || currentRating) >= star ? 'text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]' : 'text-white/20'}`} 
                                filled={(hoverRating || currentRating) >= star}
                            />
                        </button>
                    ))}
                </div>
                <span className="text-xs font-medium text-gray-400">
                    {hoverRating ? ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'][hoverRating - 1] : 'Tap to rate'}
                </span>
            </div>
        )
    }

    return (
        <div className="flex items-center bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/5 shadow-sm">
            <StarIcon className={`${starSize} text-yellow-400 mr-1.5`} filled />
            <span className="text-sm font-bold text-white">{rating.toFixed(1)}</span>
            {totalRatings && <span className="text-[10px] text-gray-400 ml-1.5 font-medium uppercase tracking-wider">{totalRatings} votes</span>}
        </div>
    );
};

export default RoomRating;
