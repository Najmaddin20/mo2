
import React, { useState, useMemo, useEffect } from 'react';
import type { ScheduledEvent, User, Friend } from '../types';
import { 
    CalendarIcon, ChevronLeftIcon, ChevronRightIcon, QuestionMarkCircleIcon, 
    CheckIcon, ListBulletIcon, CalendarDaysIcon, PlusIcon, ClockIcon, 
    SearchIcon, XIcon, UserAddIcon, PlayIcon, TicketIcon 
} from './icons';
import ScheduleRoomModal from './ScheduleRoomModal';
import EventDetailsModal from './EventDetailsModal';
import ForwardMessageModal from './ForwardMessageModal';
import ConfirmationModal from './ConfirmationModal';

interface SchedulePageProps {
    scheduledEvents: ScheduledEvent[];
    currentUser: User;
    friends: Friend[];
    onScheduleRoom: (newEventData: Omit<ScheduledEvent, 'id' | 'createdBy' | 'invitedUsers' | 'rsvps'>) => void;
    onUpdateEvent: (updatedEvent: ScheduledEvent) => void;
    onCancelEvent: (eventId: number) => void;
    onRsvp: (eventId: number, status: 'going' | 'maybe' | 'not-going') => void;
    onInviteFriends: (eventId: number, friendIds: number[]) => void;
    onStartParty: (event: ScheduledEvent) => void;
}

type ViewMode = 'month' | 'week' | 'list';
type FilterType = 'all' | 'hosting' | 'going' | 'pending';

// --- Helper Functions ---

const isSameDay = (d1: Date, d2: Date) => {
    return d1.getFullYear() === d2.getFullYear() &&
           d1.getMonth() === d2.getMonth() &&
           d1.getDate() === d2.getDate();
};

const getDaysInMonth = (year: number, month: number) => {
    const date = new Date(year, month, 1);
    const days = [];
    while (date.getMonth() === month) {
        days.push(new Date(date));
        date.setDate(date.getDate() + 1);
    }
    return days;
};

const getWeekDays = (current: Date) => {
    const start = new Date(current);
    start.setDate(start.getDate() - start.getDay()); // Start on Sunday
    const days = [];
    for (let i = 0; i < 7; i++) {
        days.push(new Date(start));
        start.setDate(start.getDate() + 1);
    }
    return days;
};

// --- Components ---

// NEW: Modern Ticket Card Design
const ModernTicketCard: React.FC<{ event: ScheduledEvent; currentUser: User; onClick: () => void }> = ({ event, currentUser, onClick }) => {
    const userRsvp = event.rsvps?.find(r => r.userId === currentUser.id)?.status;
    const isHost = event.createdBy.id === currentUser.id;
    
    const isStartingSoon = useMemo(() => {
        const now = new Date();
        const diff = event.scheduledTime.getTime() - now.getTime();
        return diff > 0 && diff < 1000 * 60 * 60; // Less than 1 hour
    }, [event.scheduledTime]);

    const day = event.scheduledTime.getDate();
    const month = event.scheduledTime.toLocaleDateString(undefined, { month: 'short' }).toUpperCase();
    const weekday = event.scheduledTime.toLocaleDateString(undefined, { weekday: 'long' });
    const time = event.scheduledTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    return (
        <div 
            onClick={onClick}
            className="group relative flex flex-col md:flex-row bg-[#18181b] border border-white/10 rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-2xl hover:shadow-purple-900/10 hover:border-[var(--theme-color)] hover:-translate-y-1 active:scale-[0.99]"
        >
            {/* Left: Date Block (Desktop) / Top Bar (Mobile) */}
            <div 
                className="hidden md:flex flex-col items-center justify-center p-6 bg-black/30 border-r border-white/5 min-w-[100px]"
                style={{ borderLeft: `4px solid var(--theme-color)` }}
            >
                <span className="text-sm font-bold text-[var(--theme-color)] tracking-widest">{month}</span>
                <span className="text-4xl font-black text-white">{day}</span>
                <span className="text-xs text-gray-500 uppercase mt-1">{weekday.substring(0, 3)}</span>
            </div>

            {/* Mobile Date Header */}
            <div className="md:hidden flex items-center justify-between px-4 py-2 bg-[#121214] border-b border-white/5">
                <div className="flex items-center gap-2 font-bold text-[var(--theme-color)]">
                    <CalendarIcon className="w-4 h-4" />
                    <span className="text-sm">{weekday}, {month} {day}</span>
                </div>
                {isStartingSoon && (
                    <span className="text-[10px] font-bold text-red-500 bg-red-500/10 px-2 py-0.5 rounded-full animate-pulse">Starting Soon</span>
                )}
            </div>

            {/* Center: Content & Thumbnail */}
            <div className="flex-1 relative p-4 md:p-5 flex flex-col justify-center z-10">
                {/* Background Image with fade */}
                <div className="absolute inset-0 z-0 opacity-20 group-hover:opacity-30 transition-opacity">
                    <img src={event.thumbnail} className="w-full h-full object-cover filter blur-xl grayscale mix-blend-screen" />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#18181b] via-[#18181b]/80 to-transparent"></div>
                </div>

                <div className="relative z-10 flex items-start gap-4">
                    {/* Thumbnail (Small) */}
                    <div className="w-20 h-20 md:w-28 md:h-16 rounded-xl overflow-hidden shadow-lg border border-white/10 flex-shrink-0 bg-black">
                        <img src={event.thumbnail} className="w-full h-full object-cover" />
                    </div>

                    <div className="flex-1 min-w-0">
                        <h3 className="text-lg md:text-xl font-bold text-white leading-tight mb-1 line-clamp-2 group-hover:text-[var(--theme-color)] transition-colors">{event.title}</h3>
                        
                        <div className="flex items-center gap-3 text-sm text-gray-400 mt-1">
                            <div className="flex items-center gap-1">
                                <ClockIcon className="w-4 h-4 text-[var(--theme-color)]" />
                                <span className="font-medium text-gray-300">{time}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                                <img src={event.createdBy.avatar} className="w-4 h-4 rounded-full border border-white/10" />
                                <span className="text-xs truncate max-w-[100px]">{event.createdBy.name}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right: Action / Status */}
            <div className="flex items-center justify-between md:justify-center p-4 md:p-6 md:border-l border-white/5 bg-white/[0.02] md:w-40">
                {/* Mobile only: RSVPs stack */}
                <div className="flex -space-x-2 md:hidden">
                    {(event.rsvps || []).filter(r => r.status === 'going').slice(0, 3).map((r, i) => (
                        <div key={i} className="w-6 h-6 rounded-full bg-gray-700 border border-[#18181b]" />
                    ))}
                </div>

                {isHost ? (
                    <span className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs font-bold text-white uppercase tracking-wide shadow-sm">
                        Hosting
                    </span>
                ) : userRsvp === 'going' ? (
                    <span className="px-4 py-2 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-xs font-bold uppercase tracking-wide shadow-sm flex items-center gap-1">
                        <CheckIcon className="w-3 h-3" /> Going
                    </span>
                ) : (
                    <button className="px-4 py-2 rounded-xl bg-[var(--theme-color)] text-white text-xs font-bold uppercase tracking-wide shadow-lg hover:brightness-110 transition-all active:scale-95">
                        Join
                    </button>
                )}
            </div>
        </div>
    );
};

const MonthCalendar: React.FC<{ 
    currentDate: Date; 
    events: ScheduledEvent[]; 
    selectedDate: Date | null;
    onSelectDate: (date: Date) => void; 
}> = ({ currentDate, events, selectedDate, onSelectDate }) => {
    const days = useMemo(() => getDaysInMonth(currentDate.getFullYear(), currentDate.getMonth()), [currentDate]);
    
    // Add padding days for start of month
    const startPadding = days[0].getDay();
    const paddedDays = Array(startPadding).fill(null).concat(days);

    return (
        <div className="bg-[#18181b] border border-white/10 rounded-3xl p-6 shadow-2xl animate-fade-in">
            <div className="grid grid-cols-7 gap-1 mb-4">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
                    <div key={d} className="text-center text-xs font-bold text-gray-500 uppercase">{d}</div>
                ))}
            </div>
            <div className="grid grid-cols-7 gap-2">
                {paddedDays.map((day, idx) => {
                    if (!day) return <div key={`pad-${idx}`} className="aspect-square"></div>;
                    
                    const dayEvents = events.filter(e => isSameDay(e.scheduledTime, day));
                    const isSelected = selectedDate && isSameDay(selectedDate, day);
                    const isToday = isSameDay(day, new Date());
                    const hasEvent = dayEvents.length > 0;

                    return (
                        <button
                            key={day.toISOString()}
                            onClick={() => onSelectDate(day)}
                            className={`
                                relative aspect-square rounded-2xl flex flex-col items-center justify-center transition-all duration-200 group
                                ${isSelected ? 'text-white shadow-lg scale-105 z-10' : 'bg-white/5 hover:bg-white/10 text-gray-300'}
                                ${isToday && !isSelected ? 'border border-[var(--theme-color)] text-[var(--theme-color)]' : 'border border-transparent'}
                            `}
                            style={{
                                backgroundColor: isSelected ? 'var(--theme-color)' : undefined,
                                boxShadow: isSelected ? '0 8px 20px -4px color-mix(in srgb, var(--theme-color), transparent 70%)' : undefined,
                            }}
                        >
                            <span className={`text-sm font-bold ${isToday || isSelected ? '' : 'opacity-80'}`}>{day.getDate()}</span>
                            
                            {hasEvent && (
                                <div className="flex gap-0.5 mt-1">
                                    {dayEvents.slice(0, 2).map((_, i) => (
                                        <div key={i} className={`w-1 h-1 rounded-full`} style={{ backgroundColor: isSelected ? 'white' : 'var(--theme-color)' }}></div>
                                    ))}
                                </div>
                            )}
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

const WeekStrip: React.FC<{ 
    currentDate: Date; 
    events: ScheduledEvent[]; 
    selectedDate: Date;
    onSelectDate: (date: Date) => void; 
}> = ({ currentDate, events, selectedDate, onSelectDate }) => {
    const days = useMemo(() => getWeekDays(currentDate), [currentDate]);

    return (
        <div className="flex justify-between gap-3 overflow-x-auto hide-scrollbar pb-2 animate-fade-in">
            {days.map((day) => {
                const isSelected = isSameDay(selectedDate, day);
                const isToday = isSameDay(day, new Date());
                const hasEvents = events.some(e => isSameDay(e.scheduledTime, day));

                return (
                    <button
                        key={day.toISOString()}
                        onClick={() => onSelectDate(day)}
                        className={`
                            flex-1 min-w-[60px] flex flex-col items-center justify-center py-3 rounded-2xl transition-all duration-200 border
                            ${isSelected 
                                ? 'text-white shadow-lg transform scale-105 border-transparent' 
                                : 'bg-[#18181b] text-gray-400 hover:bg-[#222] border-white/5'}
                        `}
                        style={{
                            backgroundColor: isSelected ? 'var(--theme-color)' : undefined,
                            borderColor: isToday && !isSelected ? 'var(--theme-color)' : undefined,
                            color: isToday && !isSelected ? 'var(--theme-color)' : undefined
                        }}
                    >
                        <span className="text-[10px] font-bold uppercase tracking-wider opacity-70">{day.toLocaleDateString(undefined, { weekday: 'short' })}</span>
                        <span className="text-lg font-black mt-0.5">{day.getDate()}</span>
                        <div className={`w-1.5 h-1.5 rounded-full mt-1 transition-opacity ${hasEvents ? 'opacity-100' : 'opacity-0'}`} style={{ backgroundColor: isSelected ? 'white' : 'var(--theme-color)' }}></div>
                    </button>
                );
            })}
        </div>
    );
};

const SchedulePage: React.FC<SchedulePageProps> = (props) => {
    const { scheduledEvents, currentUser, friends, onScheduleRoom, onUpdateEvent, onCancelEvent, onRsvp, onInviteFriends, onStartParty } = props;

    const [viewMode, setViewMode] = useState<ViewMode>('list');
    const [filter, setFilter] = useState<FilterType>('all');
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<Date>(new Date());
    const [searchQuery, setSearchQuery] = useState('');
    
    const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
    const [selectedEvent, setSelectedEvent] = useState<ScheduledEvent | null>(null);
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);

    // --- Data Filtering ---

    const filteredEvents = useMemo(() => {
        let filtered = scheduledEvents;

        // 1. Search Filter
        if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase();
            filtered = filtered.filter(e => e.title.toLowerCase().includes(q));
        }

        // 2. Category Filter
        switch (filter) {
            case 'hosting':
                filtered = filtered.filter(e => e.createdBy.id === currentUser.id);
                break;
            case 'going':
                filtered = filtered.filter(e => e.rsvps?.some(r => r.userId === currentUser.id && r.status === 'going'));
                break;
            case 'pending':
                filtered = filtered.filter(e => {
                    const myRsvp = e.rsvps?.find(r => r.userId === currentUser.id);
                    const isInvited = e.invitedUsers.some(u => u.id === currentUser.id);
                    return isInvited && (!myRsvp || myRsvp.status === 'maybe');
                });
                break;
        }

        return filtered.sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime());
    }, [scheduledEvents, searchQuery, filter, currentUser.id]);

    const eventsForDisplay = useMemo(() => {
        if (viewMode === 'list') return filteredEvents;
        // For Month/Week view, filter by selected date
        return filteredEvents.filter(e => isSameDay(e.scheduledTime, selectedDate));
    }, [filteredEvents, viewMode, selectedDate]);

    // --- Handlers ---

    const handleDateChange = (direction: number) => {
        const newDate = new Date(currentDate);
        if (viewMode === 'month') {
            newDate.setMonth(newDate.getMonth() + direction);
        } else {
            newDate.setDate(newDate.getDate() + (direction * 7));
        }
        setCurrentDate(newDate);
    };

    const handleInviteSubmit = (friendIds: number[], comment: string) => {
        if (selectedEvent) {
            onInviteFriends(selectedEvent.id, friendIds);
            // Check each selected friend ID and update the local selectedEvent state
            friendIds.forEach(friendId => {
                const friend = friends.find(f => f.id === friendId);
                if (friend && selectedEvent) {
                    // We update the state immediately so the user sees the change without reload
                    // But check if already present to avoid duplicates
                    if (!selectedEvent.invitedUsers.some(u => u.id === friendId)) {
                        setSelectedEvent(prev => prev ? {...prev, invitedUsers: [...prev.invitedUsers, friend]} : null);
                    }
                }
            });
        }
        setIsInviteModalOpen(false);
    };

    return (
        <div className="h-full flex flex-col bg-transparent text-white overflow-hidden">
            
            {/* Sticky Header */}
            <header className="flex-shrink-0 p-4 md:p-6 bg-[#0f0f0f]/80 border-b border-white/5 z-10 flex flex-col gap-6 sticky top-0 backdrop-blur-xl">
                {/* Top Bar: Title & Search */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <h1 className="text-3xl font-bold text-white tracking-tight">Schedule</h1>
                            <p className="text-gray-400 text-sm mt-0.5">Plan your next watch party.</p>
                        </div>
                        <button 
                            onClick={() => setIsScheduleModalOpen(true)}
                            className="md:hidden w-12 h-12 text-white rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform"
                            style={{ backgroundColor: 'var(--theme-color)' }}
                        >
                            <PlusIcon className="w-6 h-6"/>
                        </button>
                    </div>
                    
                    <div className="flex items-center gap-3 w-full md:w-auto">
                        <div className="relative flex-1 md:w-72 group">
                            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 group-focus-within:text-[var(--theme-color)] transition-colors"/>
                            <input 
                                type="text" 
                                placeholder="Search events..." 
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                                className="w-full bg-[#18181b] border border-white/10 rounded-2xl py-3 pl-11 pr-4 text-sm text-white focus:outline-none transition-colors placeholder-gray-500 shadow-inner"
                                style={{ caretColor: 'var(--theme-color)' }}
                                onFocus={(e) => e.target.style.borderColor = 'var(--theme-color)'}
                                onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
                            />
                        </div>
                        <button 
                            onClick={() => setIsScheduleModalOpen(true)}
                            className="hidden md:flex text-white px-5 py-3 rounded-2xl transition-all hover:opacity-90 font-bold text-sm items-center gap-2 shadow-lg"
                            style={{ backgroundColor: 'var(--theme-color)' }}
                        >
                            <PlusIcon className="w-5 h-5"/>
                            <span>New Event</span>
                        </button>
                    </div>
                </div>

                {/* Controls Bar: Date Nav & View Switcher */}
                <div className="flex flex-col sm:flex-row items-center gap-3 justify-between">
                    {/* Filter Tabs */}
                    <div className="flex gap-2 overflow-x-auto hide-scrollbar w-full sm:w-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
                        {[
                            { id: 'all', label: 'All Events' },
                            { id: 'hosting', label: 'Hosting' },
                            { id: 'going', label: 'Attending' },
                            { id: 'pending', label: 'Invites' },
                        ].map(f => (
                            <button
                                key={f.id}
                                onClick={() => setFilter(f.id as FilterType)}
                                className={`px-5 py-2 rounded-xl text-xs font-bold whitespace-nowrap border transition-all flex-shrink-0 ${filter === f.id ? 'bg-white text-black border-white shadow-md' : 'bg-transparent text-gray-400 border-white/10 hover:bg-white/5 hover:text-white'}`}
                            >
                                {f.label}
                            </button>
                        ))}
                    </div>

                    {/* Right Controls */}
                    <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                         {/* Date Nav (Hidden in List View) */}
                        {viewMode !== 'list' && (
                            <div className="flex items-center bg-[#18181b] p-1 rounded-xl border border-white/5">
                                <button onClick={() => handleDateChange(-1)} className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"><ChevronLeftIcon className="w-4 h-4"/></button>
                                <span className="font-bold text-sm min-w-[100px] text-center px-2">
                                    {viewMode === 'month' 
                                        ? currentDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })
                                        : 'This Week'
                                    }
                                </span>
                                <button onClick={() => handleDateChange(1)} className="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"><ChevronRightIcon className="w-4 h-4"/></button>
                            </div>
                        )}

                        {/* View Toggles */}
                        <div className="flex bg-[#18181b] p-1 rounded-xl border border-white/5">
                            {(['week', 'month', 'list'] as ViewMode[]).map(mode => (
                                <button
                                    key={mode}
                                    onClick={() => setViewMode(mode)}
                                    className={`px-3 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center gap-2 ${viewMode === mode ? 'text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
                                    style={{ backgroundColor: viewMode === mode ? 'var(--theme-color)' : undefined }}
                                >
                                    {mode === 'week' && <CalendarIcon className="w-4 h-4"/>}
                                    {mode === 'month' && <CalendarDaysIcon className="w-4 h-4"/>}
                                    {mode === 'list' && <ListBulletIcon className="w-4 h-4"/>}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content Area */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar">
                <div className="max-w-5xl mx-auto flex flex-col gap-8 pb-20">
                    
                    {viewMode === 'month' && (
                        <MonthCalendar 
                            currentDate={currentDate} 
                            events={filteredEvents} 
                            selectedDate={selectedDate}
                            onSelectDate={(d) => { setSelectedDate(d); setCurrentDate(d); }}
                        />
                    )}

                    {viewMode === 'week' && (
                        <WeekStrip 
                            currentDate={currentDate} 
                            events={filteredEvents}
                            selectedDate={selectedDate}
                            onSelectDate={(d) => { setSelectedDate(d); setCurrentDate(d); }}
                        />
                    )}

                    {/* List Header */}
                    {viewMode !== 'list' && (
                        <div className="flex items-center justify-between pb-2 border-b border-white/5">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                {isSameDay(selectedDate, new Date()) ? 'Today' : selectedDate.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
                            </h2>
                            <span className="text-xs font-bold text-gray-500 uppercase bg-white/5 px-2 py-1 rounded-md">{eventsForDisplay.length} Events</span>
                        </div>
                    )}

                    {/* Event List with New Design */}
                    <div className="space-y-4">
                        {eventsForDisplay.length > 0 ? (
                            eventsForDisplay.map(event => (
                                <ModernTicketCard 
                                    key={event.id}
                                    event={event} 
                                    currentUser={currentUser} 
                                    onClick={() => setSelectedEvent(event)}
                                />
                            ))
                        ) : (
                            <div className="flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-white/5 rounded-3xl bg-white/[0.02]">
                                <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4">
                                    <TicketIcon className="w-10 h-10 text-gray-600" />
                                </div>
                                <p className="text-gray-400 font-medium text-lg">No events scheduled.</p>
                                <p className="text-gray-600 text-sm mt-1">Pick a date to start planning.</p>
                                {filter === 'all' && viewMode !== 'list' && (
                                    <button 
                                        onClick={() => setIsScheduleModalOpen(true)}
                                        className="mt-6 px-6 py-2.5 rounded-xl text-sm font-bold text-white bg-[#18181b] hover:bg-[#222] transition-colors border border-white/10"
                                    >
                                        + Add Event
                                    </button>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Modals */}
            <ScheduleRoomModal 
                isOpen={isScheduleModalOpen} 
                onClose={() => setIsScheduleModalOpen(false)} 
                onScheduleRoom={(data) => {
                    onScheduleRoom({ ...data, scheduledTime: new Date(`${data.scheduledTime.toDateString()} ${data.scheduledTime.toTimeString().split(' ')[0]}`) }); 
                }} 
            />
            
            {selectedEvent && (
                <EventDetailsModal
                    isOpen={!!selectedEvent}
                    onClose={() => setSelectedEvent(null)}
                    event={selectedEvent}
                    currentUser={currentUser}
                    onRsvp={(status) => {
                        onRsvp(selectedEvent.id, status);
                        setSelectedEvent(prev => prev ? {
                            ...prev, 
                            rsvps: [...(prev.rsvps?.filter(r => r.userId !== currentUser.id) || []), {userId: currentUser.id, status}]
                        } : null);
                    }}
                    onInvite={() => setIsInviteModalOpen(true)}
                    onEdit={() => alert("Edit feature coming soon!")}
                    onCancel={() => setIsCancelConfirmOpen(true)}
                    onStartParty={onStartParty}
                />
            )}

            {isCancelConfirmOpen && selectedEvent && (
                <ConfirmationModal 
                    isOpen={isCancelConfirmOpen}
                    onClose={() => setIsCancelConfirmOpen(false)}
                    onConfirm={() => {
                        onCancelEvent(selectedEvent.id);
                        setIsCancelConfirmOpen(false);
                        setSelectedEvent(null);
                    }}
                    title="Cancel Event"
                    message={`Are you sure you want to cancel "${selectedEvent.title}"? This cannot be undone.`}
                    confirmText="Yes, Cancel"
                />
            )}

            {isInviteModalOpen && selectedEvent && (
                <ForwardMessageModal 
                    isOpen={isInviteModalOpen}
                    onClose={() => setIsInviteModalOpen(false)}
                    friends={friends.filter(f => ![...selectedEvent.invitedUsers.map(u => u.id), selectedEvent.createdBy.id].includes(f.id))}
                    onForward={handleInviteSubmit}
                    isSharingRoom
                    shareTitle={`Invite friends to "${selectedEvent.title}"`}
                />
            )}
        </div>
    );
};

export default SchedulePage;
