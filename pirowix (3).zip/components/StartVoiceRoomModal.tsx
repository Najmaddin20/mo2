
import React, { useState, useEffect, useRef } from 'react';
import { CloseIcon, WaveIcon, PublicIcon, PrivateIcon, ClockIcon, CheckIcon, MicrophoneIcon, HandIcon, SettingsIcon, UserIcon, XIcon } from './icons';
import type { User } from '../types';

interface StartVoiceRoomModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCreate: (settings: { topic: string; isPrivate: boolean; password?: string; timer?: number; tags?: string; theme?: string; openMicMode?: boolean; isRecording?: boolean }) => void;
    currentUser: User;
}

const THEMES = [
    { id: 'cosmic', name: 'Cosmic', gradient: 'from-indigo-900 via-purple-900 to-black', accent: 'text-purple-400', border: 'border-purple-500/30' },
    { id: 'sunset', name: 'Sunset', gradient: 'from-orange-900 via-red-900 to-black', accent: 'text-orange-400', border: 'border-orange-500/30' },
    { id: 'forest', name: 'Forest', gradient: 'from-green-900 via-teal-900 to-black', accent: 'text-green-400', border: 'border-green-500/30' },
    { id: 'ocean', name: 'Ocean', gradient: 'from-blue-900 via-cyan-900 to-black', accent: 'text-blue-400', border: 'border-blue-500/30' },
    { id: 'midnight', name: 'Midnight', gradient: 'from-slate-900 via-indigo-900 to-black', accent: 'text-indigo-400', border: 'border-indigo-500/30' },
    { id: 'rose', name: 'Rose', gradient: 'from-rose-900 via-pink-900 to-black', accent: 'text-pink-400', border: 'border-pink-500/30' },
    { id: 'amber', name: 'Amber', gradient: 'from-amber-900 via-yellow-900 to-black', accent: 'text-amber-400', border: 'border-amber-500/30' },
];

const StartVoiceRoomModal: React.FC<StartVoiceRoomModalProps> = ({ isOpen, onClose, onCreate, currentUser }) => {
    const [topic, setTopic] = useState('');
    const [isPrivate, setIsPrivate] = useState(false);
    const [password, setPassword] = useState('');
    const [timerMode, setTimerMode] = useState<'none' | 'custom'>('none');
    const [customMinutes, setCustomMinutes] = useState(15);
    
    // Tags State
    const [tagsList, setTagsList] = useState<string[]>([]);
    const [tagInput, setTagInput] = useState('');

    const [selectedTheme, setSelectedTheme] = useState(THEMES[0]);
    const [openMicMode, setOpenMicMode] = useState(false);
    const [autoRecord, setAutoRecord] = useState(false);

    // Reset state when opening
    useEffect(() => {
        if (isOpen) {
            setTopic('');
            setIsPrivate(false);
            setPassword('');
            setTimerMode('none');
            setTagsList([]);
            setTagInput('');
            setSelectedTheme(THEMES[0]);
            setOpenMicMode(false);
            setAutoRecord(false);
        }
    }, [isOpen]);

    const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const trimmed = tagInput.trim();
            if (trimmed && !tagsList.includes(trimmed)) {
                setTagsList([...tagsList, trimmed]);
                setTagInput('');
            }
        } else if (e.key === 'Backspace' && !tagInput && tagsList.length > 0) {
            setTagsList(tagsList.slice(0, -1));
        }
    };

    const removeTag = (tagToRemove: string) => {
        setTagsList(tagsList.filter(tag => tag !== tagToRemove));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (topic.trim()) {
            const finalTimer = timerMode === 'none' ? undefined : customMinutes;
            // If there is text in tagInput that hasn't been entered yet, add it
            const finalTags = [...tagsList];
            if (tagInput.trim() && !finalTags.includes(tagInput.trim())) {
                finalTags.push(tagInput.trim());
            }

            onCreate({
                topic: topic.trim(),
                isPrivate,
                password: isPrivate && password ? password : undefined,
                timer: finalTimer,
                tags: finalTags.join(','),
                theme: selectedTheme.id,
                openMicMode,
                isRecording: autoRecord
            });
            onClose();
        }
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[60] p-0 sm:p-4 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className="bg-[#121214] w-full h-full sm:h-auto sm:max-h-[90vh] sm:max-w-4xl sm:rounded-3xl shadow-2xl flex flex-col sm:flex-row overflow-hidden animate-slide-in-up border-0 sm:border border-white/10"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Mobile Header */}
                <div className="sm:hidden flex justify-between items-center p-4 border-b border-white/5 bg-[#121214] shrink-0 z-20">
                     <button onClick={onClose} className="text-gray-400 hover:text-white text-sm font-medium px-2 py-1">Cancel</button>
                     <h2 className="text-lg font-bold text-white">New Room</h2>
                     <div className="w-12"></div> {/* Spacer */}
                </div>

                {/* Left Side: Preview (Top on mobile, Left on desktop) */}
                <div className="relative w-full sm:w-1/3 bg-[#0a0a0a] p-4 sm:p-6 flex flex-col justify-center items-center border-b sm:border-b-0 sm:border-r border-white/5 shrink-0">
                    <div className="absolute inset-0 opacity-30 pointer-events-none">
                        <div className={`absolute inset-0 bg-gradient-to-br ${selectedTheme.gradient} opacity-50`}></div>
                    </div>
                    
                    <h3 className="relative z-10 text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4 sm:mb-6">Room Preview</h3>
                    
                    {/* Card Preview - Compact on mobile */}
                    <div className={`relative z-10 w-full max-w-[240px] sm:max-w-none aspect-[16/10] sm:aspect-[3/4] rounded-2xl sm:rounded-3xl bg-gradient-to-b ${selectedTheme.gradient} p-4 sm:p-5 flex flex-col border border-white/10 shadow-2xl group transition-all duration-500`}>
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex gap-1">
                                {isPrivate && <div className="bg-black/30 p-1 rounded text-white/70"><PrivateIcon className="w-2.5 h-2.5 sm:w-3 sm:h-3"/></div>}
                                {timerMode === 'custom' && <div className="bg-yellow-500/20 border border-yellow-500/30 px-1.5 py-0.5 rounded text-yellow-400 text-[8px] sm:text-[10px] font-bold flex items-center gap-1"><ClockIcon className="w-2.5 h-2.5 sm:w-3 sm:h-3"/> {customMinutes}m</div>}
                            </div>
                            {autoRecord && <div className="bg-red-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wide animate-pulse">REC</div>}
                        </div>

                        <h2 className="text-base sm:text-xl font-bold text-white leading-tight mb-1 sm:mb-2 line-clamp-2 sm:line-clamp-3">
                            {topic || "Your Awesome Room Topic..."}
                        </h2>

                        {tagsList.length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-2 sm:mb-4">
                                {tagsList.slice(0, 2).map((t, i) => (
                                    <span key={i} className="text-[8px] sm:text-[9px] bg-white/10 px-1.5 py-0.5 rounded text-white/80 border border-white/5">{t}</span>
                                ))}
                                {tagsList.length > 2 && (
                                    <span className="text-[8px] sm:text-[9px] bg-white/10 px-1.5 py-0.5 rounded text-white/80 border border-white/5">+{tagsList.length - 2}</span>
                                )}
                            </div>
                        )}

                        <div className="mt-auto pt-3 sm:pt-4 border-t border-white/10 flex items-center justify-between">
                            {/* Host Preview */}
                            <div className="flex items-center gap-2">
                                <img src={currentUser.avatar} alt="Host" className="w-6 h-6 sm:w-8 sm:h-8 rounded-full border-2 border-black/30 object-cover" />
                                <div className="flex flex-col">
                                    <span className="text-[8px] sm:text-[10px] font-bold text-white/90 leading-none">{currentUser.name}</span>
                                    <span className="text-[7px] sm:text-[8px] text-white/60 uppercase font-bold tracking-wide">Host</span>
                                </div>
                            </div>
                            
                            <div className={`p-1.5 sm:p-2 rounded-full bg-black/30 text-white/80 ${openMicMode ? 'text-green-400' : ''}`}>
                                {openMicMode ? <MicrophoneIcon className="w-3 h-3 sm:w-4 sm:h-4"/> : <HandIcon className="w-3 h-3 sm:w-4 sm:h-4"/>}
                            </div>
                        </div>
                    </div>
                    
                    <p className="relative z-10 text-[10px] text-gray-500 mt-4 sm:mt-6 text-center max-w-[200px] hidden sm:block">
                        This is how your room will appear in the public hallway.
                    </p>
                </div>

                {/* Right Side: Form */}
                <div className="flex-1 flex flex-col bg-[#121214] h-full overflow-hidden">
                    {/* Desktop Header */}
                    <div className="hidden sm:flex justify-between items-center p-6 border-b border-white/5 bg-white/[0.02]">
                        <h2 className="text-xl font-bold text-white">Create Room</h2>
                        <button onClick={onClose} className="text-gray-400 hover:text-white p-2 hover:bg-white/5 rounded-full transition-colors">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>

                    <form id="create-room-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 sm:space-y-8 custom-scrollbar pb-20 sm:pb-6">
                        {/* Topic Input */}
                        <div className="space-y-2 sm:space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">What are we discussing?</label>
                            <textarea 
                                value={topic} 
                                onChange={(e) => setTopic(e.target.value)}
                                className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl p-4 text-white placeholder-gray-600 focus:outline-none focus:border-[#6C5DD3] focus:ring-1 focus:ring-[#6C5DD3]/20 transition-all text-base sm:text-lg font-medium resize-none" 
                                placeholder="e.g., Late Night Movie Talks 🎬" 
                                rows={2} 
                                required
                                autoFocus
                            />
                        </div>

                        {/* Theme Selection */}
                        <div className="space-y-2 sm:space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Vibe Check</label>
                            <div className="grid grid-cols-4 gap-2 sm:gap-3">
                                {THEMES.map(theme => (
                                    <button
                                        key={theme.id}
                                        type="button"
                                        onClick={() => setSelectedTheme(theme)}
                                        className={`relative h-12 sm:h-16 rounded-xl overflow-hidden border-2 transition-all group ${selectedTheme.id === theme.id ? 'border-white scale-105 shadow-lg' : 'border-transparent opacity-70 hover:opacity-100'}`}
                                    >
                                        <div className={`absolute inset-0 bg-gradient-to-br ${theme.gradient}`}></div>
                                        {/* Only show label on desktop or if needed, simple circles on mobile is often cleaner, but let's keep small label */}
                                        <span className="hidden sm:block absolute bottom-1 left-0 right-0 text-center text-[8px] sm:text-[10px] font-bold text-white shadow-sm uppercase tracking-wide">{theme.name}</span>
                                        {selectedTheme.id === theme.id && (
                                            <div className="absolute inset-0 flex items-center justify-center bg-black/20 sm:bg-transparent sm:top-1 sm:right-1 sm:bottom-auto sm:left-auto">
                                                <div className="bg-white text-black rounded-full p-0.5 sm:p-0.5">
                                                    <CheckIcon className="w-3 h-3 sm:w-3 sm:h-3" />
                                                </div>
                                            </div>
                                        )}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Settings Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                            {/* Privacy */}
                            <div className="space-y-2 sm:space-y-3">
                                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Access</label>
                                <div className="flex bg-[#1c1c1e] p-1 rounded-xl border border-white/5">
                                    <button type="button" onClick={() => setIsPrivate(false)} className={`flex-1 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${!isPrivate ? 'bg-[#6C5DD3] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}>
                                        <PublicIcon className="w-3.5 h-3.5"/> Public
                                    </button>
                                    <button type="button" onClick={() => setIsPrivate(true)} className={`flex-1 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${isPrivate ? 'bg-[#6C5DD3] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}>
                                        <PrivateIcon className="w-3.5 h-3.5"/> Private
                                    </button>
                                </div>
                                {isPrivate && (
                                    <input 
                                        type="password" 
                                        value={password} 
                                        onChange={(e) => setPassword(e.target.value)} 
                                        className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-[#6C5DD3] outline-none animate-fade-in" 
                                        placeholder="Set a password (optional)" 
                                    />
                                )}
                            </div>

                            {/* Timer */}
                            <div className="space-y-2 sm:space-y-3">
                                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Timer</label>
                                <div className="flex items-center gap-3">
                                    <button type="button" onClick={() => setTimerMode(m => m === 'none' ? 'custom' : 'none')} className={`w-12 h-12 rounded-xl flex items-center justify-center border-2 transition-all ${timerMode === 'custom' ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500' : 'bg-[#1c1c1e] border-white/5 text-gray-400 hover:border-white/20'}`}>
                                        <ClockIcon className="w-6 h-6" />
                                    </button>
                                    {timerMode === 'custom' ? (
                                        <div className="flex-1 bg-[#1c1c1e] border border-white/10 rounded-xl px-4 py-1 flex items-center animate-fade-in">
                                            <input 
                                                type="range" min="5" max="120" step="5" 
                                                value={customMinutes} 
                                                onChange={(e) => setCustomMinutes(Number(e.target.value))} 
                                                className="flex-1 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-500"
                                            />
                                            <span className="ml-3 text-sm font-bold text-white w-12 text-right">{customMinutes}m</span>
                                        </div>
                                    ) : (
                                        <span className="text-sm text-gray-500 italic">Unlimited duration</span>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Advanced Options Toggles */}
                        <div className="space-y-2 sm:space-y-3 pt-2">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1 flex items-center gap-2"><SettingsIcon className="w-3 h-3"/> Advanced Controls</label>
                            
                            <div className="flex flex-col gap-2">
                                {/* Open Mic Toggle */}
                                <div 
                                    onClick={() => setOpenMicMode(!openMicMode)}
                                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${openMicMode ? 'bg-green-500/10 border-green-500/30' : 'bg-[#1c1c1e] border-white/5 hover:border-white/10'}`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded-lg ${openMicMode ? 'bg-green-500 text-white' : 'bg-white/10 text-gray-400'}`}>
                                            <MicrophoneIcon className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <p className={`text-sm font-bold ${openMicMode ? 'text-white' : 'text-gray-300'}`}>Open Mic Mode</p>
                                            <p className="text-[10px] text-gray-500">Listeners can speak without raising hand</p>
                                        </div>
                                    </div>
                                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${openMicMode ? 'border-green-500 bg-green-500 text-white' : 'border-gray-600'}`}>
                                        {openMicMode && <CheckIcon className="w-3 h-3" />}
                                    </div>
                                </div>

                                {/* Auto Record Toggle */}
                                <div 
                                    onClick={() => setAutoRecord(!autoRecord)}
                                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${autoRecord ? 'bg-red-500/10 border-red-500/30' : 'bg-[#1c1c1e] border-white/5 hover:border-white/10'}`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded-lg ${autoRecord ? 'bg-red-500 text-white' : 'bg-white/10 text-gray-400'}`}>
                                            <div className="w-5 h-5 flex items-center justify-center"><div className="w-2.5 h-2.5 bg-current rounded-full"></div></div>
                                        </div>
                                        <div>
                                            <p className={`text-sm font-bold ${autoRecord ? 'text-white' : 'text-gray-300'}`}>Auto-Record</p>
                                            <p className="text-[10px] text-gray-500">Start recording when room opens</p>
                                        </div>
                                    </div>
                                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${autoRecord ? 'border-red-500 bg-red-500 text-white' : 'border-gray-600'}`}>
                                        {autoRecord && <CheckIcon className="w-3 h-3" />}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-2 sm:space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Tags</label>
                            <div className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl px-2 py-2 flex flex-wrap items-center gap-2 focus-within:border-[#6C5DD3] transition-colors">
                                {tagsList.map((tag, index) => (
                                    <div key={index} className="flex items-center gap-1 bg-white/10 text-white text-xs px-2 py-1 rounded-md border border-white/5 animate-fade-in">
                                        <span>{tag}</span>
                                        <button 
                                            type="button"
                                            onClick={() => removeTag(tag)} 
                                            className="text-gray-400 hover:text-white hover:bg-white/20 rounded-full p-0.5 transition-colors"
                                        >
                                            <XIcon className="w-3 h-3" />
                                        </button>
                                    </div>
                                ))}
                                <input 
                                    type="text" 
                                    value={tagInput}
                                    onChange={(e) => setTagInput(e.target.value)}
                                    onKeyDown={handleTagKeyDown}
                                    className="flex-1 bg-transparent outline-none text-sm text-white placeholder-gray-600 min-w-[120px] py-1 px-2" 
                                    placeholder={tagsList.length === 0 ? "Type tag & press Enter..." : "Add another..."} 
                                />
                            </div>
                        </div>
                        
                        {/* Bottom Spacer */}
                        <div className="h-4"></div>
                    </form>

                    <div className="p-4 sm:p-6 bg-[#121214] border-t border-white/5 flex-shrink-0 sticky bottom-0 z-10">
                        <button
                            onClick={handleSubmit}
                            disabled={!topic.trim()}
                            className="w-full py-3.5 sm:py-4 rounded-2xl bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] text-white font-bold text-base shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                        >
                            <WaveIcon className="w-5 h-5" />
                            Go Live
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StartVoiceRoomModal;
