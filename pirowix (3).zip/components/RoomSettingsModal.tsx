
import React, { useState, useEffect } from 'react';
import type { Room, PlaybackPermission, User } from '../types';
import { 
    CloseIcon, CopyIcon, LinkIcon, PublicIcon, PrivateIcon, 
    CheckIcon, XIcon, ShieldIcon, LockClosedIcon, EyeIcon, 
    EyeOffIcon, PlayIcon, UsersIcon, UserIcon, TrashIcon,
    SettingsIcon, UserAddIcon, BlockUserIcon
} from './icons';

interface RoomSettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    room: Room;
    onUpdateSettings: (roomId: number, newSettings: Partial<Pick<Room, 'isPublic' | 'password' | 'playbackPermissions'>>) => void;
    onUnblockUser: (userId: number) => void;
    onAcceptRequest: (userId: number) => void;
    onDeclineRequest: (userId: number) => void;
}

type SettingsTab = 'overview' | 'permissions' | 'moderation';

const RoomSettingsModal: React.FC<RoomSettingsModalProps> = ({ 
    isOpen, onClose, room, onUpdateSettings, onUnblockUser, onAcceptRequest, onDeclineRequest 
}) => {
    const [activeTab, setActiveTab] = useState<SettingsTab>('overview');
    const [isPublic, setIsPublic] = useState(room.isPublic);
    const [password, setPassword] = useState(room.password || '');
    const [showPassword, setShowPassword] = useState(false);
    const [playbackPermissions, setPlaybackPermissions] = useState<PlaybackPermission>(room.playbackPermissions || 'host-only');
    const [copyButtonText, setCopyButtonText] = useState('Copy Link');
    
    const roomUrl = `${window.location.origin}?roomId=${room.id}`;

    useEffect(() => {
        if (isOpen) {
            setIsPublic(room.isPublic);
            setPassword(room.password || '');
            setPlaybackPermissions(room.playbackPermissions || 'host-only');
            setActiveTab('overview');
        }
    }, [room, isOpen]);

    const handleSave = () => {
        onUpdateSettings(room.id, {
            isPublic,
            password: !isPublic ? password : '',
            playbackPermissions,
        });
        onClose();
    };

    const handleCopyLink = () => {
        navigator.clipboard.writeText(roomUrl).then(() => {
            setCopyButtonText('Copied!');
            setTimeout(() => setCopyButtonText('Copy Link'), 2000);
        });
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[100] p-4 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className="bg-[#121214] border border-white/10 rounded-3xl shadow-2xl w-full max-w-lg flex flex-col max-h-[85vh] overflow-hidden animate-fade-in-up ring-1 ring-white/5"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="px-6 py-5 border-b border-white/5 bg-white/[0.02] flex justify-between items-center shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-gradient-to-br from-[#6C5DD3] to-[#8A79F7] rounded-xl shadow-lg shadow-purple-500/20">
                            <SettingsIcon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-white tracking-tight">Room Settings</h2>
                            <p className="text-xs text-gray-400 mt-0.5">Configure your watch party</p>
                        </div>
                    </div>
                    <button 
                        onClick={onClose} 
                        className="p-2 text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-full transition-colors"
                    >
                        <CloseIcon className="w-5 h-5" />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-white/5 px-6 gap-2 shrink-0 bg-[#121214] pt-4 pb-0 overflow-x-auto hide-scrollbar">
                    <TabButton 
                        label="Overview" 
                        isActive={activeTab === 'overview'} 
                        onClick={() => setActiveTab('overview')} 
                        icon={<PublicIcon className="w-4 h-4" />}
                    />
                    <TabButton 
                        label="Permissions" 
                        isActive={activeTab === 'permissions'} 
                        onClick={() => setActiveTab('permissions')} 
                        icon={<ShieldIcon className="w-4 h-4" />}
                    />
                    <TabButton 
                        label="Moderation" 
                        isActive={activeTab === 'moderation'} 
                        onClick={() => setActiveTab('moderation')}
                        icon={<BlockUserIcon className="w-4 h-4" />}
                        count={(room.joinRequests?.length || 0) + (room.blockedUsers?.length || 0)}
                    />
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6 bg-[#0f0f0f]">
                    
                    {/* OVERVIEW TAB */}
                    {activeTab === 'overview' && (
                        <div className="space-y-6 animate-fade-in">
                            {/* Share Section */}
                            <div className="space-y-2">
                                <SectionLabel title="Invite Link" />
                                <div className="bg-[#1c1c1e] p-2 pl-4 rounded-xl border border-white/5 flex items-center justify-between gap-3 shadow-sm group focus-within:border-[#6C5DD3]/50 transition-colors">
                                    <div className="flex items-center gap-3 min-w-0 flex-1">
                                        <LinkIcon className="w-5 h-5 text-gray-500 group-hover:text-[#8A79F7] transition-colors flex-shrink-0" />
                                        <input 
                                            type="text" 
                                            readOnly 
                                            value={roomUrl} 
                                            className="bg-transparent text-sm text-gray-300 w-full outline-none truncate font-mono" 
                                        />
                                    </div>
                                    <button 
                                        onClick={handleCopyLink}
                                        className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-lg transition-all active:scale-95 flex items-center gap-2 whitespace-nowrap"
                                    >
                                        <CopyIcon className="w-3.5 h-3.5" />
                                        {copyButtonText}
                                    </button>
                                </div>
                            </div>

                            {/* Access Control */}
                            <div>
                                <SectionLabel title="Access Level" />
                                <div className="grid grid-cols-2 gap-3 mt-2">
                                    <AccessOption 
                                        title="Public" 
                                        description="Anyone with the link can join"
                                        icon={<PublicIcon className="w-5 h-5" />}
                                        isSelected={isPublic}
                                        onClick={() => setIsPublic(true)}
                                        color="green"
                                    />
                                    <AccessOption 
                                        title="Private" 
                                        description="Require invite or password"
                                        icon={<PrivateIcon className="w-5 h-5" />}
                                        isSelected={!isPublic}
                                        onClick={() => setIsPublic(false)}
                                        color="red"
                                    />
                                </div>
                            </div>

                            {/* Private Settings */}
                            <div className={`transition-all duration-300 overflow-hidden ${!isPublic ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
                                <div className="pt-2">
                                    <SectionLabel title="Security" />
                                    <div className="bg-[#1c1c1e] border border-white/10 rounded-2xl p-4 space-y-4 mt-2">
                                        <div>
                                            <label className="text-xs font-medium text-gray-400 mb-2 block">Room Password (Optional)</label>
                                            <div className="relative group">
                                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500 group-focus-within:text-white transition-colors">
                                                    <LockClosedIcon className="w-4 h-4" />
                                                </div>
                                                <input 
                                                    type={showPassword ? "text" : "password"} 
                                                    value={password}
                                                    onChange={(e) => setPassword(e.target.value)}
                                                    placeholder="Set a password to join..."
                                                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-10 text-sm text-white focus:outline-none focus:border-[#6C5DD3] focus:ring-1 focus:ring-[#6C5DD3]/20 transition-all placeholder-gray-600"
                                                />
                                                <button 
                                                    type="button"
                                                    onClick={() => setShowPassword(!showPassword)}
                                                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 hover:text-white cursor-pointer transition-colors"
                                                >
                                                    {showPassword ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                                                </button>
                                            </div>
                                            <p className="text-[10px] text-gray-500 mt-2 leading-relaxed flex items-center gap-1">
                                                <span className="w-1 h-1 bg-gray-500 rounded-full"></span>
                                                If left blank, users must request to join.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* PERMISSIONS TAB */}
                    {activeTab === 'permissions' && (
                        <div className="space-y-6 animate-fade-in">
                            <div>
                                <SectionLabel title="Playback Control" />
                                <p className="text-xs text-gray-400 mb-4">Decide who can control the video playback.</p>
                                
                                <div className="space-y-3">
                                    <PermissionOption 
                                        title="Host Only"
                                        description="Only you and moderators can play, pause, or seek."
                                        icon={<ShieldIcon className="w-5 h-5" />}
                                        isSelected={playbackPermissions === 'host-only'}
                                        onClick={() => setPlaybackPermissions('host-only')}
                                    />
                                    <PermissionOption 
                                        title="Everyone"
                                        description="All members can control playback together."
                                        icon={<UsersIcon className="w-5 h-5" />}
                                        isSelected={playbackPermissions === 'all'}
                                        onClick={() => setPlaybackPermissions('all')}
                                    />
                                </div>
                            </div>
                        </div>
                    )}

                    {/* MODERATION TAB */}
                    {activeTab === 'moderation' && (
                        <div className="space-y-8 animate-fade-in">
                            {/* Requests */}
                            {!isPublic && !room.password && (
                                <div>
                                    <SectionLabel title={`Join Requests (${room.joinRequests?.length || 0})`} />
                                    {(!room.joinRequests || room.joinRequests.length === 0) ? (
                                        <div className="p-8 rounded-2xl bg-[#1c1c1e]/50 border border-dashed border-white/10 text-center mt-2">
                                            <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                                                <UserAddIcon className="w-6 h-6 text-gray-600" />
                                            </div>
                                            <p className="text-xs text-gray-500 font-medium">No pending requests</p>
                                        </div>
                                    ) : (
                                        <div className="space-y-2 mt-2">
                                            {room.joinRequests.map(user => (
                                                <div key={user.id} className="flex items-center justify-between p-3 bg-[#1c1c1e] rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                                                    <div className="flex items-center gap-3">
                                                        <img src={user.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" />
                                                        <div>
                                                            <p className="text-sm font-bold text-white">{user.name}</p>
                                                            <p className="text-[10px] text-gray-400">Requesting to join</p>
                                                        </div>
                                                    </div>
                                                    <div className="flex gap-2">
                                                        <button onClick={() => onAcceptRequest(user.id)} className="p-2 bg-green-500/10 text-green-400 hover:bg-green-500/20 rounded-lg transition-colors" title="Accept">
                                                            <CheckIcon className="w-4 h-4" />
                                                        </button>
                                                        <button onClick={() => onDeclineRequest(user.id)} className="p-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors" title="Decline">
                                                            <XIcon className="w-4 h-4" />
                                                        </button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Banned Users */}
                            <div>
                                <SectionLabel title={`Banned Users (${room.blockedUsers?.length || 0})`} />
                                {(!room.blockedUsers || room.blockedUsers.length === 0) ? (
                                    <div className="p-8 rounded-2xl bg-[#1c1c1e]/50 border border-dashed border-white/10 text-center mt-2">
                                        <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                                            <ShieldIcon className="w-6 h-6 text-gray-600" />
                                        </div>
                                        <p className="text-xs text-gray-500 font-medium">No banned users</p>
                                    </div>
                                ) : (
                                    <div className="space-y-2 mt-2">
                                        {room.blockedUsers.map(user => (
                                            <div key={user.id} className="flex items-center justify-between p-3 bg-[#1c1c1e] rounded-xl border border-white/5">
                                                <div className="flex items-center gap-3">
                                                    <img src={user.avatar} className="w-10 h-10 rounded-full grayscale object-cover opacity-70" />
                                                    <span className="text-sm font-medium text-gray-300 line-through decoration-gray-500">{user.name}</span>
                                                </div>
                                                <button 
                                                    onClick={() => onUnblockUser(user.id)}
                                                    className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors"
                                                >
                                                    Unban
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-white/10 bg-[#121214] shrink-0">
                    <button 
                        onClick={handleSave}
                        className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] text-white font-bold text-sm shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all transform active:scale-[0.98]"
                    >
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
};

// Sub-components for better readability and reuse

const TabButton: React.FC<{ label: string, isActive: boolean, onClick: () => void, count?: number, icon?: React.ReactNode }> = ({ label, isActive, onClick, count, icon }) => (
    <button 
        onClick={onClick}
        className={`
            relative pb-4 px-4 text-sm font-medium transition-all flex items-center gap-2
            ${isActive ? 'text-white' : 'text-gray-500 hover:text-gray-300'}
        `}
    >
        {icon}
        {label}
        {count !== undefined && count > 0 && (
            <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${isActive ? 'bg-[#6C5DD3] text-white' : 'bg-white/10 text-gray-400'}`}>
                {count}
            </span>
        )}
        {isActive && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#6C5DD3] rounded-t-full shadow-[0_-2px_8px_rgba(108,93,211,0.5)]"></div>
        )}
    </button>
);

const SectionLabel: React.FC<{ title: string }> = ({ title }) => (
    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider ml-1">{title}</h3>
);

const AccessOption: React.FC<{ 
    title: string, description: string, icon: React.ReactNode, isSelected: boolean, onClick: () => void, color: 'green' | 'red' 
}> = ({ title, description, icon, isSelected, onClick, color }) => {
    const activeBorder = color === 'green' ? 'border-green-500/50' : 'border-red-500/50';
    const activeBg = color === 'green' ? 'bg-green-500/10' : 'bg-red-500/10';
    const iconColor = color === 'green' ? 'text-green-400' : 'text-red-400';

    return (
        <button 
            onClick={onClick}
            className={`
                flex flex-col items-start p-4 rounded-2xl border transition-all text-left h-full group
                ${isSelected 
                    ? `${activeBorder} ${activeBg} shadow-lg` 
                    : 'border-white/10 bg-[#1c1c1e] hover:border-white/20 hover:bg-[#252528]'
                }
            `}
        >
            <div className={`p-2 rounded-full mb-3 transition-colors ${isSelected ? 'bg-black/20' : 'bg-white/5 group-hover:bg-white/10'}`}>
                <div className={isSelected ? iconColor : 'text-gray-400 group-hover:text-white'}>{icon}</div>
            </div>
            <h4 className={`font-bold text-sm ${isSelected ? 'text-white' : 'text-gray-200'}`}>{title}</h4>
            <p className="text-[11px] text-gray-500 mt-1 leading-snug">{description}</p>
            
            {isSelected && (
                <div className={`absolute top-3 right-3 w-5 h-5 rounded-full border-2 flex items-center justify-center ${color === 'green' ? 'bg-green-500 border-green-500' : 'bg-red-500 border-red-500'}`}>
                    <CheckIcon className="w-3 h-3 text-white" />
                </div>
            )}
        </button>
    );
};

const PermissionOption: React.FC<{
    title: string, description: string, icon: React.ReactNode, isSelected: boolean, onClick: () => void
}> = ({ title, description, icon, isSelected, onClick }) => (
    <button 
        onClick={onClick}
        className={`
            w-full flex items-center p-4 rounded-2xl border transition-all group text-left
            ${isSelected 
                ? 'border-[#6C5DD3]/50 bg-[#6C5DD3]/10 shadow-lg' 
                : 'border-white/10 bg-[#1c1c1e] hover:border-white/20 hover:bg-[#252528]'
            }
        `}
    >
        <div className={`p-3 rounded-xl mr-4 transition-colors ${isSelected ? 'bg-[#6C5DD3]/20 text-[#8A79F7]' : 'bg-white/5 text-gray-400 group-hover:text-white group-hover:bg-white/10'}`}>
            {icon}
        </div>
        <div className="flex-1">
            <h4 className={`font-bold text-sm ${isSelected ? 'text-white' : 'text-gray-200'}`}>{title}</h4>
            <p className="text-xs text-gray-500 mt-0.5">{description}</p>
        </div>
        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? 'bg-[#6C5DD3] border-[#6C5DD3]' : 'border-gray-600'}`}>
            {isSelected && <CheckIcon className="w-3.5 h-3.5 text-white" />}
        </div>
    </button>
);

export default RoomSettingsModal;
