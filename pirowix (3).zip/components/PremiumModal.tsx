
import React, { useEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { CrownIcon, CloseIcon, StarIcon, PaletteIcon, ShieldIcon, CheckIcon, MagicWandIcon } from './icons';

interface PremiumModalProps {
    isOpen: boolean;
    onClose: () => void;
    onUpgrade: () => void;
    customTitle?: string;
    customDescription?: string;
}

const FEATURES = [
    { 
        id: 'themes',
        icon: <PaletteIcon className="w-6 h-6" />, 
        title: "Unlimited Themes", 
        desc: "Unlock all premium themes and exclusive gradients." 
    },
    { 
        id: 'colors',
        icon: <StarIcon className="w-6 h-6" />, 
        title: "Custom Colors", 
        desc: "Pick any color from the spectrum for your UI accent." 
    },
    { 
        id: 'badge',
        icon: <ShieldIcon className="w-6 h-6" />, 
        title: "VIP Badge", 
        desc: "Get a verified badge and priority customer support." 
    },
    { 
        id: 'ai',
        icon: <MagicWandIcon className="w-6 h-6" />, 
        title: "AI Generation", 
        desc: "2x faster generation for images and text tools." 
    }
];

// --- Desktop Feature Card ---
const DesktopFeatureCard: React.FC<{ feature: typeof FEATURES[0]; delay: number }> = ({ feature, delay }) => (
    <div 
        className="relative group p-5 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/[0.08] hover:border-yellow-500/30 transition-all duration-300 opacity-0 animate-fade-in-up cursor-default hover:shadow-[0_0_25px_-5px_rgba(234,179,8,0.15)]"
        style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
    >
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
        
        <div className="relative z-10 flex flex-col gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400/20 to-orange-500/20 flex items-center justify-center text-yellow-400 shadow-inner border border-yellow-500/10 group-hover:scale-110 group-hover:shadow-yellow-500/20 transition-all duration-300">
                {feature.icon}
            </div>
            <div>
                <h4 className="text-base font-bold text-white mb-1 group-hover:text-yellow-200 transition-colors">{feature.title}</h4>
                <p className="text-xs text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors">{feature.desc}</p>
            </div>
        </div>
    </div>
);

// --- Mobile Feature List Item ---
const MobileFeatureItem: React.FC<{ feature: typeof FEATURES[0]; delay: number }> = ({ feature, delay }) => (
    <div 
        className="flex items-center gap-4 p-4 bg-[#1c1c1e] rounded-2xl border border-white/10 opacity-0 animate-fade-in-up shadow-lg hover:border-yellow-500/20 transition-colors"
        style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
    >
        <div className="p-3 bg-yellow-500/10 rounded-xl text-yellow-400 border border-yellow-500/10 flex-shrink-0 shadow-inner">
            {feature.icon}
        </div>
        <div>
            <h4 className="text-sm font-bold text-white">{feature.title}</h4>
            <p className="text-xs text-gray-400 leading-snug mt-0.5">{feature.desc}</p>
        </div>
    </div>
);

const PremiumModal: React.FC<PremiumModalProps> = ({ isOpen, onClose, onUpgrade, customTitle, customDescription }) => {
    const [isVisible, setIsVisible] = useState(false);
    const [isDragging, setIsDragging] = useState(false);
    const [translateY, setTranslateY] = useState(0);
    const dragStartY = useRef<number>(0);
    const modalContentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
            setTranslateY(0);
            document.body.style.overflow = 'hidden';
        } else {
            const timer = setTimeout(() => setIsVisible(false), 400);
            document.body.style.overflow = '';
            return () => clearTimeout(timer);
        }
        return () => { document.body.style.overflow = ''; };
    }, [isOpen]);

    // Mobile Drag Logic
    const handleTouchStart = (e: React.TouchEvent) => {
        // Only allow drag if at top of scroll
        if (modalContentRef.current && modalContentRef.current.scrollTop > 0) return;
        setIsDragging(true);
        dragStartY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const deltaY = e.touches[0].clientY - dragStartY.current;
        if (deltaY > 0) {
            setTranslateY(deltaY);
        }
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (translateY > 100) {
            onClose();
        } else {
            setTranslateY(0);
        }
    };

    if (!isVisible && !isOpen) return null;

    const title = customTitle || "Pirowix Premium";
    const description = customDescription || "Experience the ultimate way to watch together. No limits, just vibes.";

    return createPortal(
        <div className={`fixed inset-0 z-[9999] flex items-end md:items-center justify-center transition-all duration-500 ${isOpen ? 'visible' : 'invisible'}`}>
            
            {/* Backdrop */}
            <div 
                className={`absolute inset-0 bg-black/60 backdrop-blur-xl transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
                onClick={onClose}
            />

            {/* --- DESKTOP LAYOUT --- */}
            <div 
                className={`
                    hidden md:flex relative w-[900px] h-[550px] bg-[#0f0f0f] rounded-3xl shadow-2xl border border-white/10 overflow-hidden
                    transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)
                    ${isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-95 opacity-0 translate-y-8'}
                `}
                onClick={e => e.stopPropagation()}
            >
                {/* Close Button */}
                <button 
                    onClick={onClose} 
                    className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 rounded-full text-gray-400 hover:text-white z-50 transition-colors"
                >
                    <CloseIcon className="w-5 h-5" />
                </button>

                {/* Left Panel: Branding */}
                <div className="w-[38%] relative bg-[#0a0a0a] flex flex-col items-center justify-center p-10 overflow-hidden border-r border-white/5">
                    {/* Background Effects */}
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-yellow-900/20 via-transparent to-transparent"></div>
                    <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-yellow-600/20 rounded-full blur-[80px] animate-pulse-slow"></div>

                    {/* Hero Icon */}
                    <div className="relative mb-8 group">
                         <div className="absolute inset-0 bg-yellow-500/40 blur-[50px] rounded-full group-hover:bg-yellow-500/50 transition-all duration-500"></div>
                         <div className="relative w-36 h-36 bg-gradient-to-br from-[#FBBF24] to-[#B45309] rounded-[2.5rem] flex items-center justify-center shadow-[0_10px_50px_-10px_rgba(245,158,11,0.5)] rotate-6 border-2 border-white/20 z-10 transform group-hover:scale-105 group-hover:rotate-3 transition-all duration-500">
                            <div className="absolute inset-2 border border-white/30 rounded-[2rem]"></div>
                            <CrownIcon className="w-20 h-20 text-white drop-shadow-2xl" />
                         </div>
                         <div className="absolute -top-4 -right-4 bg-white text-black text-xs font-black px-3 py-1 rounded-full shadow-xl rotate-12 border-4 border-[#0f0f0f] z-20 animate-bounce">
                            PRO
                        </div>
                    </div>

                    <div className="text-center relative z-10">
                        <h2 className="text-4xl font-black text-white mb-3 tracking-tight leading-tight">
                            {customTitle ? customTitle : <>Pirowix <span className="text-yellow-400">Premium</span></>}
                        </h2>
                        <p className="text-sm text-gray-400 leading-relaxed">{description}</p>
                    </div>
                </div>

                {/* Right Panel: Features & Actions */}
                <div className="flex-1 flex flex-col bg-[#121212] p-10 relative">
                    <div className="absolute top-0 right-0 w-full h-32 bg-gradient-to-b from-[#121212] to-transparent pointer-events-none z-10"></div>
                    
                    <div className="flex-1 overflow-y-auto custom-scrollbar -mr-4 pr-4 pt-2">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                            <StarIcon className="w-5 h-5 text-yellow-400" filled /> What you get
                        </h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                             {FEATURES.map((feature, idx) => (
                                 <DesktopFeatureCard key={feature.id} feature={feature} delay={idx * 100} />
                             ))}
                        </div>
                    </div>

                    {/* Footer Action */}
                    <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between shrink-0 relative z-20">
                        <div>
                            <p className="text-2xl font-bold text-white">$4.99 <span className="text-sm font-medium text-gray-500">/ month</span></p>
                            <p className="text-xs text-gray-500 mt-0.5">Cancel anytime.</p>
                        </div>
                        <button 
                            onClick={onUpgrade}
                            className="relative overflow-hidden group px-10 py-3.5 bg-gradient-to-r from-[#FBBF24] to-[#D97706] text-white font-bold rounded-xl shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 hover:scale-105 transition-all active:scale-95"
                        >
                             <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-[-20deg] group-hover:animate-shine"></div>
                            Upgrade Now
                        </button>
                    </div>
                </div>
            </div>

            {/* --- MOBILE LAYOUT (Bottom Sheet) --- */}
            <div 
                className={`
                    md:hidden relative w-full bg-[#0f0f0f] border-t border-white/10 
                    rounded-t-[2.5rem] shadow-[0_-10px_50px_rgba(0,0,0,0.8)] flex flex-col
                    max-h-[90vh] h-auto
                    transition-transform duration-300 ease-out
                    ${isOpen ? 'translate-y-0' : 'translate-y-full'}
                `}
                style={{ 
                    transform: isOpen && isDragging ? `translateY(${translateY}px)` : undefined,
                }}
                onClick={e => e.stopPropagation()}
            >
                {/* Drag Handle */}
                <div 
                    className="w-full h-12 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none z-30 flex-shrink-0"
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
                </div>

                <div 
                    ref={modalContentRef}
                    className="flex-1 overflow-y-auto custom-scrollbar px-6 pb-8"
                >
                    {/* Mobile Hero */}
                    <div className="flex flex-col items-center mb-8 text-center relative">
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-yellow-500/20 blur-[50px] rounded-full pointer-events-none"></div>
                        
                        <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-600 rounded-[1.5rem] flex items-center justify-center shadow-xl rotate-6 border-2 border-white/10 mb-6 relative z-10">
                             <CrownIcon className="w-10 h-10 text-white" />
                        </div>
                        
                        <h2 className="text-3xl font-black text-white mb-2">{customTitle || title}</h2>
                        <p className="text-sm text-gray-400 max-w-xs leading-relaxed">{description}</p>
                    </div>

                    {/* Mobile Features List */}
                    <div className="space-y-3 mb-8">
                        {FEATURES.map((feature, idx) => (
                            <MobileFeatureItem key={feature.id} feature={feature} delay={idx * 100} />
                        ))}
                    </div>
                    
                    {/* Mobile Footer Action */}
                    <div className="space-y-3 pb-safe">
                        <button 
                            onClick={onUpgrade}
                            className="w-full py-4 rounded-2xl font-bold text-white text-base shadow-xl shadow-amber-900/20 bg-gradient-to-r from-yellow-400 to-amber-600 active:scale-95 transition-transform relative overflow-hidden group"
                        >
                            <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-[-20deg] animate-shine"></div>
                            <span className="relative z-10 flex items-center justify-center gap-2">
                                Upgrade for $4.99 <span className="opacity-70 font-normal text-xs">/ mo</span>
                            </span>
                        </button>
                        
                        <button onClick={onClose} className="w-full py-3 text-xs font-bold text-gray-500 hover:text-white transition-colors uppercase tracking-wide">
                            No thanks
                        </button>
                    </div>
                </div>
            </div>
            
            <style>{`
                @keyframes shine {
                    0% { left: -100%; }
                    20% { left: 200%; }
                    100% { left: 200%; }
                }
                .animate-shine {
                    animation: shine 3s infinite;
                }
                .pb-safe {
                    padding-bottom: env(safe-area-inset-bottom, 20px);
                }
            `}</style>
        </div>,
        document.body
    );
};

export default PremiumModal;
