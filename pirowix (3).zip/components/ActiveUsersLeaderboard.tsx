
import React from 'react';
import type { User } from '../types';
import { CrownIcon, FireIcon, StarIcon, ChevronRightIcon, TrophyIcon } from './icons';

interface ActiveUsersLeaderboardProps {
    users: User[];
    className?: string;
    isMobile?: boolean;
}

interface UserWithScore extends User {
    score: number;
}

// Helper to simulate activity score based on user properties
const calculateScore = (user: User) => {
    let score = 0;
    score += (user.friendsCount || 0) * 5;
    if (user.isHost) score += 500;
    if (user.voiceStats) {
        score += user.voiceStats.totalSpeakingMinutes * 2;
        score += user.voiceStats.roomsHosted * 50;
    }
    if (user.watchHistory) {
        score += user.watchHistory.reduce((acc, curr) => acc + curr.hours, 0) * 10;
    }
    score += Math.floor(Math.random() * 50);
    return score;
};

interface ItemProps {
    user: UserWithScore;
    rank: number;
}

// Mobile List Item
const MobileListItem: React.FC<ItemProps> = ({ user, rank }) => (
    <div className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-white/5 mb-2">
        <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-gray-500 font-mono w-6 text-center">#{rank}</span>
            <img src={user.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt={user.name} />
            <div>
                <p className="text-sm font-bold text-white">{user.name}</p>
                <p className="text-[10px] text-gray-400">{user.bio ? user.bio.substring(0, 20) + '...' : 'Super Star'}</p>
            </div>
        </div>
        <div className="bg-[var(--theme-color)]/10 text-[var(--theme-color)] px-2 py-1 rounded-lg text-xs font-bold font-mono">
            {user.score}
        </div>
    </div>
);

// Desktop List Item (Rank 4+)
const DesktopListItem: React.FC<ItemProps> = ({ user, rank }) => (
    <div className="flex items-center justify-between p-2.5 mb-2 bg-white/5 hover:bg-white/10 rounded-xl transition-all border border-white/5 group hover:border-white/10 hover:translate-x-1">
        <div className="flex items-center gap-3 min-w-0">
            <div className="w-6 text-center text-xs font-bold text-gray-500 font-mono">#{rank}</div>
            <img src={user.avatar} className="w-8 h-8 rounded-full object-cover border border-white/10" alt={user.name} />
            <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{user.name}</p>
                <p className="text-[9px] text-gray-400 truncate w-24">{user.bio || 'Member'}</p>
            </div>
        </div>
        <div className="flex items-center gap-1 bg-black/20 px-2 py-1 rounded-md">
            <FireIcon className="w-3 h-3 text-orange-500" />
            <span className="text-[10px] font-mono font-bold text-gray-300">{user.score}</span>
        </div>
    </div>
);

const DesktopPodium: React.FC<{ topThree: UserWithScore[] }> = ({ topThree }) => {
    const first = topThree[0];
    const second = topThree[1];
    const third = topThree[2];

    const renderProfile = (user: UserWithScore | undefined, rank: number) => {
        if (!user) return <div className="w-20" />;
        
        const isFirst = rank === 1;
        const ringColor = isFirst ? 'from-yellow-400 to-orange-500' : rank === 2 ? 'from-gray-300 to-gray-400' : 'from-orange-600 to-red-700';
        const glowColor = isFirst ? 'shadow-yellow-500/40' : rank === 2 ? 'shadow-gray-400/20' : 'shadow-orange-600/20';
        const size = isFirst ? 'w-20 h-20' : 'w-14 h-14';
        const offset = isFirst ? '-mt-6' : '';

        return (
            <div className={`flex flex-col items-center relative group ${offset}`}>
                {isFirst && (
                    <div className="absolute -top-6 animate-bounce">
                        <CrownIcon className="w-6 h-6 text-yellow-400 drop-shadow-lg" />
                    </div>
                )}
                
                <div className={`relative rounded-full p-1 bg-gradient-to-b ${ringColor} shadow-lg ${glowColor} transition-transform duration-300 group-hover:scale-105`}>
                    <img 
                        src={user.avatar} 
                        alt={user.name} 
                        className={`${size} rounded-full object-cover border-2 border-[#18181b]`}
                    />
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-[#18181b] border border-white/10 flex items-center justify-center">
                        <span className={`text-[10px] font-bold ${isFirst ? 'text-yellow-400' : 'text-gray-300'}`}>{rank}</span>
                    </div>
                </div>

                <div className="text-center mt-3">
                    <p className={`font-bold text-white truncate max-w-[80px] ${isFirst ? 'text-sm' : 'text-xs'}`}>{user.name}</p>
                    <p className="text-[9px] text-purple-300 font-mono">{user.score}</p>
                </div>
            </div>
        );
    };

    return (
        <div className="flex items-end justify-center gap-4 pb-4 pt-6 px-4 mb-2 relative">
            {/* Ambient Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-[var(--theme-color)] blur-[60px] opacity-20 rounded-full pointer-events-none"></div>
            
            <div className="order-1">{renderProfile(second, 2)}</div>
            <div className="order-2 z-10">{renderProfile(first, 1)}</div>
            <div className="order-3">{renderProfile(third, 3)}</div>
        </div>
    );
};

const ActiveUsersLeaderboard: React.FC<ActiveUsersLeaderboardProps> = ({ users, className = '', isMobile = false }) => {
    const sortedUsers = React.useMemo<UserWithScore[]>(() => {
        const uniqueUsers = Array.from(new Map<number, User>(users.map(user => [user.id, user])).values());
        return uniqueUsers
            .map(user => ({ ...user, score: calculateScore(user) }))
            .sort((a, b) => b.score - a.score)
            .slice(0, 20);
    }, [users]);

    const topThree = sortedUsers.slice(0, 3);
    const rest = sortedUsers.slice(3);

    if (sortedUsers.length === 0) return null;

    // Mobile View: Podium + List
    if (isMobile) {
        return (
            <div className={`flex flex-col h-full ${className}`}>
                <div className="flex items-center justify-between mb-2 px-2">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Leaderboard</h2>
                        <p className="text-sm text-gray-400">Top contributors</p>
                    </div>
                    <div className="bg-[var(--theme-color)]/20 p-3 rounded-2xl">
                        <TrophyIcon className="w-6 h-6 text-[var(--theme-color)]" />
                    </div>
                </div>
                
                {/* Podium Section for Mobile */}
                <DesktopPodium topThree={topThree} />

                <div className="flex-1 overflow-y-auto custom-scrollbar px-2 pb-4 mt-2">
                    {rest.map((user, index) => (
                        <MobileListItem key={user.id} user={user} rank={index + 4} />
                    ))}
                </div>
            </div>
        );
    }

    // Desktop View: Podium + List
    return (
        <div 
            className={`h-full flex flex-col bg-[#121214]/40 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden relative shadow-xl ${className}`}
        >
            {/* Header */}
            <div className="p-4 flex justify-between items-center border-b border-white/5 bg-white/[0.02] shrink-0">
                 <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-[var(--theme-color)]/10 rounded-lg text-[var(--theme-color)]">
                        <TrophyIcon className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-bold text-white tracking-wide">Leaderboard</span>
                </div>
                <button className="text-xs text-gray-400 hover:text-white transition-colors flex items-center gap-1">
                    View All <ChevronRightIcon className="w-3 h-3" />
                </button>
            </div>

            {/* Podium Section */}
            <div className="shrink-0 bg-gradient-to-b from-white/[0.02] to-transparent border-b border-white/5">
                <DesktopPodium topThree={topThree} />
            </div>

            {/* Scrollable List */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-3 relative">
                {/* Fade overlay for smooth scroll feel */}
                <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-b from-[#121214]/40 to-transparent pointer-events-none z-10"></div>
                
                {rest.map((user, index) => (
                    <DesktopListItem key={user.id} user={user} rank={index + 4} />
                ))}
            </div>
        </div>
    );
};

export default ActiveUsersLeaderboard;
