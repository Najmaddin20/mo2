
import React, { useState, useEffect, useRef, useMemo } from 'react';
import type { User, UserProfile, Gender, RelationshipGoal } from '../types';
import { 
    RadarIcon, PlanetIcon, ChatIcon, UserIcon, ArrowRightIcon, 
    CameraIcon, SearchIcon, HeartIcon, CloseIcon, CheckIcon, 
    SettingsIcon, ShieldIcon, MagicWandIcon, PlusIcon,
    LayoutGridIcon, FireIcon, StarIcon, ClockIcon, GameControllerIcon,
    UserGroupIcon
} from './icons';
import { WorldMap } from './WorldMap';

// --- Interfaces ---

interface PeopleNearbyProps {
    currentUser: User;
    allUsers: User[];
    onViewProfile: (user: User) => void;
    onAddFriend: (userId: number) => void;
    onStartChat: (userId: number) => void;
}

// --- Constants & Data ---

const RELATIONSHIP_GOALS: { id: RelationshipGoal; label: string; emoji: string; color: string; gradient: string }[] = [
    { id: 'dating', label: 'Dating', emoji: '💘', color: 'text-pink-400', gradient: 'from-pink-500 to-rose-600' },
    { id: 'friends', label: 'Friendship', emoji: '🙌', color: 'text-yellow-400', gradient: 'from-yellow-400 to-orange-500' },
    { id: 'chat', label: 'Chat', emoji: '💬', color: 'text-blue-400', gradient: 'from-blue-400 to-cyan-500' },
    { id: 'gaming', label: 'Gaming', emoji: '🎮', color: 'text-purple-400', gradient: 'from-purple-500 to-indigo-600' },
    { id: 'networking', label: 'Networking', emoji: '🤝', color: 'text-emerald-400', gradient: 'from-emerald-400 to-teal-600' },
];

const INTERESTS_LIST = [
    { id: 'movies', emoji: '🎬', label: 'Movies' },
    { id: 'books', emoji: '📚', label: 'Books' },
    { id: 'gaming', emoji: '🎮', label: 'Gaming' },
    { id: 'music', emoji: '🎵', label: 'Music' },
    { id: 'travel', emoji: '✈️', label: 'Travel' },
    { id: 'food', emoji: '🍕', label: 'Foodie' },
    { id: 'gym', emoji: '💪', label: 'Gym' },
    { id: 'art', emoji: '🎨', label: 'Art' },
    { id: 'tech', emoji: '💻', label: 'Tech' },
    { id: 'cars', emoji: '🏎️', label: 'Cars' },
    { id: 'nature', emoji: '🌿', label: 'Nature' },
    { id: 'pets', emoji: '🐾', label: 'Pets' },
];

// --- Helper Components ---

const GlassContainer: React.FC<{ children: React.ReactNode, className?: string, onClick?: () => void }> = ({ children, className, onClick }) => (
    <div 
        onClick={onClick}
        className={`bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-xl relative overflow-hidden ${className}`}
    >
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none"></div>
        {children}
    </div>
);

// Animated Background for Desktop
const AnimatedBackground = () => (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] bg-purple-900/30 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[800px] h-[800px] bg-blue-900/30 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-[40%] left-[40%] w-[600px] h-[600px] bg-indigo-900/20 rounded-full blur-[100px] animate-spin-slow"></div>
    </div>
);

// --- 1. Onboarding Component ---

const Onboarding: React.FC<{ currentUser: User; onComplete: (profile: UserProfile) => void }> = ({ currentUser, onComplete }) => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState<Partial<UserProfile>>({
        name: currentUser.name,
        avatar: currentUser.avatar,
        location: { city: '', country: '' },
        interests: [],
        photos: [currentUser.avatar],
        gender: 'male',
        age: 25,
        relationshipGoal: 'chat'
    });

    const handleNext = () => {
        if (step < 3) setStep(step + 1);
        else onComplete(formData as UserProfile);
    };

    const handleInterestToggle = (label: string) => {
        setFormData(prev => {
            const interests = prev.interests?.includes(label)
                ? prev.interests.filter(i => i !== label)
                : [...(prev.interests || []), label];
            return { ...prev, interests };
        });
    };

    return (
        <div className="absolute inset-0 z-50 bg-[#050505] flex flex-col items-center justify-center p-6 animate-fade-in overflow-hidden">
            <AnimatedBackground />

            <GlassContainer className="w-full max-w-md p-8 z-10">
                {/* Progress */}
                <div className="flex gap-2 mb-8">
                    {[1, 2, 3].map(i => (
                        <div key={i} className={`h-1 rounded-full flex-1 transition-all duration-500 ${i <= step ? 'bg-gradient-to-r from-[var(--theme-color)] to-white' : 'bg-white/10'}`} />
                    ))}
                </div>

                {step === 1 && (
                    <div className="space-y-6 animate-slide-in-up">
                        <div className="text-center">
                            <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Setup Profile</h2>
                            <p className="text-gray-400 text-sm">Let's introduce you to people nearby.</p>
                        </div>

                        <div className="flex justify-center mb-6">
                            <div className="relative w-28 h-28 group cursor-pointer">
                                <div className="absolute inset-0 bg-gradient-to-tr from-[var(--theme-color)] to-blue-500 rounded-full blur opacity-40 group-hover:opacity-60 transition-opacity"></div>
                                <img src={formData.avatar} className="w-full h-full rounded-full object-cover border-4 border-white/10 relative z-10" />
                                <div className="absolute bottom-0 right-0 bg-white text-black p-2 rounded-full z-20 shadow-lg">
                                    <CameraIcon className="w-4 h-4" />
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <GlassInput label="Name" value={formData.name || ''} onChange={v => setFormData({...formData, name: v})} />
                                <GlassInput label="Age" type="number" value={String(formData.age)} onChange={v => setFormData({...formData, age: parseInt(v)})} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <GlassInput label="City" value={formData.location?.city || ''} onChange={v => setFormData({...formData, location: { ...formData.location!, city: v }})} />
                                <GlassInput label="Country" value={formData.location?.country || ''} onChange={v => setFormData({...formData, location: { ...formData.location!, country: v }})} />
                            </div>
                            <div>
                                <label className="text-[10px] font-bold text-gray-500 uppercase ml-3 mb-2 block tracking-wider">Gender</label>
                                <div className="flex bg-black/20 p-1 rounded-xl border border-white/5">
                                    {(['male', 'female', 'non-binary'] as Gender[]).map(g => (
                                        <button 
                                            key={g}
                                            onClick={() => setFormData({...formData, gender: g})}
                                            className={`flex-1 py-2 rounded-lg text-xs font-bold capitalize transition-all ${formData.gender === g ? 'bg-white/10 text-white shadow-inner border border-white/10' : 'text-gray-500 hover:text-white'}`}
                                        >
                                            {g}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {step === 2 && (
                    <div className="space-y-6 animate-slide-in-up">
                        <div className="text-center">
                            <h2 className="text-3xl font-bold text-white mb-2">Your Goal</h2>
                            <p className="text-gray-400 text-sm">What are you looking for?</p>
                        </div>
                        
                        <div className="grid grid-cols-1 gap-3">
                            {RELATIONSHIP_GOALS.map(goal => (
                                <button
                                    key={goal.id}
                                    onClick={() => setFormData({...formData, relationshipGoal: goal.id})}
                                    className={`flex items-center p-3 rounded-2xl border transition-all duration-300 group ${formData.relationshipGoal === goal.id ? `bg-gradient-to-r ${goal.gradient} border-transparent` : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
                                >
                                    <span className="text-2xl mr-4 bg-black/20 p-2 rounded-xl backdrop-blur-sm">{goal.emoji}</span>
                                    <div className="text-left">
                                        <span className={`text-sm font-bold block ${formData.relationshipGoal === goal.id ? 'text-white' : 'text-gray-300'}`}>{goal.label}</span>
                                    </div>
                                    {formData.relationshipGoal === goal.id && <CheckIcon className="w-5 h-5 text-white ml-auto" />}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {step === 3 && (
                    <div className="space-y-6 animate-slide-in-up">
                        <div className="text-center">
                            <h2 className="text-3xl font-bold text-white mb-2">Your Interests</h2>
                            <p className="text-gray-400 text-sm">Pick a few topics you enjoy.</p>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-3 max-h-[320px] overflow-y-auto custom-scrollbar p-1">
                            {INTERESTS_LIST.map(item => {
                                const isSelected = formData.interests?.includes(item.label);
                                return (
                                    <button
                                        key={item.id}
                                        onClick={() => handleInterestToggle(item.label)}
                                        className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all duration-300 ${isSelected ? 'bg-[var(--theme-color)]/20 border-[var(--theme-color)] text-white shadow-[0_0_15px_var(--theme-color)]' : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10 hover:border-white/20'}`}
                                    >
                                        <span className="text-2xl mb-1 filter drop-shadow-md">{item.emoji}</span>
                                        <span className="text-[10px] font-bold">{item.label}</span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                )}

                <div className="mt-8 pt-6 border-t border-white/5 flex justify-end">
                    <button 
                        onClick={handleNext}
                        className="px-8 py-3.5 bg-white text-black rounded-xl font-bold shadow-lg hover:shadow-xl hover:scale-105 transition-all flex items-center gap-2 active:scale-95"
                    >
                        {step === 3 ? 'Launch' : 'Continue'} <ArrowRightIcon className="w-4 h-4" />
                    </button>
                </div>
            </GlassContainer>
        </div>
    );
};

const GlassInput: React.FC<{ label: string; value: string; onChange: (val: string) => void; type?: string; placeholder?: string }> = ({ label, value, onChange, type = "text", placeholder }) => (
    <div>
        <label className="text-[10px] font-bold text-gray-500 uppercase ml-3 mb-2 block tracking-wider">{label}</label>
        <input 
            type={type} 
            value={value} 
            onChange={e => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full bg-black/20 border border-white/10 rounded-2xl px-5 py-3 text-white text-sm focus:border-[var(--theme-color)] outline-none transition-colors placeholder-gray-600 shadow-inner"
        />
    </div>
);

// --- 2. Discovery View ---

const DiscoveryView: React.FC<{ users: User[]; onChat: (id: number) => void; isDesktop: boolean }> = ({ users, onChat, isDesktop }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    // Enhanced user data with mock fields if missing
    const currentUser = useMemo(() => {
        const u = users[currentIndex];
        if (!u) return null;
        // Mock data enrichment for demo if not present
        const userProfile: UserProfile = {
            ...u,
            age: 20 + (u.id % 10),
            gender: u.id % 2 === 0 ? 'female' : 'male',
            location: { city: ['New York', 'London', 'Tokyo', 'Paris'][u.id % 4], country: '' },
            relationshipGoal: RELATIONSHIP_GOALS[u.id % RELATIONSHIP_GOALS.length].id,
            interests: ['Movies', 'Music', 'Travel'],
            photos: [u.avatar],
        };
        return userProfile;
    }, [users, currentIndex]);

    const handleAction = (action: 'pass' | 'like') => {
        setCurrentIndex(prev => (prev + 1) % users.length);
    };

    if (!currentUser) return (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-6 animate-pulse border border-white/10">
                <RadarIcon className="w-12 h-12 text-[var(--theme-color)]" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Scanning Area...</h3>
            <p className="text-gray-400 text-sm max-w-xs">We've run out of people nearby. Try expanding your search radius.</p>
        </div>
    );

    const goalConfig = RELATIONSHIP_GOALS.find(g => g.id === currentUser.relationshipGoal) || RELATIONSHIP_GOALS[0];

    return (
        <div className={`flex-1 flex flex-col items-center justify-center relative overflow-hidden ${isDesktop ? 'p-8' : 'p-4'}`}>
            
            {/* Card Stack */}
            <div className={`relative w-full ${isDesktop ? 'max-w-sm aspect-[3/4.5]' : 'max-w-sm aspect-[3/4.5]'} z-10`}>
                
                {/* The Card */}
                <GlassContainer className="absolute inset-0 !rounded-[2.5rem] group shadow-2xl border-white/20">
                    <img src={currentUser.avatar} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 bg-zinc-800" />
                    
                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40 opacity-90"></div>
                    
                    {/* Top Info: Distance & City */}
                    <div className="absolute top-6 left-6 right-6 flex justify-between items-start">
                        <div className="flex flex-col gap-2 items-start">
                            <div className="bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 text-xs font-bold text-white flex items-center gap-1.5 shadow-lg">
                                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div> 2 km away
                            </div>
                            <div className="bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 text-xs font-bold text-white flex items-center gap-1.5 shadow-lg">
                                📍 {currentUser.location.city}
                            </div>
                        </div>
                    </div>

                    {/* Bottom Info: Name, Goal, Bio */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 pb-8 bg-gradient-to-t from-black to-transparent pt-24">
                        
                        {/* Graphical Relationship Goal Badge */}
                        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl mb-3 bg-gradient-to-r ${goalConfig.gradient} shadow-lg shadow-black/30 border border-white/20 transform -translate-y-2`}>
                            <span className="text-lg filter drop-shadow">{goalConfig.emoji}</span>
                            <span className="text-xs font-bold text-white uppercase tracking-wide">{goalConfig.label}</span>
                        </div>

                        <h2 className="text-4xl font-black text-white mb-1 flex items-end gap-2 drop-shadow-lg leading-none">
                            {currentUser.name} <span className="text-2xl font-medium text-gray-300 mb-1">{currentUser.age}</span>
                        </h2>
                        
                        <p className="text-gray-200 text-sm leading-snug line-clamp-2 mb-4 opacity-90 font-medium">
                            {currentUser.bio || "Looking for connections nearby."}
                        </p>
                        
                        <div className="flex flex-wrap gap-2 opacity-80">
                            {currentUser.interests.slice(0, 3).map(tag => (
                                <span key={tag} className="text-[10px] font-bold bg-white/10 text-gray-100 px-2.5 py-1 rounded-lg border border-white/10 backdrop-blur-md shadow-sm">
                                    {tag}
                                </span>
                            ))}
                        </div>
                    </div>
                </GlassContainer>
            </div>

            {/* Action Buttons */}
            <div className="absolute bottom-6 md:bottom-10 flex items-center gap-6 z-20">
                <button onClick={() => handleAction('pass')} className="w-14 h-14 rounded-full bg-black/60 backdrop-blur-xl border border-white/10 text-red-500 flex items-center justify-center shadow-2xl hover:scale-110 hover:bg-red-500 hover:text-white transition-all duration-300 group">
                    <CloseIcon className="w-6 h-6 group-hover:rotate-90 transition-transform" />
                </button>
                
                <button onClick={() => onChat(currentUser.id)} className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 text-blue-400 flex items-center justify-center shadow-2xl hover:scale-110 hover:bg-blue-500 hover:text-white transition-all duration-300">
                    <ChatIcon className="w-5 h-5" />
                </button>
                
                <button onClick={() => handleAction('like')} className="w-14 h-14 rounded-full bg-gradient-to-br from-[var(--theme-color)] to-pink-600 text-white flex items-center justify-center shadow-2xl shadow-pink-500/30 hover:scale-110 hover:shadow-pink-500/50 transition-all duration-300 border border-white/10">
                    <HeartIcon className="w-6 h-6" filled />
                </button>
            </div>
        </div>
    );
};

// --- 3. Connect View ---

const ConnectView: React.FC<{ users: User[] }> = ({ users }) => {
    return (
        <div className="flex-1 flex flex-col h-full p-6 overflow-y-auto custom-scrollbar space-y-8">
            
            {/* Radar/Anonymous Chat Card */}
            <GlassContainer className="p-6 flex flex-col items-center text-center relative group cursor-pointer border-white/10">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="relative z-10">
                    <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-4 mx-auto relative">
                        <div className="absolute inset-0 rounded-full border border-white/20 animate-[ping_2s_linear_infinite]"></div>
                        <RadarIcon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-1">Start Radar</h3>
                    <p className="text-gray-400 text-xs mb-6">Find random chat partners nearby instantly.</p>
                    <button className="px-8 py-3 rounded-xl bg-white text-black font-bold text-sm hover:scale-105 transition-transform shadow-lg">
                        Scan Area
                    </button>
                </div>
            </GlassContainer>

            {/* Recent Matches */}
            <div>
                <div className="flex items-center justify-between mb-4 px-2">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Recent Matches</h3>
                    <span className="bg-[var(--theme-color)] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">3</span>
                </div>
                <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-4 px-1">
                    {[1,2,3,4,5].map(i => (
                        <div key={i} className="flex flex-col items-center gap-2 group cursor-pointer flex-shrink-0">
                            <div className="relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-white/10 group-hover:border-[var(--theme-color)] transition-colors shadow-lg">
                                <img src={`https://i.pravatar.cc/150?u=${i+100}`} className="w-full h-full object-cover" />
                                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-black rounded-full m-1"></div>
                            </div>
                            <span className="text-xs font-medium text-gray-300">User {i}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Messages List */}
            <div className="flex-1">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4 px-2">Chats</h3>
                <div className="space-y-2">
                    {users.slice(0, 5).map((user) => (
                        <GlassContainer key={user.id} className="p-3 flex items-center gap-4 hover:bg-white/10 transition-colors cursor-pointer border-transparent hover:border-white/10">
                            <div className="relative">
                                <img src={user.avatar} className="w-12 h-12 rounded-full object-cover bg-black" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-center mb-0.5">
                                    <h4 className="font-bold text-white text-sm">{user.name}</h4>
                                    <span className="text-[10px] text-gray-500">2m ago</span>
                                </div>
                                <p className="text-xs text-gray-400 truncate">Matched via Dating Mode</p>
                            </div>
                        </GlassContainer>
                    ))}
                </div>
            </div>
        </div>
    );
};

// --- 4. Profile View ---

const ProfileView: React.FC<{ profile: UserProfile; onEdit: () => void }> = ({ profile, onEdit }) => {
    const goal = RELATIONSHIP_GOALS.find(g => g.id === profile.relationshipGoal) || RELATIONSHIP_GOALS[0];

    return (
        <div className="flex-1 h-full overflow-y-auto custom-scrollbar bg-transparent pb-20">
            {/* Header Card */}
            <div className="relative h-80 w-full">
                <img src={profile.photos[0]} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#050505]"></div>
                
                <div className="absolute bottom-0 left-0 right-0 p-6 flex items-end justify-between">
                    <div>
                        <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg mb-3 bg-gradient-to-r ${goal.gradient} border border-white/20 shadow-lg`}>
                            <span className="text-sm">{goal.emoji}</span>
                            <span className="text-[10px] font-bold text-white uppercase tracking-wide">{goal.label}</span>
                        </div>
                        <h1 className="text-4xl font-black text-white mb-1 leading-none">{profile.name}, {profile.age}</h1>
                        <div className="flex items-center gap-2 text-sm text-gray-300 font-medium">
                            <span>{profile.location.city}, {profile.location.country}</span>
                        </div>
                    </div>
                    <button onClick={onEdit} className="p-3 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/10 rounded-full text-white transition-all">
                        <SettingsIcon className="w-6 h-6" />
                    </button>
                </div>
            </div>

            <div className="p-6 space-y-6">
                {/* Stats */}
                <div className="flex gap-4">
                    <GlassContainer className="flex-1 p-3 flex flex-col items-center justify-center gap-1">
                        <span className="text-xl font-bold text-white">128</span>
                        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wide">Likes</span>
                    </GlassContainer>
                    <GlassContainer className="flex-1 p-3 flex flex-col items-center justify-center gap-1">
                        <span className="text-xl font-bold text-white">45</span>
                        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wide">Matches</span>
                    </GlassContainer>
                    <GlassContainer className="flex-1 p-3 flex flex-col items-center justify-center gap-1">
                        <div className="flex items-center gap-1 text-green-400 text-sm font-bold"><FireIcon className="w-3.5 h-3.5"/> 80%</div>
                        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wide">Popularity</span>
                    </GlassContainer>
                </div>

                {/* Bio */}
                <div>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 ml-1">About</h3>
                    <p className="text-gray-300 text-sm leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/5">
                        {profile.bio || "No bio set yet."}
                    </p>
                </div>

                {/* Interests */}
                <div>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 ml-1">Interests</h3>
                    <div className="flex flex-wrap gap-2">
                        {profile.interests.map(tag => (
                            <div key={tag} className="px-3 py-2 rounded-xl bg-white/5 border border-white/5 text-xs font-medium text-gray-200 hover:bg-white/10 transition-colors">
                                {tag}
                            </div>
                        ))}
                        <button className="px-3 py-2 rounded-xl border border-dashed border-white/20 text-xs font-medium text-gray-500 hover:text-white hover:border-white/40 transition-colors">
                            + Add
                        </button>
                    </div>
                </div>

                {/* Photos Grid */}
                <div>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 ml-1">Photos</h3>
                    <div className="grid grid-cols-3 gap-2">
                        {[1, 2, 3, 4, 5, 6].map(i => (
                            <div key={i} className="aspect-[3/4] bg-white/5 rounded-xl border border-white/5 relative group overflow-hidden cursor-pointer hover:border-white/20 transition-colors">
                                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                                    <PlusIcon className="w-6 h-6 text-white" />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

const MapView: React.FC = () => (
    <div className="flex-1 relative w-full h-full overflow-hidden bg-[#0a0a0a]">
        <div className="absolute inset-0 opacity-50">
            <WorldMap className="w-full h-full text-gray-700 fill-current" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#050505] pointer-events-none"></div>
        
        {/* Overlay Controls */}
        <div className="absolute top-6 left-6 z-10">
            <GlassContainer className="px-4 py-2 flex items-center gap-2 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs font-bold text-white uppercase tracking-wide">Live Map</span>
            </GlassContainer>
        </div>

        {/* Mock Pins */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
            <div className="w-64 h-64 bg-[var(--theme-color)]/20 rounded-full blur-3xl animate-pulse"></div>
            <div className="w-4 h-4 bg-white rounded-full shadow-[0_0_20px_white] relative z-10 animate-bounce">
                <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 whitespace-nowrap shadow-xl">
                    <p className="text-xs font-bold text-white">You are here</p>
                </div>
            </div>
        </div>
    </div>
);

// --- Main Component Layout ---

const PeopleNearby: React.FC<PeopleNearbyProps> = ({ currentUser, allUsers, onViewProfile, onAddFriend, onStartChat }) => {
    const [view, setView] = useState<'discover' | 'map' | 'connect' | 'profile'>('discover');
    const [profile, setProfile] = useState<UserProfile | null>(null);
    const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 1024);

    useEffect(() => {
        const handleResize = () => setIsDesktop(window.innerWidth >= 1024);
        window.addEventListener('resize', handleResize);
        
        const savedProfile = localStorage.getItem('user_dating_profile');
        if (savedProfile) {
            setProfile(JSON.parse(savedProfile));
        }
        
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleProfileComplete = (newProfile: UserProfile) => {
        setProfile(newProfile);
        localStorage.setItem('user_dating_profile', JSON.stringify(newProfile));
    };

    if (!profile) {
        return <Onboarding currentUser={currentUser} onComplete={handleProfileComplete} />;
    }

    const NAV_ITEMS = [
        { id: 'discover', label: 'Discover', icon: <RadarIcon className="w-5 h-5" /> },
        { id: 'map', label: 'Map', icon: <PlanetIcon className="w-5 h-5" /> },
        { id: 'connect', label: 'Connect', icon: <ChatIcon className="w-5 h-5" /> },
        { id: 'profile', label: 'Profile', icon: <UserIcon className="w-5 h-5" /> },
    ];

    // Desktop Layout
    if (isDesktop) {
        return (
            <div className="h-full w-full flex bg-[#050505] overflow-hidden relative">
                <AnimatedBackground />

                {/* Left Sidebar Navigation */}
                <aside className="w-80 flex flex-col p-6 z-10 bg-transparent">
                    <div className="mb-10 px-2">
                        <h1 className="text-3xl font-black text-white tracking-tight drop-shadow-lg">Nearby</h1>
                        <p className="text-gray-400 text-xs font-medium mt-1 uppercase tracking-widest">Social Discovery</p>
                    </div>

                    <nav className="flex-1 space-y-2">
                        {NAV_ITEMS.map(item => {
                            const isActive = view === item.id;
                            return (
                                <button
                                    key={item.id}
                                    onClick={() => setView(item.id as any)}
                                    className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all duration-300 group ${isActive ? 'bg-white/10 text-white shadow-lg border border-white/10 backdrop-blur-md' : 'text-gray-400 hover:bg-white/5 hover:text-white border border-transparent'}`}
                                >
                                    <div className={`p-2 rounded-xl transition-colors ${isActive ? 'bg-[var(--theme-color)] text-white shadow-lg' : 'bg-white/5 text-gray-400 group-hover:text-white'}`}>
                                        {item.icon}
                                    </div>
                                    <span className="font-bold text-sm">{item.label}</span>
                                </button>
                            )
                        })}
                    </nav>

                    {/* User Mini Profile */}
                    <div className="mt-auto">
                        <GlassContainer className="p-4 flex items-center gap-3 cursor-pointer hover:bg-white/10 transition-colors">
                            <img src={profile.avatar} className="w-10 h-10 rounded-full object-cover border-2 border-white/10" />
                            <div className="flex-1 min-w-0">
                                <p className="text-sm font-bold text-white truncate">{profile.name}</p>
                                <p className="text-[10px] text-gray-400 truncate uppercase tracking-wide font-bold">Online</p>
                            </div>
                            <SettingsIcon className="w-5 h-5 text-gray-500" />
                        </GlassContainer>
                    </div>
                </aside>

                {/* Main Content Area */}
                <main className="flex-1 p-6 pl-0 relative z-0">
                    <div className="w-full h-full rounded-[3rem] bg-black/40 backdrop-blur-3xl border border-white/10 shadow-2xl overflow-hidden relative flex flex-col ring-1 ring-white/5">
                        {view === 'discover' && <DiscoveryView users={allUsers} onChat={onStartChat} isDesktop={true} />}
                        {view === 'map' && <MapView />}
                        {view === 'connect' && <ConnectView users={allUsers} />}
                        {view === 'profile' && <ProfileView profile={profile} onEdit={() => {}} />}
                    </div>
                </main>
            </div>
        );
    }

    // Mobile Layout
    return (
        <div className="h-full flex flex-col bg-[#050505] relative overflow-hidden">
            {/* Mobile Animated Background */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 opacity-50">
                 <div className="absolute top-[-10%] right-[-10%] w-[300px] h-[300px] bg-purple-900/40 rounded-full blur-[80px] animate-pulse-slow"></div>
                 <div className="absolute bottom-[-10%] left-[-10%] w-[300px] h-[300px] bg-blue-900/40 rounded-full blur-[80px] animate-pulse-slow" style={{ animationDelay: '1s' }}></div>
            </div>

            {/* Content */}
            <div className="flex-1 relative overflow-hidden z-10">
                {view === 'discover' && <DiscoveryView users={allUsers} onChat={onStartChat} isDesktop={false} />}
                {view === 'map' && <MapView />}
                {view === 'connect' && <ConnectView users={allUsers} />}
                {view === 'profile' && <ProfileView profile={profile} onEdit={() => {}} />}
            </div>

            {/* Bottom Nav (Ultra Glass) */}
            <div className="flex-shrink-0 bg-black/60 backdrop-blur-xl border-t border-white/10 pb-safe z-30 absolute bottom-0 left-0 right-0 rounded-t-3xl shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
                <div className="flex justify-around items-center h-20 px-2">
                    {NAV_ITEMS.map(item => {
                        const isActive = view === item.id;
                        return (
                            <button 
                                key={item.id}
                                onClick={() => setView(item.id as any)}
                                className={`flex flex-col items-center justify-center w-16 h-full gap-1.5 transition-all duration-300 group`}
                            >
                                <div className={`p-2 rounded-2xl transition-all duration-300 ${isActive ? 'bg-[var(--theme-color)] text-white shadow-[0_0_15px_var(--theme-color)] -translate-y-3 scale-110' : 'text-gray-400 group-hover:text-gray-200'}`}>
                                    {item.icon}
                                </div>
                                <span className={`text-[9px] font-bold uppercase tracking-wide transition-all duration-300 ${isActive ? 'text-white opacity-100 -translate-y-2' : 'text-gray-500 opacity-0 translate-y-2'}`}>
                                    {item.label}
                                </span>
                            </button>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default PeopleNearby;
