
import React, { useEffect, useState, useRef } from 'react';
import type { AudioTrack } from '../types';
import { PlayFilledIcon, PauseFilledIcon } from './icons';
import { useAudioPlayer } from './AudioPlayerSystem';

interface ChatAudioBubbleProps {
    track: AudioTrack;
    contextQueue: AudioTrack[];
    isSent: boolean;
}

const ChatAudioBubble: React.FC<ChatAudioBubbleProps> = ({ track, contextQueue, isSent }) => {
    const { currentTrack, isPlaying, togglePlay, playTrack, currentTime, duration: totalDuration } = useAudioPlayer();
    
    const isCurrent = currentTrack?.id === track.id;
    const isActivePlaying = isCurrent && isPlaying;
    
    const progress = isCurrent && totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0;
    
    const waveform = React.useMemo(() => {
        if (track.waveform && track.waveform.length > 0) return track.waveform;
        return Array.from({ length: 30 }).map(() => Math.random() * 0.6 + 0.2);
    }, [track.id, track.waveform]);

    const handlePlayClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (isCurrent) {
            togglePlay();
        } else {
            playTrack(track, contextQueue);
        }
    };

    const formatTime = (time: number) => {
        const minutes = Math.floor(time / 60);
        const seconds = Math.floor(time % 60);
        return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    };

    // Styling constants based on Sent/Received status
    const bubbleBg = isSent 
        ? '' 
        : 'bg-[#2f2b43]';
    const bubbleStyle = isSent ? { backgroundColor: 'var(--theme-color)' } : {};
    
    const buttonBg = isSent ? 'bg-white' : 'text-white';
    const buttonStyle = isSent ? { color: 'var(--theme-color)' } : { backgroundColor: 'var(--theme-color)' };

    const textColor = isSent ? 'text-white/90' : 'text-gray-300';
    
    const waveColorActive = isSent ? 'bg-white' : '';
    const waveStyleActive = isSent ? {} : { backgroundColor: 'var(--theme-color)' };

    const waveColorInactive = isSent ? 'bg-white/40' : 'bg-[#5a5a6e]';

    return (
        <div 
            className={`flex items-center gap-3 p-3 rounded-xl w-full min-w-[240px] max-w-[280px] transition-all duration-200 ${bubbleBg} shadow-sm`}
            style={bubbleStyle}
        >
            <button 
                onClick={handlePlayClick}
                className={`relative w-11 h-11 flex-shrink-0 flex items-center justify-center rounded-lg shadow-md transition-transform hover:scale-105 active:scale-95 ${buttonBg}`}
                style={buttonStyle}
            >
                 {isActivePlaying ? <PauseFilledIcon className="w-5 h-5" /> : <PlayFilledIcon className="w-5 h-5 ml-0.5" />}
            </button>

            <div className="flex-1 flex flex-col justify-center gap-1.5 min-w-0">
                 {/* Waveform Visualizer */}
                 <div className="flex items-center justify-between h-7 gap-[2px] cursor-pointer group/waveform" onClick={(e) => e.stopPropagation()}>
                    {waveform.map((value, index) => {
                        const barProgress = (index / waveform.length) * 100;
                        const isPlayed = isCurrent && progress >= barProgress;
                        
                        // Animate current bar if playing
                        const isAnimating = isActivePlaying && Math.abs(barProgress - progress) < 5;
                        
                        return (
                            <div 
                                key={index} 
                                className={`w-1 rounded-full transition-all duration-150 ease-in-out ${isPlayed ? waveColorActive : waveColorInactive}`}
                                style={{ 
                                    height: `${Math.max(20, value * 100 * (isAnimating ? 1.2 : 1))}%`,
                                    opacity: isPlayed ? 1 : 0.6,
                                    ...(isPlayed ? waveStyleActive : {})
                                }}
                            />
                        );
                    })}
                </div>

                <div className={`flex justify-between text-[10px] font-bold font-mono tracking-wider px-0.5 ${textColor}`}>
                    <span>{isCurrent ? formatTime(currentTime) : formatTime(track.duration)}</span>
                    <span>{formatTime(track.duration)}</span>
                </div>
            </div>
        </div>
    );
};

export default ChatAudioBubble;
