
import React, { useState, useEffect } from 'react';
import type { NotificationSettings } from '../types';
import { 
    BellIcon, ChatIcon, UserAddIcon, VideoCameraIcon, 
    AtSymbolIcon, CalendarIcon, SpeakerphoneIcon, 
    CheckIcon, XIcon, MoonIcon, ChevronDownIcon
} from './icons';

interface NotificationsSettingsProps {
    settings: NotificationSettings;
    onSettingsChange: (settings: NotificationSettings) => void;
}

const SectionHeader: React.FC<{ title: string }> = ({ title }) => (
    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 mt-6 ml-1">
        {title}
    </h3>
);

const Toggle: React.FC<{ enabled: boolean; onToggle: () => void }> = ({ enabled, onToggle }) => (
    <button
        onClick={onToggle}
        className={`relative w-12 h-7 flex items-center rounded-full p-1 transition-all duration-300 ${
            enabled ? 'bg-[var(--theme-color)] shadow-lg shadow-[var(--theme-color)]/30' : 'bg-[#2c2c35]'
        }`}
    >
        <div
            className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-300 ease-out ${
                enabled ? 'translate-x-5' : 'translate-x-0'
            }`}
        />
    </button>
);

const SettingCard: React.FC<{
    icon: React.ReactNode;
    color: string;
    title: string;
    description: string;
    enabled: boolean;
    onToggle: () => void;
}> = ({ icon, color, title, description, enabled, onToggle }) => (
    <div 
        onClick={onToggle}
        className="group flex items-center justify-between p-4 bg-white/5 hover:bg-white/[0.08] border border-white/5 rounded-2xl transition-all cursor-pointer"
    >
        <div className="flex items-center gap-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white shadow-lg transition-transform group-hover:scale-110 ${color}`}>
                {icon}
            </div>
            <div>
                <p className="font-semibold text-white text-sm">{title}</p>
                <p className="text-xs text-gray-400 mt-0.5">{description}</p>
            </div>
        </div>
        <Toggle enabled={enabled} onToggle={onToggle} />
    </div>
);

const PermissionBanner: React.FC<{ 
    status: NotificationPermission; 
    onRequest: () => void;
    onTest: () => void; 
}> = ({ status, onRequest, onTest }) => {
    const isGranted = status === 'granted';
    const isDenied = status === 'denied';

    return (
        <div className={`relative overflow-hidden rounded-3xl p-6 border transition-all ${
            isGranted 
                ? 'bg-gradient-to-br from-green-900/20 to-emerald-900/20 border-green-500/30' 
                : isDenied 
                    ? 'bg-gradient-to-br from-red-900/20 to-orange-900/20 border-red-500/30'
                    : 'bg-gradient-to-br from-blue-900/20 to-indigo-900/20 border-blue-500/30'
        }`}>
            <div className="flex items-start justify-between relative z-10">
                <div className="flex gap-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-xl ${
                        isGranted ? 'bg-green-500' : isDenied ? 'bg-red-500' : 'bg-blue-500'
                    }`}>
                        <BellIcon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-white">
                            {isGranted ? 'System Enabled' : isDenied ? 'System Blocked' : 'Enable Notifications'}
                        </h3>
                        <p className="text-sm text-gray-300 mt-1 max-w-xs leading-relaxed">
                            {isGranted 
                                ? 'SyncWatch has permission to send push notifications to this device.' 
                                : isDenied 
                                    ? 'Notifications are blocked in browser settings. Please unblock to receive updates.'
                                    : 'Allow notifications to never miss an invite or message.'}
                        </p>
                    </div>
                </div>
                <div>
                    {isGranted ? (
                        <button onClick={onTest} className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-2">
                            <SpeakerphoneIcon className="w-4 h-4" /> Test
                        </button>
                    ) : !isDenied && (
                        <button onClick={onRequest} className="px-6 py-2.5 bg-blue-500 hover:bg-blue-600 text-white text-xs font-bold rounded-xl transition-colors shadow-lg shadow-blue-500/30">
                            Allow Access
                        </button>
                    )}
                </div>
            </div>
            {/* Decorative Background Glow */}
            <div className={`absolute -top-10 -right-10 w-32 h-32 rounded-full blur-[60px] opacity-40 pointer-events-none ${
                isGranted ? 'bg-green-500' : isDenied ? 'bg-red-500' : 'bg-blue-500'
            }`} />
        </div>
    );
};

const AdvancedOptions: React.FC = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Sound Selection Mockup */}
        <div className="p-4 bg-white/5 border border-white/5 rounded-2xl">
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-bold text-gray-300">
                    <SpeakerphoneIcon className="w-4 h-4 text-purple-400" /> Notification Sound
                </div>
            </div>
            <div className="flex items-center justify-between bg-black/30 p-3 rounded-xl cursor-pointer hover:bg-black/40 transition-colors group">
                <span className="text-sm text-white">Cosmic Ping</span>
                <ChevronDownIcon className="w-4 h-4 text-gray-500 group-hover:text-white" />
            </div>
        </div>

        {/* Quiet Mode Mockup */}
        <div className="p-4 bg-white/5 border border-white/5 rounded-2xl relative overflow-hidden">
            <div className="flex items-center justify-between mb-1 relative z-10">
                <div className="flex items-center gap-2 text-sm font-bold text-gray-300">
                    <MoonIcon className="w-4 h-4 text-indigo-400" /> Quiet Mode
                </div>
                <Toggle enabled={false} onToggle={() => {}} />
            </div>
            <p className="text-xs text-gray-500 relative z-10">Automatically mute notifications at night.</p>
            <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-indigo-500/10 rounded-full blur-xl"></div>
        </div>
    </div>
);

const NotificationsSettings: React.FC<NotificationsSettingsProps> = ({ settings, onSettingsChange }) => {
    
    const [permission, setPermission] = useState<NotificationPermission>('default');

    useEffect(() => {
        if ('Notification' in window) {
            setPermission(Notification.permission);
        }
    }, []);

    const handleRequestPermission = async () => {
        if (!('Notification' in window)) return;
        const result = await Notification.requestPermission();
        setPermission(result);
        if (result === 'granted') {
            new Notification('Notifications Active', {
                body: 'You are all set to receive updates from SyncWatch.',
                icon: '/vite.svg'
            });
        }
    };

    const handleTest = () => {
        if (permission === 'granted') {
            new Notification('Test Notification', {
                body: 'This is how your notifications will look.',
                icon: '/vite.svg'
            });
        }
    };

    const toggle = (key: keyof NotificationSettings) => {
        onSettingsChange({ ...settings, [key]: !settings[key] });
    };

    return (
        <div className="space-y-2 pb-10">
            <PermissionBanner 
                status={permission} 
                onRequest={handleRequestPermission} 
                onTest={handleTest} 
            />

            <SectionHeader title="Messages & Social" />
            <div className="grid grid-cols-1 gap-3">
                <SettingCard
                    title="Direct Messages"
                    description="Receive alerts when friends message you."
                    icon={<ChatIcon className="w-5 h-5" />}
                    color="bg-gradient-to-br from-blue-500 to-cyan-500"
                    enabled={settings.directMessages}
                    onToggle={() => toggle('directMessages')}
                />
                <SettingCard
                    title="Mentions"
                    description="Get notified when you are @mentioned in a group."
                    icon={<AtSymbolIcon className="w-5 h-5" />}
                    color="bg-gradient-to-br from-orange-500 to-red-500"
                    enabled={settings.chatMentions}
                    onToggle={() => toggle('chatMentions')}
                />
                <SettingCard
                    title="Friend Requests"
                    description="New friend requests and acceptances."
                    icon={<UserAddIcon className="w-5 h-5" />}
                    color="bg-gradient-to-br from-green-500 to-emerald-500"
                    enabled={settings.friendRequests}
                    onToggle={() => toggle('friendRequests')}
                />
            </div>

            <SectionHeader title="Activity" />
            <div className="grid grid-cols-1 gap-3">
                <SettingCard
                    title="Friend Joins Room"
                    description="Know when your friends start watching something."
                    icon={<VideoCameraIcon className="w-5 h-5" />}
                    color="bg-gradient-to-br from-purple-500 to-indigo-500"
                    enabled={settings.friendJoins}
                    onToggle={() => toggle('friendJoins')}
                />
                <SettingCard
                    title="Video Queue Updates"
                    description="Alerts when a new video is added to the queue."
                    icon={<CheckIcon className="w-5 h-5" />}
                    color="bg-gradient-to-br from-pink-500 to-rose-500"
                    enabled={settings.videoInQueue}
                    onToggle={() => toggle('videoInQueue')}
                />
            </div>

            <SectionHeader title="System" />
            <div className="grid grid-cols-1 gap-3">
                <SettingCard
                    title="Event Reminders"
                    description="Notifications for scheduled watch parties."
                    icon={<CalendarIcon className="w-5 h-5" />}
                    color="bg-gradient-to-br from-yellow-500 to-amber-600"
                    enabled={settings.eventReminders}
                    onToggle={() => toggle('eventReminders')}
                />
            </div>

            <SectionHeader title="Advanced" />
            <AdvancedOptions />
        </div>
    );
};

export default NotificationsSettings;
