
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { User, DirectMessage, AudioTrack } from '../types';
import { ReplyIcon, CloseIcon, PlayIcon, DownloadIcon, WaveIcon, FileZipIcon, FileIcon, SpinnerIcon, CheckIcon, DoubleCheckIcon, ForwardIcon, PlayFilledIcon, PauseFilledIcon, UsersIcon, ArrowRightIcon, TranslateIcon } from './icons';
import ChatAudioBubble from './ChatAudioBubble';
import MusicMessageBubble from './MusicMessageBubble';

const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

const FileIconComponent: React.FC<{ fileName: string, className?: string }> = ({ fileName, className }) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    if (extension === 'zip' || extension === 'rar') {
        return <FileZipIcon className={className} />;
    }
    return <FileIcon className={className} />;
};

const FileUploadItem: React.FC<{ fileInfo: { name: string; size: number }, progress: number, onCancel?: () => void }> = ({ fileInfo, progress, onCancel }) => {
    return (
        <div className="w-72 max-w-full bg-black/30 backdrop-blur-lg border border-white/10 rounded-xl p-4 space-y-3 relative overflow-hidden" style={{ boxShadow: '0 0 20px rgba(128, 90, 213, 0.2)'}}>
            {onCancel && (
                 <button onClick={onCancel} className="absolute top-2 right-2 text-gray-400 hover:text-white bg-black/30 p-1 rounded-lg z-10">
                    <CloseIcon className="w-4 h-4" />
                 </button>
            )}
            <div className="flex items-center gap-3">
                <FileIconComponent fileName={fileInfo.name} className="w-10 h-10 text-gray-300 flex-shrink-0" />
                <div className="truncate">
                    <p className="font-semibold text-white truncate">{fileInfo.name}</p>
                    <p className="text-sm text-gray-400">{formatBytes(fileInfo.size)}</p>
                </div>
            </div>
            <div>
                <div className="flex justify-between items-center text-sm mb-1">
                    <div className="flex items-center gap-2 text-gray-300">
                        <SpinnerIcon className="w-4 h-4 animate-spin" />
                        <span>Uploading...</span>
                    </div>
                    <span className="font-semibold text-white">{Math.floor(progress)}%</span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                    <div className="bg-white h-full rounded-full transition-all duration-300" style={{ width: `${progress}%`, boxShadow: '0 0 8px #fff, 0 0 12px #fff' }}></div>
                </div>
            </div>
        </div>
    );
};

const FileMessageItem: React.FC<{ fileInfo: { name: string; size: number } }> = ({ fileInfo }) => {
     return (
        <div className="w-72 max-w-full bg-black/30 backdrop-blur-lg border border-white/10 rounded-xl p-4 flex items-center justify-between gap-3" style={{ boxShadow: '0 0 20px rgba(128, 90, 213, 0.1)'}}>
            <div className="flex items-center gap-3 truncate">
                <FileIconComponent fileName={fileInfo.name} className="w-10 h-10 text-gray-300 flex-shrink-0" />
                <div className="truncate">
                    <p className="font-semibold text-white truncate">{fileInfo.name}</p>
                    <p className="text-sm text-gray-400">{formatBytes(fileInfo.size)}</p>
                </div>
            </div>
             <a href="#" download={fileInfo.name} className="flex-shrink-0 p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors" title="Download">
                <DownloadIcon className="w-5 h-5" />
            </a>
        </div>
    );
}

const ProgressOverlay: React.FC<{ progress: number, onCancel: () => void, size: number, type: 'upload' | 'download' }> = ({ progress, onCancel, size, type }) => {
    const circumference = 2 * Math.PI * 24;
    const offset = circumference - (progress / 100) * circumference;

    return (
        <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-3 rounded-lg text-white z-10 backdrop-blur-sm transition-opacity duration-300">
            <div className="relative w-16 h-16 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                    <circle cx="32" cy="32" r="24" strokeWidth="4" stroke="rgba(255,255,255,0.1)" fill="none" />
                    <circle
                        cx="32"
                        cy="32"
                        r="24"
                        strokeWidth="4"
                        stroke="#8A79F7"
                        fill="none"
                        strokeLinecap="round"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        className="transition-all duration-300"
                    />
                </svg>
                <button onClick={onCancel} className="absolute inset-0 flex items-center justify-center group">
                    <CloseIcon className="w-5 h-5 text-white/80 group-hover:text-white group-hover:scale-110 transition-transform"/>
                </button>
            </div>
            <div className="text-center">
                 <span className="block font-bold text-lg">{Math.round(progress)}%</span>
                 {size > 0 && (
                     <span className="block text-xs font-mono opacity-70 mt-1 bg-black/30 px-2 py-0.5 rounded">
                        {formatBytes((progress / 100) * size)} / {formatBytes(size)}
                     </span>
                 )}
                 <span className="block text-[10px] uppercase tracking-widest opacity-50 mt-1">{type}ing</span>
            </div>
        </div>
    );
};

// --- New Optimized Card Components ---

const RoomInviteCard: React.FC<{invite: NonNullable<DirectMessage['roomInvite']>, onJoinRoom: (id: number) => void}> = ({ invite, onJoinRoom }) => (
    <div 
        className="relative w-72 aspect-video rounded-xl overflow-hidden shadow-2xl border border-white/10 group cursor-pointer bg-black"
        onClick={() => onJoinRoom(invite.roomId)}
    >
        {/* Background Image */}
        <img 
            src={invite.thumbnail} 
            alt={invite.roomName} 
            className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-50 group-hover:scale-105 transition-all duration-500"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-90" />

        {/* Content */}
        <div className="absolute inset-0 p-4 flex flex-col justify-between z-10">
            <div className="flex justify-between items-start">
                <span className="bg-red-600/90 text-white text-[9px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider shadow-lg">
                    Watch Party
                </span>
                <div className="w-6 h-6 bg-white/10 rounded-lg flex items-center justify-center backdrop-blur-md border border-white/10">
                    <PlayFilledIcon className="w-3 h-3 text-white" />
                </div>
            </div>

            <div>
                <h3 className="font-bold text-white text-lg leading-tight drop-shadow-lg truncate mb-1 w-full" title={invite.roomName}>
                    {invite.roomName}
                </h3>
                <button className="mt-2 w-full py-1.5 bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/20 rounded-lg text-xs font-bold text-white transition-all flex items-center justify-center gap-1 group-hover:bg-[var(--theme-color)] group-hover:border-transparent">
                    Join Now <ArrowRightIcon className="w-3 h-3" />
                </button>
            </div>
        </div>
    </div>
);

const VoiceRoomInviteCard: React.FC<{invite: NonNullable<DirectMessage['voiceRoomInvite']>, onJoinRoom: (id: number) => void}> = ({ invite, onJoinRoom }) => (
    <div 
        className="relative w-72 rounded-xl overflow-hidden shadow-xl border border-white/10 group cursor-pointer bg-gradient-to-br from-[#2e1065] to-[#4c1d95]"
        onClick={() => onJoinRoom(invite.roomId)}
    >
        {/* Abstract Background Pattern */}
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, rgba(255,255,255,0.1) 0%, transparent 50%)' }}></div>
        <div className="absolute -bottom-4 -right-4 text-white opacity-5 transform rotate-12 scale-150">
            <WaveIcon className="w-32 h-32" />
        </div>

        <div className="relative z-10 p-5">
            <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center backdrop-blur-md border border-white/10 shadow-inner text-green-400">
                    <WaveIcon className="w-6 h-6" />
                </div>
                <div>
                    <div className="text-[10px] font-bold text-green-300 uppercase tracking-wide opacity-80">Voice Chat</div>
                    <div className="flex items-center gap-1 text-white/60 text-xs">
                        <UsersIcon className="w-3 h-3" /> <span>Active now</span>
                    </div>
                </div>
            </div>

            <h3 className="font-bold text-white text-lg leading-snug mb-4 truncate w-full" title={invite.roomTopic}>
                {invite.roomTopic}
            </h3>

            <button className="w-full py-2 bg-white text-black rounded-lg text-xs font-bold hover:bg-gray-200 transition-colors shadow-lg flex items-center justify-center gap-2">
                <UsersIcon className="w-3.5 h-3.5" /> Join Voice
            </button>
        </div>
    </div>
);

const MessageStatusIcon: React.FC<{status?: 'sending' | 'sent' | 'delivered' | 'seen'}> = ({ status }) => {
    if (!status) return null;
    
    if (status === 'sending') {
        return <SpinnerIcon className="w-3 h-3 text-white/50 animate-spin" />;
    }

    const colorClass = status === 'seen' ? 'text-[#4CC2FF]' : 'text-white/50';

    return (
        <div className={`flex items-center ${colorClass}`}>
            <svg width="14" height="10" viewBox="0 0 16 11" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-2.5">
                {/* First Tick (Sent) */}
                <path d="M1.5 5.5L4.5 8.5L10.5 2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                
                {/* Second Tick (Delivered/Seen) */}
                {(status === 'delivered' || status === 'seen') && (
                    <path d="M7.5 8.5L10.5 5.5L14.5 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="-ml-2" />
                )}
            </svg>
        </div>
    );
}

export const DirectMessageItem = React.forwardRef<HTMLDivElement, {message: DirectMessage, isSent: boolean, friend: User, currentUser: User, selectionMode: boolean, onOpenContextMenu: (e: React.MouseEvent | React.TouchEvent) => void, onAddReaction: (emoji: string) => void, onJoinRoom: (id: number) => void, onJoinVoiceRoom: (id: number) => void, onReplyClick: (id: number) => void, onViewMedia: (media: DirectMessage) => void, onCancelUpload: () => void, getReplyPreviewText: (msg: DirectMessage) => string, onReplyRequest: (message: DirectMessage) => void, disableInteractions?: boolean, audioContextQueue?: AudioTrack[], onViewProfile?: (user: User) => void, translation?: string }>(({ message, isSent, friend, currentUser, selectionMode, onOpenContextMenu, onAddReaction, onJoinRoom, onJoinVoiceRoom, onReplyClick, onViewMedia, onCancelUpload, getReplyPreviewText, onReplyRequest, disableInteractions = false, audioContextQueue = [], onViewProfile, translation }, ref) => {
    
    const [isExpanded, setIsExpanded] = useState(false);
    const [translateX, setTranslateX] = useState(0);
    const [showReplyIcon, setShowReplyIcon] = useState(false);
    const swipeState = useRef({
        startX: 0,
        isSwiping: false,
        isDragging: false,
    });
    const SWIPE_THRESHOLD = 60;
    const bubbleRef = useRef<HTMLDivElement>(null);
    const longPressTimer = useRef<number | undefined>(undefined);
    const [isMouseDown, setIsMouseDown] = useState(false);
    
    const textContent = message.message || message.caption;
    const canBeCollapsed = textContent && (textContent.length > 400 || textContent.split('\n').length > 8);
    const isCollapsed = canBeCollapsed && !isExpanded;
    const displayedText = isCollapsed && textContent ? textContent.substring(0, 400) + '...' : textContent;
    
    // Detect if message is an audio file (but not a voice message)
    const isAudioFile = message.fileInfo && message.fileInfo.name.match(/\.(mp3|wav|ogg|m4a)$/i) && !message.voiceMessage;
    const isFileMessage = message.fileInfo && !message.imageUrl && !message.videoUrl && !isAudioFile;
    const isInviteMessage = !!message.roomInvite || !!message.voiceRoomInvite;

    const handleInteractionEnd = useCallback(() => {
        if (longPressTimer.current) {
            clearTimeout(longPressTimer.current);
            longPressTimer.current = undefined;
        }
        if (!swipeState.current.isSwiping) return;

        swipeState.current.isSwiping = false;

        if (swipeState.current.isDragging && translateX >= SWIPE_THRESHOLD) {
            onReplyRequest(message);
        }

        const bubble = bubbleRef.current;
        if (bubble) {
            bubble.style.transition = 'transform 0.3s cubic-bezier(0.18, 0.89, 0.32, 1.28)';
        }
        setTranslateX(0);
        setShowReplyIcon(false);
        setTimeout(() => {
            if (bubble) bubble.style.transition = 'none';
        }, 300);
    }, [translateX, onReplyRequest, message]);

    const handleInteractionMove = useCallback((e: React.TouchEvent | MouseEvent) => {
        if (!swipeState.current.isSwiping) return;
        const currentX = 'touches' in e ? e.touches[0].clientX : e.clientX;
        const deltaX = currentX - swipeState.current.startX;

        if (Math.abs(deltaX) > 10) {
            swipeState.current.isDragging = true;
            if (longPressTimer.current) {
                clearTimeout(longPressTimer.current);
                longPressTimer.current = undefined;
            }
        }
        if (!swipeState.current.isDragging) return;
        
        const moveX = Math.max(0, deltaX);
        setTranslateX(Math.min(moveX, SWIPE_THRESHOLD + 30));

        setShowReplyIcon(moveX > SWIPE_THRESHOLD / 2);
    }, []);

    const handleInteractionStart = useCallback((e: React.TouchEvent | React.MouseEvent) => {
        if (selectionMode || ('button' in e && e.button !== 0) || disableInteractions) return;
        
        swipeState.current.isSwiping = true;
        swipeState.current.isDragging = false;
        swipeState.current.startX = 'touches' in e ? e.touches[0].clientX : e.clientX;

        if (!('touches' in e)) {
            setIsMouseDown(true);
        }

        longPressTimer.current = window.setTimeout(() => {
            if (swipeState.current.isSwiping && !swipeState.current.isDragging) {
                onOpenContextMenu(e);
            }
            swipeState.current.isSwiping = false;
            setIsMouseDown(false);
        }, 300);
    }, [selectionMode, onOpenContextMenu, disableInteractions]);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => handleInteractionMove(e);
        const handleMouseUp = () => {
            setIsMouseDown(false);
            handleInteractionEnd();
        };

        if (isMouseDown) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }

        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isMouseDown, handleInteractionMove, handleInteractionEnd]);

    const TextContentComponent = () => {
        if (!displayedText && !message.voiceMessage && !isFileMessage && !isAudioFile) return null;

        return (
            <div>
                 {displayedText && <p className="whitespace-pre-wrap break-all">{displayedText}</p>}
                {isCollapsed && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); setIsExpanded(true); }}
                        className="text-sm font-semibold text-purple-300 hover:underline mt-1"
                    >
                        Show More
                    </button>
                )}
                {canBeCollapsed && isExpanded && (
                     <button 
                        onClick={(e) => { e.stopPropagation(); setIsExpanded(false); }}
                        className="text-sm font-semibold text-purple-300 hover:underline mt-1"
                    >
                        Show Less
                    </button>
                )}
            </div>
        );
    };
    
    const replyUser = message.replyTo ? (message.replyTo.senderId === friend.id ? friend.name : 'You') : '';
    
    const MediaComponent = () => {
        const isUploading = typeof message.uploadProgress === 'number' && message.uploadProgress < 100;
        const isDownloading = typeof message.downloadProgress === 'number' && message.downloadProgress < 100;
        const isTransmitting = isUploading || isDownloading;
        const progress = isUploading ? message.uploadProgress : message.downloadProgress;
        
        const fileSize = message.fileInfo?.size || (message.videoUrl ? 25 * 1024 * 1024 : 3 * 1024 * 1024);

        if (message.imageUrl) return (
            <div className="relative cursor-pointer group/media overflow-hidden rounded-lg" onClick={!isTransmitting ? () => onViewMedia(message) : undefined}>
                <img src={message.imageUrl} alt="attachment" className={`max-h-[500px] w-full object-cover ${isTransmitting ? 'filter blur-sm scale-105' : ''} transition-all duration-500`} />
                {isTransmitting && <ProgressOverlay progress={progress ?? 0} onCancel={onCancelUpload} size={fileSize} type={isUploading ? 'upload' : 'download'} />}
            </div>
        );
        if (message.videoUrl && !isAudioFile) return (
             <div className="relative group/media overflow-hidden rounded-lg bg-black w-full min-w-[250px]">
                <video 
                    src={message.videoUrl} 
                    className={`max-h-[500px] w-full object-contain ${isTransmitting ? 'filter blur-md opacity-50' : ''}`} 
                    preload="metadata"
                    controls={!isTransmitting}
                    playsInline
                    onClick={!isTransmitting ? (e) => e.stopPropagation() : (e) => e.preventDefault()}
                />

                {isTransmitting && <ProgressOverlay progress={progress ?? 0} onCancel={onCancelUpload} size={fileSize} type={isUploading ? 'upload' : 'download'} />}
                
                {!isTransmitting && (
                    <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded-md font-mono font-bold pointer-events-none transition-opacity z-10 shadow-sm">
                        {formatBytes(fileSize)}
                    </div>
                )}
            </div>
        );
        return null;
    }

    // Transparent BG check
    const isTransparentBg = isFileMessage || message.voiceMessage || isInviteMessage || isAudioFile;

    return (
        <div ref={ref} className={`flex w-full items-center ${isSent ? 'justify-end' : 'justify-start'}`}>
            <div className={`relative ${selectionMode ? (isSent ? 'order-1' : 'order-2') : ''}`}
                 onTouchStart={handleInteractionStart}
                 onTouchMove={handleInteractionMove}
                 onTouchEnd={handleInteractionEnd}
                 onMouseDown={handleInteractionStart}
            >
                <div className={`absolute inset-y-0 my-auto h-6 flex items-center -left-8 transition-all duration-200 ${showReplyIcon ? 'opacity-100 scale-100' : 'opacity-0 scale-50'}`}>
                    <ReplyIcon className="w-5 h-5 text-white" />
                </div>
                <div 
                    ref={bubbleRef}
                    className="swipeable-content"
                    style={{transform: `translateX(${translateX}px)`}}
                >
                    <div className={`flex flex-col max-w-[90%] md:max-w-xl my-1 ${isSent ? 'items-end' : 'items-start'}`}>
                        <div onDoubleClick={() => onAddReaction('❤️')} 
                             onContextMenu={(e) => {
                                if (!swipeState.current.isDragging) onOpenContextMenu(e);
                                else e.preventDefault();
                             }}
                             className={`relative break-words shadow-md group 
                            ${isTransparentBg ? 'bg-transparent p-0' : 'px-3 py-2 text-sm'} 
                            ${isSent ? 
                            (isTransparentBg ? '' : 'text-white rounded-xl rounded-tr-sm') : 
                            (isTransparentBg ? '' : 'bg-[#2f2b43] text-gray-200 rounded-xl rounded-tl-sm')
                            }`}
                            style={isSent && !isTransparentBg ? { backgroundColor: 'var(--theme-color)' } : undefined}
                            >

                            {isAudioFile ? (
                                <MusicMessageBubble 
                                    track={{
                                        id: message.id.toString(),
                                        url: message.videoUrl || '', // Assuming videoUrl holds the audio file URL for uploads
                                        title: message.fileInfo?.name || 'Audio File',
                                        artist: isSent ? currentUser.name : friend.name,
                                        duration: 0, // Duration not usually known for generic files without loading
                                        contextId: friend.id
                                    }}
                                    isSent={isSent}
                                    fileSize={message.fileInfo?.size || 0}
                                    fileName={message.fileInfo?.name || 'Audio'}
                                />
                            ) : isFileMessage ? (
                                message.uploadProgress !== undefined && message.uploadProgress < 100 ? (
                                    <FileUploadItem fileInfo={message.fileInfo!} progress={message.uploadProgress} onCancel={onCancelUpload} />
                                ) : (
                                    <FileMessageItem fileInfo={message.fileInfo!} />
                                )
                            ) : (
                                <>
                                    {message.forwardedFrom && (
                                        <div 
                                            className={`flex items-center gap-1.5 mb-1.5 cursor-pointer group/forward ${isTransparentBg ? 'bg-black/30 backdrop-blur-sm' : 'bg-black/10'} p-1 rounded-lg`}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (onViewProfile && message.forwardedFrom) {
                                                    onViewProfile(message.forwardedFrom);
                                                }
                                            }}
                                        >
                                            <ForwardIcon className="w-3 h-3 text-purple-300 flex-shrink-0" />
                                            <div className="flex items-center gap-1.5 overflow-hidden">
                                                <span className="text-[10px] text-purple-300 font-medium whitespace-nowrap">Forwarded from</span>
                                                <img src={message.forwardedFrom.avatar} className="w-3.5 h-3.5 rounded-full flex-shrink-0 border border-white/20" />
                                                <span className="text-[10px] font-bold text-white truncate group-hover/forward:underline">{message.forwardedFrom.name}</span>
                                            </div>
                                        </div>
                                    )}
                                    
                                    {message.replyTo && (
                                        <div onClick={() => message.replyTo && onReplyClick(message.replyTo.id)} className={`border-l-2 border-purple-400 pl-2 mb-1.5 opacity-80 cursor-pointer ${isTransparentBg ? 'bg-black/30 backdrop-blur-sm' : 'bg-black/10'} p-1.5 rounded-sm`}>
                                            <p className="font-bold text-purple-300 text-xs">{replyUser}</p>
                                            <p className="text-gray-300 text-xs truncate">{getReplyPreviewText(message.replyTo)}</p>
                                        </div>
                                    )}
                                    <div className="space-y-1.5">
                                        {(message.imageUrl || message.videoUrl) && <MediaComponent />}
                                        <TextContentComponent />
                                        {translation && (
                                            <div className={`mt-2 pt-2 border-t ${isSent ? 'border-white/20' : 'border-white/10'} text-xs italic ${isSent ? 'text-white/80' : 'text-gray-300'}`}>
                                                <div className="flex items-center gap-1 mb-1 text-[10px] font-bold opacity-80 uppercase">
                                                    <TranslateIcon className="w-3 h-3" /> Translated
                                                </div>
                                                {translation}
                                            </div>
                                        )}
                                        {message.voiceMessage && (
                                            <ChatAudioBubble 
                                                track={{
                                                    id: message.id.toString(),
                                                    url: message.voiceMessage.url,
                                                    title: 'Voice Message',
                                                    artist: isSent ? currentUser.name : friend.name,
                                                    duration: message.voiceMessage.duration,
                                                    waveform: message.voiceMessage.waveform,
                                                    contextId: friend.id
                                                }}
                                                contextQueue={audioContextQueue}
                                                isSent={isSent}
                                            />
                                        )}
                                        {message.roomInvite && <RoomInviteCard invite={message.roomInvite} onJoinRoom={onJoinRoom} />}
                                        {message.voiceRoomInvite && <VoiceRoomInviteCard invite={message.voiceRoomInvite} onJoinRoom={onJoinVoiceRoom} />}
                                    </div>
                                </>
                            )}
                            
                            {message.reactions && Object.keys(message.reactions).length > 0 && (
                                <div className={`absolute -bottom-3 flex gap-1 ${isSent ? 'left-1' : 'right-1'}`}>
                                    {Object.entries(message.reactions).map(([emoji, count]) => (
                                        <div key={emoji} onClick={() => onAddReaction(emoji)} className="flex items-center text-xs bg-[#2f2b43] rounded-lg px-1.5 py-0.5 shadow-lg animate-bounce-in cursor-pointer border border-white/5">{emoji} <span className="text-white ml-1">{count}</span></div>
                                    ))}
                                </div>
                            )}
                        </div>
                        
                        <div className={`flex items-center gap-1 px-1 mt-1 text-[10px] text-gray-500 ${isSent ? 'flex-row-reverse' : ''}`}>
                            {/* Metadata Row */}
                            {message.isEdited && <span>edited</span>}
                            <span className="font-medium tracking-wide opacity-70">{message.displayTime}</span>
                            {isSent && (
                                <div className="ml-0.5">
                                    <MessageStatusIcon status={message.status} />
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
});