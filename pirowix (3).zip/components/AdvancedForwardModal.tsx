
import React, { useState, useMemo } from 'react';
import type { Friend, User } from '../types';
import { CloseIcon, SendIcon, SearchIcon, EyeOffIcon, EyeIcon, CheckIcon, UserIcon } from './icons';

interface AdvancedForwardModalProps {
    isOpen: boolean;
    onClose: () => void;
    friends: Friend[];
    currentUser: User;
    selectedCount: number;
    onSend: (friendIds: number[], options: { hideSender: boolean }) => void;
}

const AdvancedForwardModal: React.FC<AdvancedForwardModalProps> = ({ isOpen, onClose, friends, currentUser, selectedCount, onSend }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedFriendIds, setSelectedFriendIds] = useState<Set<number>>(new Set());
    const [hideSender, setHideSender] = useState(false);

    const filteredFriends = useMemo(() => 
        friends.filter(friend => 
            friend.name.toLowerCase().includes(searchTerm.toLowerCase()) && friend.id !== currentUser.id
        ), [friends, searchTerm, currentUser.id]);

    // Saved Messages Logic (Self)
    const showSavedMessages = 'saved messages'.includes(searchTerm.toLowerCase()) || 'me'.includes(searchTerm.toLowerCase()) || searchTerm === '';

    const toggleSelection = (id: number) => {
        setSelectedFriendIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) newSet.delete(id);
            else newSet.add(id);
            return newSet;
        });
    };

    const handleSend = () => {
        if (selectedFriendIds.size > 0) {
            onSend(Array.from(selectedFriendIds), { hideSender });
            onClose();
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[150] p-4 animate-fade-in" onClick={onClose}>
            <div 
                className="bg-[#121214] border border-white/10 rounded-[2rem] shadow-2xl w-full max-w-md flex flex-col max-h-[85vh] overflow-hidden animate-slide-in-up ring-1 ring-white/5" 
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="p-5 border-b border-white/5 bg-[#18181b]">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-white">Forward {selectedCount} Message{selectedCount > 1 ? 's' : ''}</h2>
                        <button onClick={onClose} className="text-gray-400 hover:text-white p-2 bg-white/5 hover:bg-white/10 rounded-full transition-colors"><CloseIcon className="w-5 h-5" /></button>
                    </div>

                    {/* Search */}
                    <div className="relative">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input 
                            type="text" 
                            placeholder="Search friends..." 
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full bg-black/30 text-white pl-10 pr-4 py-3 text-sm rounded-xl border border-white/10 focus:outline-none focus:border-[#6C5DD3] transition-colors placeholder-gray-500"
                        />
                    </div>
                </div>

                {/* List */}
                <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar bg-[#121214]">
                    {showSavedMessages && (
                        <div 
                            onClick={() => toggleSelection(currentUser.id)}
                            className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-all border border-transparent group ${selectedFriendIds.has(currentUser.id) ? 'bg-[#6C5DD3]/10 border-[#6C5DD3]/30' : 'hover:bg-white/5'}`}
                        >
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg">
                                    <div className="p-1 bg-white/20 rounded-full">
                                        <UserIcon className="w-5 h-5 text-white" />
                                    </div>
                                </div>
                                <div>
                                    <p className={`font-bold text-sm ${selectedFriendIds.has(currentUser.id) ? 'text-[#8A79F7]' : 'text-white'}`}>Saved Messages</p>
                                    <p className="text-xs text-gray-500">Forward to yourself</p>
                                </div>
                            </div>
                            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${selectedFriendIds.has(currentUser.id) ? 'bg-[#6C5DD3] border-[#6C5DD3]' : 'border-gray-600 group-hover:border-gray-400'}`}>
                                {selectedFriendIds.has(currentUser.id) && <CheckIcon className="w-3.5 h-3.5 text-white" />}
                            </div>
                        </div>
                    )}

                    {filteredFriends.length > 0 ? (
                        filteredFriends.map(friend => {
                            const isSelected = selectedFriendIds.has(friend.id);
                            return (
                                <div 
                                    key={friend.id} 
                                    onClick={() => toggleSelection(friend.id)}
                                    className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-all border border-transparent group ${isSelected ? 'bg-[#6C5DD3]/10 border-[#6C5DD3]/30' : 'hover:bg-white/5'}`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className="relative">
                                            <img src={friend.avatar} alt={friend.name} className="w-12 h-12 rounded-full object-cover bg-gray-800" />
                                            <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#121214] ${friend.status === 'online' ? 'bg-green-500' : 'bg-gray-500'}`}></span>
                                        </div>
                                        <div>
                                            <p className={`font-bold text-sm ${isSelected ? 'text-[#8A79F7]' : 'text-white'}`}>{friend.name}</p>
                                            <p className="text-xs text-gray-500">{friend.status === 'ingame' ? 'In a room' : friend.status}</p>
                                        </div>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? 'bg-[#6C5DD3] border-[#6C5DD3]' : 'border-gray-600 group-hover:border-gray-400'}`}>
                                        {isSelected && <CheckIcon className="w-3.5 h-3.5 text-white" />}
                                    </div>
                                </div>
                            );
                        })
                    ) : !showSavedMessages && (
                        <p className="text-center text-gray-500 p-8 text-sm">No friends found.</p>
                    )}
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-white/10 bg-[#18181b] space-y-4">
                    {/* Hide Sender Toggle */}
                    <div 
                        onClick={() => setHideSender(!hideSender)}
                        className="flex items-center justify-between px-2 cursor-pointer group"
                    >
                        <div className="flex items-center gap-2">
                            {hideSender ? <EyeOffIcon className="w-5 h-5 text-[#8A79F7]" /> : <EyeIcon className="w-5 h-5 text-gray-400" />}
                            <span className={`text-sm font-medium ${hideSender ? 'text-[#8A79F7]' : 'text-gray-400 group-hover:text-gray-200'}`}>Hide Sender Name</span>
                        </div>
                        <div className={`w-10 h-6 rounded-full p-1 transition-colors duration-300 ${hideSender ? 'bg-[#6C5DD3]' : 'bg-gray-700'}`}>
                            <div className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform duration-300 ${hideSender ? 'translate-x-4' : 'translate-x-0'}`} />
                        </div>
                    </div>

                    <button 
                        onClick={handleSend}
                        disabled={selectedFriendIds.size === 0}
                        className="w-full py-3.5 bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] text-white font-bold rounded-xl shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all transform active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                    >
                        <SendIcon className="w-5 h-5" />
                        {selectedFriendIds.size === 0 ? 'Select Recipients' : `Forward to ${selectedFriendIds.size} Chat${selectedFriendIds.size > 1 ? 's' : ''}`}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AdvancedForwardModal;
