import React, { useState, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';

const EMOJIS = ['👏', '😂', '❤️', '😮', '👍'];

interface Reaction {
  id: number;
  emoji: string;
  x: number;
  y: number;
}

export interface VoiceRoomReactionsHandles {
    addReaction: (emoji: string) => void;
}

const VoiceRoomReactions = forwardRef<VoiceRoomReactionsHandles>((props, ref) => {
  const [reactions, setReactions] = useState<Reaction[]>([]);

  const addReaction = useCallback((emoji: string) => {
    const newReaction: Reaction = {
      id: Date.now() + Math.random(),
      emoji,
      x: Math.random() * 80 + 10, // position from 10% to 90%
      y: 100,
    };
    setReactions(prev => [...prev.slice(-20), newReaction]); // Keep max 20 reactions
  }, []);

  useImperativeHandle(ref, () => ({
      addReaction,
  }));

  useEffect(() => {
    if (reactions.length > 0) {
      const timer = setTimeout(() => {
        setReactions(prev => prev.slice(1));
      }, 4000); // Reactions disappear after 4 seconds
      return () => clearTimeout(timer);
    }
  }, [reactions]);

  // Simulate reactions from other users
  useEffect(() => {
      const interval = setInterval(() => {
          if (document.visibilityState === 'visible') {
              const randomEmoji = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
              addReaction(randomEmoji);
          }
      }, 2500);
      return () => clearInterval(interval);
  }, [addReaction]);

  return (
    <>
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {reactions.map(r => (
          <span
            key={r.id}
            className="absolute text-4xl animate-float-up"
            style={{ left: `${r.x}%`, bottom: '-10%' }}
          >
            {r.emoji}
          </span>
        ))}
        <style>{`
          @keyframes float-up {
            0% { transform: translateY(0) scale(0.8); opacity: 1; }
            100% { transform: translateY(-500px) scale(1.2); opacity: 0; }
          }
          .animate-float-up { animation: float-up 4s ease-out forwards; }
        `}</style>
      </div>
    </>
  );
});

export default VoiceRoomReactions;