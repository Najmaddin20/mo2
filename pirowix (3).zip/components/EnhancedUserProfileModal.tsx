
import React, { useState, useRef, useEffect } from 'react';
import type { User } from '../types';
import { CloseIcon, UserAddIcon, ChatIcon, MicrophoneIcon, HeadphonesIcon, CrownIcon, ShareIcon, ShieldIcon, BlockUserIcon, MoreHorizIcon, LinkIcon, VerifiedIcon, PlayIcon, ClockIcon, StarIcon } from './icons';
import AppActivityWidget from './AppActivityWidget';

interface EnhancedUserProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User;
    onAddFriend: (userId: number) => { status: 'success' } | { status: 'error', message: string };
    currentUserId: number;
    onStartChat: (userId: number) => void;
    context?: 'general' | 'watch' | 'voice';
    onBlockUser?: (userId: number) => void;
}

// --- Sub-Components ---

const WatchHistoryChart: React.FC<{ data: { genre: string, hours: number }[] }> = ({ data }) => {
    const maxHours = Math.max(...data.map(d => d.hours), 0);
    const colors = ['bg-purple-500', 'bg-indigo-500', 'bg-blue-500', 'bg-sky-500', 'bg-cyan-500'];

    return (
        <div className="space-y-3 animate-fade-in bg-white/5 p-5 rounded-2xl border border-white/5 h-full flex flex-col">
            <div className="flex justify-between items-center mb-2">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div> Top Genres
                </h4>
                <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-gray-400">Lifetime</span>
            </div>
            <div className="space-y-3 flex-1 overflow-y-auto custom-scrollbar pr-1">
                {data.map((item, index) => (
                    <div key={item.genre} className="flex items-center text-xs gap-3 group">
                        <div className="w-20 font-medium text-gray-400 group-hover:text-white transition-colors truncate text-right">{item.genre}</div>
                        <div className="flex-1 bg-black/20 rounded-full h-2 overflow-hidden">
                            <div
                                className={`${colors[index % colors.length]} h-full rounded-full animate-bar-fill shadow-[0_0_10px_currentColor] relative`}
                                style={{ width: `${(item.hours / maxHours) * 100}%`, animationDelay: `${index * 100}ms` }}
                            >
                                <div className="absolute inset-0 bg-white/20"></div>
                            </div>
                        </div>
                        <div className="w-10 text-right text-gray-500 font-mono group-hover:text-white transition-colors">{item.hours}h</div>
                    </div>
                ))}
            </div>
            <style>{`
                @keyframes bar-fill { 0% { width: 0; } 100% { } }
                .animate-bar-fill { animation: bar-fill 1s ease-out forwards; }
            `}</style>
        </div>
    );
};

const VoiceStatsWidget: React.FC<{ stats: NonNullable<User['voiceStats']> }> = ({ stats }) => {
    const totalMinutes = stats.totalSpeakingMinutes + stats.totalListeningMinutes;
    const speakingPercent = totalMinutes > 0 ? Math.round((stats.totalSpeakingMinutes / totalMinutes) * 100) : 0;

    return (
        <div className="space-y-4 animate-fade-in h-full flex flex-col">
            <div className="grid grid-cols-2 gap-3">
                <div className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border border-purple-500/20 p-4 rounded-2xl text-center relative overflow-hidden group">
                    <div className="absolute inset-0 bg-purple-500/5 group-hover:bg-purple-500/10 transition-colors"></div>
                    <CrownIcon className="w-6 h-6 text-purple-400 mx-auto mb-2 drop-shadow-md group-hover:scale-110 transition-transform" />
                    <span className="text-2xl font-black text-white block tracking-tight">{stats.roomsHosted}</span>
                    <span className="text-[10px] text-purple-300 uppercase font-bold tracking-wider">Hosted</span>
                </div>
                <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 p-4 rounded-2xl text-center relative overflow-hidden group">
                    <div className="absolute inset-0 bg-blue-500/5 group-hover:bg-blue-500/10 transition-colors"></div>
                    <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto mb-2 text-xs font-bold shadow-inner group-hover:scale-110 transition-transform">#</div>
                    <span className="text-2xl font-black text-white block tracking-tight">{stats.roomsJoined}</span>
                    <span className="text-[10px] text-blue-300 uppercase font-bold tracking-wider">Joined</span>
                </div>
            </div>

            <div className="bg-[#1e1931]/50 border border-white/10 rounded-2xl p-5 backdrop-blur-sm flex-1 flex flex-col justify-center relative overflow-hidden">
                 {/* Background decoration */}
                 <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 blur-[40px] rounded-full pointer-events-none"></div>

                <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-4 text-center tracking-widest relative z-10">Audio Presence</h4>
                <div className="space-y-5 relative z-10">
                    <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-green-500/10 text-green-400 border border-green-500/20">
                            <MicrophoneIcon className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between text-xs mb-1.5">
                                <span className="text-gray-300 font-medium">Speaking</span>
                                <span className="text-green-400 font-mono font-bold">{speakingPercent}%</span>
                            </div>
                            <div className="h-2 bg-black/40 rounded-full overflow-hidden border border-white/5">
                                <div className="h-full bg-gradient-to-r from-green-400 to-emerald-500 rounded-full" style={{ width: `${speakingPercent}%` }}></div>
                            </div>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                             <HeadphonesIcon className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                             <div className="flex justify-between text-xs mb-1.5">
                                <span className="text-gray-300 font-medium">Listening</span>
                                <span className="text-blue-400 font-mono font-bold">{100 - speakingPercent}%</span>
                            </div>
                            <div className="h-2 bg-black/40 rounded-full overflow-hidden border border-white/5">
                                <div className="h-full bg-gradient-to-r from-blue-400 to-indigo-500 rounded-full" style={{ width: `${100 - speakingPercent}%` }}></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const EnhancedUserProfileModal: React.FC<EnhancedUserProfileModalProps> = ({ isOpen, onClose, user, onAddFriend, currentUserId, onStartChat, context = 'general', onBlockUser }) => {
    const [isAvatarZoomed, setIsAvatarZoomed] = useState(false);
    const [showMenu, setShowMenu] = useState(false);
    
    // Mobile Sheet States
    const [isExpanded, setIsExpanded] = useState(false);
    const [startY, setStartY] = useState<number | null>(null);
    const [currentY, setCurrentY] = useState(0);
    const [isDragging, setIsDragging] = useState(false);
    const [mobileTab, setMobileTab] = useState<'stats' | 'activity'>('stats');
    
    useEffect(() => {
        if (isOpen) {
            setIsExpanded(false);
            setShowMenu(false);
            setCurrentY(0);
            setMobileTab('stats');
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const isCurrentUser = user.id === currentUserId;

    // Context-Specific Theme & Config
    const config = {
        voice: {
            gradient: 'from-indigo-950 via-[#1e1b2e] to-[#0f0f0f]',
            accent: 'text-purple-400',
            button: 'bg-gradient-to-r from-purple-600 to-indigo-600',
            icon: <MicrophoneIcon className="w-3.5 h-3.5" />,
            label: 'Voice Profile'
        },
        watch: {
            gradient: 'from-slate-900 via-[#1e293b] to-[#0f0f0f]',
            accent: 'text-blue-400',
            button: 'bg-gradient-to-r from-blue-600 to-cyan-600',
            icon: <PlayIcon className="w-3.5 h-3.5" />,
            label: 'Watcher Profile'
        },
        general: {
            gradient: 'from-zinc-900 via-[#18181b] to-[#0f0f0f]',
            accent: 'text-gray-200',
            button: 'bg-white text-black',
            icon: <StarIcon className="w-3.5 h-3.5" />,
            label: 'User Profile'
        }
    }[context] || { gradient: '', accent: '', button: '', icon: null, label: '' };

    // Handlers
    const handleBlock = () => {
        if (confirm(`Are you sure you want to block ${user.name}?`)) {
            if (onBlockUser) onBlockUser(user.id);
            onClose();
        }
    };

    const handleReport = () => {
        alert(`Reported ${user.name} for review.`);
        setShowMenu(false);
    };

    const handleShare = () => {
        const url = `${window.location.origin}/user/${user.id}`;
        navigator.clipboard.writeText(url);
        alert("Profile link copied!");
    };

    // Mobile Touch Handlers
    const handleTouchStart = (e: React.TouchEvent) => {
        setStartY(e.touches[0].clientY);
        setIsDragging(true);
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (startY === null) return;
        const deltaY = e.touches[0].clientY - startY;
        if (isExpanded && deltaY < 0) return;
        setCurrentY(deltaY);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (startY === null) return;
        const threshold = 100;
        if (isExpanded) {
            if (currentY > threshold) setIsExpanded(false);
        } else {
            if (currentY < -threshold) setIsExpanded(true);
            else if (currentY > threshold) onClose();
        }
        setCurrentY(0);
        setStartY(null);
    };

    // ---------------- DESKTOP LAYOUT ----------------
    const DesktopLayout = () => (
        <div className="hidden md:flex fixed inset-0 items-center justify-center z-[151] p-8 pointer-events-none">
            <div className="bg-[#0f0f0f] w-full max-w-5xl h-[650px] rounded-[2.5rem] shadow-2xl border border-white/10 overflow-hidden flex pointer-events-auto relative animate-fade-in-up ring-1 ring-white/5">
                
                <button onClick={onClose} className="absolute top-6 right-6 p-2.5 bg-black/40 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors z-50 backdrop-blur-md border border-white/5">
                    <CloseIcon className="w-5 h-5" />
                </button>

                {/* LEFT COLUMN: Identity */}
                <div className="w-[340px] flex-shrink-0 bg-[#121212] border-r border-white/5 flex flex-col relative">
                    {/* Banner */}
                    <div className={`h-44 bg-gradient-to-b ${config.gradient} relative overflow-hidden`}>
                        {user.profileBanner && (
                            <div className="absolute inset-0 bg-cover bg-center opacity-50 mix-blend-overlay transition-opacity hover:opacity-70" style={{ backgroundImage: `url(${user.profileBanner})` }} />
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent"></div>
                        
                        <div className="absolute top-6 left-6">
                            <div className="bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white/80 flex items-center gap-2 border border-white/5 shadow-sm">
                                {config.icon} {config.label}
                            </div>
                        </div>
                    </div>

                    {/* Avatar & Details */}
                    <div className="flex-1 flex flex-col px-8 relative -mt-16">
                        <div className="relative group self-start cursor-pointer mb-4" onClick={() => setIsAvatarZoomed(true)}>
                            <div className="absolute inset-0 bg-black/50 rounded-full blur-lg"></div>
                            <div className="w-32 h-32 p-1.5 bg-[#121212] rounded-full relative z-10 ring-1 ring-white/5">
                                <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover bg-zinc-800 group-hover:scale-105 transition-transform duration-500" />
                                <div className="absolute bottom-1 right-1 w-7 h-7 bg-[#121212] rounded-full flex items-center justify-center">
                                     <div className="w-4 h-4 bg-green-500 rounded-full border-2 border-[#121212] shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse"></div>
                                </div>
                            </div>
                        </div>

                        <div className="mb-6">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                                <h1 className="text-3xl font-black text-white tracking-tight leading-tight">{user.name}</h1>
                                {user.isVerified && (
                                    <div className="relative group/badge">
                                        <div className="absolute inset-0 bg-blue-500/50 blur-[8px] rounded-full opacity-60"></div>
                                        <div className="relative bg-gradient-to-b from-blue-400 to-blue-600 text-white p-1 rounded-full shadow-lg">
                                            <VerifiedIcon className="w-4 h-4" />
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-400">
                                <span className="font-mono opacity-70">@{user.name.toLowerCase().replace(/\s/g, '')}</span>
                                {user.isHost && <span className="px-2 py-0.5 bg-yellow-500/10 text-yellow-500 text-[10px] font-bold rounded uppercase tracking-wide border border-yellow-500/20 flex items-center gap-1"><CrownIcon className="w-3 h-3"/>Host</span>}
                            </div>
                        </div>

                        <div className="mb-8 flex-1 overflow-y-auto custom-scrollbar max-h-[100px]">
                            <p className="text-sm text-gray-300 leading-relaxed font-light">{user.bio || "No biography provided."}</p>
                        </div>

                        <div className="space-y-3 pb-8 mt-auto">
                            {!isCurrentUser && (
                                <div className="flex gap-3">
                                     {user.isFriend ? (
                                         <button onClick={() => onStartChat(user.id)} className={`flex-1 py-3.5 rounded-xl font-bold text-sm text-white shadow-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 ${config.button}`}>
                                            <ChatIcon className="w-4 h-4" /> Message
                                         </button>
                                     ) : (
                                         <button onClick={() => onAddFriend(user.id)} className="flex-1 py-3.5 bg-white text-black rounded-xl font-bold text-sm shadow-lg hover:bg-gray-200 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2">
                                            <UserAddIcon className="w-4 h-4" /> Add Friend
                                         </button>
                                     )}
                                     <button onClick={() => setShowMenu(!showMenu)} className="p-3.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-gray-400 hover:text-white transition-colors relative">
                                        <MoreHorizIcon className="w-5 h-5" />
                                        {showMenu && (
                                            <div className="absolute bottom-full left-0 mb-2 w-40 bg-[#1e1e24] border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50 animate-fade-in-up ring-1 ring-black/50" onClick={e => e.stopPropagation()}>
                                                <button onClick={handleShare} className="w-full text-left px-4 py-3 text-xs font-bold text-gray-300 hover:text-white hover:bg-white/5 flex items-center gap-3"><ShareIcon className="w-4 h-4" /> Share</button>
                                                <button onClick={handleReport} className="w-full text-left px-4 py-3 text-xs font-bold text-gray-300 hover:text-white hover:bg-white/5 flex items-center gap-3"><ShieldIcon className="w-4 h-4" /> Report</button>
                                                <button onClick={handleBlock} className="w-full text-left px-4 py-3 text-xs font-bold text-red-400 hover:bg-red-500/10 flex items-center gap-3"><BlockUserIcon className="w-4 h-4" /> Block</button>
                                            </div>
                                        )}
                                     </button>
                                </div>
                            )}
                            {isCurrentUser && (
                                <div className="p-4 bg-white/5 rounded-xl text-center text-xs text-gray-500 border border-white/5 border-dashed">This is how others see your profile.</div>
                            )}
                        </div>
                    </div>
                </div>

                {/* RIGHT COLUMN: Contextual Stats */}
                <div className="flex-1 bg-black/20 flex flex-col min-h-0 relative">
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 pointer-events-none"></div>
                    
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-6">
                        
                        {/* Header specific to context */}
                        <div className="flex justify-between items-end border-b border-white/5 pb-4">
                             <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest">Activity & Stats</h3>
                             <span className={`text-xs font-bold ${config.accent}`}>
                                 {context === 'voice' ? 'Microphone Active' : context === 'watch' ? 'Video Player' : 'General Usage'}
                             </span>
                        </div>

                        {/* Context Switching Logic */}
                        {context === 'voice' ? (
                            <div className="animate-fade-in space-y-6">
                                {user.voiceStats ? (
                                    <div className="h-[320px]">
                                        <VoiceStatsWidget stats={user.voiceStats} />
                                    </div>
                                ) : (
                                    <div className="text-gray-500 text-center py-10">No voice data available.</div>
                                )}
                                <div className="grid grid-cols-2 gap-4">
                                    {/* Mock 'Recent Rooms' or similar additional voice info could go here */}
                                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                                        <h4 className="text-[10px] text-gray-400 font-bold uppercase mb-2">Last Seen In</h4>
                                        <p className="text-sm text-white font-medium truncate">Late Night Talks 🌙</p>
                                        <p className="text-xs text-gray-500">2 hours ago</p>
                                    </div>
                                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                                        <h4 className="text-[10px] text-gray-400 font-bold uppercase mb-2">Avg. Session</h4>
                                        <p className="text-sm text-white font-medium">45 Minutes</p>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="animate-fade-in space-y-6">
                                {/* Watch Party Layout */}
                                <div className="h-[280px]">
                                    <WatchHistoryChart data={user.watchHistory || []} />
                                </div>
                                {user.appActivity && (
                                    <div className="w-full">
                                        <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3 tracking-wider">Platform Usage</h4>
                                        <AppActivityWidget activity={user.appActivity} />
                                    </div>
                                )}
                            </div>
                        )}

                    </div>
                </div>
            </div>
        </div>
    );

    // ---------------- MOBILE LAYOUT ----------------
    const MobileLayout = () => (
        <div 
            className={`
                md:hidden fixed z-[151] bg-[#0a0a0a] text-white shadow-[0_-10px_40px_rgba(0,0,0,0.8)] border-t border-white/10
                bottom-0 left-0 right-0 rounded-t-[2.5rem] transition-all duration-300 ease-out
                ${isExpanded ? 'h-[95vh]' : 'h-[75vh]'} 
            `}
            style={{ transform: isDragging ? `translateY(${Math.max(isExpanded ? 0 : -100, currentY)}px)` : undefined }}
            onClick={(e) => e.stopPropagation()}
        >
            <div className="w-full h-full flex flex-col overflow-hidden rounded-t-[2.5rem] relative bg-[#0a0a0a]">
                
                {/* Drag Handle */}
                <div 
                    className="w-full h-12 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none bg-gradient-to-b from-black/20 to-transparent absolute top-0 z-50"
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="w-12 h-1.5 bg-white/20 rounded-full backdrop-blur-md" />
                </div>

                {/* Dynamic Banner */}
                <div className={`relative z-0 h-52 bg-gradient-to-b ${config.gradient} flex-shrink-0 bg-cover bg-center`}>
                    {user.profileBanner && <div className="absolute inset-0 bg-cover bg-center opacity-60 mix-blend-overlay" style={{ backgroundImage: `url(${user.profileBanner})` }} />}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/20 to-transparent" />
                    
                    <div className="absolute top-4 left-6">
                        <div className="bg-black/30 backdrop-blur-xl px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest text-white/80 flex items-center gap-2 border border-white/10 shadow-lg">
                            {config.icon} {config.label}
                        </div>
                    </div>
                    <button onClick={onClose} className="absolute top-4 right-4 bg-black/30 backdrop-blur-xl p-2 rounded-full text-white/70 hover:text-white border border-white/10 shadow-lg">
                        <CloseIcon className="w-5 h-5" />
                    </button>
                </div>

                {/* Content Scroll */}
                <div className="flex-1 overflow-y-auto hide-scrollbar relative -mt-20 px-6 pb-24 z-10">
                    
                    {/* Avatar Row */}
                    <div className="flex justify-between items-end mb-4 px-1">
                        <div className="relative group" onClick={() => setIsAvatarZoomed(true)}>
                            <div className="w-28 h-28 rounded-full p-1 bg-[#0a0a0a] relative z-10 ring-1 ring-white/10 shadow-2xl">
                                <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover bg-zinc-800" />
                            </div>
                            <div className="absolute bottom-2 right-2 w-6 h-6 bg-[#0a0a0a] rounded-full flex items-center justify-center z-20">
                                <div className="w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-[#0a0a0a] animate-pulse"></div>
                            </div>
                        </div>
                        
                        <div className="flex gap-3 mb-2">
                            <button onClick={handleShare} className="w-10 h-10 bg-[#1c1c1e] rounded-full text-gray-300 flex items-center justify-center border border-white/10"><ShareIcon className="w-5 h-5" /></button>
                            {!isCurrentUser && (
                                <button onClick={() => setShowMenu(!showMenu)} className={`w-10 h-10 rounded-full border border-white/10 flex items-center justify-center ${showMenu ? 'bg-white text-black' : 'bg-[#1c1c1e] text-gray-300'}`}>
                                    <MoreHorizIcon className="w-5 h-5" />
                                </button>
                            )}
                        </div>
                    </div>
                    
                    {/* Mobile Context Menu */}
                    {showMenu && (
                        <div className="absolute right-6 top-16 z-50 w-44 bg-[#1e1e24] border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up">
                            <button onClick={handleReport} className="w-full text-left px-4 py-3 text-xs font-bold text-gray-300 flex items-center gap-3 border-b border-white/5"><ShieldIcon className="w-4 h-4" /> Report</button>
                            <button onClick={handleBlock} className="w-full text-left px-4 py-3 text-xs font-bold text-red-400 flex items-center gap-3"><BlockUserIcon className="w-4 h-4" /> Block</button>
                        </div>
                    )}

                    {/* Info */}
                    <div className="mb-6">
                         <div className="flex items-center gap-2 mb-1">
                            <h1 className="text-2xl font-black text-white tracking-tight">{user.name}</h1>
                            {user.isVerified && <VerifiedIcon className="w-4 h-4 text-blue-400" />}
                        </div>
                        <div className="flex items-center gap-2 text-sm mb-4">
                             <span className="text-gray-400 font-mono">@{user.name.toLowerCase().replace(/\s/g, '')}</span>
                             {user.isHost && <span className="text-[9px] font-bold bg-yellow-500/20 text-yellow-500 px-1.5 py-0.5 rounded border border-yellow-500/20">HOST</span>}
                        </div>
                        <p className="text-sm text-gray-300 leading-relaxed font-light opacity-90">{user.bio || "No bio provided."}</p>
                    </div>

                    {/* Mobile Stats Tab Switcher */}
                    <div className="flex bg-white/5 p-1 rounded-xl mb-6 border border-white/5">
                        <button 
                            onClick={() => setMobileTab('stats')} 
                            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${mobileTab === 'stats' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500'}`}
                        >
                            Stats
                        </button>
                        <button 
                            onClick={() => setMobileTab('activity')} 
                            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${mobileTab === 'activity' ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500'}`}
                        >
                            Activity
                        </button>
                    </div>

                    {/* Dynamic Content Area */}
                    <div className="min-h-[250px]">
                        {mobileTab === 'stats' ? (
                             // Context Specific Stats
                            <div className="space-y-4 animate-fade-in">
                                {context === 'voice' && user.voiceStats ? (
                                     <VoiceStatsWidget stats={user.voiceStats} />
                                ) : (
                                    <>
                                         <div className="grid grid-cols-3 gap-3 mb-4">
                                            {[
                                                { label: 'Friends', value: user.friendsCount || 0 },
                                                { label: 'Hours', value: (user.watchHistory || []).reduce((acc, c) => acc + c.hours, 0) },
                                                { label: 'Rooms', value: 12 }
                                            ].map((s, i) => (
                                                <div key={i} className="bg-[#1c1c1e] p-3 rounded-2xl border border-white/5 text-center">
                                                    <div className="text-lg font-black text-white">{s.value}</div>
                                                    <div className="text-[9px] text-gray-500 uppercase font-bold">{s.label}</div>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="h-56">
                                            <WatchHistoryChart data={user.watchHistory || []} />
                                        </div>
                                    </>
                                )}
                            </div>
                        ) : (
                             // Activity View
                            <div className="animate-fade-in">
                                {user.appActivity ? (
                                    <AppActivityWidget activity={user.appActivity} />
                                ) : (
                                    <div className="text-center text-gray-500 py-10 text-sm">No recent activity to show.</div>
                                )}
                            </div>
                        )}
                    </div>

                </div>

                {/* Mobile Sticky Actions */}
                <div className="absolute bottom-0 left-0 right-0 p-5 bg-[#0a0a0a]/90 backdrop-blur-xl border-t border-white/10 z-30 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
                    {!isCurrentUser && (
                        user.isFriend ? (
                            <button onClick={() => onStartChat(user.id)} className={`w-full flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-bold rounded-2xl text-white shadow-lg transition-transform active:scale-95 ${config.button}`}>
                                <ChatIcon className="w-5 h-5" /> Send Message
                            </button>
                        ) : (
                            <button onClick={() => onAddFriend(user.id)} className="w-full flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-bold rounded-2xl text-black bg-white shadow-lg transition-transform active:scale-95">
                                <UserAddIcon className="w-5 h-5" /> Add Friend
                            </button>
                        )
                    )}
                </div>
            </div>
        </div>
    );

    return (
        <>
            <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[150] transition-opacity duration-300" onClick={onClose} />
            <DesktopLayout />
            <MobileLayout />
            
            {isAvatarZoomed && (
                <div className="fixed inset-0 bg-black/95 backdrop-blur-2xl flex items-center justify-center z-[160] animate-fade-in p-4" onClick={() => setIsAvatarZoomed(false)}>
                    <img src={user.avatar} alt={user.name} className="max-w-full max-h-full object-contain rounded-3xl shadow-2xl animate-zoom-in ring-1 ring-white/10" onClick={(e) => e.stopPropagation()} />
                    <button className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md border border-white/10 transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
            )}
        </>
    );
};

export default EnhancedUserProfileModal;
