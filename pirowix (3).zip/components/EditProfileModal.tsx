
import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { User } from '../types';
import { 
    CloseIcon, CameraIcon, CheckIcon, LockClosedIcon, 
    UserIcon, AtSymbolIcon, PhoneIcon, CalendarIcon, MailIcon,
    ImageIcon
} from './icons';

interface EditProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User;
    onUpdateProfile: (updates: Partial<User>) => void;
}

const InputGroup = ({ label, error, children }: { label: string, error?: string | null, children?: React.ReactNode }) => (
    <div className="space-y-1.5">
        <div className="flex justify-between">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider ml-1">{label}</label>
            {error && <span className="text-[10px] font-bold text-red-500 animate-fade-in">{error}</span>}
        </div>
        {children}
    </div>
);

const StyledInput = ({ icon, value, onChange, disabled, type = "text" }: any) => (
    <div className={`relative group flex items-center bg-[#1c1c1e] border border-white/10 rounded-xl focus-within:border-[var(--theme-color)] focus-within:bg-[#252528] transition-all ${disabled ? 'opacity-50' : ''}`}>
        <div className="absolute left-3.5 text-gray-500 group-focus-within:text-white transition-colors">
            {icon}
        </div>
        <input 
            type={type}
            value={value}
            onChange={e => onChange(e.target.value)}
            disabled={disabled}
            className="w-full bg-transparent border-none py-3 pl-10 pr-4 text-sm text-white placeholder-gray-600 focus:outline-none rounded-xl font-medium"
        />
    </div>
);

const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose, user, onUpdateProfile }) => {
    const [isVisible, setIsVisible] = useState(false);
    
    // Form State
    const [avatarPreview, setAvatarPreview] = useState(user.avatar);
    const [bannerPreview, setBannerPreview] = useState(user.profileBanner);
    const [displayName, setDisplayName] = useState(user.name);
    const [username, setUsername] = useState(user.name.toLowerCase().replace(/\s/g, ''));
    const [bio, setBio] = useState(user.bio || '');
    
    // Private Data (Mocked)
    const [email, setEmail] = useState("user@example.com");
    const [phone, setPhone] = useState("+1 234 567 890");
    const [birthday, setBirthday] = useState("2000-01-01");

    const [errors, setErrors] = useState<{ [key: string]: string | null }>({});
    const [isSaving, setIsSaving] = useState(false);

    const avatarInputRef = useRef<HTMLInputElement>(null);
    const bannerInputRef = useRef<HTMLInputElement>(null);

    // Mobile Drag
    const [isDragging, setIsDragging] = useState(false);
    const [translateY, setTranslateY] = useState(0);
    const dragStartY = useRef<number>(0);
    const mobileContentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
            setTranslateY(0);
            document.body.style.overflow = 'hidden';
        } else {
            const timer = setTimeout(() => setIsVisible(false), 400);
            document.body.style.overflow = '';
            return () => clearTimeout(timer);
        }
        return () => { document.body.style.overflow = ''; };
    }, [isOpen]);

    // Validation
    useEffect(() => {
        const newErrors: { [key: string]: string | null } = {};
        
        const usernameRegex = /^[a-zA-Z0-9_.]+$/;
        if (username.length < 3) newErrors.username = "Min 3 chars";
        else if (username.length > 20) newErrors.username = "Max 20 chars";
        else if (!usernameRegex.test(username)) newErrors.username = "Invalid chars";
        
        if (displayName.length < 2) newErrors.displayName = "Name too short";
        else if (displayName.length > 50) newErrors.displayName = "Name too long";

        if (bio.length > 150) newErrors.bio = "Max 150 chars";

        setErrors(newErrors);
    }, [username, displayName, bio]);

    const isValid = Object.keys(errors).length === 0;

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'banner') => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const result = e.target?.result as string;
                if (type === 'avatar') setAvatarPreview(result);
                else setBannerPreview(result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSave = () => {
        if (!isValid) return;
        setIsSaving(true);
        
        // Simulate API call
        setTimeout(() => {
            onUpdateProfile({
                name: displayName,
                bio,
                avatar: avatarPreview,
                profileBanner: bannerPreview,
            });
            setIsSaving(false);
            onClose();
        }, 800);
    };

    // Touch Handlers
    const handleTouchStart = (e: React.TouchEvent) => {
        if (mobileContentRef.current && mobileContentRef.current.scrollTop > 0) return;
        setIsDragging(true);
        dragStartY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const deltaY = e.touches[0].clientY - dragStartY.current;
        if (deltaY > 0) setTranslateY(deltaY);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (translateY > 100) onClose();
        else setTranslateY(0);
    };

    if (!isVisible && !isOpen) return null;

    // --- Desktop Layout ---
    const DesktopLayout = () => (
        <div 
            className={`
                hidden md:flex relative w-[800px] h-[600px] bg-[#0f0f0f] rounded-3xl shadow-2xl border border-white/10 overflow-hidden
                transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)
                ${isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-95 opacity-0 translate-y-8'}
            `}
            onClick={e => e.stopPropagation()}
        >
            {/* Close Button */}
            <button onClick={onClose} className="absolute top-4 right-4 z-50 p-2 bg-black/40 hover:bg-black/60 rounded-full text-white backdrop-blur-md transition-colors border border-white/10">
                <CloseIcon className="w-5 h-5" />
            </button>

            {/* Left Column: Visuals */}
            <div className="w-[35%] relative border-r border-white/5 bg-[#121212] flex flex-col">
                {/* Banner Area */}
                <div className="h-1/2 relative group cursor-pointer overflow-hidden">
                    <div className="absolute inset-0 bg-cover bg-center transition-all duration-500 group-hover:scale-105" style={{ backgroundImage: `url(${bannerPreview || 'https://picsum.photos/seed/banner/600/200'})` }}></div>
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-colors"></div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                         <div className="bg-black/60 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 backdrop-blur-md border border-white/10">
                            <CameraIcon className="w-4 h-4" /> Edit Banner
                        </div>
                    </div>
                    <input type="file" ref={bannerInputRef} onChange={(e) => handleFileChange(e, 'banner')} accept="image/*" className="hidden" />
                    <button onClick={() => bannerInputRef.current?.click()} className="absolute inset-0 w-full h-full cursor-pointer"></button>
                </div>

                {/* Avatar Area */}
                <div className="h-1/2 relative bg-[#121212] flex flex-col items-center justify-center p-6">
                    <div className="relative -mt-20 group cursor-pointer">
                        <div className="w-32 h-32 rounded-full p-1.5 bg-[#121212] relative z-10 ring-1 ring-white/10 shadow-xl overflow-hidden">
                            <img src={avatarPreview} className="w-full h-full rounded-full object-cover bg-[#1e1e1e]" alt="Avatar" />
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full">
                                <CameraIcon className="w-8 h-8 text-white" />
                            </div>
                        </div>
                        <input type="file" ref={avatarInputRef} onChange={(e) => handleFileChange(e, 'avatar')} accept="image/*" className="hidden" />
                        <button onClick={() => avatarInputRef.current?.click()} className="absolute inset-0 w-full h-full rounded-full z-20"></button>
                    </div>

                    <div className="mt-6 text-center">
                        <h3 className="text-xl font-bold text-white">{displayName}</h3>
                        <p className="text-sm text-gray-500">@{username}</p>
                    </div>
                </div>
            </div>

            {/* Right Column: Form */}
            <div className="flex-1 flex flex-col bg-[#0f0f0f]">
                <div className="p-8 border-b border-white/5">
                    <h2 className="text-2xl font-bold text-white">Edit Profile</h2>
                    <p className="text-sm text-gray-400">Update your personal information.</p>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-8">
                    {/* Public Info */}
                    <section className="space-y-4">
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest border-b border-white/5 pb-2">Public Info</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <InputGroup label="Display Name" error={errors.displayName}>
                                <StyledInput icon={<UserIcon className="w-4 h-4"/>} value={displayName} onChange={setDisplayName} />
                            </InputGroup>
                            <InputGroup label="Username" error={errors.username}>
                                <StyledInput icon={<AtSymbolIcon className="w-4 h-4"/>} value={username} onChange={setUsername} />
                            </InputGroup>
                        </div>

                        <InputGroup label="Bio" error={errors.bio}>
                             <div className="relative group">
                                <textarea 
                                    value={bio}
                                    onChange={(e) => setBio(e.target.value)}
                                    rows={3}
                                    maxLength={150}
                                    className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl p-4 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--theme-color)] focus:bg-[#252528] transition-all resize-none"
                                    placeholder="Tell us about yourself..."
                                />
                                <span className={`absolute bottom-3 right-3 text-[10px] font-bold ${bio.length > 140 ? 'text-red-500' : 'text-gray-600'}`}>{bio.length}/150</span>
                            </div>
                        </InputGroup>
                    </section>

                    {/* Private Info */}
                    <section className="space-y-4">
                         <div className="flex items-center justify-between border-b border-white/5 pb-2">
                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                Private Info <LockClosedIcon className="w-3 h-3 text-gray-600" />
                            </h3>
                            <span className="text-[9px] bg-white/5 px-2 py-0.5 rounded text-gray-500 font-medium">Visible to you</span>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                             <InputGroup label="Email">
                                <StyledInput icon={<MailIcon className="w-4 h-4"/>} value={email} onChange={setEmail} />
                            </InputGroup>
                             <InputGroup label="Phone">
                                <StyledInput icon={<PhoneIcon className="w-4 h-4"/>} value={phone} onChange={setPhone} />
                            </InputGroup>
                        </div>
                        <InputGroup label="Birthday">
                            <StyledInput icon={<CalendarIcon className="w-4 h-4"/>} value={birthday} onChange={setBirthday} type="date" />
                        </InputGroup>
                    </section>
                </div>

                {/* Footer */}
                <div className="p-6 border-t border-white/5 bg-[#0f0f0f] flex justify-end gap-3">
                    <button onClick={onClose} className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-400 hover:text-white hover:bg-white/5 transition-colors">Cancel</button>
                    <button 
                        onClick={handleSave} 
                        disabled={!isValid || isSaving}
                        className={`px-8 py-2.5 rounded-xl text-sm font-bold text-white shadow-lg flex items-center gap-2 transition-all active:scale-95 ${!isValid ? 'bg-white/10 cursor-not-allowed opacity-50' : 'bg-[var(--theme-color)] hover:brightness-110'}`}
                    >
                        {isSaving ? 'Saving...' : 'Save Changes'}
                        {!isSaving && <CheckIcon className="w-4 h-4" />}
                    </button>
                </div>
            </div>
        </div>
    );

    // --- Mobile Layout ---
    const MobileLayout = () => (
        <div 
            className={`
                md:hidden fixed inset-0 z-[200] flex flex-col bg-black
                transition-transform duration-300 ease-out
                ${isOpen ? 'translate-y-0' : 'translate-y-full'}
            `}
            style={{ 
                transform: isDragging ? `translateY(${Math.max(0, translateY)}px)` : undefined,
            }}
        >
            {/* Header / Banner Area */}
            <div className="relative h-64 flex-shrink-0 bg-[#121212]">
                 {/* Banner */}
                 <div className="absolute inset-0">
                    <div className="absolute inset-0 bg-cover bg-center opacity-60" style={{ backgroundImage: `url(${bannerPreview || 'https://picsum.photos/seed/banner/600/200'})` }}></div>
                    <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black"></div>
                 </div>
                 
                 {/* Navbar */}
                 <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-20 pt-safe">
                     <button onClick={onClose} className="p-2 bg-black/40 backdrop-blur-md rounded-full text-white border border-white/10">
                        <CloseIcon className="w-5 h-5" />
                     </button>
                     <div className="flex gap-3">
                        <button 
                            onClick={() => bannerInputRef.current?.click()} 
                            className="p-2 bg-black/40 backdrop-blur-md rounded-full text-white border border-white/10"
                        >
                            <ImageIcon className="w-5 h-5" />
                        </button>
                     </div>
                 </div>
                 
                 {/* Avatar Centered Overlap */}
                 <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 z-20">
                     <div className="relative group" onClick={() => avatarInputRef.current?.click()}>
                        <div className="w-28 h-28 rounded-full p-1 bg-black ring-2 ring-white/10 shadow-2xl relative overflow-hidden">
                            <img src={avatarPreview} className="w-full h-full rounded-full object-cover bg-[#1e1e1e]" />
                            <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity rounded-full">
                                <CameraIcon className="w-8 h-8 text-white" />
                            </div>
                        </div>
                        <div className="absolute bottom-0 right-0 p-1.5 bg-[var(--theme-color)] rounded-full text-white border-2 border-black shadow-lg">
                            <CameraIcon className="w-3 h-3" />
                        </div>
                     </div>
                 </div>
            </div>
            
            <input type="file" ref={bannerInputRef} onChange={(e) => handleFileChange(e, 'banner')} accept="image/*" className="hidden" />
            <input type="file" ref={avatarInputRef} onChange={(e) => handleFileChange(e, 'avatar')} accept="image/*" className="hidden" />

            {/* Scrollable Form Content */}
            <div 
                ref={mobileContentRef}
                className="flex-1 overflow-y-auto bg-black pt-16 px-5 pb-32 space-y-8"
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
            >
                {/* Public Info */}
                <div className="space-y-4">
                    <InputGroup label="Display Name" error={errors.displayName}>
                        <input 
                            value={displayName}
                            onChange={e => setDisplayName(e.target.value)}
                            className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl px-5 py-4 text-white text-base font-medium focus:outline-none focus:border-[var(--theme-color)] transition-colors"
                            placeholder="Your Name"
                        />
                    </InputGroup>

                    <InputGroup label="Username" error={errors.username}>
                        <div className="relative flex items-center">
                            <span className="absolute left-5 text-gray-500">@</span>
                            <input 
                                value={username}
                                onChange={e => setUsername(e.target.value.toLowerCase())}
                                className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl pl-10 pr-5 py-4 text-white text-base font-medium focus:outline-none focus:border-[var(--theme-color)] transition-colors"
                                placeholder="username"
                            />
                        </div>
                    </InputGroup>

                    <InputGroup label="Bio" error={errors.bio}>
                         <textarea 
                            value={bio}
                            onChange={e => setBio(e.target.value)}
                            rows={3}
                            maxLength={150}
                            className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl px-5 py-4 text-white text-sm font-medium focus:outline-none focus:border-[var(--theme-color)] transition-colors resize-none"
                            placeholder="Add a bio..."
                        />
                    </InputGroup>
                </div>

                {/* Private Info */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                            Private Details
                        </h3>
                        <LockClosedIcon className="w-3 h-3 text-gray-600" />
                    </div>

                    <InputGroup label="Email">
                        <div className="relative">
                            <div className="absolute left-5 top-4 text-gray-500"><MailIcon className="w-4 h-4"/></div>
                            <input value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white text-sm focus:outline-none focus:border-[var(--theme-color)]" />
                        </div>
                    </InputGroup>

                     <InputGroup label="Phone">
                        <div className="relative">
                            <div className="absolute left-5 top-4 text-gray-500"><PhoneIcon className="w-4 h-4"/></div>
                            <input value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white text-sm focus:outline-none focus:border-[var(--theme-color)]" />
                        </div>
                    </InputGroup>

                     <InputGroup label="Birthday">
                        <div className="relative">
                            <div className="absolute left-5 top-4 text-gray-500"><CalendarIcon className="w-4 h-4"/></div>
                            <input type="date" value={birthday} onChange={e => setBirthday(e.target.value)} className="w-full bg-[#1c1c1e] border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white text-sm focus:outline-none focus:border-[var(--theme-color)]" />
                        </div>
                    </InputGroup>
                </div>
            </div>

            {/* Floating Save Button */}
            <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-black via-black to-transparent pt-12 z-30">
                <button 
                    onClick={handleSave}
                    disabled={!isValid || isSaving}
                    className={`w-full py-4 rounded-2xl text-white font-bold text-lg shadow-xl flex items-center justify-center gap-3 transition-all active:scale-95 ${!isValid ? 'bg-[#222] text-gray-500' : 'bg-[var(--theme-color)]'}`}
                >
                    {isSaving ? 'Saving...' : 'Save Profile'}
                    {!isSaving && <CheckIcon className="w-5 h-5" />}
                </button>
            </div>
        </div>
    );

    return createPortal(
        <div className={`fixed inset-0 z-[200] flex items-end md:items-center justify-center transition-all duration-500 ${isOpen ? 'visible' : 'invisible'}`}>
            
            {/* Backdrop */}
            <div 
                className={`absolute inset-0 bg-black/80 backdrop-blur-xl transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
                onClick={onClose}
            />

            <DesktopLayout />
            <MobileLayout />
            
        </div>,
        document.body
    );
};

export default EditProfileModal;
