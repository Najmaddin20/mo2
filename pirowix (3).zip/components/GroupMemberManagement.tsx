
import React, { useState, useMemo } from 'react';
import type { User, Conversation, GroupPermission } from '../types';
import { SearchIcon, MoreVertIcon, CrownIcon, ShieldIcon, TrashIcon, BlockUserIcon, UserAddIcon, ArrowLeftIcon } from './icons';
import GroupPermissionsModal from './GroupPermissionsModal';

interface GroupMemberManagementProps {
    conversation: Conversation;
    currentUser: User;
    onUpdateGroup: (updates: Partial<Conversation>) => void;
    onKickUser: (userId: number) => void;
    onBanUser: (userId: number) => void;
    onPromote: (userId: number) => void; // Default promote to Admin
    onDemote: (userId: number) => void;
    onBack?: () => void;
}

const GroupMemberManagement: React.FC<GroupMemberManagementProps> = ({ 
    conversation, currentUser, onUpdateGroup, onKickUser, onBanUser, onPromote, onDemote, onBack
}) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [activeMenuId, setActiveMenuId] = useState<number | null>(null);
    const [permissionModalUser, setPermissionModalUser] = useState<User | null>(null);

    const participants = conversation.participants || [];
    const ownerId = conversation.groupOwnerId;
    const adminIds = conversation.adminIds || [];
    
    const isCurrentUserOwner = currentUser.id === ownerId;
    const isCurrentUserAdmin = adminIds.includes(currentUser.id) || isCurrentUserOwner;

    const filteredMembers = useMemo(() => 
        participants.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase())),
    [participants, searchQuery]);

    const handleSavePermissions = (permissions: GroupPermission[]) => {
        if (!permissionModalUser) return;
        const newPermissionsMap = { ...(conversation.memberPermissions || {}) };
        newPermissionsMap[permissionModalUser.id] = permissions;
        onUpdateGroup({ memberPermissions: newPermissionsMap });
    };
    
    // Helper to check if current user can manage target user
    const canManage = (targetUserId: number) => {
        if (targetUserId === currentUser.id) return false; // Can't manage self
        if (targetUserId === ownerId) return false; // No one touches owner
        if (isCurrentUserOwner) return true; // Owner manages all
        if (isCurrentUserAdmin && !adminIds.includes(targetUserId)) return true; // Admin manages members
        return false;
    };

    return (
        <div className="flex flex-col h-full bg-[#121214]">
            <div className="p-4 border-b border-white/10 sticky top-0 bg-[#121214] z-10">
                <div className="flex items-center gap-3 mb-4">
                    {onBack && <button onClick={onBack}><ArrowLeftIcon className="w-6 h-6 text-gray-400" /></button>}
                    <h2 className="text-xl font-bold text-white">Members</h2>
                    <span className="text-sm text-gray-500">{participants.length}</span>
                </div>
                <div className="relative">
                    <SearchIcon className="absolute left-3 top-2.5 w-5 h-5 text-gray-500" />
                    <input 
                        type="text" 
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        placeholder="Search members"
                        className="w-full bg-[#27272a] text-white pl-10 pr-4 py-2 rounded-xl focus:outline-none focus:ring-1 focus:ring-purple-500"
                    />
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2">
                {filteredMembers.map(member => {
                    const isOwner = member.id === ownerId;
                    const isAdmin = adminIds.includes(member.id);
                    const isMe = member.id === currentUser.id;
                    const canAct = canManage(member.id);

                    return (
                        <div key={member.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-white/5 group transition-colors relative">
                            <div className="flex items-center gap-3">
                                <img src={member.avatar} className="w-12 h-12 rounded-full object-cover" />
                                <div>
                                    <div className="flex items-center gap-2">
                                        <span className={`font-bold ${isMe ? 'text-purple-400' : 'text-white'}`}>{member.name}</span>
                                        {isOwner && <CrownIcon className="w-4 h-4 text-yellow-500" />}
                                        {isAdmin && !isOwner && <ShieldIcon className="w-4 h-4 text-blue-400" />}
                                    </div>
                                    <span className="text-xs text-gray-500">{(member as any).status || 'offline'}</span>
                                </div>
                            </div>

                            {canAct && (
                                <div className="relative">
                                    <button onClick={() => setActiveMenuId(activeMenuId === member.id ? null : member.id)} className="p-2 text-gray-400 hover:text-white rounded-full hover:bg-white/10">
                                        <MoreVertIcon className="w-5 h-5" />
                                    </button>
                                    
                                    {activeMenuId === member.id && (
                                        <>
                                            <div className="fixed inset-0 z-20" onClick={() => setActiveMenuId(null)} />
                                            <div className="absolute right-0 mt-2 w-48 bg-[#27272a] border border-white/10 rounded-xl shadow-2xl z-30 overflow-hidden animate-fade-in-up">
                                                {isCurrentUserOwner && (
                                                    isAdmin ? (
                                                        <>
                                                            <button onClick={() => { setPermissionModalUser(member); setActiveMenuId(null); }} className="w-full text-left px-4 py-2.5 text-sm text-white hover:bg-white/10 flex items-center gap-2">
                                                                <ShieldIcon className="w-4 h-4" /> Edit Permissions
                                                            </button>
                                                            <button onClick={() => { onDemote(member.id); setActiveMenuId(null); }} className="w-full text-left px-4 py-2.5 text-sm text-white hover:bg-white/10">Dismiss Admin</button>
                                                        </>
                                                    ) : (
                                                        <button onClick={() => { onPromote(member.id); setActiveMenuId(null); }} className="w-full text-left px-4 py-2.5 text-sm text-white hover:bg-white/10 flex items-center gap-2">
                                                            <ShieldIcon className="w-4 h-4" /> Make Admin
                                                        </button>
                                                    )
                                                )}
                                                
                                                <div className="h-px bg-white/10 my-1" />
                                                
                                                <button onClick={() => { onKickUser(member.id); setActiveMenuId(null); }} className="w-full text-left px-4 py-2.5 text-sm text-orange-400 hover:bg-white/5 flex items-center gap-2">
                                                    <UserAddIcon className="w-4 h-4" /> Kick from Group
                                                </button>
                                                <button onClick={() => { onBanUser(member.id); setActiveMenuId(null); }} className="w-full text-left px-4 py-2.5 text-sm text-red-500 hover:bg-red-500/10 flex items-center gap-2">
                                                    <BlockUserIcon className="w-4 h-4" /> Ban User
                                                </button>
                                            </div>
                                        </>
                                    )}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            {permissionModalUser && (
                <GroupPermissionsModal
                    isOpen={!!permissionModalUser}
                    onClose={() => setPermissionModalUser(null)}
                    targetUser={permissionModalUser}
                    currentPermissions={conversation.memberPermissions?.[permissionModalUser.id] || []}
                    onSave={handleSavePermissions}
                />
            )}
        </div>
    );
};

export default GroupMemberManagement;
