
import React from 'react';
import type { Room } from '../types';
import { SkipNextIcon, PlayIcon, QueueIcon, ClockIcon, CheckIcon } from './icons';

interface NowPlayingManagerProps {
  room: Room;
  onSkipNext: () => void;
}

export const NowPlayingManager: React.FC<NowPlayingManagerProps> = ({ room, onSkipNext }) => {
  const nextVideo = room.videoQueue && room.videoQueue.length > 0 ? room.videoQueue[0] : null;

  return (
    <div className="bg-black/20 backdrop-blur-2xl border border-white/10 rounded-3xl p-5 shadow-xl relative overflow-hidden group">
        {/* Background Glow */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--theme-color)] opacity-5 blur-[60px] pointer-events-none"></div>

        <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    Now Playing
                </h3>
                <button
                    onClick={onSkipNext}
                    disabled={!nextVideo}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-[10px] font-bold text-white transition-all active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
                >
                    Skip <SkipNextIcon className="w-3 h-3" />
                </button>
            </div>

            {/* Current Video Card */}
            <div className="flex items-start gap-4">
                <div className="relative w-24 h-16 rounded-xl overflow-hidden shadow-lg flex-shrink-0 border border-white/5">
                    <img src={room.thumbnail} alt={room.nowPlaying} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <PlayIcon className="w-6 h-6 text-white/80 drop-shadow-md" />
                    </div>
                </div>
                <div className="flex-1 min-w-0 py-1">
                    <h2 className="text-base font-bold text-white leading-tight line-clamp-2" title={room.nowPlaying}>
                        {room.nowPlaying}
                    </h2>
                    <p className="text-xs text-gray-500 mt-1 truncate">Playing for everyone</p>
                </div>
            </div>

            {/* Up Next Section */}
            {nextVideo ? (
                <div className="mt-4 pt-3 border-t border-white/5">
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-2">Up Next</p>
                    <div className="flex items-center gap-3 bg-black/20 p-2 rounded-xl border border-white/5">
                        <img src={nextVideo.thumbnail} alt={nextVideo.title} className="w-10 h-10 rounded-lg object-cover flex-shrink-0 opacity-70" />
                        <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-gray-300 truncate">{nextVideo.title}</p>
                            <p className="text-[10px] text-gray-500 truncate">Added by {nextVideo.addedBy.name}</p>
                        </div>
                        <div className="p-1.5 bg-white/5 rounded-md">
                            <QueueIcon className="w-3 h-3 text-gray-500" />
                        </div>
                    </div>
                </div>
            ) : (
                <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-gray-600">
                    <QueueIcon className="w-3.5 h-3.5" />
                    <span className="text-xs italic">Queue is empty</span>
                </div>
            )}
        </div>
    </div>
  );
};

export const MobileNowPlayingBar: React.FC<NowPlayingManagerProps> = ({ room, onSkipNext }) => {
    const nextVideo = room.videoQueue && room.videoQueue.length > 0 ? room.videoQueue[0] : null;

    return (
        <div className="flex items-center justify-between gap-3 px-3 py-2 bg-[#121214] border-b border-white/10 shadow-md shrink-0 z-20">
            <div className="flex items-center gap-2.5 flex-1 min-w-0">
                <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0 border border-white/10 relative">
                    <img src={room.thumbnail} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-sm"></div>
                    </div>
                </div>
                <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <p className="text-[9px] font-bold text-gray-500 uppercase tracking-wider leading-none mb-0.5">Now Playing</p>
                    <p className="text-xs font-bold text-white truncate leading-tight">
                        {room.nowPlaying}
                    </p>
                </div>
            </div>
            
            {nextVideo && (
                <button 
                    onClick={onSkipNext}
                    className="p-2 bg-white/5 hover:bg-white/10 rounded-full text-gray-300 active:scale-95 transition-all border border-white/5"
                    title="Skip to next"
                >
                    <SkipNextIcon className="w-4 h-4" />
                </button>
            )}
        </div>
    );
};

export const MobileNowPlayingPanel: React.FC<NowPlayingManagerProps> = ({ room, onSkipNext }) => {
    const nextVideo = room.videoQueue && room.videoQueue.length > 0 ? room.videoQueue[0] : null;
    
    // Mock history data for UI demonstration
    const watchHistory = [
        { id: 101, title: "Previous Video 1", time: "10:30 AM" },
        { id: 102, title: "Music Video Collection", time: "10:15 AM" },
        { id: 103, title: "Funny Cats Compilation", time: "09:45 AM" },
    ];

    return (
        <div className="flex flex-col h-full p-4 space-y-6 overflow-y-auto custom-scrollbar bg-transparent">
            
            {/* Main Control Card */}
            <div className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-lg relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
                
                <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-xs font-bold text-red-400 uppercase tracking-widest flex items-center gap-2">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                            </span>
                            On Air
                        </h3>
                        <div className="bg-white/5 px-2 py-1 rounded-lg text-[10px] font-mono text-gray-400">
                            00:00 / 12:45
                        </div>
                    </div>

                    <div className="aspect-video w-full rounded-2xl overflow-hidden border border-white/5 shadow-2xl mb-4 relative group">
                        <img src={room.thumbnail} className="w-full h-full object-cover" alt="Now Playing" />
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center shadow-lg border border-white/10">
                                <PlayIcon className="w-5 h-5 text-white ml-0.5" />
                            </div>
                        </div>
                    </div>

                    <div className="mb-6">
                        <h2 className="text-xl font-bold text-white leading-tight mb-1">{room.nowPlaying}</h2>
                        <p className="text-xs text-gray-500">Streaming to {room.users.length} viewers</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <button className="py-3 rounded-xl bg-white/5 text-gray-300 font-bold text-xs border border-white/5 hover:bg-white/10 transition-colors">
                            Pause Playback
                        </button>
                        <button 
                            onClick={onSkipNext}
                            disabled={!nextVideo}
                            className="py-3 rounded-xl bg-[var(--theme-color)] text-white font-bold text-xs shadow-lg shadow-[var(--theme-color)]/20 hover:brightness-110 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                            Skip Video <SkipNextIcon className="w-3 h-3"/>
                        </button>
                    </div>
                </div>
            </div>

            {/* Queue Section */}
            <div>
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">Up Next</h3>
                {nextVideo ? (
                    <div className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-2xl p-3 flex items-center gap-3">
                        <img src={nextVideo.thumbnail} className="w-16 h-10 rounded-lg object-cover bg-black" alt={nextVideo.title}/>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-white truncate">{nextVideo.title}</p>
                            <p className="text-[10px] text-gray-500">Added by {nextVideo.addedBy.name}</p>
                        </div>
                        <div className="p-2 bg-white/5 rounded-full">
                            <QueueIcon className="w-4 h-4 text-gray-400" />
                        </div>
                    </div>
                ) : (
                    <div className="bg-black/20 backdrop-blur-md border border-white/5 rounded-2xl p-6 text-center">
                        <QueueIcon className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                        <p className="text-xs text-gray-500">Queue is empty</p>
                    </div>
                )}
            </div>

            {/* History Section */}
            <div>
                <div className="flex items-center justify-between mb-3 px-1">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Session History</h3>
                    <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-gray-400">3 Watched</span>
                </div>
                <div className="space-y-2">
                    {watchHistory.map((item) => (
                        <div key={item.id} className="flex items-center justify-between p-3 rounded-xl bg-black/20 backdrop-blur-md border border-white/5">
                            <div className="flex items-center gap-3">
                                <div className="p-1.5 bg-green-500/10 rounded-full text-green-500">
                                    <CheckIcon className="w-3 h-3" />
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-gray-300 line-clamp-1">{item.title}</p>
                                    <div className="flex items-center gap-1 text-[10px] text-gray-500">
                                        <ClockIcon className="w-3 h-3" /> {item.time}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                <button className="w-full py-3 mt-2 text-xs font-bold text-gray-500 hover:text-gray-300 transition-colors">
                    View Full History
                </button>
            </div>
            
            <div className="h-12"></div>
        </div>
    );
};

export default NowPlayingManager;
