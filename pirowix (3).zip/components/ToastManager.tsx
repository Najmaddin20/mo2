
import React, { useState, createContext, useContext, useCallback, useEffect, useRef } from 'react';
import type { Toast as ToastType } from '../types';

// 1. Context and Hook
const ToastContext = createContext<{ addToast: (toast: Omit<ToastType, 'id'>) => void } | undefined>(undefined);

export const useToast = () => {
    const context = useContext(ToastContext);
    if (context === undefined) {
        throw new Error('useToast must be used within a ToastProvider');
    }
    return context;
};

// 2. Icons
const SuccessIcon = () => (
    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-green-500/20">
      <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
      </svg>
    </div>
);
  
const ErrorIcon = () => (
    <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-red-500/20">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-4 h-4">
            <path d="M11.3418 3.32632C10.5513 1.93953 8.44873 1.93953 7.65825 3.32632L1.6062 13.89C0.768001 15.3614 1.86532 17.25 3.51335 17.25H16.4867C18.1347 17.25 19.232 15.3614 18.3938 13.89L11.3418 3.32632Z" fill="white" fillOpacity="0.2"/>
            <path d="M10 7.5V11.25" stroke="white" strokeWidth="2" strokeLinecap="round"/>
            <path d="M10 13.75V14.375" stroke="white" strokeWidth="2" strokeLinecap="round"/>
        </svg>
    </div>
);

const InfoIcon = () => (
    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/20">
        <span className="text-white font-bold text-sm italic">i</span>
    </div>
);

const WarningIcon = () => (
    <div className="w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-yellow-500/20">
        <span className="text-white font-bold text-lg">!</span>
    </div>
);

const typeStyles = {
    success: {
        glowClass: 'shadow-green-500/20 border-green-500/20',
        icon: <SuccessIcon />,
        button: 'bg-green-500/20 hover:bg-green-500/30 text-green-400'
    },
    error: {
        glowClass: 'shadow-red-500/20 border-red-500/20',
        icon: <ErrorIcon />,
        button: 'bg-red-500/20 hover:bg-red-500/30 text-red-400'
    },
    warning: {
        glowClass: 'shadow-yellow-500/20 border-yellow-500/20',
        icon: <WarningIcon />,
        button: 'bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400'
    },
    info: {
        glowClass: 'shadow-blue-500/20 border-blue-500/20',
        icon: <InfoIcon />,
        button: 'bg-blue-500/20 hover:bg-blue-500/30 text-blue-400'
    }
};

const Toast: React.FC<{ toast: ToastType; onDismiss: (id: number) => void }> = ({ toast, onDismiss }) => {
    const [isShown, setIsShown] = useState(false);
    // On mobile, default to collapsed. On desktop, expanded.
    const [isExpanded, setIsExpanded] = useState(window.innerWidth >= 768);
    const [exitClass, setExitClass] = useState('');
    const toastRef = useRef<HTMLDivElement>(null);
    const interactionState = useRef({ startX: 0, startY: 0, isPointerDown: false });
    const autoDismissTimer = useRef<number | undefined>(undefined);

    // Handle window resize for responsiveness
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 768 && !isExpanded) setIsExpanded(true);
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, [isExpanded]);

    // Animate in
    useEffect(() => {
        const timer = setTimeout(() => setIsShown(true), 10);
        return () => clearTimeout(timer);
    }, []);

    const dismiss = useCallback((direction: 'up' | 'left' | 'right' = 'up') => {
        const exitClasses = {
            up: 'opacity-0 -translate-y-8 scale-95',
            left: 'opacity-0 -translate-x-full',
            right: 'opacity-0 translate-x-full',
        };
        setExitClass(exitClasses[direction]);
        setTimeout(() => onDismiss(toast.id), 400); 
    }, [onDismiss, toast.id]);

    // Auto-dismiss logic
    useEffect(() => {
        // Longer duration if it's the expanded view on mobile to allow reading
        const duration = (isExpanded && window.innerWidth < 768) ? (toast.duration || 5000) + 2000 : (toast.duration || 5000);
        
        autoDismissTimer.current = window.setTimeout(() => dismiss('up'), duration);
        
        return () => {
            if (autoDismissTimer.current) clearTimeout(autoDismissTimer.current);
        };
    }, [dismiss, toast.duration, isExpanded]);

    const handlePointerDown = (e: React.PointerEvent) => {
        if ((e.target as HTMLElement).closest('button')) return;
        interactionState.current = { startX: e.clientX, startY: e.clientY, isPointerDown: true };
        toastRef.current?.setPointerCapture(e.pointerId);
        
        // Pause timer on interaction
        if (autoDismissTimer.current) clearTimeout(autoDismissTimer.current);
    };

    const handlePointerUp = (e: React.PointerEvent) => {
        if (!interactionState.current.isPointerDown || !toastRef.current) return;
        interactionState.current.isPointerDown = false;
        toastRef.current.releasePointerCapture(e.pointerId);
        
        const deltaX = e.clientX - interactionState.current.startX;
        const deltaY = e.clientY - interactionState.current.startY;
        const SWIPE_THRESHOLD = 30;

        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            // Horizontal swipe -> Dismiss
            if (Math.abs(deltaX) > SWIPE_THRESHOLD) dismiss(deltaX > 0 ? 'right' : 'left');
            else {
                // Resume timer if no action
                 autoDismissTimer.current = window.setTimeout(() => dismiss('up'), 2000);
            }
        } else {
            // Vertical swipe
            if (deltaY < -SWIPE_THRESHOLD) {
                // Swipe Up -> Dismiss
                dismiss('up');
            } else if (deltaY > SWIPE_THRESHOLD) {
                // Swipe Down -> Expand (Mobile)
                if (!isExpanded && window.innerWidth < 768) setIsExpanded(true);
                else autoDismissTimer.current = window.setTimeout(() => dismiss('up'), 2000);
            } else {
                // Tap -> Expand (Mobile)
                if (!isExpanded && window.innerWidth < 768) setIsExpanded(true);
                else autoDismissTimer.current = window.setTimeout(() => dismiss('up'), 2000);
            }
        }
    };
    
    const styles = typeStyles[toast.type];
    const initialClasses = 'opacity-0 -translate-y-8 scale-95';
    const visibleClasses = 'opacity-100 translate-y-0 scale-100';
    const dynamicClasses = exitClass || (isShown ? visibleClasses : initialClasses);

    return (
        <div
            ref={toastRef}
            className={`
                relative w-auto mx-auto touch-none 
                rounded-3xl md:rounded-2xl shadow-2xl border backdrop-blur-xl
                transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)
                ${styles.glowClass} ${dynamicClasses}
                ${isExpanded 
                    ? 'bg-[#1A1A1A]/95 max-w-[90vw] md:max-w-sm mt-2' 
                    : 'bg-[#1A1A1A]/80 max-w-[80vw] mt-0 hover:scale-105 cursor-pointer'
                }
            `}
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            role="alert"
            style={{ transformOrigin: 'top center' }}
        >
            <div className={`
                flex gap-3.5 transition-all duration-300
                ${isExpanded ? 'items-start p-4' : 'items-center p-2 pr-4'}
            `}>
                {/* Icon */}
                <div className={`flex-shrink-0 transition-all ${isExpanded ? 'pt-0.5' : ''} ${!isExpanded ? 'scale-75' : ''}`}>
                    {styles.icon}
                </div>
                
                {/* Content */}
                <div className="flex-1 min-w-0">
                    <p className={`font-bold text-white leading-tight transition-all ${isExpanded ? 'text-[15px] whitespace-normal' : 'text-sm truncate'}`}>
                        {toast.title}
                    </p>
                    
                    {/* Description & Button: Collapsible container */}
                    <div className={`
                        overflow-hidden transition-all duration-300 ease-out
                        ${isExpanded ? 'max-h-40 opacity-100 mt-1.5' : 'max-h-0 opacity-0 mt-0'}
                    `}>
                        {toast.description && (
                            <p className="text-xs text-gray-400 leading-relaxed mb-3">
                                {toast.description}
                            </p>
                        )}
                        
                        {toast.buttonText && (
                            <div className="flex justify-end">
                                <button 
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        dismiss('up');
                                    }} 
                                    className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors active:scale-95 ${styles.button}`}
                                >
                                    {toast.buttonText}
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Gesture Hint Bar (Mobile Only, Visible when not expanded) */}
            {!isExpanded && (
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-1 bg-white/20 rounded-full md:hidden animate-pulse"></div>
            )}
        </div>
    );
};

// 3. The ToastContainer
const ToastContainer: React.FC<{ toasts: ToastType[]; removeToast: (id: number) => void }> = ({ toasts, removeToast }) => (
    <div className="fixed top-4 left-0 right-0 z-[200] flex flex-col items-center gap-2 pointer-events-none px-4">
        {toasts.map(toast => (
            <div key={toast.id} className="pointer-events-auto">
                <Toast toast={toast} onDismiss={removeToast} />
            </div>
        ))}
    </div>
);

// 4. The Provider
export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [toasts, setToasts] = useState<ToastType[]>([]);

    const addToast = useCallback((toast: Omit<ToastType, 'id'>) => {
        const id = Date.now() + Math.random();
        setToasts(prevToasts => [ { id, ...toast }, ...prevToasts.slice(0, 2) ]);
    }, []);

    const removeToast = useCallback((id: number) => {
        setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    }, []);

    return (
        <ToastContext.Provider value={{ addToast }}>
            {children}
            <ToastContainer toasts={toasts} removeToast={removeToast} />
        </ToastContext.Provider>
    );
};
