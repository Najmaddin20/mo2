
import React from 'react';
import type { User } from '../types';
import { CloseIcon } from './icons';

interface UserProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User | null;
}

const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose, user }) => {
    if (!isOpen || !user) return null;

    return (
        <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={onClose}
        >
            <div
                className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl p-8 space-y-6 w-full max-w-md animate-fade-in-up"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">{user.name}'s Profile</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <div className="flex items-center gap-4">
                    <img src={user.avatar} alt={user.name} className="w-24 h-24 rounded-full" />
                    <div>
                        <p className="text-lg font-semibold">{user.name}</p>
                        <p className="text-gray-400">{user.bio || 'A SyncWatch user.'}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserProfileModal;
