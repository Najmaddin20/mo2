
import React, { useState, useEffect } from 'react';
import type { User, Friend } from '../types';
import { SearchIcon, SpinnerIcon } from './icons';

// Debounce hook
const useDebounce = (value: string, delay: number) => {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
};

interface FriendSearchProps {
    currentUser: User;
    friends: Friend[];
    onClose: () => void;
    onGlobalSearch: (query: string) => User[];
    onAddFriend: (userId: number) => { status: 'success' } | { status: 'error', message: string };
    onStartChat: (friendId: number) => void;
}

const FriendSearch: React.FC<FriendSearchProps> = ({ currentUser, friends, onClose, onGlobalSearch, onAddFriend, onStartChat }) => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<{ myFriends: Friend[], global: User[] }>({ myFriends: [], global: [] });
    const [isLoading, setIsLoading] = useState(false);
    const [requestedUsers, setRequestedUsers] = useState<Set<number>>(new Set());
    const debouncedQuery = useDebounce(query, 300);

    useEffect(() => {
        if (!debouncedQuery) {
            setResults({ myFriends: [], global: [] });
            setIsLoading(false);
            return;
        }

        setIsLoading(true);

        const searchFriends = friends.filter(friend =>
            friend.name.toLowerCase().includes(debouncedQuery.toLowerCase())
        );

        const globalResults = onGlobalSearch(debouncedQuery);
        
        // Simulate network delay for global search
        setTimeout(() => {
            setResults({ myFriends: searchFriends, global: globalResults });
            setIsLoading(false);
        }, 250);

    }, [debouncedQuery, friends, onGlobalSearch]);

    const handleAddToggle = (user: User) => {
        if (requestedUsers.has(user.id)) {
            // This is a local "cancel" action.
            setRequestedUsers(prev => {
                const newSet = new Set(prev);
                newSet.delete(user.id);
                return newSet;
            });
        } else {
            // Send friend request
            onAddFriend(user.id);
            setRequestedUsers(prev => new Set(prev).add(user.id));
        }
    };

    return (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-xl z-30 flex flex-col animate-fade-in" onClick={onClose}>
            <div className="flex-shrink-0" onClick={e => e.stopPropagation()}>
                <header className="flex-shrink-0 p-4 border-b border-white/5 flex items-center gap-3">
                    <SearchIcon className="w-5 h-5 text-gray-400"/>
                    <input
                        type="text"
                        placeholder="Search people by name..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        autoFocus
                        className="flex-1 bg-transparent text-white focus:outline-none placeholder-gray-400"
                        style={{ caretColor: 'var(--theme-color)' }}
                    />
                    <button 
                        onClick={onClose} 
                        className="text-sm font-semibold hover:opacity-80 transition-opacity"
                        style={{ color: 'var(--theme-color)' }}
                    >
                        Cancel
                    </button>
                </header>
            </div>

            <div className="flex-1 overflow-y-auto" onClick={e => e.stopPropagation()}>
                {isLoading && (
                    <div className="flex justify-center items-center p-8">
                        <SpinnerIcon className="w-8 h-8 animate-spin text-[var(--theme-color)]" />
                    </div>
                )}
                {!isLoading && debouncedQuery && results.myFriends.length === 0 && results.global.length === 0 && (
                    <div className="text-center text-gray-400 p-8">
                        <p>No results found for "{debouncedQuery}"</p>
                    </div>
                )}

                {results.myFriends.length > 0 && (
                    <section className="p-4">
                        <h3 className="text-xs font-bold text-gray-400 uppercase mb-2">My Friends</h3>
                        <div className="space-y-2">
                            {results.myFriends.map(friend => (
                                <UserItem key={friend.id} user={friend} action="chat" onAction={() => onStartChat(friend.id)} />
                            ))}
                        </div>
                    </section>
                )}

                {results.global.length > 0 && (
                    <section className="p-4">
                         <h3 className="text-xs font-bold text-gray-400 uppercase mb-2">Discover People</h3>
                         <div className="space-y-2">
                            {results.global.map(user => (
                                <UserItem 
                                    key={user.id} 
                                    user={user} 
                                    action={requestedUsers.has(user.id) ? 'requested' : 'add'} 
                                    onAction={() => handleAddToggle(user)} 
                                />
                            ))}
                        </div>
                    </section>
                )}
            </div>
        </div>
    );
};

const UserItem: React.FC<{ user: User, action: 'chat' | 'add' | 'requested', onAction: () => void }> = ({ user, action, onAction }) => {
    const getActionStyle = () => {
        switch(action) {
            case 'chat': return { className: 'bg-white/10 text-white hover:bg-white/20' };
            case 'add': return { className: 'text-white hover:opacity-90', style: { backgroundColor: 'var(--theme-color)' } };
            case 'requested': return { className: 'bg-transparent border border-white/20 text-white/70 hover:bg-white/10' };
        }
    };
    const currentConfig = getActionStyle();

    const actionText = {
        chat: 'Chat',
        add: 'Add',
        requested: 'Requested'
    }[action];

    return (
        <div className="flex items-center justify-between p-2 rounded-lg hover:bg-white/5">
            <div className="flex items-center gap-3">
                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                <p className="font-semibold text-white">{user.name}</p>
            </div>
            <button
                onClick={onAction}
                className={`px-4 py-1.5 text-sm font-semibold rounded-lg transition-colors ${currentConfig.className}`}
                style={currentConfig.style}
            >
                {actionText}
            </button>
        </div>
    );
};

export default FriendSearch;
