import React, { useEffect, useRef, useState } from 'react';
import type { Conversation } from '../types';
import { LockClosedIcon, ArchiveBoxIcon, BellSlashIcon, PinIcon, TrashIcon } from './icons';

interface ChatContextMenuProps {
  menu: { x: number; y: number; conversation: Conversation } | null;
  onClose: () => void;
  onPin: (friendId: number) => void;
  onMute: (friendId: number) => void;
  onArchive: (friendId: number) => void;
  onLock: (friendId: number) => void;
  onDelete: (friendId: number) => void;
}

const MenuItem: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void; className?: string }> = ({ icon, label, onClick, className = '' }) => (
    <button
        onClick={onClick}
        className={`w-full flex items-center gap-4 px-4 py-3 text-left text-sm font-medium transition-colors hover:bg-white/10 rounded-lg ${className}`}
        role="menuitem"
    >
        {icon}
        <span>{label}</span>
    </button>
);

const ChatContextMenu: React.FC<ChatContextMenuProps> = ({ menu, onClose, onPin, onMute, onArchive, onLock, onDelete }) => {
    const menuRef = useRef<HTMLDivElement>(null);
    const [style, setStyle] = useState<React.CSSProperties>({ opacity: 0, pointerEvents: 'none' });
    const [isMobileView, setIsMobileView] = useState(window.innerWidth < 768);

    useEffect(() => {
        const handleResize = () => setIsMobileView(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    useEffect(() => {
        if (!menu || isMobileView) return;
        const { x, y } = menu;

        const calculatePosition = () => {
            if (!menuRef.current) return;
            const menuWidth = menuRef.current.offsetWidth;
            const menuHeight = menuRef.current.offsetHeight;
            const screenWidth = window.innerWidth;
            const screenHeight = window.innerHeight;

            let top = y;
            let left = x;

            if (x + menuWidth > screenWidth) left = screenWidth - menuWidth - 10;
            if (y + menuHeight > screenHeight) top = screenHeight - menuHeight - 10;

            setStyle({ top: `${top}px`, left: `${left}px`, opacity: 1, pointerEvents: 'auto' });
        };
        requestAnimationFrame(calculatePosition);

    }, [menu, isMobileView]);

    if (!menu) return null;

    const { conversation } = menu;

    const handleAction = (action: (id: number) => void) => {
        action(conversation.friend.id);
        onClose();
    };

    const actionItems = (
        <>
            <MenuItem
                icon={<LockClosedIcon className="w-5 h-5" />}
                label={conversation.lockPin ? "Unlock Chat" : "Lock Chat"}
                onClick={() => handleAction(onLock)}
            />
            <MenuItem
                icon={<ArchiveBoxIcon className="w-5 h-5" />}
                label={conversation.isArchived ? "Unarchive Chat" : "Archive Chat"}
                onClick={() => handleAction(onArchive)}
            />
            <MenuItem
                icon={<BellSlashIcon className="w-5 h-5" />}
                label={conversation.isMuted ? "Unmute Notifications" : "Mute Notifications"}
                onClick={() => handleAction(onMute)}
            />
            <MenuItem
                icon={<PinIcon className="w-5 h-5" />}
                label={conversation.isPinned ? "Unpin from Top" : "Pin to Top"}
                onClick={() => handleAction(onPin)}
            />
            <MenuItem
                icon={<TrashIcon className="w-5 h-5" />}
                label="Delete Chat"
                className="text-red-400"
                onClick={() => handleAction(onDelete)}
            />
        </>
    );

    if (isMobileView) {
        return (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end animate-fade-in" onClick={onClose} role="dialog" aria-modal="true">
                <div 
                    className="w-full bg-gray-900/70 backdrop-blur-xl border-t border-gray-200/20 rounded-t-3xl pt-3 pb-4 px-4 space-y-2 animate-slide-in-from-bottom" 
                    onClick={e => e.stopPropagation()} 
                    role="menu"
                    aria-label="Chat Actions"
                >
                    <div className="w-10 h-1.5 bg-gray-500 rounded-full mx-auto mb-3"></div>
                    <div className="text-center font-bold text-lg p-2 border-b border-white/10 mb-2">{conversation.friend.name}</div>
                    {actionItems}
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-black/30 z-50 animate-fade-in" onClick={onClose}>
            <div
                ref={menuRef}
                style={style}
                className="fixed w-60 bg-[#1e1931]/90 backdrop-blur-md border border-white/10 rounded-xl shadow-2xl p-2 text-white animate-fade-in-up"
                role="menu"
                aria-label="Chat Actions"
            >
                {actionItems}
            </div>
        </div>
    );
};

export default ChatContextMenu;