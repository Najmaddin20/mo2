
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { 
    SpinnerIcon, SparklesIcon, DownloadIcon, TrashIcon, ReplyIcon, 
    UserAddIcon, ImageIcon, CloseIcon, MagicWandIcon, PaletteIcon, 
    SettingsIcon, CheckIcon, SearchIcon, ClockIcon, LayoutGridIcon,
    CrownIcon, PlusIcon, EyeIcon
} from './icons';
import type { User } from '../types';
import TokenPurchaseModal from './TokenPurchaseModal';
import { useToast } from './ToastManager';

interface HistoryImage {
    id: string;
    src: string;
    prompt: string;
    style: string;
    aspectRatio: string;
    timestamp: number;
}

interface ImageStudioProps {
    onUpdateProfile: (updates: Partial<User>) => void;
    onNavigate: (page: 'settings') => void;
}

const aspectRatios = [
    { value: "1:1", label: "Square", icon: "□" },
    { value: "16:9", label: "Landscape", icon: "▭" },
    { value: "9:16", label: "Portrait", icon: "▯" },
    { value: "4:3", label: "Standard", icon: "▅" },
    { value: "3:4", label: "Tall", icon: "▆" },
];

const styles = [
    { id: 'none', label: 'No Style', prompt: '' },
    { id: 'cinematic', label: 'Cinematic', prompt: ', cinematic lighting, highly detailed, dramatic atmosphere, 8k resolution, photorealistic, depth of field' },
    { id: 'anime', label: 'Anime', prompt: ', anime style, studio ghibli, vibrant colors, detailed background, high quality' },
    { id: 'digital-art', label: 'Digital Art', prompt: ', digital painting, concept art, smooth, sharp focus, illustration, trending on artstation' },
    { id: 'cyberpunk', label: 'Cyberpunk', prompt: ', cyberpunk, neon lights, futuristic, high tech, night city, glowing, synthwave' },
    { id: 'oil-painting', label: 'Oil Painting', prompt: ', oil painting texture, classic art style, visible brushstrokes, artistic, masterpiece' },
    { id: '3d-render', label: '3D Render', prompt: ', 3d render, unreal engine 5, octane render, ray tracing, hyperrealistic, plastic texture' },
];

const loadingTips = [
    "Enhancing your prompt with AI magic...",
    "Mixing colors and digital dreams...",
    "Calculating light rays and shadows...",
    "Applying artistic styles...",
    "Rendering your imagination...",
];

const ZoomableImage = ({ src, alt }: { src: string, alt: string }) => {
    const [scale, setScale] = useState(1);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const [startPos, setStartPos] = useState({ x: 0, y: 0 });
    const containerRef = useRef<HTMLDivElement>(null);

    const handleWheel = (e: React.WheelEvent) => {
        e.stopPropagation();
        const delta = -e.deltaY * 0.001;
        const newScale = Math.min(Math.max(1, scale + delta), 5);
        setScale(newScale);
        if (newScale === 1) setPosition({ x: 0, y: 0 });
    };

    const handleMouseDown = (e: React.MouseEvent) => {
        if (scale > 1) {
            setIsDragging(true);
            setStartPos({ x: e.clientX - position.x, y: e.clientY - position.y });
        }
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (isDragging && scale > 1) {
            setPosition({
                x: e.clientX - startPos.x,
                y: e.clientY - startPos.y
            });
        }
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    // Reset on src change
    useEffect(() => {
        setScale(1);
        setPosition({ x: 0, y: 0 });
    }, [src]);

    return (
        <div 
            ref={containerRef}
            className="flex-1 bg-[#050505] flex items-center justify-center relative overflow-hidden cursor-move active:cursor-grabbing"
            onWheel={handleWheel}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
        >
            <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#333 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
            <img 
                src={src} 
                className="max-w-full max-h-full object-contain relative z-10 transition-transform duration-75 ease-linear" 
                alt={alt} 
                style={{ 
                    transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
                    cursor: scale > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default'
                }}
                draggable={false}
            />
            
            {/* Zoom Controls */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-20 bg-black/60 backdrop-blur-md p-1.5 rounded-xl border border-white/10">
                <button onClick={(e) => { e.stopPropagation(); setScale(Math.max(1, scale - 0.5)); if(scale <= 1.5) setPosition({x:0, y:0}); }} className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14" /></svg>
                </button>
                <span className="px-2 flex items-center text-xs font-mono font-bold min-w-[40px] justify-center">{Math.round(scale * 100)}%</span>
                <button onClick={(e) => { e.stopPropagation(); setScale(Math.min(5, scale + 0.5)); }} className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14" /></svg>
                </button>
            </div>
        </div>
    );
};

const ImageStudio: React.FC<ImageStudioProps> = ({ onUpdateProfile, onNavigate }) => {
    const [prompt, setPrompt] = useState('');
    const [negativePrompt, setNegativePrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState('1:1');
    const [selectedStyle, setSelectedStyle] = useState(styles[0]);
    
    // Image Upload State
    const [startImage, setStartImage] = useState<File | null>(null);
    const [startImagePreview, setStartImagePreview] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [isLoading, setIsLoading] = useState(false);
    const [isEnhancing, setIsEnhancing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [imageHistory, setImageHistory] = useState<HistoryImage[]>([]);
    const [viewingImage, setViewingImage] = useState<HistoryImage | null>(null);
    const [loadingTip, setLoadingTip] = useState(loadingTips[0]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    
    // Mobile Viewer Details Toggle
    const [showMobileDetails, setShowMobileDetails] = useState(true);

    // Token System
    const [tokens, setTokens] = useState(5);
    const [showTokenModal, setShowTokenModal] = useState(false);
    const { addToast } = useToast();

    // Mobile View State
    const [mobileTab, setMobileTab] = useState<'create' | 'history'>('create');
    
    // Advanced History State
    const [selectionMode, setSelectionMode] = useState(false);
    const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        try {
            const savedHistory = localStorage.getItem('imageStudioHistory');
            const savedTokens = localStorage.getItem('imageTokens');
            
            if (savedHistory) setImageHistory(JSON.parse(savedHistory));
            if (savedTokens) setTokens(parseInt(savedTokens));
        } catch (e) {
            console.error("Failed to load data", e);
            // If loading fails (e.g. corrupt data), reset history
            localStorage.removeItem('imageStudioHistory');
        }
    }, []);
    
    useEffect(() => {
        localStorage.setItem('imageTokens', tokens.toString());
    }, [tokens]);

    useEffect(() => {
        let interval: number;
        if (isLoading) {
            setLoadingTip(loadingTips[0]);
            let i = 0;
            interval = window.setInterval(() => {
                i = (i + 1) % loadingTips.length;
                setLoadingTip(loadingTips[i]);
            }, 2500);
        }
        return () => window.clearInterval(interval);
    }, [isLoading]);

    const handlePurchaseTokens = (amount: number) => {
        setTokens(prev => prev + amount);
        addToast({
            title: 'Purchase Successful',
            description: `Added ${amount} tokens to your account.`,
            type: 'success'
        });
    };

    const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setStartImage(file);
            const url = URL.createObjectURL(file);
            setStartImagePreview(url);
        }
    };

    const clearImage = () => {
        setStartImage(null);
        setStartImagePreview(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
        const base64EncodedDataPromise = new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(file);
        });
        return {
            inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
        };
    };

    const handleEnhancePrompt = async () => {
        if (!prompt.trim()) return;
        setIsEnhancing(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Rewrite the following image prompt to be more descriptive, artistic, and suitable for a high-quality AI image generator. Keep it under 40 words. Do not add any introductory text. Prompt: "${prompt}"`,
            });
            if (response.text) {
                setPrompt(response.text.trim());
            }
        } catch (e) {
            console.error("Enhance failed", e);
        } finally {
            setIsEnhancing(false);
        }
    };

    const handleGenerate = async () => {
        if (tokens <= 0) {
            setShowTokenModal(true);
            return;
        }

        if (!prompt.trim() && !startImage) {
            setError('Please enter a prompt or upload a reference image.');
            return;
        }
        setIsLoading(true);
        setError(null);
        
        const finalPrompt = `${prompt}${selectedStyle.prompt}${negativePrompt ? ` (avoid: ${negativePrompt})` : ''}`;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            const parts: any[] = [{ text: finalPrompt }];
            
            if (startImage) {
                const imgPart = await fileToGenerativePart(startImage);
                parts.push(imgPart);
            }

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts },
                config: {
                    imageConfig: {
                        aspectRatio: aspectRatio,
                    }
                }
            });

            let imageUrl: string | null = null;

            if (response.candidates?.[0]?.content?.parts) {
                for (const part of response.candidates[0].content.parts) {
                    if (part.inlineData) {
                        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
                        break;
                    }
                }
            }

            if (imageUrl) {
                setGeneratedImage(imageUrl);
                setTokens(prev => Math.max(0, prev - 1));
                
                const newHistoryItem: HistoryImage = {
                    id: `${Date.now()}-${Math.random()}`,
                    src: imageUrl,
                    prompt: prompt,
                    style: selectedStyle.id,
                    aspectRatio: aspectRatio,
                    timestamp: Date.now(),
                };
                
                setImageHistory(prevHistory => {
                    // Keep recent 20 items in memory state
                    const updatedHistory = [newHistoryItem, ...prevHistory].slice(0, 20);
                    
                    // Try to save to localStorage, but fail gracefully if quota exceeded (common with base64 images)
                    try {
                        localStorage.setItem('imageStudioHistory', JSON.stringify(updatedHistory));
                    } catch (err) {
                        console.warn("Storage quota exceeded. History not saved persistently.", err);
                        // Optional: Could remove oldest items and retry, or just silently fail persistence
                    }
                    return updatedHistory;
                });
            } else {
                if (response.text) {
                     setError(`Model message: ${response.text}`);
                } else {
                     setError('Image generation failed. Please try again.');
                }
            }
        } catch (e) {
            console.error(e);
            let friendlyError = "An error occurred. Please try again.";
            const errorMessage = e instanceof Error ? e.message : String(e);
            if (errorMessage.includes('SAFETY')) {
                friendlyError = "Safety block triggered. Please modify your prompt.";
            }
            setError(friendlyError);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleUseAsAvatar = (src: string) => {
        onUpdateProfile({ avatar: src });
        onNavigate('settings');
    };
    
    const handleUseAsBanner = (src: string) => {
        onUpdateProfile({ profileBanner: src });
        onNavigate('settings');
    };
    
    const handleDeleteHistory = (id: string) => {
        const updatedHistory = imageHistory.filter(item => item.id !== id);
        setImageHistory(updatedHistory);
        try {
            localStorage.setItem('imageStudioHistory', JSON.stringify(updatedHistory));
        } catch (e) {
            console.error("Failed to update storage after delete", e);
        }
        if (viewingImage?.id === id) setViewingImage(null);
    };

    const handleDeleteSelected = () => {
        const updatedHistory = imageHistory.filter(item => !selectedImages.has(item.id));
        setImageHistory(updatedHistory);
        try {
            localStorage.setItem('imageStudioHistory', JSON.stringify(updatedHistory));
        } catch (e) {
            console.error("Failed to update storage after delete", e);
        }
        setSelectedImages(new Set());
        setSelectionMode(false);
    };

    const handleReuse = (item: HistoryImage) => {
        setPrompt(item.prompt);
        setAspectRatio(item.aspectRatio);
        const style = styles.find(s => s.id === item.style) || styles[0];
        setSelectedStyle(style);
        setViewingImage(null);
        setMobileTab('create');
    };

    const toggleSelection = (id: string) => {
        setSelectedImages(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) newSet.delete(id);
            else newSet.add(id);
            return newSet;
        });
    };

    const groupedHistory = useMemo(() => {
        const filtered = imageHistory.filter(img => img.prompt.toLowerCase().includes(searchQuery.toLowerCase()));
        const groups: Record<string, HistoryImage[]> = { 'Today': [], 'Yesterday': [], 'Older': [] };
        
        const now = new Date();
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);

        filtered.forEach(img => {
            const date = new Date(img.timestamp);
            if (date.toDateString() === now.toDateString()) {
                groups['Today'].push(img);
            } else if (date.toDateString() === yesterday.toDateString()) {
                groups['Yesterday'].push(img);
            } else {
                groups['Older'].push(img);
            }
        });
        return groups;
    }, [imageHistory, searchQuery]);

    const openPreview = () => {
        if (generatedImage) {
            // Create a temporary history item for preview
            const tempItem: HistoryImage = {
                id: 'temp',
                src: generatedImage,
                prompt: prompt,
                style: selectedStyle.id,
                aspectRatio: aspectRatio,
                timestamp: Date.now()
            };
            setViewingImage(tempItem);
        }
    };

    const PreviewArea = ({ className }: { className?: string }) => (
        <div className={`relative overflow-hidden rounded-3xl bg-black/20 backdrop-blur-md border border-white/5 flex items-center justify-center ${className}`}>
            {/* Grid Pattern */}
            <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#666 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
            
            {generatedImage && <div className="absolute inset-0 blur-3xl opacity-30" style={{ backgroundColor: 'var(--theme-color)' }}></div>}

            {generatedImage ? (
                <div className="relative w-full h-full flex items-center justify-center p-4 group cursor-zoom-in" onClick={openPreview}>
                     {/* Image constrained to parent size */}
                    <img 
                        src={generatedImage} 
                        alt="Generated" 
                        className={`max-w-full max-h-full object-contain shadow-2xl transition-all duration-500 ${isLoading ? 'blur-sm scale-95 opacity-80' : 'scale-100 opacity-100'}`} 
                    />
                    
                    {isLoading && (
                         <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-black/20 backdrop-blur-[2px]">
                            <div className="p-4 bg-black/60 rounded-2xl backdrop-blur-md border border-white/10 flex flex-col items-center">
                                 <SpinnerIcon className="w-8 h-8 animate-spin text-white mb-2" />
                                 <p className="text-xs font-bold text-white">{loadingTip}</p>
                            </div>
                        </div>
                    )}

                    {/* Desktop Hover Actions */}
                    {!isLoading && (
                        <div className="absolute bottom-6 flex gap-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0 z-20 pointer-events-none">
                            <span className="bg-black/60 text-white text-xs font-bold px-3 py-1.5 rounded-full backdrop-blur-md border border-white/10 pointer-events-auto">
                                Click to Expand
                            </span>
                        </div>
                    )}
                </div>
            ) : isLoading ? (
                <div className="text-center z-10">
                    <div className="relative w-20 h-20 mx-auto mb-4">
                        <div className="absolute inset-0 border-t-2 border-[var(--theme-color)] rounded-full animate-spin"></div>
                        <div className="absolute inset-2 border-t-2 border-white/50 rounded-full animate-spin-slow"></div>
                         <SparklesIcon className="absolute inset-0 m-auto w-6 h-6 text-white animate-pulse" />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-1">Creating...</h3>
                    <p className="text-xs text-gray-400 max-w-[200px] mx-auto">{loadingTip}</p>
                </div>
            ) : (
                <div className="text-center text-gray-500 z-10">
                    <div className="w-16 h-16 bg-white/5 rounded-2xl mx-auto mb-3 flex items-center justify-center border border-white/5 shadow-inner">
                        <ImageIcon className="w-8 h-8 opacity-40" />
                    </div>
                    <p className="text-sm font-bold text-gray-400">No Image Yet</p>
                    <p className="text-xs opacity-50 mt-1">Your creation will appear here.</p>
                </div>
            )}
        </div>
    );

    return (
        <div className="h-full flex flex-col text-white overflow-hidden bg-transparent relative">
            
            {/* Desktop Header */}
            <div className="flex-shrink-0 px-6 py-4 border-b border-white/5 bg-black/20 backdrop-blur-md flex justify-between items-center sticky top-0 z-20">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shadow-lg" style={{ background: 'linear-gradient(to bottom right, var(--theme-color), color-mix(in srgb, var(--theme-color), black 30%))' }}>
                        <MagicWandIcon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-xl font-bold text-white leading-none">Image Studio</h1>
                        <p className="text-xs text-gray-400 mt-1 hidden sm:block">Generate & Edit with AI</p>
                    </div>
                </div>

                {/* Token Display & Purchase */}
                <div className="flex items-center gap-3">
                    <button 
                        onClick={() => setShowTokenModal(true)}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 transition-all group active:scale-95"
                    >
                        <div className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-sm">
                            <SparklesIcon className="w-3 h-3 text-white" />
                        </div>
                        <span className={`text-xs font-bold ${tokens > 0 ? 'text-white' : 'text-red-400'}`}>
                            {tokens} Token{tokens !== 1 ? 's' : ''}
                        </span>
                        <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-white group-hover:bg-white/20">
                            <PlusIcon className="w-3 h-3" />
                        </div>
                    </button>
                </div>
            </div>

            {/* Mobile Tabs */}
            <div className="lg:hidden flex bg-black/40 p-1 border-b border-white/10 backdrop-blur-md z-20">
                <button 
                    onClick={() => setMobileTab('create')}
                    className={`flex-1 py-3 text-xs font-bold transition-all relative ${mobileTab === 'create' ? 'text-white' : 'text-gray-400 hover:text-white'}`}
                >
                    Create
                    {mobileTab === 'create' && <div className="absolute bottom-0 left-1/3 right-1/3 h-0.5 bg-[var(--theme-color)] rounded-t-full"></div>}
                </button>
                <button 
                    onClick={() => setMobileTab('history')}
                    className={`flex-1 py-3 text-xs font-bold transition-all relative ${mobileTab === 'history' ? 'text-white' : 'text-gray-400 hover:text-white'}`}
                >
                    Library
                    {mobileTab === 'history' && <div className="absolute bottom-0 left-1/3 right-1/3 h-0.5 bg-[var(--theme-color)] rounded-t-full"></div>}
                </button>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row min-h-0 relative z-10">
                
                {/* LEFT PANEL: CONTROLS & CREATION */}
                <div className={`
                    w-full lg:w-[420px] flex flex-col lg:border-r border-white/5 bg-black/40 backdrop-blur-xl z-10 transition-transform h-full
                    ${mobileTab === 'create' ? 'flex' : 'hidden lg:flex'}
                `}>
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-4 lg:p-6 space-y-8">
                        
                        {/* Mobile Preview Injection */}
                        <div className="lg:hidden mb-4">
                            <PreviewArea className="min-h-[300px]" />
                        </div>

                        {/* Prompt Input Section (Glassy) */}
                        <div className="space-y-3">
                            <div className="flex justify-between items-center">
                                <label className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                                    <MagicWandIcon className="w-3 h-3 text-[var(--theme-color)]" />
                                    Prompt & Reference
                                </label>
                            </div>

                            <div className={`relative group rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 transition-all hover:bg-white/[0.07] focus-within:bg-black/40 focus-within:border-[var(--theme-color)] focus-within:ring-1 focus-within:ring-[var(--theme-color)]/50 overflow-hidden shadow-2xl`}>
                                
                                {/* Image Preview Area (Reference) */}
                                {startImagePreview && (
                                    <div className="relative w-full h-40 bg-black/50 border-b border-white/5">
                                        <img 
                                            src={startImagePreview} 
                                            alt="Reference" 
                                            className="w-full h-full object-cover opacity-70"
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                                        <div className="absolute bottom-2 left-4 text-xs font-bold text-white flex items-center gap-2">
                                            <ImageIcon className="w-4 h-4" /> Using Reference Image
                                        </div>
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); clearImage(); }}
                                            className="absolute top-2 right-2 p-1.5 bg-black/60 text-white rounded-full hover:bg-red-500 transition-colors backdrop-blur-md border border-white/10"
                                        >
                                            <CloseIcon className="w-3 h-3" />
                                        </button>
                                    </div>
                                )}

                                <textarea
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                    placeholder={startImagePreview ? "Describe how to transform this image..." : "Describe your imagination..."}
                                    rows={startImagePreview ? 2 : 4}
                                    className={`w-full bg-transparent border-none p-5 text-base text-white placeholder-gray-500 focus:outline-none resize-none leading-relaxed relative z-10`} 
                                />

                                {/* Toolbar */}
                                <div className="flex items-center justify-between px-4 pb-4 relative z-10">
                                     <div className="flex items-center gap-2">
                                          <button 
                                              onClick={() => fileInputRef.current?.click()}
                                              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${startImagePreview ? 'bg-[var(--theme-color)]/20 text-[var(--theme-color)] border border-[var(--theme-color)]/30' : 'bg-white/10 text-gray-300 hover:text-white hover:bg-white/20 border border-white/5'}`}
                                          >
                                              <ImageIcon className="w-4 h-4" />
                                              {startImagePreview ? 'Change Ref' : 'Add Reference'}
                                          </button>
                                          <input type="file" ref={fileInputRef} onChange={handleImageSelect} accept="image/*" className="hidden" />
                                     </div>
                                     
                                     <button 
                                        onClick={handleEnhancePrompt}
                                        disabled={isEnhancing || !prompt}
                                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all disabled:opacity-50 hover:brightness-110"
                                        style={{ 
                                            color: 'var(--theme-color)', 
                                            backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 90%)',
                                            border: '1px solid color-mix(in srgb, var(--theme-color), transparent 80%)'
                                        }}
                                        title="Enhance Prompt"
                                     >
                                        <SparklesIcon className={`w-3.5 h-3.5 ${isEnhancing ? 'animate-spin' : ''}`} /> 
                                        {isEnhancing ? 'Enhancing...' : 'Enhance'}
                                     </button>
                                </div>
                            </div>
                        </div>

                        {/* Aspect Ratio (Row - No Scroll) */}
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Aspect Ratio</label>
                            <div className="flex flex-wrap gap-2">
                                {aspectRatios.map(ratio => (
                                    <button
                                        key={ratio.value}
                                        onClick={() => setAspectRatio(ratio.value)}
                                        className={`flex-1 min-w-[80px] py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${aspectRatio === ratio.value ? 'shadow-lg' : 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10'}`}
                                        style={aspectRatio === ratio.value ? { 
                                            backgroundColor: 'var(--theme-color)', 
                                            borderColor: 'var(--theme-color)', 
                                            color: '#ffffff' 
                                        } : {}}
                                    >
                                        <span className="text-lg leading-none opacity-80">{ratio.icon}</span> {ratio.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Styles (Row - No Scroll) */}
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">Art Style</label>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                 {styles.map(style => (
                                     <button
                                         key={style.id}
                                         onClick={() => setSelectedStyle(style)}
                                         className={`text-left px-3 py-3 rounded-xl text-xs font-bold border transition-all ${selectedStyle.id === style.id ? 'text-white shadow-md' : 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10'}`}
                                         style={selectedStyle.id === style.id ? { 
                                             backgroundColor: 'var(--theme-color)', 
                                             borderColor: 'var(--theme-color)' 
                                         } : {}}
                                     >
                                         {style.label}
                                     </button>
                                 ))}
                            </div>
                        </div>

                        {/* Advanced Toggle */}
                        <div>
                            <button 
                                onClick={() => setShowAdvanced(!showAdvanced)}
                                className="flex items-center gap-2 text-xs font-bold text-gray-500 hover:text-gray-300 transition-colors px-1"
                            >
                                <SettingsIcon className="w-3 h-3" /> Advanced Settings
                            </button>
                            
                            {showAdvanced && (
                                <div className="mt-3 p-4 bg-black/20 rounded-xl border border-white/5 animate-fade-in">
                                    <div>
                                        <label className="text-[10px] font-bold text-gray-500 uppercase mb-1.5 block">Negative Prompt</label>
                                        <input 
                                            type="text" 
                                            value={negativePrompt}
                                            onChange={(e) => setNegativePrompt(e.target.value)}
                                            placeholder="bad quality, blurry, ugly..."
                                            className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white outline-none transition-colors placeholder-gray-600 focus:border-[var(--theme-color)]"
                                            style={{ borderColor: 'var(--theme-color)' }}
                                        />
                                    </div>
                                </div>
                            )}
                        </div>

                        {error && (
                            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
                                {error}
                            </div>
                        )}

                        <div className="pt-2 pb-6 lg:pb-0">
                            <button
                                onClick={handleGenerate}
                                disabled={isLoading || (!prompt.trim() && !startImage)}
                                className="w-full py-4 text-white font-bold rounded-2xl transition-all transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 group shadow-xl"
                                style={{ background: 'linear-gradient(to right, var(--theme-color), color-mix(in srgb, var(--theme-color), white 20%))' }}
                            >
                                {isLoading ? (
                                    <>
                                        <SpinnerIcon className="w-5 h-5 animate-spin" />
                                        <span>Creating Magic...</span>
                                    </>
                                ) : (
                                    <>
                                        {tokens > 0 ? (
                                            <>
                                                <MagicWandIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                                                <span>Generate (1 Token)</span>
                                            </>
                                        ) : (
                                            <>
                                                <CrownIcon className="w-5 h-5 text-yellow-300 group-hover:scale-110 transition-transform" />
                                                <span>Get Tokens</span>
                                            </>
                                        )}
                                    </>
                                )}
                            </button>
                            {tokens === 0 && !isLoading && (
                                <p className="text-xs text-center text-red-400 mt-2 font-medium animate-pulse">Not enough tokens!</p>
                            )}
                        </div>
                    </div>
                </div>

                {/* RIGHT PANEL: PREVIEW & HISTORY (Desktop Only) */}
                <div className="hidden lg:flex flex-1 flex-col min-h-0 relative bg-transparent">
                    
                    {/* Desktop Preview Area - Always visible on desktop */}
                    <div className="flex-1 flex-col relative hidden lg:flex min-h-0">
                         <PreviewArea className="flex-1 m-6" />
                    </div>

                    {/* History Area */}
                    <div className="h-56 flex-shrink-0 flex flex-col bg-black/40 backdrop-blur-xl border-t border-white/5">
                        {/* History Toolbar */}
                        <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-black/20">
                            <div className="flex items-center gap-4">
                                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2"><LayoutGridIcon className="w-4 h-4"/> Library</h3>
                                {selectionMode && (
                                    <span className="text-xs font-bold px-2 py-0.5 rounded border" style={{ color: 'var(--theme-color)', backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 90%)', borderColor: 'color-mix(in srgb, var(--theme-color), transparent 80%)' }}>{selectedImages.size} selected</span>
                                )}
                            </div>
                            
                            <div className="flex items-center gap-2">
                                {selectionMode ? (
                                    <>
                                        <button onClick={() => handleDeleteSelected()} className="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors" title="Delete Selected"><TrashIcon className="w-4 h-4"/></button>
                                        <button onClick={() => { setSelectionMode(false); setSelectedImages(new Set()); }} className="text-xs font-bold text-gray-400 hover:text-white px-2">Cancel</button>
                                    </>
                                ) : (
                                    <>
                                        <div className="relative mr-2 hidden sm:block">
                                            <SearchIcon className="w-3 h-3 absolute left-2 top-2 text-gray-500"/>
                                            <input 
                                                type="text" 
                                                placeholder="Search..." 
                                                value={searchQuery}
                                                onChange={e => setSearchQuery(e.target.value)}
                                                className="bg-black/20 border border-white/10 rounded-lg pl-7 pr-2 py-1.5 text-xs text-white outline-none w-32 sm:w-40 transition-all focus:w-48"
                                                style={{ borderColor: 'var(--theme-color)' }}
                                            />
                                        </div>
                                        <button onClick={() => setSelectionMode(true)} className="text-xs font-bold text-gray-500 hover:text-white px-2 py-1 hover:bg-white/5 rounded transition-colors">Select</button>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* History Grid/List */}
                        <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                            {imageHistory.length === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-2 opacity-60">
                                    <ClockIcon className="w-8 h-8" />
                                    <p className="text-xs font-medium">No history yet</p>
                                </div>
                            ) : (
                                Object.entries(groupedHistory).map(([label, items]) => {
                                    const historyItems = items as HistoryImage[];
                                    return (
                                        historyItems.length > 0 && (
                                            <div key={label} className="mb-4">
                                                <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 px-1 sticky top-0 bg-black/40 backdrop-blur-md py-1 z-10 w-fit rounded">{label}</h4>
                                                <div className="grid grid-flow-col auto-cols-[140px] overflow-x-auto pb-2 hide-scrollbar gap-3">
                                                    {historyItems.map(item => {
                                                        const isSelected = selectedImages.has(item.id);
                                                        return (
                                                            <div 
                                                                key={item.id} 
                                                                onClick={() => {
                                                                    if (selectionMode) toggleSelection(item.id);
                                                                    else setViewingImage(item);
                                                                }}
                                                                className={`
                                                                    relative rounded-xl overflow-hidden cursor-pointer group transition-all border-2 bg-[#1e1e1e] aspect-square h-32 w-32
                                                                    ${isSelected ? '' : 'border-white/5 hover:border-white/20'}
                                                                `}
                                                                style={isSelected ? { borderColor: 'var(--theme-color)', boxShadow: '0 0 0 2px color-mix(in srgb, var(--theme-color), transparent 70%)' } : {}}
                                                            >
                                                                <img src={item.src} className="w-full h-full object-cover" alt="history item" loading="lazy" />
                                                                
                                                                {/* Selection Overlay */}
                                                                {selectionMode && (
                                                                    <div className={`absolute top-2 right-2 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${isSelected ? '' : 'border-white/50 bg-black/40 backdrop-blur-sm'}`} style={isSelected ? { backgroundColor: 'var(--theme-color)', borderColor: 'var(--theme-color)' } : {}}>
                                                                        {isSelected && <CheckIcon className="w-3 h-3 text-white" />}
                                                                    </div>
                                                                )}

                                                                {/* Hover Overlay (Desktop) */}
                                                                {!selectionMode && (
                                                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                                                        <button 
                                                                            onClick={(e) => { e.stopPropagation(); handleReuse(item); }}
                                                                            className="p-2 bg-black/50 rounded-full backdrop-blur-sm hover:opacity-90 transition-colors text-white"
                                                                            title="Reuse"
                                                                            style={{ backgroundColor: 'var(--theme-color)' }}
                                                                        >
                                                                            <ReplyIcon className="w-4 h-4" />
                                                                        </button>
                                                                    </div>
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        )
                                    );
                                })
                            )}
                        </div>
                    </div>
                </div>
                
                {/* Mobile History View (Visible only when mobile tab is 'history') */}
                <div className={`
                    flex-1 flex flex-col h-full bg-black/40 backdrop-blur-xl lg:hidden
                    ${mobileTab === 'history' ? 'flex' : 'hidden'}
                `}>
                     {/* Same History Grid logic but vertical for mobile */}
                     <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-black/20">
                        {/* ... Toolbar (same logic, just copy structure) ... */}
                         <div className="flex items-center gap-4">
                                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2"><LayoutGridIcon className="w-4 h-4"/> Library</h3>
                                {selectionMode && <span className="text-xs font-bold px-2 py-0.5 rounded border text-[var(--theme-color)] border-[var(--theme-color)]">{selectedImages.size} selected</span>}
                        </div>
                         <div className="flex items-center gap-2">
                                {selectionMode ? (
                                    <>
                                        <button onClick={() => handleDeleteSelected()} className="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg"><TrashIcon className="w-4 h-4"/></button>
                                        <button onClick={() => { setSelectionMode(false); setSelectedImages(new Set()); }} className="text-xs font-bold text-gray-400">Cancel</button>
                                    </>
                                ) : (
                                    <button onClick={() => setSelectionMode(true)} className="text-xs font-bold text-gray-500">Select</button>
                                )}
                        </div>
                     </div>

                     <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                        {imageHistory.length === 0 ? (
                             <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-2 opacity-60">
                                <ClockIcon className="w-8 h-8" />
                                <p className="text-xs font-medium">No history yet</p>
                            </div>
                        ) : (
                             Object.entries(groupedHistory).map(([label, items]) => {
                                const historyItems = items as HistoryImage[];
                                return historyItems.length > 0 && (
                                    <div key={label} className="mb-4">
                                        <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 sticky top-0 bg-black/60 backdrop-blur-md py-1 z-10">{label}</h4>
                                        <div className="grid grid-cols-3 gap-2">
                                            {historyItems.map((item: any) => {
                                                 const isSelected = selectedImages.has(item.id);
                                                 return (
                                                     <div key={item.id} onClick={() => { if(selectionMode) toggleSelection(item.id); else setViewingImage(item); }} className={`relative aspect-square rounded-xl overflow-hidden bg-[#222] border-2 ${isSelected ? 'border-[var(--theme-color)]' : 'border-transparent'}`}>
                                                         <img src={item.src} className="w-full h-full object-cover" loading="lazy" />
                                                         {selectionMode && (
                                                            <div className={`absolute top-1 right-1 w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'bg-[var(--theme-color)] border-[var(--theme-color)]' : 'bg-black/50 border-white/50'}`}>
                                                                {isSelected && <CheckIcon className="w-2.5 h-2.5 text-white" />}
                                                            </div>
                                                         )}
                                                     </div>
                                                 )
                                            })}
                                        </div>
                                    </div>
                                )
                             })
                        )}
                     </div>
                </div>

            </div>

            {/* Fullscreen Viewer Modal (Updated for Zoom and Better Mobile) */}
            {viewingImage && (
                <div className="fixed inset-0 z-[200] bg-black animate-fade-in flex flex-col lg:flex-row" onClick={(e) => e.stopPropagation()}>
                    
                    {/* Mobile Header (Overlay) */}
                    <div className="lg:hidden absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-50 bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
                        <button onClick={() => setViewingImage(null)} className="p-2.5 bg-black/40 text-white rounded-full backdrop-blur-md pointer-events-auto border border-white/10">
                            <CloseIcon className="w-6 h-6"/>
                        </button>
                        <button onClick={() => setShowMobileDetails(!showMobileDetails)} className="p-2.5 bg-black/40 text-white rounded-full backdrop-blur-md pointer-events-auto border border-white/10">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        </button>
                    </div>

                    {/* Image Container with Zoom */}
                    <div className="flex-1 relative overflow-hidden h-full w-full flex items-center justify-center bg-[#050505]">
                         <ZoomableImage src={viewingImage.src} alt="View" />
                         
                         {/* Desktop Close */}
                         <button onClick={() => setViewingImage(null)} className="hidden lg:block absolute top-6 right-6 p-2 bg-black/50 text-white rounded-full hover:bg-white/10 transition-colors z-50 backdrop-blur-md border border-white/10">
                            <CloseIcon className="w-6 h-6"/>
                        </button>
                    </div>

                    {/* Sidebar Details (Desktop) / Bottom Sheet (Mobile) */}
                    <div className={`
                        bg-[#121214] flex flex-col border-l border-white/5 transition-transform duration-300 ease-out z-40
                        lg:w-96 lg:relative lg:translate-y-0
                        fixed bottom-0 left-0 right-0 rounded-t-3xl shadow-2xl lg:rounded-none
                        ${showMobileDetails ? 'translate-y-0' : 'translate-y-full lg:translate-y-0'}
                    `}>
                        {/* Mobile Drag Handle */}
                        <div className="lg:hidden w-full flex justify-center pt-3 pb-1" onClick={() => setShowMobileDetails(false)}>
                            <div className="w-12 h-1.5 bg-gray-600 rounded-full opacity-50"></div>
                        </div>

                        <div className="p-6 border-b border-white/5">
                            <h3 className="text-xl font-bold text-white">Image Details</h3>
                            <p className="text-xs text-gray-500 mt-1">{new Date(viewingImage.timestamp).toLocaleString()}</p>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6 max-h-[50vh] lg:max-h-none">
                            <div>
                                <label className="text-xs font-bold uppercase mb-2 block flex items-center gap-2" style={{ color: 'var(--theme-color)' }}>
                                    <MagicWandIcon className="w-3 h-3"/> Prompt
                                </label>
                                <div className="bg-black/30 p-4 rounded-xl border border-white/5 hover:border-white/10 transition-colors group relative">
                                    <p className="text-sm text-gray-200 leading-relaxed italic">"{viewingImage.prompt}"</p>
                                    <button 
                                        onClick={() => navigator.clipboard.writeText(viewingImage.prompt)} 
                                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 bg-white/10 rounded-md hover:bg-white/20 text-white transition-all"
                                        title="Copy Prompt"
                                    >
                                        <CheckIcon className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>

                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Parameters</label>
                                <div className="flex flex-wrap gap-2">
                                    <div className="px-3 py-1.5 text-xs font-bold rounded-lg border capitalize flex items-center gap-1.5" style={{ backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 90%)', borderColor: 'color-mix(in srgb, var(--theme-color), transparent 80%)', color: 'var(--theme-color)' }}>
                                        <PaletteIcon className="w-3 h-3"/> {viewingImage.style}
                                    </div>
                                    <div className="px-3 py-1.5 bg-white/5 text-gray-300 text-xs font-bold rounded-lg border border-white/10 flex items-center gap-1.5">
                                        <span className="text-[10px] border border-current px-0.5 rounded-sm">AR</span> {viewingImage.aspectRatio}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="p-6 border-t border-white/5 bg-[#18181b] pb-safe">
                            <button 
                                onClick={() => handleReuse(viewingImage)} 
                                className="w-full py-3.5 text-white rounded-xl text-sm font-bold hover:shadow-lg transition-all active:scale-[0.98] mb-3"
                                style={{ background: 'linear-gradient(to right, var(--theme-color), color-mix(in srgb, var(--theme-color), white 20%))', boxShadow: '0 10px 15px -3px color-mix(in srgb, var(--theme-color), transparent 80%)' }}
                            >
                                Reuse Prompt
                            </button>
                            
                            <div className="grid grid-cols-2 gap-3 mb-3">
                                <button onClick={() => handleUseAsAvatar(viewingImage.src)} className="py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 border border-white/5">
                                    <UserAddIcon className="w-4 h-4"/> Set Avatar
                                </button>
                                <button onClick={() => handleUseAsBanner(viewingImage.src)} className="py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 border border-white/5">
                                    <ImageIcon className="w-4 h-4"/> Set Banner
                                </button>
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <a 
                                    href={viewingImage.src} 
                                    download={`ai-image-${viewingImage.timestamp}.png`} 
                                    className="py-3 bg-white/5 text-white rounded-xl text-sm font-bold hover:bg-white/10 transition-colors flex items-center justify-center gap-2 border border-white/5"
                                >
                                    <DownloadIcon className="w-4 h-4"/> Save
                                </a>
                                <button 
                                    onClick={() => { handleDeleteHistory(viewingImage.id); setViewingImage(null); }} 
                                    className="py-3 bg-red-500/10 text-red-400 rounded-xl text-sm font-bold hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2 border border-red-500/20"
                                >
                                    <TrashIcon className="w-4 h-4"/> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <TokenPurchaseModal 
                isOpen={showTokenModal}
                onClose={() => setShowTokenModal(false)}
                onPurchase={handlePurchaseTokens}
            />
        </div>
    );
};

export default ImageStudio;
