
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TrashIcon, SendIcon, PlayFilledIcon, PauseFilledIcon, StopIcon } from './icons';

interface VoiceMessageRecorderProps {
    isRecording: boolean;
    onCancel: () => void;
    onSend: (blobUrl: string, duration: number, waveform: number[]) => void;
}

const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
};

const VoiceMessageRecorder: React.FC<VoiceMessageRecorderProps> = ({ isRecording, onCancel, onSend }) => {
    const [internalState, setInternalState] = useState<'recording' | 'review'>('recording');
    const [duration, setDuration] = useState(0);
    const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
    const [waveform, setWaveform] = useState<number[]>([]);
    
    // Playback state
    const [isPlaying, setIsPlaying] = useState(false);
    const [playbackTime, setPlaybackTime] = useState(0);
    
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<number | undefined>(undefined);
    const audioContextRef = useRef<AudioContext | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const animationFrameRef = useRef<number | undefined>(undefined);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

    // --- Visualizer Logic (Live) ---
    const drawLiveWaveform = useCallback(() => {
        const canvas = canvasRef.current;
        const analyser = analyserRef.current;
        if (!canvas || !analyser) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteFrequencyData(dataArray);

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const bars = 35;
        const totalWidth = canvas.width;
        const barWidth = 2.5;
        const gap = (totalWidth - (bars * barWidth)) / (bars - 1); 
        const centerY = canvas.height / 2;

        for (let i = 0; i < bars; i++) {
            // Use lower frequency data for more movement visual
            const value = dataArray[i * 2]; 
            const percent = value / 255;
            const height = Math.max(4, percent * canvas.height * 0.9);

            // Draw rounded bar with improved color
            ctx.fillStyle = `rgba(255, 255, 255, ${0.5 + percent * 0.5})`;
            
            const x = i * (barWidth + gap);
            const y = centerY - height / 2;
            
            // Simple rect for compatibility, could use roundRect if supported
            ctx.fillRect(x, y, barWidth, height);
        }

        if (internalState === 'recording') {
            animationFrameRef.current = requestAnimationFrame(drawLiveWaveform);
        }
    }, [internalState]);

    // --- Recording Logic ---
    useEffect(() => {
        if (isRecording && !mediaRecorderRef.current) {
            startRecording();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isRecording]);

    const startRecording = async () => {
        try {
            setInternalState('recording');
            setDuration(0);
            setAudioBlob(null);
            setWaveform([]);
            audioChunksRef.current = [];

            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;

            // Audio Context for Visualization
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
            analyserRef.current = audioContextRef.current.createAnalyser();
            analyserRef.current.fftSize = 256; // Improved resolution
            sourceRef.current = audioContextRef.current.createMediaStreamSource(stream);
            sourceRef.current.connect(analyserRef.current);

            // Media Recorder
            const recorder = new MediaRecorder(stream);
            mediaRecorderRef.current = recorder;

            recorder.ondataavailable = (e) => {
                if (e.data.size > 0) audioChunksRef.current.push(e.data);
            };

            recorder.onstop = async () => {
                 const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                 if (blob.size > 0) {
                     // Generate a nice looking fake static waveform for the review
                     const dummyWave = Array.from({ length: 40 }, () => 0.2 + Math.random() * 0.6);
                     setWaveform(dummyWave);
                     setAudioBlob(blob);
                     
                     const url = URL.createObjectURL(blob);
                     const audio = new Audio(url);
                     audioPlayerRef.current = audio;
                     
                     audio.ontimeupdate = () => setPlaybackTime(audio.currentTime);
                     audio.onended = () => {
                         setIsPlaying(false);
                         setPlaybackTime(0);
                     };
                 }
            };

            recorder.start();
            
            // Start Timer
            timerIntervalRef.current = window.setInterval(() => {
                setDuration(prev => prev + 1);
            }, 1000);

            // Start Visualizer
            drawLiveWaveform();

        } catch (err) {
            console.error("Failed to start recording", err);
            onCancel();
        }
    };

    const stopRecordingLogic = (nextAction: 'review' | 'send') => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            mediaRecorderRef.current.stop();
        }
        
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
        }
        
        if (timerIntervalRef.current) {
            clearInterval(timerIntervalRef.current);
        }
        
        if (animationFrameRef.current !== undefined) {
            cancelAnimationFrame(animationFrameRef.current);
        }
        
        if (audioContextRef.current) {
            audioContextRef.current.close();
        }
        
        if (nextAction === 'review') {
            setInternalState('review');
        } else if (nextAction === 'send') {
            // Give a small delay for the blob to be created in onstop
            setTimeout(() => {
                if (audioChunksRef.current.length > 0) {
                    const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                    const dummyWave = Array.from({ length: 40 }, () => Math.random()); 
                    const url = URL.createObjectURL(blob);
                    onSend(url, duration, dummyWave);
                }
            }, 100);
        }
    };

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
            if (animationFrameRef.current !== undefined) cancelAnimationFrame(animationFrameRef.current);
            if (audioPlayerRef.current) {
                audioPlayerRef.current.pause();
                audioPlayerRef.current = null;
            }
            if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
        };
    }, []);

    const togglePlayback = () => {
        if (!audioPlayerRef.current) return;
        if (isPlaying) {
            audioPlayerRef.current.pause();
        } else {
            const playPromise = audioPlayerRef.current.play();
            if (playPromise !== undefined) {
                playPromise.catch(e => {
                    console.error("Preview playback failed", e);
                    setIsPlaying(false);
                });
            }
        }
        setIsPlaying(!isPlaying);
    };

    const handleSendClick = () => {
        if (audioBlob) {
            const url = URL.createObjectURL(audioBlob);
            onSend(url, duration, waveform);
        }
    };

    const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!audioPlayerRef.current || internalState !== 'review') return;
        const rect = e.currentTarget.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        const newTime = percent * duration;
        
        if(isFinite(newTime)) {
             audioPlayerRef.current.currentTime = newTime;
             setPlaybackTime(newTime);
        }
    };

    // --- RENDER ---

    if (internalState === 'recording') {
        return (
            <div className="flex items-center w-full h-full px-2 gap-2 animate-fade-in py-1.5">
                 {/* Recording Status Pill */}
                 <div className="flex-1 h-10 bg-gradient-to-r from-red-500/10 to-red-500/5 rounded-xl flex items-center px-3 gap-3 border border-red-500/20 relative overflow-hidden shadow-inner">
                     {/* Pulse Dot */}
                     <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)] flex-shrink-0 ring-2 ring-red-500/30"></div>
                     
                     {/* Timer */}
                     <span className="text-xs font-mono font-bold text-red-200 min-w-[40px] tracking-wider">
                        {formatTime(duration)}
                     </span>
                     
                     {/* Live Canvas Visualizer */}
                     <div className="flex-1 h-full flex items-center opacity-80 max-w-[180px] ml-auto">
                        <canvas ref={canvasRef} width={180} height={24} className="w-full h-full" />
                     </div>
                 </div>

                 {/* Actions */}
                 <div className="flex items-center gap-2">
                     <button onClick={onCancel} className="w-10 h-10 flex items-center justify-center rounded-lg text-gray-400 hover:bg-white/5 hover:text-red-400 transition-colors active:scale-95">
                        <TrashIcon className="w-5 h-5" />
                     </button>
                     <button 
                        onClick={() => stopRecordingLogic('review')}
                        className="w-10 h-10 flex items-center justify-center rounded-lg bg-[#27272a] border border-white/10 text-white hover:bg-white/10 hover:scale-105 active:scale-95 transition-all shadow-lg"
                     >
                        <StopIcon className="w-4 h-4 text-red-400" />
                     </button>
                 </div>
            </div>
        );
    }

    // Review Mode
    return (
        <div className="flex items-center w-full h-full px-2 gap-2 animate-fade-in-up py-1.5">
            {/* Review Player Pill */}
            <div className="flex-1 h-10 bg-[#1c1c1e] rounded-xl flex items-center pl-1 pr-3 gap-3 border border-white/5 shadow-lg overflow-hidden">
                <button 
                    onClick={togglePlayback}
                    className="w-8 h-8 flex items-center justify-center rounded-lg text-white hover:brightness-110 transition-all shadow-md flex-shrink-0 active:scale-95"
                    style={{ background: 'var(--theme-color)' }}
                >
                    {isPlaying ? <PauseFilledIcon className="w-3.5 h-3.5" /> : <PlayFilledIcon className="w-3.5 h-3.5 ml-0.5" />}
                </button>

                {/* Visualizer */}
                <div 
                    className="flex-1 h-full flex items-center gap-[2px] cursor-pointer group/wave"
                    onClick={handleSeek}
                >
                    {waveform.map((val, i) => {
                        const barProgress = (i / waveform.length) * duration;
                        const isPassed = playbackTime >= barProgress;
                        // Enhance wave height calculation
                        const height = Math.max(12, val * 75); 
                        return (
                            <div 
                                key={i} 
                                className="flex-1 rounded-full transition-all duration-150 ease-in-out"
                                style={{
                                    height: `${height}%`,
                                    backgroundColor: isPassed ? 'var(--theme-color)' : 'rgba(255,255,255,0.15)',
                                    minWidth: '2px'
                                }}
                            ></div>
                        )
                    })}
                </div>
                
                <span className="text-[10px] font-medium text-gray-400 font-mono flex-shrink-0 w-[35px] text-right tracking-wide">
                    {formatTime(isPlaying ? playbackTime : duration)}
                </span>
            </div>

             {/* Delete Action */}
            <button 
                onClick={onCancel}
                className="w-10 h-10 flex items-center justify-center rounded-lg text-gray-400 hover:text-red-500 hover:bg-white/5 transition-colors flex-shrink-0 active:scale-95"
            >
                <TrashIcon className="w-5 h-5" />
            </button>

            {/* Send Action */}
            <button 
                onClick={handleSendClick}
                className="w-10 h-10 flex items-center justify-center rounded-lg text-white shadow-lg shadow-purple-500/30 hover:scale-105 transition-transform active:scale-95 flex-shrink-0"
                style={{ background: 'var(--theme-color)' }}
            >
                <SendIcon className="w-5 h-5 ml-0.5" />
            </button>
        </div>
    );
};

export default VoiceMessageRecorder;
