
import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { User, Friend, Conversation, DirectMessage, ChatBackground, CallState } from '../types';
import { CheckIcon, XIcon, ChatIcon, MenuIcon, PinIcon, LockClosedIcon, SearchIcon, ArchiveBoxIcon, BellSlashIcon, UsersIcon, PlusCircleIcon, ArrowLeftIcon, CloseIcon, SpinnerIcon, PlayFilledIcon, FilmReelIcon, WaveIcon } from './icons';
import AdvancedChat from './AdvancedChat';
import GroupChat from './GroupChat';
import MediaViewerModal from './MediaViewerModal';
import UserInfoPanel from './UserInfoPanel';
import ChatContextMenu from './ChatContextMenu';
import ConfirmationModal from './ConfirmationModal';
import FriendSearchResults from './FriendSearchResults';
import FriendRequestsPanel from './FriendRequestsPanel';
import CreateGroupModal from './CreateGroupModal';
import LockScreenModal from './LockScreenModal';
import SavedMessagesItem from './SavedMessagesItem';
import SavedMessagesChat from './SavedMessagesChat';
import { useToast } from './ToastManager';

interface FriendsPanelProps {
    currentUser: User;
    friends: Friend[];
    pendingRequests: User[];
    sentRequests: User[];
    onAcceptRequest: (id: number) => void;
    onDeclineRequest: (id: number) => void;
    onCancelRequest: (id: number) => void;
    conversations: Conversation[];
    selectedFriendId: number | null;
    onAttemptSelectFriend: (id: number) => void;
    onSendMessage: (friendId: number, message: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'>) => void;
    onDeleteMessage: (friendId: number, messageIds: number | number[]) => void;
    onEditMessage: (friendId: number, messageId: number, newText: string) => void;
    onPinMessage: (friendId: number, messageId: number) => void;
    onAddReaction: (friendId: number, messageId: number, emoji: string) => void;
    onAddFriend: (userId: number) => { status: 'success' } | { status: 'error', message: string };
    onGlobalUserSearch: (query: string) => User[];
    onJoinRoom: (roomId: number) => void;
    onJoinVoiceRoom: (roomId: number) => void;
    onForwardDirectMessage: (toFriendId: number, message: DirectMessage, fromFriend: User) => void;
    onForwardMultipleDirectMessages: (toFriendIds: number[], messages: DirectMessage[]) => void;
    chatBackground: ChatBackground;
    onToggleSidebar: () => void;
    onViewProfile: (user: User) => void;
    onPinChat: (friendId: number) => void;
    onMuteChat: (friendId: number) => void;
    onArchiveChat: (friendId: number) => void;
    onLockChat: (friendId: number) => void;
    onDeleteChat: (friendId: number) => void;
    onStartCall: (friend: Friend, type: CallState) => void;
    onBlockUser: (user: User) => void;
    onUnblockUser: (user: User) => void;
    blockedUsers: User[];
    onCreateGroup: (groupData: { name: string, participantIds: number[], description?: string, theme?: string, avatar?: string, isPrivate?: boolean }) => void;
    // Helper to update conversation data from child components if needed (mock function)
    onUpdateConversation?: (id: number, updates: Partial<Conversation>) => void; 
}

const statusStyles = {
    online: { text: 'Online', color: 'text-green-400', bg: 'bg-green-400' },
    ingame: { text: 'In Game', color: 'text-purple-400', bg: 'bg-purple-400' },
    offline: { text: 'Offline', color: 'text-gray-400', bg: 'bg-gray-500' },
};

const useDebounce = (value: string, delay: number) => {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);
    return debouncedValue;
};

// Advanced Interaction Hook for Click vs Long Press
const useContextMenuTrigger = (
    onOpenMenu: (event: React.MouseEvent | React.TouchEvent) => void,
    onSelect: () => void
) => {
    const longPressTimeout = useRef<number | undefined>(undefined);
    const isLongPress = useRef(false);
    const startCoord = useRef<{ x: number; y: number } | null>(null);

    const handleContextMenu = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        onOpenMenu(e);
    };

    const handleTouchStart = (e: React.TouchEvent) => {
        isLongPress.current = false;
        startCoord.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        
        longPressTimeout.current = window.setTimeout(() => {
            isLongPress.current = true;
            if (navigator.vibrate) navigator.vibrate(50);
            onOpenMenu(e);
        }, 500);
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!startCoord.current) return;
        const moveX = e.touches[0].clientX;
        const moveY = e.touches[0].clientY;
        
        if (Math.abs(moveX - startCoord.current.x) > 10 || Math.abs(moveY - startCoord.current.y) > 10) {
            if (longPressTimeout.current) {
                clearTimeout(longPressTimeout.current);
                longPressTimeout.current = undefined;
            }
        }
    };

    const handleTouchEnd = (e: React.TouchEvent) => {
        if (longPressTimeout.current) {
            clearTimeout(longPressTimeout.current);
        }
        startCoord.current = null;
        if (isLongPress.current) {
             e.preventDefault();
        } 
    };

    const handleClick = (e: React.MouseEvent) => {
        if (isLongPress.current) {
            isLongPress.current = false; 
            return;
        }
        onSelect();
    };

    return {
        onContextMenu: handleContextMenu,
        onTouchStart: handleTouchStart,
        onTouchMove: handleTouchMove,
        onTouchEnd: handleTouchEnd,
        onClick: handleClick,
    };
};

const HeroCarousel = () => {
    const [index, setIndex] = useState(0);
    
    const slides = [
        {
            id: 'connect',
            title: 'Stay Connected',
            desc: 'Message friends and groups instantly.',
            visual: (
                <div className="relative w-full h-full flex items-center justify-center">
                    <div className="absolute inset-0 bg-[var(--theme-color)] opacity-20 blur-[60px] rounded-full animate-pulse-slow"></div>
                    <div className="relative z-10 w-24 h-24 bg-white/5 border border-white/10 rounded-[2rem] flex items-center justify-center backdrop-blur-md shadow-2xl ring-1 ring-white/20">
                        <ChatIcon className="w-10 h-10 text-white" />
                    </div>
                    {/* Orbiting elements */}
                    <div className="absolute inset-0 animate-[spin_10s_linear_infinite]">
                        <div className="absolute top-[10%] left-1/2 -translate-x-1/2 w-10 h-10 bg-[#1e1e24] rounded-xl border border-white/10 flex items-center justify-center shadow-lg animate-[spin_10s_linear_infinite_reverse]">
                            <div className="w-3 h-3 bg-[var(--theme-color)] rounded-full shadow-[0_0_10px_var(--theme-color)]"></div>
                        </div>
                        <div className="absolute bottom-[20%] right-[20%] w-8 h-8 bg-[#1e1e24] rounded-full border border-white/10 flex items-center justify-center shadow-lg animate-[spin_10s_linear_infinite_reverse]">
                             <UsersIcon className="w-3.5 h-3.5 text-gray-400" />
                        </div>
                    </div>
                </div>
            )
        },
        {
            id: 'watch',
            title: 'Watch Together',
            desc: 'Stream movies and videos in sync.',
            visual: (
                <div className="relative w-full h-full flex items-center justify-center">
                     <div className="absolute inset-0 bg-blue-500 opacity-10 blur-[60px] rounded-full"></div>
                     <div className="relative z-10 w-32 h-20 bg-black/40 border border-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md shadow-2xl transform -rotate-6 ring-1 ring-white/10">
                        <FilmReelIcon className="w-10 h-10 text-[var(--theme-color)] drop-shadow-md" />
                     </div>
                     <div className="absolute z-0 w-28 h-16 bg-white/5 border border-white/5 rounded-xl transform rotate-[12deg] translate-x-6 translate-y-2 backdrop-blur-sm"></div>
                     <div className="absolute z-20 -bottom-4 -left-4 bg-white/10 backdrop-blur-md p-2 rounded-xl border border-white/10 animate-bounce">
                        <PlayFilledIcon className="w-5 h-5 text-white" />
                     </div>
                </div>
            )
        },
        {
            id: 'voice',
            title: 'Crystal Clear Voice',
            desc: 'Hangout in voice rooms with high quality audio.',
            visual: (
                <div className="relative w-full h-full flex items-center justify-center">
                    <div className="absolute inset-0 bg-purple-500 opacity-15 blur-[60px] rounded-full"></div>
                    <div className="flex items-end gap-2 h-16 relative z-10">
                        {[1,2,3,4,5].map(i => (
                            <div 
                                key={i} 
                                className="w-3 bg-gradient-to-t from-[var(--theme-color)] to-white rounded-full" 
                                style={{ 
                                    animation: `voice-bar 1.2s ease-in-out infinite`,
                                    animationDelay: `${i * 0.1}s`, 
                                    height: '40%' 
                                }}
                            ></div>
                        ))}
                    </div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 border-2 border-[var(--theme-color)] rounded-full opacity-20 animate-[ping_2s_infinite]"></div>
                </div>
            )
        }
    ];

    useEffect(() => {
        const timer = setInterval(() => {
            setIndex(prev => (prev + 1) % slides.length);
        }, 5000);
        return () => clearInterval(timer);
    }, [slides.length]);

    return (
        <div className="w-full max-w-md mx-auto">
            <style>{`
                @keyframes voice-bar {
                    0%, 100% { height: 20%; opacity: 0.5; }
                    50% { height: 80%; opacity: 1; }
                }
            `}</style>
            <div className="relative aspect-[16/10] mb-6">
                {/* Render all slides with transition */}
                {slides.map((slide, i) => (
                    <div 
                        key={slide.id}
                        className={`absolute inset-0 transition-all duration-700 ease-in-out transform ${i === index ? 'opacity-100 scale-100 translate-x-0 blur-0' : 'opacity-0 scale-90 translate-x-12 blur-sm'}`}
                    >
                        {slide.visual}
                    </div>
                ))}
            </div>
            
            <div className="text-center relative h-20 overflow-hidden">
                 {slides.map((slide, i) => (
                    <div 
                        key={slide.id}
                        className={`absolute inset-0 flex flex-col items-center transition-all duration-500 ${i === index ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                    >
                        <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">{slide.title}</h3>
                        <p className="text-gray-400 text-sm leading-relaxed max-w-xs">{slide.desc}</p>
                    </div>
                 ))}
            </div>

            <div className="flex justify-center gap-2 mt-6">
                {slides.map((_, i) => (
                    <button 
                        key={i} 
                        onClick={() => setIndex(i)}
                        className={`h-1.5 rounded-full transition-all duration-500 ${i === index ? 'w-8 bg-[var(--theme-color)]' : 'w-1.5 bg-white/20 hover:bg-white/40'}`}
                    />
                ))}
            </div>
        </div>
    );
}

const FriendsPanel: React.FC<FriendsPanelProps> = (props) => {
    const { currentUser, friends, pendingRequests, sentRequests, onAcceptRequest, onDeclineRequest, onCancelRequest, conversations, selectedFriendId, onAttemptSelectFriend, onAddFriend, onGlobalUserSearch, onJoinRoom, onJoinVoiceRoom, chatBackground, onToggleSidebar, onDeleteChat, onStartCall, onBlockUser, onUnblockUser, blockedUsers, onCreateGroup } = props;
    
    const [activeTab, setActiveTab] = useState<'all' | 'groups' | 'archived' | 'requests'>('all');
    const [isLockedMode, setIsLockedMode] = useState(false); 
    
    const [viewingMedia, setViewingMedia] = useState<DirectMessage | null>(null);
    const [viewingUserInfo, setViewingUserInfo] = useState(false);
    const [contextMenu, setContextMenu] = useState<{ x: number; y: number; conversation: Conversation } | null>(null);
    const [deleteConfirmation, setDeleteConfirmation] = useState<Conversation | null>(null);
    
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<{ myFriends: Friend[], global: User[] }>({ myFriends: [], global: [] });
    const [isSearchLoading, setIsSearchLoading] = useState(false);
    const [isSearchFocused, setIsSearchFocused] = useState(false);
    const [requestedUsers, setRequestedUsers] = useState<Set<number>>(new Set());
    
    const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
    const [isLockScreenOpen, setIsLockScreenOpen] = useState(false);

    const debouncedSearchQuery = useDebounce(searchQuery, 300);
    const searchContainerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);
    const { addToast } = useToast();

     // Keyboard shortcut for search (Cmd+K / Ctrl+K)
     useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                inputRef.current?.focus();
            }
            if (e.key === 'Escape' && isSearchFocused) {
                inputRef.current?.blur();
                setIsSearchFocused(false);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isSearchFocused]);

     useEffect(() => {
        if (!debouncedSearchQuery) {
            setSearchResults({ myFriends: [], global: [] });
            setIsSearchLoading(false);
            return;
        }

        setIsSearchLoading(true);
        const searchFriends = friends.filter(friend =>
            friend.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase())
        );
        const globalResults = onGlobalUserSearch(debouncedSearchQuery);
        
        setTimeout(() => {
            setSearchResults({ myFriends: searchFriends, global: globalResults });
            setIsSearchLoading(false);
        }, 250);

    }, [debouncedSearchQuery, friends, onGlobalUserSearch]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
                setIsSearchFocused(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleAddToggle = (user: User) => {
        if (requestedUsers.has(user.id)) {
            setRequestedUsers(prev => {
                const newSet = new Set(prev);
                newSet.delete(user.id);
                return newSet;
            });
        } else {
            onAddFriend(user.id);
            setRequestedUsers(prev => new Set(prev).add(user.id));
        }
    };

    const savedMessagesConversation = useMemo(() => {
        const conv = conversations.find(c => c.friend.id === currentUser.id);
        if (conv) return conv;
        return null;
    }, [conversations, currentUser.id]);

    const sortedConversations = useMemo(() => {
        const convs = [...conversations];
        const friendIdsWithConvs = new Set(convs.filter(c => !c.isGroup).map(c => c.friend.id));
        
        friends.forEach(f => {
            if (!friendIdsWithConvs.has(f.id) && !f.isFriend) { 
                 if (!f.id.toString().includes('.')) { // Basic check if it's a real user ID
                    convs.push({
                        friend: f,
                        messages: [],
                        unreadCount: 0,
                        lastMessageTimestamp: 0,
                        isPinned: false,
                        isGroup: false
                    });
                 }
            }
        });

        return convs.sort((a, b) => {
            if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
            const timeA = a.lastMessageTimestamp || 0;
            const timeB = b.lastMessageTimestamp || 0;
            return timeB - timeA;
        });
    }, [conversations, friends]);

    const filteredConversations = useMemo(() => {
        if (isLockedMode) {
            return sortedConversations.filter(c => !!c.lockPin);
        }
        let filtered = sortedConversations.filter(c => !c.lockPin);

        // Filter out Saved Messages from the main list as it's rendered separately at top
        filtered = filtered.filter(c => c.friend.id !== currentUser.id);

        switch (activeTab) {
            case 'groups':
                return filtered.filter(c => c.isGroup && !c.isArchived);
            case 'archived':
                return filtered.filter(c => c.isArchived);
            case 'all':
            default:
                return filtered.filter(c => !c.isGroup && !c.isArchived);
        }
    }, [sortedConversations, activeTab, isLockedMode, currentUser.id]);
    
    const handleSelectFriend = (friendId: number) => {
        setViewingUserInfo(false);
        onAttemptSelectFriend(friendId);
    }
    
    const selectedConversation = useMemo(() => {
        if (!selectedFriendId) return null;
        
        if (selectedFriendId === currentUser.id) {
             // Construct Saved Messages placeholder if not exists
             const existing = conversations.find(c => c.friend.id === currentUser.id);
             if (existing) return existing;
             return { 
                 friend: { ...currentUser, name: 'Saved Messages', status: 'online' } as Friend, 
                 messages: [], 
                 unreadCount: 0, 
                 lastMessageTimestamp: 0 
             };
        }

        const conv = conversations.find(c => c.friend.id === selectedFriendId);
        if (conv) return conv;
        const friend = friends.find(f => f.id === selectedFriendId);
        return friend ? { friend, messages: [], unreadCount: 0, lastMessageTimestamp: 0 } : null;
    }, [selectedFriendId, conversations, friends, currentUser]);

    const handleOpenContextMenu = (event: React.MouseEvent | React.TouchEvent, conv: Conversation) => {
        const x = 'touches' in event ? event.touches[0].clientX : (event as React.MouseEvent).clientX;
        const y = 'touches' in event ? event.touches[0].clientY : (event as React.MouseEvent).clientY;
        setContextMenu({ x, y, conversation: conv });
    };

    const handleDeleteRequest = (friendId: number) => {
        const convToDelete = conversations.find(c => c.friend.id === friendId);
        if (convToDelete) {
            setDeleteConfirmation(convToDelete);
        }
    };
    
    const confirmDelete = () => {
        if (deleteConfirmation) {
            onDeleteChat(deleteConfirmation.friend.id);
            setDeleteConfirmation(null);
            if(selectedFriendId === deleteConfirmation.friend.id) {
                onAttemptSelectFriend(0);
            }
        }
    };

    const handleUnlockSuccess = () => {
        setIsLockScreenOpen(false);
        setIsLockedMode(true);
        addToast({ title: 'Unlocked', description: 'Hidden chats are now visible.', type: 'success' });
    };

    // Mock update handler for groups
    const handleUpdateGroup = (updates: Partial<Conversation>) => {
        console.log("Updating group:", updates);
        addToast({ title: 'Group Updated', description: 'Changes saved locally (mock).', type: 'success' });
    };

    return (
        <div className="flex h-full text-white">
            <aside className={`relative w-full md:w-80 lg:w-96 flex flex-col bg-black/20 backdrop-blur-xl md:border-r border-white/5 transition-transform duration-300 ease-in-out ${selectedFriendId ? 'hidden md:flex' : 'flex'}`}>
                <header className="p-4 border-b border-white/5 bg-white/[0.02]">
                    <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-3">
                            <button onClick={onToggleSidebar} className="md:hidden text-gray-300 hover:text-white">
                                <MenuIcon className="h-6 w-6" />
                            </button>
                            <h2 className="text-xl font-bold flex items-center gap-2">
                                {isLockedMode ? <LockClosedIcon className="w-5 h-5 text-[var(--theme-color)]" /> : null}
                                {isLockedMode ? 'Locked Chats' : 'Friends'}
                            </h2>
                        </div>
                        <div className="flex items-center gap-1">
                             <button 
                                onClick={() => {
                                    if (isLockedMode) setIsLockedMode(false);
                                    else setIsLockScreenOpen(true);
                                }}
                                style={{ backgroundColor: isLockedMode ? 'var(--theme-color)' : undefined }}
                                className={`p-2 rounded-full transition-colors ${isLockedMode ? 'text-white' : 'text-gray-400 hover:text-white hover:bg-white/10'}`}
                                title={isLockedMode ? "Exit Locked Mode" : "View Locked Chats"}
                             >
                                <LockClosedIcon className="w-5 h-5" />
                             </button>
                        </div>
                    </div>

                     <div ref={searchContainerRef} className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <SearchIcon className={`w-5 h-5 transition-colors ${isSearchFocused ? 'text-[var(--theme-color)]' : 'text-gray-400'}`} />
                        </div>
                        <input
                            ref={inputRef}
                            type="text"
                            placeholder="Search friends or people..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onFocus={() => setIsSearchFocused(true)}
                            style={{ 
                                borderColor: isSearchFocused ? 'var(--theme-color)' : undefined,
                                boxShadow: isSearchFocused ? '0 0 0 1px var(--theme-color)' : undefined,
                                caretColor: 'var(--theme-color)'
                            }}
                            className={`w-full bg-[#18181b]/80 text-white pl-10 pr-10 py-3 text-sm rounded-xl border transition-all shadow-inner
                                ${isSearchFocused ? '' : 'border-white/10 hover:border-white/20'}
                                placeholder-gray-500 focus:outline-none
                            `}
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                            {isSearchLoading ? (
                                <SpinnerIcon className="w-4 h-4 text-[var(--theme-color)] animate-spin" />
                            ) : searchQuery ? (
                                <button 
                                    onClick={() => { setSearchQuery(''); inputRef.current?.focus(); }}
                                    className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-gray-400 hover:text-white transition-colors"
                                >
                                    <CloseIcon className="w-3 h-3" />
                                </button>
                            ) : (
                                <div className="hidden md:flex items-center pointer-events-none">
                                    <kbd className="hidden sm:inline-block border border-gray-600 rounded px-1.5 text-[10px] font-mono text-gray-500 font-bold bg-[#2a2a2d]">
                                        Ctrl K
                                    </kbd>
                                </div>
                            )}
                        </div>

                        {isSearchFocused && searchQuery && (
                            <FriendSearchResults
                                isLoading={isSearchLoading}
                                query={debouncedSearchQuery}
                                results={searchResults}
                                requestedUsers={requestedUsers}
                                onAddToggle={handleAddToggle}
                                onStartChat={(friendId) => {
                                    onAttemptSelectFriend(friendId);
                                    setIsSearchFocused(false);
                                    setSearchQuery('');
                                }}
                            />
                        )}
                    </div>
                </header>

                {!isLockedMode && (
                    <nav className="flex-shrink-0 p-2 flex gap-1 border-b border-white/5 overflow-x-auto hide-scrollbar">
                        <TabButton label="All" active={activeTab === 'all'} onClick={() => setActiveTab('all')} />
                        <TabButton label="Groups" active={activeTab === 'groups'} onClick={() => setActiveTab('groups')} />
                        <TabButton label="Archive" active={activeTab === 'archived'} onClick={() => setActiveTab('archived')} />
                        <TabButton label="Requests" count={pendingRequests.length} active={activeTab === 'requests'} onClick={() => setActiveTab('requests')} />
                    </nav>
                )}

                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    {activeTab === 'requests' && !isLockedMode ? (
                        <FriendRequestsPanel
                            incoming={pendingRequests}
                            sent={sentRequests}
                            onAccept={onAcceptRequest}
                            onDecline={onDeclineRequest}
                            onCancel={onCancelRequest}
                        />
                    ) : (
                        <div className="p-2 space-y-1">
                            {/* Saved Messages - Always visible in 'all' tab if not locked */}
                            {activeTab === 'all' && !isLockedMode && (
                                <SavedMessagesItem 
                                    isSelected={selectedFriendId === currentUser.id} 
                                    onClick={() => handleSelectFriend(currentUser.id)}
                                    lastMessage={savedMessagesConversation?.messages[savedMessagesConversation.messages.length-1]?.message}
                                    displayTime={savedMessagesConversation?.messages[savedMessagesConversation.messages.length-1]?.displayTime}
                                />
                            )}

                            {activeTab === 'groups' && !isLockedMode && (
                                <button 
                                    onClick={() => setIsCreateGroupOpen(true)}
                                    className="w-full flex items-center justify-center gap-2 p-3 mb-2 rounded-xl border-2 border-dashed border-white/10 text-gray-400 hover:text-white hover:bg-white/5 transition-all"
                                    style={{ borderColor: 'color-mix(in srgb, var(--theme-color), transparent 50%)' }}
                                >
                                    <PlusCircleIcon className="w-5 h-5" />
                                    <span className="font-semibold text-sm">Create New Group</span>
                                </button>
                            )}

                             {filteredConversations.length > 0 ? (
                                 filteredConversations.map(conv => (
                                    <FriendListItem 
                                        key={conv.friend.id} 
                                        friend={conv.friend} 
                                        conversation={conv}
                                        isSelected={selectedFriendId === conv.friend.id}
                                        onSelect={() => handleSelectFriend(conv.friend.id)}
                                        onContextMenu={(e) => handleOpenContextMenu(e, conv)}
                                    />
                                 ))
                             ) : (
                                 <div className="flex flex-col items-center justify-center h-40 text-gray-500">
                                     <p className="text-sm">
                                         {isLockedMode ? 'No locked chats found.' : 
                                          activeTab === 'archived' ? 'No archived chats.' :
                                          activeTab === 'groups' ? 'No groups yet.' : 'No conversations found.'}
                                     </p>
                                 </div>
                             )}
                        </div>
                    )}
                </div>
            </aside>
            
            <main className={`flex-1 flex-col bg-black/20 backdrop-blur-xl ${selectedFriendId ? 'flex fixed inset-0 z-50 md:static md:z-auto' : 'hidden md:flex'}`}>
                {selectedConversation ? (
                    // Check if it's Saved Messages
                    selectedConversation.friend.id === currentUser.id ? (
                        <SavedMessagesChat
                            currentUser={currentUser}
                            conversation={selectedConversation}
                            onSendMessage={(msg) => props.onSendMessage(currentUser.id, msg)}
                            onBack={() => onAttemptSelectFriend(0)}
                            chatBackground={chatBackground}
                            onDeleteMessage={(msgIds) => props.onDeleteMessage(currentUser.id, msgIds)}
                            onJoinRoom={onJoinRoom}
                            onJoinVoiceRoom={onJoinVoiceRoom}
                            onViewMedia={setViewingMedia}
                            onForwardMessage={(toId, msg) => props.onForwardDirectMessage(toId, msg, currentUser)}
                        />
                    ) : viewingUserInfo ? (
                        <UserInfoPanel 
                            user={selectedConversation.friend} 
                            conversation={selectedConversation}
                            onBack={() => setViewingUserInfo(false)}
                            onStartCall={onStartCall}
                            onBlockUser={onBlockUser}
                            onUnblockUser={onUnblockUser}
                            blockedUsers={blockedUsers}
                        />
                    ) : selectedConversation.isGroup ? (
                        <GroupChat 
                             key={selectedConversation.friend.id}
                             currentUser={currentUser}
                             conversation={selectedConversation}
                             onSendMessage={(msg) => props.onSendMessage(selectedConversation.friend.id, msg)}
                             onBack={() => { setViewingUserInfo(false); onAttemptSelectFriend(0); }}
                             chatBackground={chatBackground}
                             onUpdateGroup={handleUpdateGroup}
                             onDeleteGroup={() => { onDeleteChat(selectedConversation.friend.id); onAttemptSelectFriend(0); }}
                             onLeaveGroup={() => { onDeleteChat(selectedConversation.friend.id); onAttemptSelectFriend(0); }}
                             onDeleteMessage={(msgIds) => props.onDeleteMessage(selectedConversation.friend.id, msgIds)}
                             onJoinVoiceRoom={() => { /* Implement Voice Room Join for Groups */ }}
                             onViewMedia={setViewingMedia}
                             onForwardMessage={(toFriendId, message) => props.onForwardDirectMessage(toFriendId, message, selectedConversation.friend)}
                        />
                    ) : (
                        <AdvancedChat 
                            key={selectedConversation.friend.id}
                            currentUser={currentUser} 
                            conversation={selectedConversation} 
                            friends={friends.filter(f => ![currentUser.id, selectedConversation.friend.id].includes(f.id))}
                            onSendMessage={(msg) => props.onSendMessage(selectedConversation.friend.id, msg)}
                            onDeleteMessage={(msgIds) => props.onDeleteMessage(selectedConversation.friend.id, msgIds)}
                            onEditMessage={(msgId, newText) => props.onEditMessage(selectedConversation.friend.id, msgId, newText)}
                            onPinMessage={(msgId) => props.onPinMessage(selectedConversation.friend.id, msgId)}
                            onAddReaction={(msgId, emoji) => props.onAddReaction(selectedConversation.friend.id, msgId, emoji)}
                            onBack={() => { setViewingUserInfo(false); onAttemptSelectFriend(0); }}
                            onJoinRoom={onJoinRoom}
                            onJoinVoiceRoom={onJoinVoiceRoom}
                            onForwardMultipleMessages={(toFriendIds, messages) => props.onForwardMultipleDirectMessages(toFriendIds, messages)}
                            onViewMedia={setViewingMedia}
                            chatBackground={chatBackground}
                            onHeaderClick={() => setViewingUserInfo(true)}
                            onStartCall={onStartCall}
                            blockedUsers={blockedUsers}
                            onUnblockUser={onUnblockUser} 
                        />
                    )
                ) : (
                    <div className="flex-1 flex flex-col items-center justify-center relative overflow-hidden">
                        {/* Ambient Background Glows */}
                        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[100px] animate-pulse-slow pointer-events-none"></div>
                        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/10 rounded-full blur-[100px] animate-pulse-slow delay-1000 pointer-events-none"></div>

                        {/* Glass Card Container */}
                        <div className="relative z-10 p-8 md:p-12 bg-white/[0.02] backdrop-blur-[40px] border border-white/10 rounded-[3rem] shadow-2xl text-center w-full max-w-lg mx-auto animate-fade-in-up overflow-hidden ring-1 ring-white/5">
                            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
                            
                            <HeroCarousel />
                        </div>
                    </div>
                )}
            </main>

            <MediaViewerModal
                isOpen={!!viewingMedia}
                onClose={() => setViewingMedia(null)}
                mediaItem={viewingMedia}
            />

            {contextMenu && (
                <ChatContextMenu
                    menu={contextMenu}
                    onClose={() => setContextMenu(null)}
                    onPin={props.onPinChat}
                    onMute={props.onMuteChat}
                    onArchive={props.onArchiveChat}
                    onLock={props.onLockChat}
                    onDelete={handleDeleteRequest}
                />
            )}

            <ConfirmationModal
                isOpen={!!deleteConfirmation}
                onClose={() => setDeleteConfirmation(null)}
                onConfirm={confirmDelete}
                title="Delete Chat"
                message={`Are you sure you want to permanently delete this chat? This action cannot be undone.`}
            />
            
            <CreateGroupModal 
                isOpen={isCreateGroupOpen}
                onClose={() => setIsCreateGroupOpen(false)}
                friends={friends}
                onCreate={onCreateGroup}
            />

            <LockScreenModal
                isOpen={isLockScreenOpen}
                mode="enter"
                onClose={() => setIsLockScreenOpen(false)}
                targetChatName="Locked Folder"
                onPinSet={() => {}}
                onPinUnlockAttempt={(pin) => {
                    if (pin === '1234') {
                        handleUnlockSuccess();
                        return true;
                    }
                    return false;
                }}
            />
        </div>
    );
};

const TabButton: React.FC<{label: string, count?: number, active: boolean, onClick: () => void}> = ({label, count, active, onClick}) => (
    <button 
        onClick={onClick} 
        className={`flex-1 min-w-fit text-xs font-bold uppercase tracking-wide p-2 rounded-lg transition-all ${active ? 'text-white shadow-md' : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'}`}
        style={{ backgroundColor: active ? 'var(--theme-color)' : undefined }}
    >
        <div className="flex items-center justify-center gap-1.5">
            {label}
            {count !== undefined && count > 0 && <span className="bg-white/20 px-1.5 py-0.5 rounded-full text-[10px]">{count}</span>}
        </div>
    </button>
);

const FriendListItem: React.FC<{friend: Friend, conversation: Conversation, isSelected: boolean, onSelect: () => void, onContextMenu: (e: React.MouseEvent | React.TouchEvent) => void}> = ({ friend, conversation, isSelected, onSelect, onContextMenu }) => {
    const status = statusStyles[friend.status];
    const unreadCount = conversation.unreadCount || 0;
    const isLocked = !!conversation.lockPin;
    const isPinned = !!conversation.isPinned;
    const isMuted = !!conversation.isMuted;
    const isArchived = !!conversation.isArchived;
    const isGroup = !!conversation.isGroup;
    
    const { onContextMenu: handleContextMenu, onTouchStart, onTouchMove, onTouchEnd, onClick } = useContextMenuTrigger(
        onContextMenu, 
        onSelect
    );
    
    const lastMessage = conversation.messages[conversation.messages.length - 1];
    const previewText = useMemo(() => {
        if (friend.isTyping) return <span className="text-purple-400 font-medium animate-pulse">typing...</span>;
        if (isLocked && !isSelected) return <span className="italic text-gray-600 flex items-center gap-1"><LockClosedIcon className="w-3 h-3"/> Message hidden</span>;
        
        if (!lastMessage) {
            if (friend.status === 'ingame' && friend.currentRoom) return <span className="text-purple-400">Playing: {friend.currentRoom}</span>;
            if (isGroup) return <span className="text-gray-500 italic">Group created</span>;
            return <span className="text-gray-500 opacity-60">Start a conversation</span>;
        }

        let content = '';
        if (lastMessage.message) content = lastMessage.message;
        else if (lastMessage.caption) content = lastMessage.caption;
        else if (lastMessage.voiceMessage) content = '🎤 Voice Message';
        else if (lastMessage.imageUrl) content = '🖼️ Image';
        else if (lastMessage.videoUrl) content = '🎬 Video';
        else if (lastMessage.call) content = lastMessage.call.type === 'video' ? 'Video Call' : 'Voice Call';
        else content = 'Attachment';

        if (isGroup && lastMessage.senderId !== friend.id) {
             const sender = conversation.participants?.find(p => p.id === lastMessage.senderId);
             const senderName = sender ? sender.name.split(' ')[0] : 'User';
             return <span><span className="text-white/70 mr-1">{senderName}:</span>{content}</span>
        }
        return content;

    }, [friend.isTyping, friend.status, friend.currentRoom, lastMessage, isLocked, isSelected, isGroup, conversation.participants]);

    return (
        <div 
            className={`relative flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-all select-none group overflow-hidden
                ${isPinned ? 'bg-white/[0.03]' : ''}
                ${isMuted ? 'opacity-75' : 'opacity-100'}
            `}
            style={{
                backgroundColor: isSelected ? 'color-mix(in srgb, var(--theme-color), transparent 80%)' : (!isPinned ? 'transparent' : undefined),
                borderColor: isSelected ? 'color-mix(in srgb, var(--theme-color), transparent 70%)' : 'transparent',
                borderWidth: '1px'
            }}
            onClick={onClick}
            onContextMenu={handleContextMenu}
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
        >
            <div className="relative flex-shrink-0">
                {isGroup ? (
                     <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg shadow-lg border-2 border-[#1e1931]">
                        {friend.name.charAt(0).toUpperCase()}
                     </div>
                ) : (
                    <>
                        <img src={friend.avatar} alt={friend.name} className="w-12 h-12 rounded-full object-cover bg-[#1e1931] ring-2 ring-transparent group-hover:ring-white/10 transition-all" />
                        <span className={`absolute bottom-0.5 right-0.5 block h-3.5 w-3.5 rounded-full ring-2 ring-[#111] ${status.bg}`}></span>
                    </>
                )}
            </div>
            
            <div className="flex-1 min-w-0 flex flex-col justify-center gap-0.5">
                <div className="flex justify-between items-center">
                    <h4 className="font-bold text-white truncate text-[15px] flex items-center gap-1.5">
                        {friend.name}
                        {isLocked && <LockClosedIcon className="w-3 h-3 text-gray-400" />}
                        {isMuted && <BellSlashIcon className="w-3 h-3 text-gray-500" />}
                        {isArchived && <ArchiveBoxIcon className="w-3 h-3 text-gray-500" />}
                    </h4>
                    <div className="flex items-center gap-1">
                        {lastMessage && (
                            <span className="text-[11px] text-gray-500 flex-shrink-0 font-medium">
                                {lastMessage.displayTime}
                            </span>
                        )}
                    </div>
                </div>
                
                <div className="flex justify-between items-center mt-0.5">
                    <div className={`text-sm truncate pr-2 ${isLocked && !isSelected ? 'filter blur-[4px] select-none opacity-50' : ''} ${unreadCount > 0 ? 'text-gray-200 font-medium' : 'text-gray-400'}`}>
                        {previewText}
                    </div>
                    
                    <div className="flex items-center gap-2 flex-shrink-0 h-5">
                         {isPinned && <PinIcon className="w-3.5 h-3.5 text-gray-400 rotate-45" />}
                         {unreadCount > 0 && (
                            <div 
                                className="min-w-[20px] h-5 flex items-center justify-center text-white text-[10px] font-bold rounded-full px-1.5 shadow-sm"
                                style={{ backgroundColor: isMuted ? '#4b5563' : '#ef4444' }}
                            >
                                {unreadCount > 99 ? '99+' : unreadCount}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default FriendsPanel;
