
import React from 'react';
import { ShareIcon, SettingsIcon, TrashIcon, GameControllerIcon, MicrophoneIcon } from './icons';

interface VoiceRoomHeaderMenuProps {
    isHost: boolean;
    isRecording: boolean;
    onToggleRecording: () => void;
    onCopyInviteLink: () => void;
    onOpenSettings: () => void;
    onOpenStartGame: () => void;
    onEndRoom: () => void;
}

const VoiceRoomHeaderMenu: React.FC<VoiceRoomHeaderMenuProps> = ({ isHost, isRecording, onToggleRecording, onCopyInviteLink, onOpenSettings, onOpenStartGame, onEndRoom }) => {
    if (!isHost) return null;

    return (
        <div className="absolute top-16 right-4 bg-[#1e1931]/80 backdrop-blur-md border border-white/10 rounded-lg shadow-2xl p-2 text-sm w-56 z-20 animate-fade-in-up" onClick={e => e.stopPropagation()}>
            <MenuItem icon={<MicrophoneIcon />} onClick={onToggleRecording}>
                {isRecording ? 'Stop Recording' : 'Start Recording'}
            </MenuItem>
            <MenuItem icon={<ShareIcon />} onClick={onCopyInviteLink}>Copy Invite Link</MenuItem>
            <MenuItem icon={<GameControllerIcon />} onClick={onOpenStartGame}>Start a Game</MenuItem>
            <MenuItem icon={<SettingsIcon />} onClick={onOpenSettings}>Room Settings</MenuItem>
            <div className="my-1 border-t border-white/10" />
            <MenuItem icon={<TrashIcon />} className="text-red-400" onClick={onEndRoom}>End Room for All</MenuItem>
        </div>
    );
};

const MenuItem: React.FC<{ icon: React.ReactNode; children: React.ReactNode; onClick: () => void; className?: string }> = ({ icon, children, onClick, className }) => (
    <button onClick={onClick} className={`w-full flex items-center gap-3 p-2.5 rounded-md hover:bg-white/10 transition-colors ${className}`}>
        <div className="w-5 h-5 flex items-center justify-center">{icon}</div>
        <span className="font-medium">{children}</span>
    </button>
);

export default VoiceRoomHeaderMenu;