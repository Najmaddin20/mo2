
import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { ActiveCall, User, Conversation, CallState } from '../types';
import { PhoneIcon, VideoCameraIcon, MicrophoneIcon, SpeakerphoneIcon, CloseIcon, VideoCameraOffIcon, UserAddIcon, MicrophoneOffIcon, SwitchCameraIcon, MoreVertIcon, ShareIcon, StopIcon, ChevronDownIcon, MoreHorizIcon, ShieldCheckIcon, SparklesIcon, WaveIcon, BlurIcon, MicNoiseIcon, LayoutGridIcon, ScreenShareIcon, FullscreenEnterIcon } from './icons';

const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
}

const RecordingIndicator = () => (
    <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-500/80 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full animate-fade-in z-20 shadow-lg border border-red-400/30">
        <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
        REC
    </div>
);

const ConnectionQuality = () => (
    <div className="flex gap-0.5 items-end h-3">
        <div className="w-1 h-1.5 bg-green-500 rounded-[1px]"></div>
        <div className="w-1 h-2 bg-green-500 rounded-[1px]"></div>
        <div className="w-1 h-2.5 bg-green-500 rounded-[1px]"></div>
        <div className="w-1 h-3 bg-white/20 rounded-[1px]"></div>
    </div>
);

// Advanced CSS-based visualizer
const WaveformVisualizer = ({ isActive }: { isActive: boolean }) => (
    <div className={`flex items-center gap-1 h-12 ${isActive ? 'opacity-100' : 'opacity-30'}`}>
        {[...Array(12)].map((_, i) => (
            <div 
                key={i} 
                className="w-1 bg-gradient-to-t from-purple-500 to-cyan-400 rounded-full animate-voice-bar"
                style={{ 
                    animationDuration: `${0.4 + Math.random() * 0.4}s`,
                    animationDelay: `${Math.random() * 0.2}s`,
                    height: isActive ? `${20 + Math.random() * 80}%` : '10%' 
                }} 
            />
        ))}
    </div>
);

interface CallManagerProps {
    call: ActiveCall;
    currentUser: User;
    conversation: Conversation;
    onEndCall: (duration: number) => void;
    onAcceptCall: () => void;
    onChangeState: (newState: CallState) => void;
    onSwitchToVideoRequest: () => void;
    onRecordingComplete: (blob: Blob, duration: number) => void;
    isMinimized: boolean;
    onMinimize: () => void;
    onMaximize: () => void;
}

const CallEndedScreen = ({ duration, isClosing }: { duration: number, isClosing: boolean }) => (
    <div className={`flex flex-col h-full items-center justify-center text-white p-8 bg-black/90 backdrop-blur-xl transition-opacity duration-500 ${isClosing ? 'opacity-0' : 'opacity-100'}`}>
        <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mb-6 ring-1 ring-red-500/50 shadow-[0_0_30px_rgba(239,68,68,0.3)]">
            <PhoneIcon className="w-10 h-10 text-red-500" />
        </div>
        <h2 className="text-3xl font-bold tracking-tight">Call Ended</h2>
        <p className="text-gray-400 mt-2 font-mono text-lg">{formatDuration(duration)}</p>
    </div>
);

const DraggableOverlay: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [position, setPosition] = useState(() => {
        // Safe initial position calculation
        const cardWidth = 320;
        const safeX = Math.max(16, window.innerWidth - cardWidth - 16);
        const safeY = window.innerHeight - 180;
        return { x: safeX, y: safeY };
    });
    const [isDragging, setIsDragging] = useState(false);
    const dragOffset = useRef({ x: 0, y: 0 });
    const overlayRef = useRef<HTMLDivElement>(null);

    const handleStart = (clientX: number, clientY: number) => {
        if (!overlayRef.current) return;
        const rect = overlayRef.current.getBoundingClientRect();
        dragOffset.current = { x: clientX - rect.left, y: clientY - rect.top };
        setIsDragging(true);
    };

    const handleMove = useCallback((clientX: number, clientY: number) => {
        if (!isDragging || !overlayRef.current) return;
        
        // Calculate new position
        let newX = clientX - dragOffset.current.x;
        let newY = clientY - dragOffset.current.y;

        // Boundaries (keep within window)
        const maxX = window.innerWidth - overlayRef.current.offsetWidth;
        const maxY = window.innerHeight - overlayRef.current.offsetHeight;
        
        newX = Math.max(0, Math.min(newX, maxX));
        newY = Math.max(0, Math.min(newY, maxY));

        setPosition({ x: newX, y: newY });
    }, [isDragging]);

    const handleEnd = () => setIsDragging(false);

    useEffect(() => {
        const onMouseMove = (e: MouseEvent) => handleMove(e.clientX, e.clientY);
        const onTouchMove = (e: TouchEvent) => handleMove(e.touches[0].clientX, e.touches[0].clientY);
        
        if (isDragging) {
            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('mouseup', handleEnd);
            window.addEventListener('touchmove', onTouchMove, { passive: false });
            window.addEventListener('touchend', handleEnd);
        }
        return () => {
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', handleEnd);
            window.removeEventListener('touchmove', onTouchMove);
            window.removeEventListener('touchend', handleEnd);
        };
    }, [isDragging, handleMove]);

    return (
        <div 
            ref={overlayRef}
            className="fixed z-[150] touch-none cursor-move transition-shadow duration-200 hover:shadow-2xl"
            style={{ left: position.x, top: position.y }}
            onMouseDown={(e) => handleStart(e.clientX, e.clientY)}
            onTouchStart={(e) => handleStart(e.touches[0].clientX, e.touches[0].clientY)}
        >
            {children}
        </div>
    );
};

const MinimizedCallOverlay = ({ 
    call, 
    duration, 
    isMobile, 
    onMaximize, 
    onEndCall,
    isMuted,
    onToggleMute
}: {
    call: ActiveCall, 
    duration: number, 
    isMobile: boolean, 
    onMaximize: () => void, 
    onEndCall: () => void,
    isMuted: boolean,
    onToggleMute: () => void
}) => {
    // Unified Floating Card for both Mobile and Desktop
    return (
        <DraggableOverlay>
            <div className="w-80 max-w-[90vw] bg-[#18181b]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-slide-in-from-bottom ring-1 ring-white/5">
                <div 
                    className="relative h-20 bg-gradient-to-r from-[#2c2c35] to-[#1c1c1e] flex items-center p-4 gap-4 cursor-move hover:brightness-110 transition-all group select-none" 
                    onDoubleClick={onMaximize}
                >
                    <div className="relative pointer-events-none">
                        <img src={call.friend.avatar} className="w-12 h-12 rounded-full object-cover border-2 border-white/10 group-hover:border-white/30 transition-colors" />
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-[#1c1c1e] rounded-full animate-pulse"></div>
                    </div>
                    <div className="flex-1 min-w-0 pointer-events-none">
                        <h4 className="font-bold text-white truncate text-base">{call.friend.name}</h4>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                            <span className="font-mono text-green-400">{formatDuration(duration)}</span>
                            <span>•</span>
                            <span>{call.state.includes('video') ? 'Video Call' : 'Voice Call'}</span>
                        </div>
                    </div>
                    <button 
                        className="p-2 bg-white/5 rounded-full text-white hover:bg-white/20 transition-colors"
                        onClick={(e) => { e.stopPropagation(); onMaximize(); }}
                        onMouseDown={(e) => e.stopPropagation()} // Prevent drag start on button
                        onTouchStart={(e) => e.stopPropagation()}
                    >
                        <FullscreenEnterIcon className="w-5 h-5 text-gray-300" />
                    </button>
                </div>
                
                {/* Mini Actions */}
                <div className="grid grid-cols-2 divide-x divide-white/5 bg-[#222] border-t border-white/5" onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
                    <button 
                        onClick={onToggleMute} 
                        className={`p-3 flex justify-center items-center gap-2 hover:bg-white/5 transition-colors ${isMuted ? 'text-red-400 bg-red-500/10' : 'text-gray-300'}`}
                    >
                        {isMuted ? <MicrophoneOffIcon className="w-5 h-5" /> : <MicrophoneIcon className="w-5 h-5" />}
                        <span className="text-xs font-bold">{isMuted ? 'Unmute' : 'Mute'}</span>
                    </button>
                    <button 
                        onClick={onEndCall} 
                        className="p-3 flex justify-center items-center gap-2 hover:bg-red-500/20 text-red-500 transition-colors bg-red-500/5"
                    >
                        <PhoneIcon className="w-5 h-5 rotate-[135deg]" />
                        <span className="text-xs font-bold">End</span>
                    </button>
                </div>
            </div>
        </DraggableOverlay>
    );
};

const CallManager: React.FC<CallManagerProps> = ({ call, currentUser, onEndCall, onAcceptCall, onChangeState, onSwitchToVideoRequest, onRecordingComplete, isMinimized, onMinimize, onMaximize }) => {
    const { friend, state } = call;
    const [duration, setDuration] = useState(0);
    const [isMuted, setIsMuted] = useState(false);
    const [isSpeaker, setIsSpeaker] = useState(true);
    const [isCameraOn, setIsCameraOn] = useState(state.includes('video'));
    const [isRecording, setIsRecording] = useState(false);
    const [callEnded, setCallEnded] = useState<{ ended: boolean, finalDuration: number }>({ ended: false, finalDuration: 0 });
    const [isClosing, setIsClosing] = useState(false);
    
    // Advanced Features State
    const [videoEffects, setVideoEffects] = useState(false); 
    const [blurBackground, setBlurBackground] = useState(false);
    const [noiseCancellation, setNoiseCancellation] = useState(true);
    const [screenShare, setScreenShare] = useState(false);
    
    const localVideoRef = useRef<HTMLVideoElement>(null);
    const remoteVideoRef = useRef<HTMLVideoElement>(null);
    const [localStream, setLocalStream] = useState<MediaStream | null>(null);

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const durationRef = useRef(duration);
    
    // Camera flip state
    const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
    const [currentVideoDeviceIndex, setCurrentVideoDeviceIndex] = useState(0);
    
    const isMobile = window.innerWidth < 768;

    useEffect(() => {
        durationRef.current = duration;
    }, [duration]);

    // --- AUTO-ANSWER SIMULATION FOR TESTING ---
    useEffect(() => {
        let autoAnswerTimer: number;
        
        if (state === 'outgoing-voice') {
            autoAnswerTimer = window.setTimeout(() => {
                onChangeState('active-voice');
            }, 3000); // Answer after 3 seconds
        } else if (state === 'outgoing-video') {
            autoAnswerTimer = window.setTimeout(() => {
                onChangeState('active-video');
            }, 3000); // Answer after 3 seconds
        }

        return () => clearTimeout(autoAnswerTimer);
    }, [state, onChangeState]);
    // ------------------------------------------

    const handleEndSequence = useCallback(() => {
        if (callEnded.ended) return;

        if (mediaRecorderRef.current?.state === 'recording' || mediaRecorderRef.current?.state === 'paused') {
            mediaRecorderRef.current.stop();
        }
        if (isRecording) {
            setIsRecording(false);
        }
    
        setCallEnded({ ended: true, finalDuration: durationRef.current });
        
        setTimeout(() => {
            setIsClosing(true);
            setTimeout(() => {
                onEndCall(durationRef.current);
            }, 500); // Animation duration
        }, 2000); // Show end screen duration
    }, [onEndCall, isRecording, callEnded.ended]);


    useEffect(() => {
        let timer: number | undefined;
        if (state.startsWith('active') && !callEnded.ended) {
            timer = window.setInterval(() => setDuration(prev => prev + 1), 1000);
        } else {
            setDuration(0);
        }
        return () => clearInterval(timer);
    }, [state, callEnded.ended]);

    // Stream handling logic
    useEffect(() => {
        if (!state.includes('video')) {
            localStream?.getTracks().forEach(track => track.stop());
            setLocalStream(null);
            return;
        }

        const getStream = async () => {
            try {
                const devices = await navigator.mediaDevices.enumerateDevices();
                const videoInputs = devices.filter(device => device.kind === 'videoinput');
                setVideoDevices(videoInputs);

                const deviceIndex = Math.min(currentVideoDeviceIndex, videoInputs.length - 1);
                const deviceId = videoInputs[deviceIndex]?.deviceId;

                const constraints = {
                    video: deviceId ? { deviceId: { exact: deviceId } } : true,
                    audio: true
                };
                
                if (localStream) {
                    localStream.getTracks().forEach(track => track.stop());
                }

                const stream = await navigator.mediaDevices.getUserMedia(constraints);
                setLocalStream(stream);
                if (localVideoRef.current) {
                    localVideoRef.current.srcObject = stream;
                }
                setIsCameraOn(true);
            } catch (err) {
                console.error("Error accessing media devices.", err);
                setIsCameraOn(false);
            }
        };

        getStream();

        return () => {};
    }, [state, currentVideoDeviceIndex]);

    // Re-attach stream when maximizing
    useEffect(() => {
        if (localVideoRef.current && localStream) {
            localVideoRef.current.srcObject = localStream;
        }
    }, [localStream, isMinimized]);

    const handleFlipCamera = () => {
        if (videoDevices.length > 1) {
            setCurrentVideoDeviceIndex(prevIndex => (prevIndex + 1) % videoDevices.length);
        }
    };

    const toggleMute = () => setIsMuted(!isMuted);
    const toggleSpeaker = () => setIsSpeaker(!isSpeaker);
    const toggleCamera = () => {
        if (localStream) {
            localStream.getVideoTracks().forEach(track => {
                track.enabled = !track.enabled;
            });
        }
        setIsCameraOn(!isCameraOn);
    };

    const baseProps = { 
        call, duration, isMuted, isSpeaker, isCameraOn, localVideoRef, remoteVideoRef, 
        toggleMute, toggleSpeaker, toggleCamera, switchToVideo: onSwitchToVideoRequest, 
        onEndCall: handleEndSequence, onAcceptCall, handleFlipCamera, videoDevices, 
        isRecording, setIsRecording, onMinimize,
        videoEffects, setVideoEffects, blurBackground, setBlurBackground,
        noiseCancellation, setNoiseCancellation, screenShare, setScreenShare
    };

    if (callEnded.ended) {
        return (
            <div className={`fixed inset-0 z-[100] bg-black transition-opacity duration-500 ${isClosing ? 'opacity-0' : 'opacity-100'}`}>
                <CallEndedScreen duration={callEnded.finalDuration} isClosing={isClosing} />
            </div>
        );
    }
    
    // Render Minimized State
    if (isMinimized && state.startsWith('active')) {
        return (
            <MinimizedCallOverlay 
                call={call}
                duration={duration}
                isMobile={isMobile}
                onMaximize={onMaximize}
                onEndCall={handleEndSequence}
                isMuted={isMuted}
                onToggleMute={toggleMute}
            />
        );
    }
    
    const renderRingingScreen = () => <RingingScreen {...baseProps} />;
    const renderActiveVoiceCall = () => <ActiveVoiceCall {...baseProps} />;
    const renderActiveVideoCall = () => <ActiveVideoCall {...baseProps} />;

    let content;
    switch (state) {
        case 'outgoing-voice':
        case 'incoming-voice':
        case 'outgoing-video':
        case 'incoming-video':
            content = renderRingingScreen();
            break;
        case 'active-voice':
            content = renderActiveVoiceCall();
            break;
        case 'active-video':
            content = renderActiveVideoCall();
            break;
        default:
            content = null;
    }

    return isMobile ? (
        <div className="fixed inset-0 z-[100] animate-fade-in bg-[#0f0f0f]">{content}</div>
    ) : (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center animate-fade-in">
            <div 
                className="w-[400px] h-[750px] border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden animate-slide-in-from-top-right bg-[#0f0f0f] ring-8 ring-black"
            >
                {content}
            </div>
        </div>
    );
};

const ControlButton = ({ icon, onClick, className = "", active = false, label, disabled }: { icon: React.ReactNode, onClick: () => void, className?: string, active?: boolean, label?: string, disabled?: boolean }) => (
    <div className="flex flex-col items-center gap-2 group">
        <button 
            onClick={onClick}
            disabled={disabled}
            className={`w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center rounded-full transition-all active:scale-95 shadow-lg 
            ${active ? 'bg-white text-black' : 'bg-white/10 text-white hover:bg-white/20'} 
            backdrop-blur-md disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
        >
            {icon}
        </button>
        {label && <span className="text-[10px] font-medium text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity absolute -top-6 bg-black/50 px-2 py-0.5 rounded pointer-events-none whitespace-nowrap">{label}</span>}
    </div>
);

const RingingScreen: React.FC<any> = ({ call, onEndCall, onAcceptCall }) => {
    const { friend, state } = call;
    const isIncoming = state.startsWith('incoming');
    const statusText = isIncoming ? 'Incoming Call...' : 'Calling...';

    return (
        <div className="relative flex flex-col h-full items-center justify-between text-white p-8 overflow-hidden bg-[#0f0f0f]">
            {/* Immersive Background */}
            <div className="absolute inset-0 z-0">
                <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/80 z-10"></div>
                <img src={friend.avatar} className="w-full h-full object-cover filter blur-2xl scale-110 opacity-50 animate-pulse-subtle" />
            </div>

            <div className="relative z-10 flex flex-col items-center w-full mt-16 space-y-8">
                <div className="flex items-center gap-2 text-green-400 text-[10px] font-bold uppercase tracking-widest bg-green-900/30 px-3 py-1.5 rounded-full backdrop-blur-md border border-green-500/20 shadow-lg">
                    <ShieldCheckIcon className="w-3 h-3" /> End-to-End Encrypted
                </div>
                
                <div className="relative">
                    {/* Animated Rings */}
                    <div className="absolute inset-0 rounded-full bg-white/5 animate-[ping_2s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
                    <div className="absolute -inset-4 rounded-full border border-white/10 animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
                    <img src={friend.avatar} alt={friend.name} className="w-32 h-32 sm:w-40 sm:h-40 rounded-full relative z-10 border-4 border-white/10 shadow-2xl object-cover" />
                </div>
                
                <div className="text-center space-y-2">
                    <h2 className="text-3xl sm:text-4xl font-bold drop-shadow-lg">{friend.name}</h2>
                    <p className="text-gray-300 font-medium text-base tracking-wide animate-pulse">{statusText}</p>
                </div>
            </div>

            <div className={`relative z-10 flex w-full items-center pb-12 gap-8 ${isIncoming ? 'justify-between px-6' : 'justify-center'}`}>
                <button onClick={onEndCall} className="flex flex-col items-center gap-2 group">
                    <div className="w-16 h-16 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center shadow-lg shadow-red-500/30 transition-transform transform group-active:scale-95">
                        <PhoneIcon className="w-8 h-8 text-white rotate-[135deg]" />
                    </div>
                    <span className="text-xs font-bold uppercase tracking-wide opacity-80">Decline</span>
                </button>
                
                {isIncoming && (
                    <button onClick={onAcceptCall} className="flex flex-col items-center gap-2 group">
                        <div className="w-16 h-16 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center shadow-lg shadow-green-500/30 transition-transform transform group-active:scale-95 animate-bounce">
                            <PhoneIcon className="w-8 h-8 text-white" />
                        </div>
                        <span className="text-xs font-bold uppercase tracking-wide opacity-80">Accept</span>
                    </button>
                )}
            </div>
        </div>
    );
};

const ActiveVoiceCall: React.FC<any> = (props) => {
    const { call, duration, isMuted, isSpeaker, toggleMute, toggleSpeaker, switchToVideo, onEndCall, isRecording, setIsRecording, onMinimize, noiseCancellation, setNoiseCancellation } = props;

    return (
        <div className="relative flex flex-col h-full items-center text-white bg-[#0f0f0f] overflow-hidden">
            {/* Dynamic Audio Background */}
            <div className="absolute inset-0 pointer-events-none opacity-30">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-radial from-purple-900/40 to-transparent rounded-full animate-pulse-slow"></div>
                <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            </div>

            {isRecording && <RecordingIndicator />}
            
            <header className="w-full flex justify-between items-center p-6 z-10">
                <button onClick={onMinimize} className="p-2 bg-white/5 hover:bg-white/10 rounded-full backdrop-blur-md transition-colors">
                    <ChevronDownIcon className="w-6 h-6 text-gray-300"/>
                </button>
                <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 bg-white/5 px-3 py-1 rounded-full border border-white/5 backdrop-blur-sm">
                    <ShieldCheckIcon className="w-3 h-3" /> Encrypted
                </div>
                <button className="p-2 bg-white/5 hover:bg-white/10 rounded-full backdrop-blur-md transition-colors">
                    <UserAddIcon className="w-5 h-5 text-gray-300"/>
                </button>
            </header>
            
            <div className="flex-1 flex flex-col items-center justify-center -mt-12 z-10 w-full relative px-6">
                 {/* Visualizer Avatar */}
                 <div className="relative mb-10">
                    {!isMuted && (
                        <div className="absolute inset-0 -m-4">
                             {/* CSS-based spinning gradient ring */}
                             <div className="w-full h-full rounded-full border-2 border-purple-500/30 animate-spin-slow"></div>
                        </div>
                    )}
                    <div className="w-40 h-40 sm:w-48 sm:h-48 rounded-full p-1 bg-gradient-to-br from-purple-600 to-blue-600 shadow-[0_0_40px_rgba(124,58,237,0.3)] relative z-10">
                        <img src={call.friend.avatar} className="w-full h-full rounded-full object-cover bg-zinc-900" />
                    </div>
                    {/* Signal Strength Indicator */}
                    <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-xl px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-2 z-20 shadow-lg">
                        <ConnectionQuality />
                        <span className="text-[10px] font-bold text-green-400 tracking-wide">EXCELLENT</span>
                    </div>
                 </div>

                 <div className="text-center space-y-3">
                    <h2 className="text-3xl font-bold text-white tracking-tight">{call.friend.name}</h2>
                    <div className="flex flex-col items-center gap-2">
                        <p className="text-purple-300 font-mono text-lg">{formatDuration(duration)}</p>
                        {!isMuted && <WaveformVisualizer isActive={true} />}
                    </div>
                 </div>
            </div>
            
            {/* Glassmorphism Control Dock */}
            <div className="w-full px-6 pb-10 z-20">
                 <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] p-4 flex justify-between items-center shadow-2xl relative">
                    {/* Noise Cancel Toggle */}
                    <button 
                        onClick={() => setNoiseCancellation(!noiseCancellation)}
                        className={`absolute -top-14 left-4 p-2.5 rounded-full backdrop-blur-md border border-white/10 shadow-lg transition-all ${noiseCancellation ? 'bg-blue-500/20 text-blue-400' : 'bg-black/40 text-gray-400'}`}
                        title="Noise Cancellation"
                    >
                        <MicNoiseIcon className="w-5 h-5" />
                    </button>

                    <ControlButton onClick={toggleSpeaker} active={isSpeaker} icon={<SpeakerphoneIcon className="w-6 h-6"/>} label="Speaker"/>
                    <ControlButton onClick={switchToVideo} icon={<VideoCameraIcon className="w-6 h-6"/>} label="Video"/>
                    <ControlButton onClick={toggleMute} active={isMuted} icon={isMuted ? <MicrophoneOffIcon className="w-6 h-6"/> : <MicrophoneIcon className="w-6 h-6"/>} label="Mute"/>
                    
                    <div className="w-px h-10 bg-white/10 mx-1"></div>
                    
                    <button onClick={onEndCall} className="w-14 h-14 flex items-center justify-center rounded-2xl bg-red-500 hover:bg-red-600 text-white shadow-lg shadow-red-500/30 transition-all active:scale-95">
                        <PhoneIcon className="w-7 h-7 rotate-[135deg]" />
                    </button>
                </div>
            </div>
        </div>
    );
};

const ActiveVideoCall: React.FC<any> = (props) => {
    const { call, duration, isMuted, isSpeaker, isCameraOn, localVideoRef, remoteVideoRef, toggleMute, toggleSpeaker, toggleCamera, onEndCall, handleFlipCamera, videoDevices, onMinimize, videoEffects, setVideoEffects, blurBackground, setBlurBackground, screenShare, setScreenShare } = props;
    const [showControls, setShowControls] = useState(true);
    const controlsTimer = useRef<number | undefined>(undefined);
    const [showMoreMenu, setShowMoreMenu] = useState(false);
    
    const hideControls = useCallback(() => {
        setShowControls(false);
        setShowMoreMenu(false);
    }, []);

    const showControlsAndAutoHide = useCallback(() => {
        setShowControls(true);
        if (controlsTimer.current) clearTimeout(controlsTimer.current);
        controlsTimer.current = window.setTimeout(hideControls, 4000);
    }, [hideControls]);

    useEffect(() => {
        showControlsAndAutoHide();
        return () => { if (controlsTimer.current) clearTimeout(controlsTimer.current) };
    }, [showControlsAndAutoHide]);
    
    return (
        <div className="relative w-full h-full bg-black text-white group overflow-hidden" onMouseMove={showControlsAndAutoHide} onClick={showControlsAndAutoHide}>
            {/* Remote Video */}
            <video 
                ref={remoteVideoRef} 
                playsInline 
                autoPlay 
                className={`absolute inset-0 w-full h-full object-cover transition-all duration-500 ${videoEffects ? 'sepia-[.3]' : ''}`} 
                poster={call.friend.profileBanner || call.friend.avatar}
            />
            
            {/* Enhanced Draggable PiP */}
            <DraggablePiP>
                <video ref={localVideoRef} playsInline autoPlay muted className={`w-full h-full object-cover transition-all ${blurBackground ? 'blur-sm' : ''}`}/>
                {/* Status Indicators on PiP */}
                <div className="absolute bottom-2 left-2 flex gap-1">
                    {isMuted && <div className="bg-red-500/80 p-1 rounded-full"><MicrophoneOffIcon className="w-3 h-3 text-white"/></div>}
                </div>
                <div className="absolute inset-0 border border-white/20 rounded-[inherit] pointer-events-none shadow-inner"></div>
            </DraggablePiP>

            {/* Top Gradient */}
            <div className={`absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/90 to-transparent transition-opacity duration-300 pointer-events-none ${showControls ? 'opacity-100' : 'opacity-0'}`} />

            {/* Header Info */}
            <div className={`absolute top-0 left-0 right-0 p-6 transition-all duration-300 flex justify-between items-start ${showControls ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0'}`}>
                <div className="flex items-center gap-3">
                    <button onClick={onMinimize} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-xl transition-colors border border-white/5">
                        <ChevronDownIcon className="w-6 h-6"/>
                    </button>
                    <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-white drop-shadow-md leading-none">{call.friend.name}</h3>
                        <span className="text-xs font-mono text-green-400 bg-black/40 px-2 py-0.5 rounded mt-1 backdrop-blur-sm self-start">{formatDuration(duration)}</span>
                    </div>
                </div>
                
                {/* Quick Toggles (Top Right) */}
                <div className="flex gap-2">
                     <button onClick={() => setBlurBackground(!blurBackground)} className={`p-2.5 rounded-full backdrop-blur-xl transition-colors ${blurBackground ? 'bg-blue-500 text-white' : 'bg-black/30 text-gray-300 hover:bg-black/50'}`}>
                        <BlurIcon className="w-5 h-5"/>
                    </button>
                    <button onClick={handleFlipCamera} className="p-2.5 bg-black/30 hover:bg-black/50 rounded-full backdrop-blur-xl text-gray-300 transition-colors" disabled={videoDevices.length <= 1}>
                        <SwitchCameraIcon className="w-5 h-5"/>
                    </button>
                </div>
            </div>

            {/* Bottom Gradient */}
            <div className={`absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-black/90 via-black/50 to-transparent transition-opacity duration-300 pointer-events-none ${showControls ? 'opacity-100' : 'opacity-0'}`} />

            {/* Responsive Control Bar */}
            <div className={`absolute bottom-8 left-0 right-0 flex justify-center px-4 transition-all duration-300 ${showControls ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                <div className="flex items-center gap-3 sm:gap-5 p-2 sm:px-6 sm:py-3 bg-[#1c1c1e]/80 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl overflow-visible relative">
                    
                    <ControlButton onClick={toggleMute} active={!isMuted} icon={isMuted ? <MicrophoneOffIcon className="w-6 h-6" /> : <MicrophoneIcon className="w-6 h-6"/>} className={isMuted ? "bg-white/10 text-white" : "bg-white text-black"} />
                    <ControlButton onClick={toggleCamera} active={isCameraOn} icon={isCameraOn ? <VideoCameraIcon className="w-6 h-6" /> : <VideoCameraOffIcon className="w-6 h-6"/>} className={!isCameraOn ? "bg-white/10 text-red-400" : ""} />
                    
                    <button onClick={onEndCall} className="w-16 h-16 bg-red-500 hover:bg-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-500/30 transition-all active:scale-95 mx-2">
                        <PhoneIcon className="w-8 h-8 text-white rotate-[135deg]" />
                    </button>

                    <ControlButton onClick={toggleSpeaker} active={isSpeaker} icon={<SpeakerphoneIcon className="w-6 h-6"/>} />
                    
                    <div className="relative">
                        <ControlButton onClick={() => setShowMoreMenu(!showMoreMenu)} icon={<MoreVertIcon className="w-6 h-6"/>} active={showMoreMenu} />
                        
                        {/* More Menu (Popup) */}
                        {showMoreMenu && (
                            <div className="absolute bottom-full right-0 mb-4 w-56 bg-[#1c1c1e]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl p-2 animate-fade-in-up flex flex-col gap-1 z-50 origin-bottom-right">
                                <button onClick={() => setScreenShare(!screenShare)} className={`flex items-center gap-3 p-3 rounded-xl hover:bg-white/10 transition-colors text-sm font-medium ${screenShare ? 'text-green-400' : 'text-white'}`}>
                                    <ScreenShareIcon className="w-5 h-5" /> {screenShare ? 'Stop Sharing' : 'Share Screen'}
                                </button>
                                <button onClick={() => setVideoEffects(!videoEffects)} className={`flex items-center gap-3 p-3 rounded-xl hover:bg-white/10 transition-colors text-sm font-medium ${videoEffects ? 'text-purple-400' : 'text-white'}`}>
                                    <SparklesIcon className="w-5 h-5" /> Filters & Effects
                                </button>
                                <button className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/10 transition-colors text-sm font-medium text-white">
                                    <LayoutGridIcon className="w-5 h-5" /> Change Layout
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Improved Draggable PiP with boundaries and snap
const DraggablePiP: React.FC<{children: React.ReactNode}> = ({ children }) => {
    const pipRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState({ x: 16, y: 80 }); // Initial position
    const [isDragging, setIsDragging] = useState(false);
    const dragOffset = useRef({ x: 0, y: 0 });

    const handleStart = (clientX: number, clientY: number) => {
        if (!pipRef.current) return;
        const rect = pipRef.current.getBoundingClientRect();
        dragOffset.current = { x: clientX - rect.left, y: clientY - rect.top };
        setIsDragging(true);
    };

    const handleMove = useCallback((clientX: number, clientY: number) => {
        if (!isDragging || !pipRef.current) return;
        const parent = pipRef.current.offsetParent as HTMLElement;
        if (!parent) return;

        let newX = clientX - parent.getBoundingClientRect().left - dragOffset.current.x;
        let newY = clientY - parent.getBoundingClientRect().top - dragOffset.current.y;

        // Boundaries
        const maxX = parent.clientWidth - pipRef.current.offsetWidth - 16;
        const maxY = parent.clientHeight - pipRef.current.offsetHeight - 16;
        
        newX = Math.max(16, Math.min(newX, maxX));
        newY = Math.max(16, Math.min(newY, maxY));

        setPosition({ x: newX, y: newY });
    }, [isDragging]);

    const handleEnd = () => setIsDragging(false);

    // Mouse Events
    const onMouseDown = (e: React.MouseEvent) => {
        e.preventDefault(); // Prevent default drag behavior
        handleStart(e.clientX, e.clientY);
    };
    
    // Touch Events
    const onTouchStart = (e: React.TouchEvent) => {
        handleStart(e.touches[0].clientX, e.touches[0].clientY);
    };

    useEffect(() => {
        const onMouseMove = (e: MouseEvent) => handleMove(e.clientX, e.clientY);
        const onTouchMove = (e: TouchEvent) => handleMove(e.touches[0].clientX, e.touches[0].clientY);
        
        if (isDragging) {
            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('mouseup', handleEnd);
            window.addEventListener('touchmove', onTouchMove, { passive: false });
            window.addEventListener('touchend', handleEnd);
        }
        return () => {
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', handleEnd);
            window.removeEventListener('touchmove', onTouchMove);
            window.removeEventListener('touchend', handleEnd);
        };
    }, [isDragging, handleMove]);

    return (
        <div 
            ref={pipRef} 
            className="absolute w-32 h-48 sm:w-40 sm:h-60 rounded-2xl overflow-hidden bg-black shadow-[0_8px_30px_rgba(0,0,0,0.5)] transition-shadow duration-300 z-30 touch-none border-2 border-white/10"
            style={{ top: position.y, left: position.x, cursor: isDragging ? 'grabbing' : 'grab' }}
            onMouseDown={onMouseDown}
            onTouchStart={onTouchStart}
        >
            {children}
        </div>
    )
}

export default CallManager;
