
import React from 'react';
import type { User } from '../types';

interface BannedUsersManagerProps {
    bannedUsers: User[];
    onUnblockUser: (userId: number) => void;
}

const BannedUsersManager: React.FC<BannedUsersManagerProps> = ({ bannedUsers, onUnblockUser }) => {
    return (
        <div>
            <h3 className="text-sm font-medium text-gray-300 mb-2">Banned Users</h3>
            <div className="bg-black/30 border border-white/20 rounded-lg p-3 space-y-2">
                {(!bannedUsers || bannedUsers.length === 0) ? (
                    <p className="text-sm text-gray-400 text-center py-2">No users have been banned from this room.</p>
                ) : (
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                        {bannedUsers.map(user => (
                            <div key={user.id} className="flex items-center justify-between p-2 rounded-lg bg-black/20">
                                <div className="flex items-center gap-3">
                                    <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full" />
                                    <span className="text-sm text-white font-medium">{user.name}</span>
                                </div>
                                <button
                                    onClick={() => onUnblockUser(user.id)}
                                    className="px-3 py-1 text-xs font-semibold rounded-md text-white bg-green-500/80 hover:bg-green-500/100 transition-colors"
                                >
                                    Unban
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default BannedUsersManager;
