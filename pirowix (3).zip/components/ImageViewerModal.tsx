import React from 'react';
import { CloseIcon, DownloadIcon } from './icons';

interface ImageViewerModalProps {
    isOpen: boolean;
    onClose: () => void;
    imageUrl: string;
    imageName?: string;
}

const ImageViewerModal: React.FC<ImageViewerModalProps> = ({ isOpen, onClose, imageUrl, imageName = 'profile_picture.jpg' }) => {
    if (!isOpen) return null;

    const handleDownload = (e: React.MouseEvent) => {
        e.stopPropagation();
        const link = document.createElement('a');
        link.href = imageUrl;
        link.download = imageName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-lg flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
        >
             <div className="absolute top-4 right-4 z-20 flex gap-4">
                <button
                    onClick={handleDownload}
                    className="bg-black/40 backdrop-blur-sm rounded-lg p-2 text-white flex items-center gap-2 hover:bg-black/60 transition-colors"
                >
                    <DownloadIcon className="w-6 h-6"/>
                </button>
                <button onClick={onClose} className="text-white/70 hover:text-white bg-black/40 backdrop-blur-sm rounded-full p-1.5">
                    <CloseIcon className="w-6 h-6" />
                </button>
            </div>
            <div className="w-full h-full flex flex-col items-center justify-center" onClick={(e) => e.stopPropagation()}>
                <img 
                    src={imageUrl} 
                    alt="Full screen view" 
                    className="max-w-full max-h-full object-contain rounded-lg shadow-2xl animate-fade-in-up" 
                />
            </div>
        </div>
    );
};

export default ImageViewerModal;
