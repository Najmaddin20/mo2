import React from 'react';
import type { VoiceRoom } from '../types';
import { CloseIcon, GameControllerIcon, QuestionMarkCircleIcon, SparklesIcon } from './icons';

interface StartGameModalProps {
    isOpen: boolean;
    onClose: () => void;
    onGameAction: (action: 'start' | 'next' | 'end' | 'truth' | 'dare' | 'vote', payload?: any) => void;
}

const games = [
    {
        type: 'truth-or-dare',
        title: 'Truth or Dare',
        description: 'A classic party game to get to know each other.',
        icon: <GameControllerIcon className="w-8 h-8 text-purple-400" />,
    },
    {
        type: 'would-you-rather',
        title: 'Would You Rather',
        description: 'Make tough choices and see what others pick.',
        icon: <QuestionMarkCircleIcon className="w-8 h-8 text-cyan-400" />,
    },
    {
        type: 'this-or-that',
        title: 'This or That',
        description: 'Quick polls on fun topics.',
        icon: <SparklesIcon className="w-8 h-8 text-yellow-400" />,
    },
    {
        type: 'charades',
        title: 'Charades',
        description: 'AI-powered word generation for endless fun.',
        icon: <SparklesIcon className="w-8 h-8 text-orange-400" />,
    }
];

const StartGameModal: React.FC<StartGameModalProps> = ({ isOpen, onClose, onGameAction }) => {
    if (!isOpen) return null;

    const handleStartGame = (gameType: 'truth-or-dare' | 'would-you-rather' | 'this-or-that' | 'charades') => {
        onGameAction('start', { gameType });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl p-8 space-y-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">Start a Game</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6" /></button>
                </div>
                <p className="text-gray-300">Choose a game to play with everyone in the room.</p>
                <div className="space-y-3">
                    {games.map(game => (
                         <button 
                            key={game.type}
                            onClick={() => handleStartGame(game.type as any)}
                            className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all border-2 border-transparent hover:border-purple-500/50 transform active:scale-95"
                        >
                            <div className="p-3 bg-black/30 rounded-lg">{game.icon}</div>
                            <div>
                                <p className="font-bold text-left text-lg">{game.title}</p>
                                <p className="text-sm text-gray-400 text-left">{game.description}</p>
                            </div>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default StartGameModal;