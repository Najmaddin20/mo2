import React from 'react';
import type { ScheduledEvent, User, Friend } from '../types';
import { ArrowLeftIcon } from './icons';
import ExpandableEventCard from './ExpandableEventCard';

interface DayViewProps {
    date: Date;
    events: ScheduledEvent[];
    onBack: () => void;
    currentUser: User;
    friends: Friend[];
    onRsvp: (eventId: number, status: 'going' | 'maybe' | 'not-going') => void;
    onInviteFriends: (eventId: number, friendIds: number[]) => void;
    onUpdateEvent: (updatedEvent: ScheduledEvent) => void;
    onCancelEvent: (eventId: number) => void;
    onStartParty: (event: ScheduledEvent) => void;
}

const DayView: React.FC<DayViewProps> = (props) => {
    const { date, events, onBack } = props;

    return (
        <div className="h-full flex flex-col text-white animate-fade-in-up">
            <header className="flex-shrink-0 p-4 md:p-6 flex items-center gap-4 border-b border-white/10">
                <button onClick={onBack} className="p-2 rounded-lg bg-white/10 hover:bg-white/20">
                    <ArrowLeftIcon className="w-6 h-6" />
                </button>
                <div>
                    <h2 className="text-2xl font-bold">{date.toLocaleDateString(undefined, { weekday: 'long' })}</h2>
                    <p className="text-gray-400">{date.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                </div>
            </header>

            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
                {events.map(event => (
                    <ExpandableEventCard 
                        key={event.id}
                        event={event}
                        currentUser={props.currentUser}
                        friends={props.friends}
                        onRsvp={props.onRsvp}
                        onInviteFriends={props.onInviteFriends}
                        onUpdateEvent={props.onUpdateEvent}
                        onCancelEvent={props.onCancelEvent}
                        onStartParty={props.onStartParty}
                    />
                ))}
            </div>
        </div>
    );
};

export default DayView;