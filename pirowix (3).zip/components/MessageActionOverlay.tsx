
import React, { useState, useEffect } from 'react';
import type { User, DirectMessage } from '../types';
import { ReplyIcon, CopyIcon, EditIcon, PinIcon, ForwardIcon, SelectIcon, TrashIcon, ChevronDownIcon, CloseIcon, DownloadIcon, TranslateIcon } from './icons';
import { DirectMessageItem } from './DirectMessageItem';

const ALL_REACTION_EMOJIS = ['🎉', '😁', '❤️', '👍', '👎', '🔥', '🥰', '👏', '😮', '😢', '🤔', '🤯', '👀'];
const SHORT_REACTION_EMOJIS = ALL_REACTION_EMOJIS.slice(0, 6);

interface MessageActionOverlayProps {
    message: DirectMessage;
    isSent: boolean;
    isPinned: boolean;
    onClose: () => void;
    onReply: () => void;
    onEdit: () => void;
    onCopy: () => void;
    onPin: () => void;
    onDelete: () => void;
    onForward: () => void;
    onSelect: () => void;
    onTranslate: () => void;
    onAddReaction: (emoji: string) => void;
    // Pass-through props for DirectMessageItem
    currentUser: User;
    friend: User;
    onJoinRoom: (id: number) => void;
    onJoinVoiceRoom: (id: number) => void;
    onReplyClick: (id: number) => void;
    onViewMedia: (media: DirectMessage) => void;
    getReplyPreviewText: (msg: DirectMessage) => string;
}

const MessageActionOverlay: React.FC<MessageActionOverlayProps> = (props) => {
    const { message, isSent, isPinned, onClose, onAddReaction, onReply, onEdit, onCopy, onPin, onDelete, onForward, onSelect, onTranslate } = props;
    const [showAllEmojis, setShowAllEmojis] = useState(false);
    const [isExiting, setIsExiting] = useState(false);
    const [isMounting, setIsMounting] = useState(true);
    
    const emojisToShow = showAllEmojis ? ALL_REACTION_EMOJIS : SHORT_REACTION_EMOJIS;
    
    useEffect(() => {
        setIsMounting(false);
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') handleClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    const handleClose = () => {
        setIsExiting(true);
        setTimeout(onClose, 300);
    };

    const handleAction = (action: () => void) => {
        setIsExiting(true);
        setTimeout(() => {
            action();
            onClose();
        }, 300);
    };
    
    const handleDownload = () => {
        const url = message.videoUrl || message.imageUrl || message.voiceMessage?.url;
        const filename = message.fileInfo?.name || `download_${Date.now()}`;
        
        if (url) {
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };

    const canCopy = !!message.message || !!message.caption;
    const canEdit = isSent && (!!message.message || !!message.caption);
    const hasMedia = !!(message.imageUrl || message.videoUrl || message.voiceMessage || message.fileInfo);
    const hasText = !!(message.message || message.caption);

    const actionButtons = [
        { label: 'Reply', icon: <ReplyIcon className="w-5 h-5 text-blue-400"/>, action: onReply },
        canCopy && { label: 'Copy', icon: <CopyIcon className="w-5 h-5 text-green-400"/>, action: onCopy },
        canEdit && { label: 'Edit', icon: <EditIcon className="w-5 h-5 text-yellow-400"/>, action: onEdit },
        hasMedia && { label: 'Download', icon: <DownloadIcon className="w-5 h-5 text-cyan-400"/>, action: handleDownload },
        hasText && { label: 'Translate', icon: <TranslateIcon className="w-5 h-5 text-pink-400"/>, action: onTranslate },
        { label: isPinned ? 'Unpin' : 'Pin', icon: <PinIcon className="w-5 h-5 text-purple-400"/>, action: onPin },
        { label: 'Forward', icon: <ForwardIcon className="w-5 h-5 text-orange-400"/>, action: onForward },
        { label: 'Select', icon: <SelectIcon className="w-5 h-5 text-gray-400"/>, action: onSelect },
        { label: 'Delete', icon: <TrashIcon className="w-5 h-5 text-red-500"/>, action: onDelete, className: 'text-red-500 hover:bg-red-500/10' },
    ].filter(Boolean) as { label: string; icon: React.ReactNode; action: () => void; className?: string }[];

    return (
        <div 
            className={`fixed inset-0 z-[100] flex flex-col transition-all duration-300 ${isExiting ? 'opacity-0' : 'opacity-100'}`}
            onClick={handleClose}
        >
            {/* Backdrop with Blur and Darkening */}
            <div className={`absolute inset-0 bg-black/80 backdrop-blur-xl transition-opacity duration-300 ${isMounting ? 'opacity-0' : 'opacity-100'}`} />

            {/* Main Content Area */}
            <div className="relative flex-1 flex flex-col md:flex-row items-center justify-center w-full h-full p-4 md:p-10 gap-6 md:gap-12">
                
                {/* MESSAGE PREVIEW (Center Stage) */}
                <div 
                    className={`relative z-10 w-full max-w-md transition-all duration-500 ease-out transform 
                        ${isMounting ? 'scale-90 opacity-0 translate-y-10' : 'scale-100 opacity-100 translate-y-0'}
                        ${isExiting ? 'scale-95 opacity-0' : ''}
                    `}
                    onClick={e => e.stopPropagation()}
                >
                    {/* Reaction Bar - Floating above/top */}
                    <div className="absolute -top-16 left-0 right-0 flex justify-center md:justify-start z-20 mb-4">
                         <div className="flex items-center gap-1 bg-[#1e1931] border border-white/10 p-1.5 rounded-full shadow-[0_0_30px_rgba(108,93,211,0.3)] overflow-hidden transition-all animate-fade-in-up">
                            <div className={`flex gap-1 transition-all duration-300 ${showAllEmojis ? 'max-w-[350px] overflow-x-auto hide-scrollbar' : 'max-w-[280px]'}`}>
                                {emojisToShow.map((emoji, index) => (
                                    <button 
                                        key={emoji} 
                                        onClick={() => handleAction(() => onAddReaction(emoji))} 
                                        className="w-10 h-10 flex-shrink-0 flex items-center justify-center text-2xl hover:bg-white/10 rounded-full transition-transform hover:scale-125 active:scale-95"
                                        style={{ 
                                            animation: `pop-in 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) forwards`, 
                                            animationDelay: `${index * 0.04}s`, 
                                            opacity: 0, 
                                            transform: 'scale(0)' 
                                        }}
                                    >
                                        {emoji}
                                    </button>
                                ))}
                            </div>
                            <div className="w-px h-6 bg-white/10 mx-1"></div>
                            <button 
                                onClick={() => setShowAllEmojis(!showAllEmojis)} 
                                className="w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
                            >
                                <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 ${showAllEmojis ? 'rotate-180' : ''}`} />
                            </button>
                        </div>
                    </div>

                    {/* The Actual Message Bubble */}
                    <div className={`flex ${isSent ? 'justify-end' : 'justify-start'} filter drop-shadow-2xl`}>
                         <div className="transform transition-transform origin-center pointer-events-none scale-105 ring-4 ring-transparent">
                            <DirectMessageItem
                                {...props}
                                onOpenContextMenu={() => {}} 
                                onReplyRequest={() => {}}
                                onAddReaction={() => {}} 
                                onCancelUpload={() => {}}
                                selectionMode={false}
                                disableInteractions={true}
                            />
                        </div>
                    </div>
                </div>

                {/* ACTIONS MENU */}
                
                {/* DESKTOP LAYOUT: Side Panel / Grid */}
                <div 
                    className={`hidden md:flex flex-col z-10 w-64 bg-[#1e1931]/60 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden transition-all duration-500 delay-75
                    ${isMounting ? 'opacity-0 translate-x-10' : 'opacity-100 translate-x-0'}
                    ${isExiting ? 'opacity-0 translate-x-10' : ''}
                    `}
                    onClick={e => e.stopPropagation()}
                >
                    <div className="p-2 space-y-1">
                        {actionButtons.map((item, idx) => (
                             <button 
                                key={item.label} 
                                onClick={() => handleAction(item.action)} 
                                className={`flex items-center gap-4 w-full px-4 py-3 hover:bg-white/10 rounded-xl font-medium text-white transition-all duration-200 hover:translate-x-1 active:scale-[0.98] group ${item.className || ''}`}
                            >
                                <span className="p-2 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors">{item.icon}</span>
                                <span>{item.label}</span>
                            </button>
                        ))}
                    </div>
                </div>

                {/* MOBILE LAYOUT: Bottom Sheet */}
                <div 
                    className={`md:hidden absolute bottom-0 left-0 right-0 z-20 bg-[#151517] border-t border-white/10 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)] transition-transform duration-300 ease-out
                    ${isMounting ? 'translate-y-full' : 'translate-y-0'}
                    ${isExiting ? 'translate-y-full' : ''}
                    `}
                    onClick={e => e.stopPropagation()}
                >
                    <div className="w-12 h-1.5 bg-gray-600 rounded-full mx-auto mt-3 mb-2 opacity-50"></div>
                    <div className="grid grid-cols-4 gap-y-6 gap-x-2 p-6 pb-10">
                        {actionButtons.map((item, idx) => (
                             <button 
                                key={item.label} 
                                onClick={() => handleAction(item.action)} 
                                className="flex flex-col items-center gap-2 group active:scale-95 transition-transform"
                            >
                                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-[#212124] border border-white/5 group-hover:bg-white/10 transition-colors shadow-lg ${item.label === 'Delete' ? 'bg-red-500/10 border-red-500/20' : ''}`}>
                                    {item.icon}
                                </div>
                                <span className={`text-xs font-medium ${item.label === 'Delete' ? 'text-red-400' : 'text-gray-300'}`}>{item.label}</span>
                            </button>
                        ))}
                    </div>
                </div>

            </div>
            
            {/* Desktop Close Button */}
            <button 
                onClick={handleClose} 
                className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors md:block hidden z-50"
            >
                <CloseIcon className="w-6 h-6" />
            </button>
            
            <style>{`
                @keyframes pop-in { 0% { opacity: 0; transform: scale(0.5); } 60% { transform: scale(1.2); } 100% { opacity: 1; transform: scale(1); } }
                @keyframes fade-in-up { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                .animate-fade-in-up { animation: fade-in-up 0.4s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default MessageActionOverlay;
