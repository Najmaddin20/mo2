
import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { CloseIcon, CheckIcon, ShieldCheckIcon, ShieldIcon, CrownIcon, StarIcon } from './icons';

interface VerificationModalProps {
    isOpen: boolean;
    onClose: () => void;
    onVerify: () => void;
}

const BENEFITS = [
    {
        id: 'badge',
        icon: <ShieldCheckIcon className="w-6 h-6" />,
        title: "Official Blue Badge",
        desc: "Get the verified blue tick next to your name everywhere."
    },
    {
        id: 'support',
        icon: <ShieldIcon className="w-6 h-6" />,
        title: "Priority Support",
        desc: "Jump to the front of the line for all inquiries."
    },
    {
        id: 'features',
        icon: <CrownIcon className="w-6 h-6" />,
        title: "Exclusive Access",
        desc: "Early access to beta features and new releases."
    },
    {
        id: 'boost',
        icon: <StarIcon className="w-6 h-6" />,
        title: "Profile Boost",
        desc: "Higher visibility in search and recommendations."
    }
];

// --- Visual Components ---

const BlueTickHero = ({ scale = 1 }: { scale?: number }) => (
    <div className="relative group" style={{ transform: `scale(${scale})` }}>
        {/* Outer Glow */}
        <div className="absolute inset-0 bg-blue-500/40 blur-[50px] rounded-full group-hover:bg-blue-400/50 transition-all duration-1000"></div>
        
        {/* Main Shape */}
        <div className="relative w-32 h-32 bg-gradient-to-br from-blue-400 to-blue-700 rounded-full flex items-center justify-center shadow-[0_0_50px_-10px_rgba(59,130,246,0.6)] border-4 border-white/10 z-10">
            
            {/* Inner Shine */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-white/20 to-transparent opacity-50"></div>
            
            {/* The Checkmark */}
            <svg className="w-16 h-16 text-white drop-shadow-md" viewBox="0 0 24 24" fill="currentColor">
                 <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.491 4.491 0 013.497-1.307zm4.45 6.75l2.3-2.29a.75.75 0 011.1 1.08l-2.75 2.75a.75.75 0 01-1.1 0l-2.75-2.75a.75.75 0 111.1-1.08l2.1 2.29z" clipRule="evenodd" />
            </svg>
        </div>

        {/* Floating Particles (CSS Animation) */}
        <div className="absolute top-0 right-0 w-3 h-3 bg-blue-300 rounded-full blur-[2px] animate-ping" style={{ animationDuration: '3s' }}></div>
        <div className="absolute bottom-2 left-2 w-2 h-2 bg-white rounded-full blur-[1px] animate-pulse"></div>
    </div>
);

const DesktopBenefitCard: React.FC<{ benefit: typeof BENEFITS[0]; delay: number }> = ({ benefit, delay }) => (
    <div 
        className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/[0.08] hover:border-blue-500/30 transition-all duration-300 opacity-0 animate-fade-in-up group"
        style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
    >
        <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 text-blue-400 border border-blue-500/10 group-hover:scale-110 transition-transform duration-300 shadow-inner">
            {benefit.icon}
        </div>
        <div>
            <h4 className="text-sm font-bold text-white group-hover:text-blue-200 transition-colors">{benefit.title}</h4>
            <p className="text-xs text-gray-400 leading-relaxed mt-1">{benefit.desc}</p>
        </div>
    </div>
);

const MobileBenefitItem: React.FC<{ benefit: typeof BENEFITS[0]; delay: number }> = ({ benefit, delay }) => (
    <div 
        className="flex items-center gap-4 p-4 bg-[#1c1c1e] rounded-2xl border border-white/10 opacity-0 animate-fade-in-up shadow-md"
        style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
    >
        <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400 border border-blue-500/10 flex-shrink-0">
            {benefit.icon}
        </div>
        <div>
            <h4 className="text-sm font-bold text-white">{benefit.title}</h4>
            <p className="text-xs text-gray-400 leading-snug mt-0.5">{benefit.desc}</p>
        </div>
    </div>
);

const VerificationModal: React.FC<VerificationModalProps> = ({ isOpen, onClose, onVerify }) => {
    const [step, setStep] = useState<'intro' | 'processing' | 'success'>('intro');
    const [isVisible, setIsVisible] = useState(false);
    
    // Mobile Drag
    const [isDragging, setIsDragging] = useState(false);
    const [translateY, setTranslateY] = useState(0);
    const dragStartY = useRef<number>(0);
    const modalContentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            setIsVisible(true);
            setStep('intro');
            setTranslateY(0);
            document.body.style.overflow = 'hidden';
        } else {
            const timer = setTimeout(() => setIsVisible(false), 400);
            document.body.style.overflow = '';
            return () => clearTimeout(timer);
        }
        return () => { document.body.style.overflow = ''; };
    }, [isOpen]);

    const handlePurchase = () => {
        setStep('processing');
        setTimeout(() => {
            setStep('success');
            setTimeout(onVerify, 1500);
        }, 2500);
    };

    // Mobile Drag Logic
    const handleTouchStart = (e: React.TouchEvent) => {
        if (modalContentRef.current && modalContentRef.current.scrollTop > 0) return;
        setIsDragging(true);
        dragStartY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const deltaY = e.touches[0].clientY - dragStartY.current;
        if (deltaY > 0) setTranslateY(deltaY);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (translateY > 100) onClose();
        else setTranslateY(0);
    };

    if (!isVisible && !isOpen) return null;

    // --- Render Content based on Step ---

    const renderContent = (isMobile: boolean) => {
        if (step === 'processing') {
            return (
                <div className="flex flex-col items-center justify-center h-full py-12 text-center animate-fade-in">
                    <div className="relative w-32 h-32 mb-8">
                        {/* Scanning Rings */}
                        <div className="absolute inset-0 border-4 border-blue-500/20 rounded-full animate-ping" style={{ animationDuration: '2s' }}></div>
                        <div className="absolute inset-4 border-4 border-blue-500/40 rounded-full animate-ping" style={{ animationDuration: '2s', animationDelay: '0.5s' }}></div>
                        
                        <div className="absolute inset-0 flex items-center justify-center">
                            <ShieldCheckIcon className="w-12 h-12 text-blue-500 animate-pulse" />
                        </div>
                        
                        {/* Spinner */}
                        <div className="absolute inset-0 border-4 border-t-blue-500 border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Verifying Identity...</h3>
                    <p className="text-gray-400 text-sm">Connecting to the verification matrix.</p>
                </div>
            );
        }

        if (step === 'success') {
            return (
                <div className="flex flex-col items-center justify-center h-full py-12 text-center animate-bounce-in">
                    <div className="mb-8 relative">
                        <div className="absolute inset-0 bg-green-500/40 blur-2xl rounded-full"></div>
                        <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center shadow-2xl relative z-10 border-4 border-[#121214]">
                            <CheckIcon className="w-12 h-12 text-white" />
                        </div>
                    </div>
                    <h2 className="text-3xl font-black text-white mb-2">You're Verified!</h2>
                    <p className="text-gray-400 text-sm mb-8 max-w-xs mx-auto">
                        Your profile now displays the blue tick. Enjoy your exclusive status.
                    </p>
                </div>
            );
        }

        // Intro Step
        if (isMobile) {
            return (
                <>
                    <div className="flex flex-col items-center mb-8 text-center relative">
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-blue-600/20 blur-[60px] rounded-full pointer-events-none"></div>
                        <div className="mb-6">
                            <BlueTickHero scale={0.8} />
                        </div>
                        <h2 className="text-3xl font-black text-white mb-2">Get Verified</h2>
                        <p className="text-sm text-gray-400 max-w-xs leading-relaxed">Stand out with the prestigious blue tick.</p>
                    </div>

                    <div className="space-y-3 mb-8">
                        {BENEFITS.map((b, idx) => (
                            <MobileBenefitItem key={b.id} benefit={b} delay={idx * 100} />
                        ))}
                    </div>
                    
                    <div className="space-y-3 pb-safe mt-auto">
                        <button 
                            onClick={handlePurchase}
                            className="w-full py-4 rounded-2xl font-bold text-white text-base shadow-xl shadow-blue-900/20 bg-gradient-to-r from-blue-500 to-blue-700 active:scale-95 transition-transform relative overflow-hidden group"
                        >
                            <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-[-20deg] animate-shine"></div>
                            <span className="relative z-10">Verify for $14.99 / mo</span>
                        </button>
                        
                        <button onClick={onClose} className="w-full py-3 text-xs font-bold text-gray-500 hover:text-white transition-colors uppercase tracking-wide">
                            Maybe Later
                        </button>
                    </div>
                </>
            );
        }

        // Desktop Intro
        return (
            <>
                <div className="grid grid-cols-2 gap-4 mb-8">
                    {BENEFITS.map((b, idx) => (
                        <DesktopBenefitCard key={b.id} benefit={b} delay={idx * 100} />
                    ))}
                </div>

                <div className="mt-auto pt-6 border-t border-white/5 flex items-center justify-between shrink-0 relative z-20">
                    <div>
                        <p className="text-2xl font-bold text-white">$14.99 <span className="text-sm font-medium text-gray-500">/ month</span></p>
                        <p className="text-xs text-gray-500 mt-0.5">Cancel anytime.</p>
                    </div>
                    <button 
                        onClick={handlePurchase}
                        className="relative overflow-hidden group px-10 py-3.5 bg-gradient-to-r from-blue-600 to-blue-500 text-white font-bold rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40 hover:scale-105 transition-all active:scale-95"
                    >
                            <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-[-20deg] group-hover:animate-shine"></div>
                        Start Verification
                    </button>
                </div>
            </>
        );
    };

    return createPortal(
        <div className={`fixed inset-0 z-[9999] flex items-end md:items-center justify-center transition-all duration-500 ${isOpen ? 'visible' : 'invisible'}`}>
            
            {/* Backdrop */}
            <div 
                className={`absolute inset-0 bg-black/70 backdrop-blur-xl transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
                onClick={onClose}
            />

            {/* --- DESKTOP LAYOUT --- */}
            <div 
                className={`
                    hidden md:flex relative w-[850px] h-[500px] bg-[#0f0f0f] rounded-3xl shadow-2xl border border-white/10 overflow-hidden
                    transition-all duration-500 cubic-bezier(0.34, 1.56, 0.64, 1)
                    ${isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-95 opacity-0 translate-y-8'}
                `}
                onClick={e => e.stopPropagation()}
            >
                {/* Close Button */}
                <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 rounded-full text-gray-400 hover:text-white z-50 transition-colors">
                    <CloseIcon className="w-5 h-5" />
                </button>

                {/* Left Panel: Branding */}
                <div className="w-[40%] relative bg-[#08080a] flex flex-col items-center justify-center p-10 overflow-hidden border-r border-white/5">
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-blue-900/20 via-transparent to-transparent"></div>
                    
                    <div className="relative mb-8 z-10">
                        <BlueTickHero />
                    </div>

                    <div className="text-center relative z-10">
                        <h2 className="text-3xl font-black text-white mb-3 tracking-tight leading-tight">
                            Get <span className="text-blue-400">Verified</span>
                        </h2>
                        <p className="text-sm text-gray-400 leading-relaxed">
                            Build trust and unlock exclusive tools for your profile.
                        </p>
                    </div>
                </div>

                {/* Right Panel: Content */}
                <div className="flex-1 flex flex-col bg-[#121212] p-10 relative">
                    <div className="absolute top-0 right-0 w-full h-32 bg-gradient-to-b from-[#121212] to-transparent pointer-events-none z-10"></div>
                    <div className="flex-1 flex flex-col h-full">
                         {renderContent(false)}
                    </div>
                </div>
            </div>

            {/* --- MOBILE LAYOUT (Bottom Sheet) --- */}
            <div 
                className={`
                    md:hidden relative w-full bg-[#0f0f0f] border-t border-white/10 
                    rounded-t-[2.5rem] shadow-[0_-10px_50px_rgba(0,0,0,0.8)] flex flex-col
                    max-h-[90vh] h-auto
                    transition-transform duration-300 ease-out
                    ${isOpen ? 'translate-y-0' : 'translate-y-full'}
                `}
                style={{ 
                    transform: isOpen && isDragging ? `translateY(${translateY}px)` : undefined,
                }}
                onClick={e => e.stopPropagation()}
            >
                {/* Drag Handle */}
                <div 
                    className="w-full h-12 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none z-30 flex-shrink-0"
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
                </div>

                <div 
                    ref={modalContentRef}
                    className="flex-1 overflow-y-auto custom-scrollbar px-6 pb-8 flex flex-col"
                >
                    {renderContent(true)}
                </div>
            </div>

             <style>{`
                @keyframes shine {
                    0% { left: -100%; }
                    20% { left: 200%; }
                    100% { left: 200%; }
                }
                .animate-shine {
                    animation: shine 3s infinite;
                }
                .pb-safe {
                    padding-bottom: env(safe-area-inset-bottom, 20px);
                }
            `}</style>
        </div>,
        document.body
    );
};

export default VerificationModal;
