
import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import type { VoiceRoom, User, VoiceRoomUser, BannedDetail } from '../types';
import { HandIcon, MicrophoneIcon, MicrophoneOffIcon, CrownIcon, HeartIcon, SettingsIcon, ArrowLeftIcon, UsersIcon, MoreVertIcon, ClockIcon, GameControllerIcon, ChevronDownIcon, StarIcon, CloseIcon, DownloadIcon, UserAddIcon, TrashIcon, BlockUserIcon, CheckIcon, DoorOutIcon, VolumeUpIcon, VolumeOffIcon, ShieldIcon, XIcon } from './icons';
import VoiceRoomReactions from './VoiceRoomReactions';
import VoiceRoomHeaderMenu from './VoiceRoomHeaderMenu';
import SoundEffectsPanel from './SoundEffectsPanel';
import WidgetsPanel from './WidgetsPanel';
import GamesPanel from './GamesPanel';
import HostLeaveModal from './HostLeaveModal';
import { useToast } from './ToastManager';
import VoiceRoomSettingsModal from './VoiceRoomSettingsModal';

interface VoiceRoomProps {
    room: VoiceRoom;
    currentUser: User;
    onLeave: () => void;
    onRaiseHand: () => void;
    onInviteToSpeak: (userId: number) => void;
    onMoveToAudience: (userId: number) => void;
    onPromoteToHost: (userId: number) => void;
    onMuteUser: (userId: number) => void;
    onKickUser: (userId: number) => void;
    onBlockUser: (userId: number) => void;
    onGameAction: (action: string, payload?: any) => void;
    onViewProfile: (user: User) => void;
    onSelfMute: (isMuted: boolean) => void;
    onShare: () => void;
    onOpenSettingsModal: () => void;
    onOpenStartGameModal: () => void;
    onToggleRecording: () => void;
    onEndRoom: () => void;
    onAcceptRequest: (userId: number) => void;
    onDeclineRequest: (userId: number) => void;
}

const formatTimeLeft = (secondsLeft: number) => {
    const h = Math.floor(secondsLeft / 3600);
    const m = Math.floor((secondsLeft % 3600) / 60);
    const s = Math.floor(secondsLeft % 60);
    return `${h > 0 ? `${h}:` : ''}${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
};

const VoiceRoomHeader: React.FC<{
    room: VoiceRoom;
    isHost: boolean;
    onLeave: () => void;
    onOpenMenu: () => void;
    onToggleGame: () => void;
    onViewRequests: () => void;
    isGameOpen: boolean;
    timeLeftSeconds: number;
}> = ({ room, isHost, onLeave, onOpenMenu, onToggleGame, onViewRequests, isGameOpen, timeLeftSeconds }) => {
    
    // Urgent Visuals for last 10 seconds
    const isUrgent = room.timer && timeLeftSeconds <= 10 && timeLeftSeconds > 0;
    const requestCount = room.joinRequests?.length || 0;

    return (
        <header className="flex-shrink-0 p-4 flex items-center justify-between z-20 bg-gradient-to-b from-black/60 to-transparent pointer-events-none">
            <div className="flex items-center gap-3 min-w-0 pointer-events-auto flex-1 mr-2">
                <button onClick={onLeave} className="text-white/80 hover:text-white p-2 bg-white/5 hover:bg-white/10 rounded-full backdrop-blur-sm transition-colors flex-shrink-0">
                    <ArrowLeftIcon className="w-5 h-5" />
                </button>
                <div className="flex flex-col min-w-0">
                    <h1 className="text-base md:text-lg font-bold text-white truncate drop-shadow-md">{room.topic}</h1>
                     <div className="flex items-center gap-3 text-xs font-medium text-gray-300 drop-shadow-sm">
                        {room.isRecording && (
                            <div className="flex items-center gap-1.5 text-red-400 flex-shrink-0">
                                <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                                REC
                            </div>
                        )}
                        <div className="flex items-center gap-1 flex-shrink-0">
                            <UsersIcon className="w-3.5 h-3.5" />
                            <span>{room.speakers.length + room.listeners.length}</span>
                        </div>
                        {room.timer && (
                            <div className={`flex items-center gap-1 transition-all duration-300 flex-shrink-0 ${isUrgent ? 'text-red-500 font-bold scale-110' : 'text-yellow-400'}`}>
                                <ClockIcon className={`w-3.5 h-3.5 ${isUrgent ? 'animate-bounce' : ''}`} />
                                <span className={`font-mono ${isUrgent ? 'animate-pulse' : ''}`}>{formatTimeLeft(timeLeftSeconds)}</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            <div className="flex items-center gap-1 sm:gap-2 pointer-events-auto flex-shrink-0">
                {isHost && requestCount > 0 && (
                    <button 
                        onClick={onViewRequests}
                        className="p-2 sm:p-2.5 rounded-full bg-blue-600 text-white shadow-lg shadow-blue-500/30 animate-pulse hover:bg-blue-500 transition-colors relative mr-1 group"
                        title="Join Requests"
                    >
                        <UserAddIcon className="w-5 h-5" />
                        <span className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-red-500 rounded-full text-[9px] sm:text-[10px] font-bold flex items-center justify-center border-2 border-[#1e1931] shadow-sm">{requestCount}</span>
                        <span className="absolute inset-0 rounded-full ring-4 ring-blue-500/30 animate-ping opacity-50"></span>
                    </button>
                )}
                
                <button 
                    onClick={onToggleGame} 
                    className={`p-2 rounded-full backdrop-blur-sm transition-colors ${isGameOpen ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30' : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'} ${room.game ? 'animate-pulse-subtle' : ''}`}
                    title="Game Panel"
                >
                    <GameControllerIcon className="w-5 h-5" />
                </button>

                {isHost && (
                     <button onClick={(e) => { e.stopPropagation(); onOpenMenu(); }} className="text-white/80 hover:text-white p-2 bg-white/5 hover:bg-white/10 rounded-full backdrop-blur-sm transition-colors">
                        <MoreVertIcon className="w-5 h-5" />
                    </button>
                )}
            </div>
        </header>
    );
};

const AvatarPod: React.FC<{ 
    user: VoiceRoomUser; 
    type: 'host' | 'speaker' | 'listener'; 
    onClick: () => void; 
    onContextMenu: (e: React.MouseEvent | React.TouchEvent) => void; 
    userVolume?: number;
}> = ({ user, type, onClick, onContextMenu, userVolume = 100 }) => {
    
    // Optimized for mobile
    const sizeClasses = {
        host: 'w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28',
        speaker: 'w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24',
        listener: 'w-14 h-14 sm:w-16 sm:h-16',
    }[type];

    const textSize = type === 'listener' ? 'text-[10px] sm:text-xs' : 'text-xs sm:text-sm';
    const isMuted = user.isMuted || user.isMutedByHost;
    const isLowVolume = userVolume < 50 && !isMuted;

    // Long press logic for mobile context menu
    const longPressTimer = useRef<number | undefined>(undefined);
    const isLongPress = useRef(false);

    const handleTouchStart = (e: React.TouchEvent) => {
        isLongPress.current = false;
        longPressTimer.current = window.setTimeout(() => {
            isLongPress.current = true;
            onContextMenu(e);
        }, 500);
    };

    const handleTouchEnd = () => {
        if (longPressTimer.current) clearTimeout(longPressTimer.current);
    };

    const handleTouchMove = () => {
        if (longPressTimer.current) clearTimeout(longPressTimer.current);
    };

    return (
        <div 
            className="flex flex-col items-center gap-2 group relative select-none" 
            onContextMenu={(e) => { e.preventDefault(); onContextMenu(e); }}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            onTouchMove={handleTouchMove}
        >
            <div className="relative cursor-pointer" onClick={() => !isLongPress.current && onClick()}>
                {user.isSpeaking && (
                    <div className="absolute inset-0 rounded-[2rem] z-0">
                        <div className="absolute inset-[-4px] rounded-[2.2rem] bg-gradient-to-tr from-purple-500 via-pink-500 to-orange-500 animate-spin-slow opacity-70 blur-sm"></div>
                        <div className="absolute inset-[-8px] rounded-[2.4rem] border-2 border-purple-500/30 animate-ping-slow"></div>
                    </div>
                )}

                <div className={`relative z-10 rounded-[2rem] p-[2px] transition-all duration-300 bg-[#18181b]`}>
                    <img 
                        src={user.avatar} 
                        alt={user.name} 
                        className={`${sizeClasses} rounded-[1.8rem] object-cover bg-zinc-800 border-2 ${user.isSpeaking ? 'border-transparent' : 'border-white/10'} transition-all duration-300 group-hover:brightness-110 pointer-events-none`} 
                    />
                </div>
                
                <div className="absolute -bottom-1 -right-1 z-20 flex gap-1">
                    {type === 'host' && (
                        <div className="bg-yellow-400 text-black p-1 rounded-full border-2 border-[#121212] shadow-sm" title="Host">
                            <CrownIcon className="w-3 h-3" />
                        </div>
                    )}
                    {isMuted && (type === 'host' || type === 'speaker') && (
                        <div className="bg-red-500 text-white p-1 rounded-full border-2 border-[#121212] shadow-sm">
                            <MicrophoneOffIcon className="w-3 h-3" />
                        </div>
                    )}
                    {isLowVolume && !isMuted && (
                        <div className="bg-blue-500 text-white p-1 rounded-full border-2 border-[#121212] shadow-sm">
                            <VolumeOffIcon className="w-3 h-3" />
                        </div>
                    )}
                </div>
            </div>
            <p className={`${textSize} font-medium text-gray-200 truncate max-w-[80px] sm:max-w-[100px] text-center px-1.5 py-0.5 rounded bg-black/20 backdrop-blur-sm relative z-10`}>
                {user.name}
            </p>
        </div>
    )
}

const VoiceRoomComponent: React.FC<VoiceRoomProps> = (props) => {
    const { room, currentUser, onLeave, onRaiseHand, onInviteToSpeak, onMoveToAudience, onPromoteToHost, onMuteUser, onKickUser, onBlockUser, onViewProfile, onSelfMute, onShare, onOpenSettingsModal, onOpenStartGameModal, onToggleRecording, onEndRoom, onAcceptRequest, onDeclineRequest } = props;
    
    const [contextMenu, setContextMenu] = useState<{ x: number, y: number, user: VoiceRoomUser } | null>(null);
    const [isHeaderMenuOpen, setIsHeaderMenuOpen] = useState(false);
    const [showSfxPanel, setShowSfxPanel] = useState(false);
    const [isGamePanelOpen, setIsGamePanelOpen] = useState(false);
    const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
    const [recordingBlobUrl, setRecordingBlobUrl] = useState<string | null>(null);
    const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);
    const [isRoomEnding, setIsRoomEnding] = useState(false);
    const [showHostLeaveModal, setShowHostLeaveModal] = useState(false);
    const [userVolumes, setUserVolumes] = useState<Record<number, number>>({});

    const { addToast } = useToast();
    const prevRequestsLength = useRef(room.joinRequests?.length || 0);

    const currentUserInRoom = useMemo(() => 
        [...room.speakers, ...room.listeners].find(u => u.id === currentUser.id), 
    [room, currentUser.id]);

    const isHost = currentUserInRoom?.role === 'host';
    const isOwner = currentUser.id === room.ownerId;
    const isInvitedToSpeak = room.invitedSpeakerIds?.includes(currentUser.id);

    // Handle block logic with metadata
    const handleBlockUserWithDetails = (userId: number) => {
        const blockedUser = [...room.speakers, ...room.listeners].find(u => u.id === userId);
        if (blockedUser) {
            const banDetail: BannedDetail = {
                userId: userId,
                bannedBy: currentUser,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                reason: 'Removed by admin'
            };
            // Pass everything in one action to avoid race conditions
            props.onGameAction('block-user', { userId, details: banDetail });
        } else {
            onBlockUser(userId);
        }
    };

    const handleAdvancedAction = (action: string, payload: any) => {
        if (action === 'revoke-host') {
            props.onGameAction('revoke-host', payload);
        } else if (action === 'decline-speaker-request') {
             props.onGameAction('decline-speaker-request', payload);
        } else if (action === 'respond-to-invite') {
             props.onGameAction('respond-to-invite', payload);
        } else {
            props.onGameAction(action, payload);
        }
    };

    // Monitor Join Requests and Notify Host
    useEffect(() => {
        if (!isHost) return;
        const currentLength = room.joinRequests?.length || 0;
        if (currentLength > prevRequestsLength.current) {
            // New request(s) added
            const newRequest = room.joinRequests![currentLength - 1];
            addToast({
                title: 'New Join Request',
                description: `${newRequest.name} requested to join the room.`,
                type: 'info',
                duration: 5000,
                buttonText: 'View',
            });
        }
        prevRequestsLength.current = currentLength;
    }, [room.joinRequests, isHost, addToast]);

    // Timer Logic
    useEffect(() => {
        if (!room.timer) return;
        
        const calculateTimeLeft = () => Math.max(0, Math.floor((room.timer!.endsAt - Date.now()) / 1000));
        setTimeLeftSeconds(calculateTimeLeft());

        const interval = setInterval(() => {
            const seconds = calculateTimeLeft();
            setTimeLeftSeconds(seconds);
            
            // Room Ending Sequence
            if (seconds <= 0 && !isRoomEnding) {
                setIsRoomEnding(true);
                clearInterval(interval);
                // Automatically close room after delay
                setTimeout(() => {
                    onEndRoom();
                }, 3500);
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [room.timer, onEndRoom, isRoomEnding]);

    const prevRecordingState = useRef(room.isRecording);

    useEffect(() => {
        if (prevRecordingState.current && !room.isRecording) {
            simulateRecordingSave();
        }
        prevRecordingState.current = room.isRecording;
    }, [room.isRecording]);

    const simulateRecordingSave = () => {
        const dummyContent = "Simulated Audio Content";
        const blob = new Blob([dummyContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        setRecordingBlobUrl(url);
        
        addToast({ 
            title: 'Recording Saved', 
            description: 'Audio recording has been saved to your device.', 
            type: 'success',
            duration: 5000
        });

        const a = document.createElement('a');
        a.href = url;
        a.download = `recording-${new Date().toISOString()}.mp3`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    useEffect(() => {
        if (room.game && !isGamePanelOpen) {
            setIsGamePanelOpen(true);
        }
    }, [room.game]);

    const isSpeaker = currentUserInRoom?.role === 'speaker';
    const hasRaisedHand = room.raisedHands.some(u => u.id === currentUser.id);
    
    const hosts = room.speakers.filter(s => s.role === 'host');
    const speakers = room.speakers.filter(s => s.role === 'speaker');
    const raisedHandsListeners = room.listeners.filter(l => room.raisedHands.some(rh => rh.id === l.id));
    const otherListeners = room.listeners.filter(l => !room.raisedHands.some(rh => rh.id === l.id));

    const closeContextMenu = useCallback(() => setContextMenu(null), []);
    const closeHeaderMenu = useCallback(() => setIsHeaderMenuOpen(false), []);

    useEffect(() => {
        const activeMenu = contextMenu || isHeaderMenuOpen;
        if (activeMenu) {
            const closeAll = () => {
                closeContextMenu();
                closeHeaderMenu();
            }
            window.addEventListener('click', closeAll);
            return () => window.removeEventListener('click', closeAll);
        }
    }, [contextMenu, isHeaderMenuOpen, closeContextMenu, closeHeaderMenu]);
    
    const openContextMenu = (event: React.MouseEvent | React.TouchEvent, user: VoiceRoomUser) => {
        if (user.id === currentUser.id) return;

        if (event.type === 'contextmenu') event.preventDefault();
        
        const clientX = 'touches' in event ? event.touches[0].clientX : (event as React.MouseEvent).clientX;
        const clientY = 'touches' in event ? event.touches[0].clientY : (event as React.MouseEvent).clientY;
        setContextMenu({ x: clientX, y: clientY, user });
    };

    const handleLeaveAttempt = () => {
        if (isHost) {
            const totalUsers = room.speakers.length + room.listeners.length;
            if (totalUsers > 1) {
                setShowHostLeaveModal(true);
            } else {
                onEndRoom(); 
            }
        } else {
            onLeave();
        }
    };

    const handleTransferAndLeave = (newHostId: number) => {
        onPromoteToHost(newHostId); 
        onLeave();
        setShowHostLeaveModal(false);
    };

    const handleVolumeChange = (userId: number, val: number) => {
        setUserVolumes(prev => ({ ...prev, [userId]: val }));
    };

    const UserContextMenu: React.FC<{ menu: { x: number, y: number, user: VoiceRoomUser } }> = ({ menu }) => {
        const { user } = menu;
        const vol = userVolumes[user.id] ?? 100;
        const canManageUser = isHost || (isOwner && user.role !== 'host'); 
        const isTargetHost = user.role === 'host';
        const isStageUser = user.role === 'host' || user.role === 'speaker';
        const hasRaisedHand = room.raisedHands.some(u => u.id === user.id);

        const screenW = window.innerWidth;
        const screenH = window.innerHeight;
        const menuW = 220;
        const menuH = 350;
        
        let left = menu.x;
        let top = menu.y;

        if (left + menuW > screenW) left = screenW - menuW - 10;
        if (top + menuH > screenH) top = screenH - menuH - 10;

        return (
            <div 
                className="fixed z-50 bg-[#18181b]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-2 text-sm w-[220px] animate-fade-in-up ring-1 ring-white/5" 
                style={{ top, left }} 
                onClick={e => e.stopPropagation()}
            >
                <div className="px-3 py-2 border-b border-white/5 mb-1 flex items-center gap-2">
                    <img src={user.avatar} className="w-6 h-6 rounded-full object-cover" />
                    <span className="font-bold text-white truncate">{user.name}</span>
                </div>

                {isStageUser && (
                    <div className="px-3 py-3">
                        <div className="flex justify-between items-center mb-2 text-xs text-gray-400">
                            <div className="flex items-center gap-1">
                                {vol === 0 ? <VolumeOffIcon className="w-3 h-3"/> : <VolumeUpIcon className="w-3 h-3"/>}
                                <span>Volume</span>
                            </div>
                            <span className="font-mono text-white">{vol}%</span>
                        </div>
                        <input 
                            type="range" 
                            min="0" max="200" step="5" 
                            value={vol} 
                            onChange={(e) => handleVolumeChange(user.id, Number(e.target.value))}
                            className="w-full h-1.5 bg-white/20 rounded-full appearance-none cursor-pointer accent-[#6C5DD3]"
                        />
                        <div className="h-px bg-white/10 my-2"></div>
                    </div>
                )}

                {isHost && (
                    <>
                        {hasRaisedHand ? (
                            <>
                                <MenuItem onClick={() => onInviteToSpeak(user.id)} icon={<CheckIcon className="w-4 h-4 text-green-400"/>}>
                                    Accept Speaker Request
                                </MenuItem>
                                <MenuItem onClick={() => handleAdvancedAction('decline-speaker-request', { userId: user.id })} icon={<XIcon className="w-4 h-4 text-red-400"/>}>
                                    Decline Request
                                </MenuItem>
                            </>
                        ) : (
                            user.role === 'listener' && <MenuItem onClick={() => onInviteToSpeak(user.id)} icon={<MicrophoneIcon className="w-4 h-4"/>}>Invite to Speak</MenuItem>
                        )}
                        
                        {user.role === 'speaker' && (
                            <>
                                <MenuItem onClick={() => onMoveToAudience(user.id)} icon={<UsersIcon className="w-4 h-4"/>}>Move to Audience</MenuItem>
                                <MenuItem onClick={() => onPromoteToHost(user.id)} icon={<CrownIcon className="w-4 h-4 text-yellow-500"/>}>Promote to Host</MenuItem>
                            </>
                        )}

                        {isOwner && isTargetHost && (
                            <MenuItem onClick={() => handleAdvancedAction('revoke-host', { userId: user.id })} icon={<ShieldIcon className="w-4 h-4 text-orange-400"/>}>Dismiss as Admin</MenuItem>
                        )}

                        {isStageUser && !user.isMutedByHost && !user.isMuted && (
                            <MenuItem onClick={() => onMuteUser(user.id)} icon={<MicrophoneOffIcon className="w-4 h-4 text-red-400"/>}>
                                Mute User
                            </MenuItem>
                        )}
                        
                        <div className="h-px bg-white/10 my-1"></div>
                        
                        {canManageUser && (
                            <>
                                <MenuItem className="text-orange-400 hover:bg-orange-500/10" onClick={() => onKickUser(user.id)} icon={<DoorOutIcon className="w-4 h-4"/>}>Kick User</MenuItem>
                                <MenuItem className="text-red-400 hover:bg-red-500/10" onClick={() => handleBlockUserWithDetails(user.id)} icon={<BlockUserIcon className="w-4 h-4"/>}>Ban User</MenuItem>
                            </>
                        )}
                    </>
                )}
                
                <MenuItem onClick={() => onViewProfile(user)} icon={<UserAddIcon className="w-4 h-4"/>}>View Profile</MenuItem>
            </div>
        );
    };

    const MenuItem: React.FC<{ onClick: () => void, className?: string, children: React.ReactNode, icon?: React.ReactNode }> = ({ onClick, className, children, icon }) => (
        <button onClick={() => { onClick(); closeContextMenu(); }} className={`w-full text-left px-3 py-2.5 rounded-lg hover:bg-white/5 transition-colors font-medium flex items-center gap-3 text-gray-200 ${className}`}>
            {icon && <span className="opacity-70">{icon}</span>}
            <span>{children}</span>
        </button>
    );

    return (
        <div className="flex h-full bg-[#0f0f11] overflow-hidden relative">
             <style>{`
                .theme-cosmic { background: radial-gradient(circle at 50% 0%, #2e1065 0%, #0f0f11 60%); }
                .theme-sunset { background: radial-gradient(circle at 50% 0%, #7c2d12 0%, #0f0f11 60%); }
                .theme-forest { background: radial-gradient(circle at 50% 0%, #064e3b 0%, #0f0f11 60%); }
                .theme-ocean { background: radial-gradient(circle at 50% 0%, #1e3a8a 0%, #0f0f11 60%); }
                .theme-midnight { background: radial-gradient(circle at 50% 0%, #312e81 0%, #0f0f11 60%); }
                .theme-rose { background: radial-gradient(circle at 50% 0%, #881337 0%, #0f0f11 60%); }
                .theme-amber { background: radial-gradient(circle at 50% 0%, #78350f 0%, #0f0f11 60%); }
                @keyframes ping-slow { 0% { transform: scale(1); opacity: 0.4; } 100% { transform: scale(1.3); opacity: 0; } }
                .animate-ping-slow { animation: ping-slow 2s cubic-bezier(0, 0, 0.2, 1) infinite; }
                .animate-pulse-subtle { animation: pulse-subtle 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
                .animate-spin-slow { animation: spin 8s linear infinite; }
                @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
                @keyframes pulse-subtle { 0%, 100% { opacity: 1; } 50% { opacity: .7; } }
                @keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-2px); } 75% { transform: translateX(2px); } }
                .animate-shake { animation: shake 0.3s ease-in-out 3; }
            `}</style>
            
            <div className={`absolute inset-0 z-0 theme-${room.theme || 'cosmic'} transition-opacity duration-500 ${isRoomEnding ? 'opacity-20' : 'opacity-100'}`} />
            
            {isRoomEnding && (
                <div className="absolute inset-0 z-[100] flex flex-col items-center justify-center bg-black/80 backdrop-blur-xl animate-fade-in">
                    <div className="text-center animate-bounce-in">
                        <ClockIcon className="w-20 h-20 text-red-500 mx-auto mb-4 animate-pulse" />
                        <h1 className="text-5xl font-black text-white mb-2 tracking-tight">TIME'S UP</h1>
                        <p className="text-gray-400 text-lg">The room session has ended.</p>
                    </div>
                </div>
            )}

            <div className={`flex flex-1 h-full relative z-10 overflow-hidden transition-all duration-500 ${isRoomEnding ? 'scale-95 blur-sm' : ''}`}>
                
                <div className="flex-1 flex flex-col min-w-0 h-full relative">
                    <VoiceRoomHeader
                        room={room}
                        isHost={isHost}
                        onLeave={handleLeaveAttempt}
                        onOpenMenu={() => setIsHeaderMenuOpen(prev => !prev)}
                        onToggleGame={() => setIsGamePanelOpen(prev => !prev)}
                        onViewRequests={() => setIsSettingsModalOpen(true)} 
                        isGameOpen={isGamePanelOpen}
                        timeLeftSeconds={timeLeftSeconds}
                    />
                    
                    {isHeaderMenuOpen && (
                        <VoiceRoomHeaderMenu 
                            isHost={isHost}
                            isRecording={!!room.isRecording}
                            onToggleRecording={() => { onToggleRecording(); closeHeaderMenu(); }}
                            onCopyInviteLink={() => { navigator.clipboard.writeText(`${window.location.origin}?joinVoice=${room.inviteCode}`); closeHeaderMenu(); }}
                            onOpenSettings={() => { setIsSettingsModalOpen(true); closeHeaderMenu(); }}
                            onOpenStartGame={() => { onOpenStartGameModal(); closeHeaderMenu(); }}
                            onEndRoom={() => { onEndRoom(); closeHeaderMenu(); }}
                        />
                    )}
                    
                    <VoiceRoomReactions />

                    <main className="flex-1 overflow-y-auto hide-scrollbar px-3 sm:px-4 pb-24 pt-2">
                        <div className="max-w-5xl mx-auto space-y-6 sm:space-y-8">
                            
                            <section className="bg-white/5 backdrop-blur-sm border border-white/5 rounded-3xl p-4 sm:p-6 min-h-[200px] relative overflow-hidden animate-fade-in">
                                <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
                                <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mb-6 text-center relative z-10">Stage</h3>
                                
                                <div className="flex flex-wrap justify-center gap-4 sm:gap-10 relative z-10">
                                    {hosts.map(host => (
                                        <AvatarPod 
                                            key={host.id} 
                                            user={host} 
                                            type="host" 
                                            onClick={() => onViewProfile(host)} 
                                            onContextMenu={(e) => openContextMenu(e, host)} 
                                            userVolume={userVolumes[host.id]}
                                        />
                                    ))}
                                    {speakers.map(speaker => (
                                        <AvatarPod 
                                            key={speaker.id} 
                                            user={speaker} 
                                            type="speaker" 
                                            onClick={() => onViewProfile(speaker)} 
                                            onContextMenu={(e) => openContextMenu(e, speaker)} 
                                            userVolume={userVolumes[speaker.id]}
                                        />
                                    ))}
                                    {hosts.length === 0 && speakers.length === 0 && (
                                        <div className="text-gray-500 text-sm italic py-10">The stage is empty.</div>
                                    )}
                                </div>
                            </section>

                            {raisedHandsListeners.length > 0 && (
                                <section className="animate-fade-in-up">
                                    <div className="flex items-center gap-2 mb-4 px-2">
                                        <div className="bg-blue-500/20 text-blue-300 p-1.5 rounded-lg"><HandIcon className="w-4 h-4"/></div>
                                        <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wide">Requests to Speak</h3>
                                    </div>
                                    <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4">
                                        {raisedHandsListeners.map(listener => (
                                            <AvatarPod key={listener.id} user={listener} type="listener" onClick={() => onViewProfile(listener)} onContextMenu={(e) => openContextMenu(e, listener)}/>
                                        ))}
                                    </div>
                                </section>
                            )}

                            <section>
                                <h3 className="text-xs font-bold text-gray-500 uppercase mb-4 px-2 tracking-wider">Audience ({otherListeners.length})</h3>
                                {otherListeners.length > 0 ? (
                                    <div className="grid grid-cols-3 xs:grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-3 sm:gap-6">
                                        {otherListeners.map(listener => (
                                            <AvatarPod key={listener.id} user={listener} type="listener" onClick={() => onViewProfile(listener)} onContextMenu={(e) => openContextMenu(e, listener)} />
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-gray-600 text-sm px-2">No one in the audience yet.</div>
                                )}
                            </section>

                            <div className="h-16"></div>
                        </div>
                    </main>

                    {/* Floating Control Dock - Raised for mobile */}
                    <div className="absolute bottom-8 sm:bottom-6 left-1/2 -translate-x-1/2 z-30 w-[90%] max-w-md">
                        {showSfxPanel && <SoundEffectsPanel onClose={() => setShowSfxPanel(false)} />}
                        
                        <div className="bg-[#1e1931]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-2 shadow-2xl flex items-center justify-between gap-1">
                            
                             <button onClick={handleLeaveAttempt} className="flex flex-col items-center justify-center w-14 h-14 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors">
                                 <div className="bg-red-500/20 p-2 rounded-full mb-0.5"><ArrowLeftIcon className="w-5 h-5"/></div>
                                <span className="text-[10px] font-semibold">Leave</span>
                            </button>

                            <div className="w-px h-8 bg-white/10 mx-1"></div>

                            {(isHost || isSpeaker) ? (
                                <button 
                                    onClick={() => onSelfMute(!currentUserInRoom?.isMuted)} 
                                    className={`flex flex-col items-center justify-center w-16 h-14 rounded-xl transition-colors ${currentUserInRoom?.isMuted ? 'text-red-400' : 'text-white'}`}
                                >
                                    <div className={`p-3 rounded-full mb-0.5 transition-all ${currentUserInRoom?.isMuted ? 'bg-red-500/20' : 'bg-white/10 hover:bg-white/20'}`}>
                                        {currentUserInRoom?.isMuted ? <MicrophoneOffIcon className="w-6 h-6"/> : <MicrophoneIcon className="w-6 h-6"/>}
                                    </div>
                                </button>
                            ) : (
                                <button 
                                    onClick={onRaiseHand} 
                                    className={`flex flex-col items-center justify-center w-16 h-14 rounded-xl transition-colors ${hasRaisedHand ? 'text-blue-400' : 'text-gray-300'}`}
                                >
                                    <div className={`p-3 rounded-full mb-0.5 transition-all ${hasRaisedHand ? 'bg-blue-500/20' : 'bg-white/5 hover:bg-white/10'}`}>
                                        <HandIcon className="w-6 h-6"/>
                                    </div>
                                </button>
                            )}

                             <button onClick={() => {}} className="flex flex-col items-center justify-center w-14 h-14 rounded-xl text-pink-400 hover:bg-pink-500/10 transition-colors">
                                <div className="bg-pink-500/20 p-2 rounded-full mb-0.5"><HeartIcon className="w-5 h-5"/></div>
                                <span className="text-[10px] font-semibold">React</span>
                            </button>

                            {(isHost || isSpeaker) && (
                                 <button onClick={() => setShowSfxPanel(prev => !prev)} className={`hidden sm:flex flex-col items-center justify-center w-14 h-14 rounded-xl transition-colors ${showSfxPanel ? 'text-yellow-400' : 'text-gray-400 hover:text-white'}`}>
                                    <div className={`p-2 rounded-full mb-0.5 ${showSfxPanel ? 'bg-yellow-500/20' : 'bg-white/5'}`}><StarIcon className="w-5 h-5"/></div>
                                    <span className="text-[10px] font-semibold">SFX</span>
                                </button>
                            )}
                        </div>
                    </div>
                </div>

                <aside className={`
                    hidden lg:flex flex-col w-96 bg-[#18181b] border-l border-white/10 transition-all duration-300 ease-in-out relative z-20
                    ${isGamePanelOpen ? 'mr-0' : '-mr-96 w-0 border-none opacity-0 overflow-hidden'}
                `}>
                    <GamesPanel 
                        room={room} 
                        currentUser={currentUser} 
                        onGameAction={props.onGameAction} 
                        onClose={() => setIsGamePanelOpen(false)}
                    />
                </aside>

            </div>

            <div className={`
                lg:hidden fixed inset-0 z-50 transition-colors duration-300
                ${isGamePanelOpen ? 'bg-black/60 backdrop-blur-sm' : 'pointer-events-none bg-transparent'}
            `} onClick={() => setIsGamePanelOpen(false)}>
                <div 
                    className={`
                        absolute bottom-0 left-0 right-0 bg-[#18181b] rounded-t-3xl shadow-2xl border-t border-white/10 transition-transform duration-300 ease-out flex flex-col max-h-[80vh]
                        ${isGamePanelOpen ? 'translate-y-0' : 'translate-y-full'}
                    `}
                    onClick={e => e.stopPropagation()}
                >
                    <div className="w-full h-1.5 bg-gray-600 rounded-full opacity-30 mx-auto mt-3 mb-1 w-12"></div>
                    <GamesPanel 
                        room={room} 
                        currentUser={currentUser} 
                        onGameAction={props.onGameAction} 
                        onClose={() => setIsGamePanelOpen(false)}
                        isMobile
                    />
                </div>
            </div>

            {contextMenu && <UserContextMenu menu={contextMenu} />}
            
            {showHostLeaveModal && (
                <HostLeaveModal 
                    speakers={room.speakers.filter(s => s.id !== currentUser.id)}
                    onCancel={() => setShowHostLeaveModal(false)}
                    onEndRoom={onEndRoom}
                    onTransferAndLeave={handleTransferAndLeave}
                />
            )}

            {isInvitedToSpeak && (
                <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-[#1e1931] border border-white/10 rounded-2xl shadow-2xl w-full max-w-sm p-6 text-center animate-bounce-in">
                        <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <MicrophoneIcon className="w-8 h-8 text-green-400" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-2">Invitation to Speak</h3>
                        <p className="text-gray-300 text-sm mb-6">
                            The host has invited you to join the stage as a speaker.
                        </p>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => handleAdvancedAction('respond-to-invite', { userId: currentUser.id, accept: true })}
                                className="flex-1 py-3 bg-green-600 hover:bg-green-500 text-white rounded-xl font-bold text-sm transition-colors shadow-lg"
                            >
                                Accept
                            </button>
                            <button 
                                onClick={() => handleAdvancedAction('respond-to-invite', { userId: currentUser.id, accept: false })}
                                className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold text-sm transition-colors"
                            >
                                Decline
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isSettingsModalOpen && (
                <VoiceRoomSettingsModal 
                    isOpen={isSettingsModalOpen}
                    onClose={() => setIsSettingsModalOpen(false)}
                    room={room}
                    onUpdateSettings={(s) => props.onGameAction('update-settings', s)}
                    onUpdateTheme={(t) => props.onGameAction('update-theme', { theme: t })}
                    onTransferHost={(id) => props.onGameAction('transfer-host', { userId: id })}
                    onUnblockUser={(id) => props.onGameAction('unblock-user', { userId: id })}
                    onAcceptRequest={onAcceptRequest}
                    onDeclineRequest={onDeclineRequest}
                />
            )}
        </div>
    );
};

export default VoiceRoomComponent;
