
import React, { useState } from 'react';
import type { ScheduledEvent, User, Friend } from '../types';
import { ClockIcon, ChevronDownIcon } from './icons';
import EventDetailsContent from './EventDetailsContent';
import ConfirmationModal from './ConfirmationModal';
import ForwardMessageModal from './ForwardMessageModal';

interface ExpandableEventCardProps {
    event: ScheduledEvent;
    currentUser: User;
    friends: Friend[];
    onRsvp: (eventId: number, status: 'going' | 'maybe' | 'not-going') => void;
    onInviteFriends: (eventId: number, friendIds: number[]) => void;
    onUpdateEvent: (updatedEvent: ScheduledEvent) => void;
    onCancelEvent: (eventId: number) => void;
    onStartParty: (event: ScheduledEvent) => void;
}

const ExpandableEventCard: React.FC<ExpandableEventCardProps> = (props) => {
    const { event, currentUser, friends, onRsvp, onInviteFriends, onCancelEvent, onStartParty } = props;
    const [isExpanded, setIsExpanded] = useState(false);
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
    const [currentEvent, setCurrentEvent] = useState(event);

    const handleRsvp = (eventId: number, status: 'going' | 'maybe' | 'not-going') => {
        onRsvp(eventId, status);
        setCurrentEvent(prev => ({
            ...prev,
            rsvps: [...(prev.rsvps?.filter(r => r.userId !== currentUser.id) || []), {userId: currentUser.id, status}]
        }));
    };
    
    const handleInviteSubmit = (friendIds: number[], comment: string) => {
        onInviteFriends(event.id, friendIds);
        
        const newInvites: Friend[] = [];
        friendIds.forEach(id => {
             const friend = friends.find(f => f.id === id);
             if (friend && !currentEvent.invitedUsers.some(u => u.id === id)) {
                 newInvites.push(friend);
             }
        });

        if (newInvites.length > 0) {
            setCurrentEvent(prev => ({...prev, invitedUsers: [...prev.invitedUsers, ...newInvites]}));
        }
        setIsInviteModalOpen(false);
    };

    const handleCancel = () => {
        onCancelEvent(event.id);
        setIsCancelConfirmOpen(false);
    };
    
    return (
        <>
            <div className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden transition-all duration-300">
                <div 
                    className="p-4 flex items-center gap-4 cursor-pointer hover:bg-white/5"
                    onClick={() => setIsExpanded(prev => !prev)}
                >
                    <img src={event.thumbnail} alt={event.title} className="w-24 h-16 object-cover rounded-lg flex-shrink-0"/>
                    <div className="flex-1 min-w-0">
                        <p className="font-bold text-white truncate">{event.title}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-300 mt-1">
                            <span style={{ color: 'var(--theme-color)' }}><ClockIcon className="w-4 h-4" /></span>
                            <span>{event.scheduledTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                    </div>
                    <ChevronDownIcon className={`w-6 h-6 text-gray-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                </div>

                <div className={`transition-[max-height] duration-500 ease-in-out overflow-hidden ${isExpanded ? 'max-h-[1500px]' : 'max-h-0'}`}>
                    <div className="border-t border-white/10">
                        <EventDetailsContent
                            event={currentEvent}
                            currentUser={currentUser}
                            onRsvp={handleRsvp}
                            onInvite={() => setIsInviteModalOpen(true)}
                            onEdit={() => alert('Editing not implemented in this view.')}
                            onCancel={() => setIsCancelConfirmOpen(true)}
                            onStartParty={onStartParty}
                        />
                    </div>
                </div>
            </div>
             {isCancelConfirmOpen && (
                <ConfirmationModal 
                    isOpen={isCancelConfirmOpen}
                    onClose={() => setIsCancelConfirmOpen(false)}
                    onConfirm={handleCancel}
                    title="Cancel Event"
                    message={`Are you sure you want to cancel "${event.title}"? This cannot be undone.`}
                    confirmText="Yes, Cancel"
                />
            )}
            {isInviteModalOpen && (
                <ForwardMessageModal 
                    isOpen={isInviteModalOpen}
                    onClose={() => setIsInviteModalOpen(false)}
                    friends={friends.filter(f => ![...currentEvent.invitedUsers.map(u => u.id), currentEvent.createdBy.id].includes(f.id))}
                    onForward={handleInviteSubmit}
                    isSharingRoom
                    shareTitle={`Invite friends to "${event.title}"`}
                />
            )}
        </>
    );
};

export default ExpandableEventCard;
