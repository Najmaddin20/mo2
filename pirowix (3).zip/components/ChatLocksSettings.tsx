import React from 'react';
import type { Conversation } from '../types';
import { LockClosedIcon, TrashIcon } from './icons';

interface ChatLocksSettingsProps {
    lockedConversations: Conversation[];
    onUnlockRequest: (conv: Conversation) => void;
    onChangePinRequest: (conv: Conversation) => void;
    onResetAllPins: () => void;
}

const ChatLocksSettings: React.FC<ChatLocksSettingsProps> = ({ lockedConversations, onUnlockRequest, onChangePinRequest, onResetAllPins }) => {
    return (
        <div className="space-y-6">
            <h2 className="text-xl font-bold">Manage Chat Locks</h2>
            <p className="text-gray-400">Here you can change PINs or unlock your private conversations individually.</p>
            
            <div className="space-y-3">
                {lockedConversations.length > 0 ? (
                    lockedConversations.map(conv => (
                        <div key={conv.friend.id} className="p-4 rounded-lg bg-black/30 border border-white/20 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <img src={conv.friend.avatar} alt={conv.friend.name} className="w-12 h-12 rounded-full" />
                                <div>
                                    <p className="font-semibold text-white">{conv.friend.name}</p>
                                    <p className="text-xs text-gray-400 flex items-center gap-1"><LockClosedIcon className="w-3 h-3"/> Chat is locked</p>
                                </div>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-2">
                                <button onClick={() => onChangePinRequest(conv)} className="px-3 py-1.5 text-xs font-semibold rounded-md text-white bg-white/10 hover:bg-white/20">Change PIN</button>
                                <button onClick={() => onUnlockRequest(conv)} className="px-3 py-1.5 text-xs font-semibold rounded-md text-white bg-blue-500 hover:bg-blue-600">Unlock</button>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="text-center py-8 px-4 rounded-lg bg-black/30 border border-dashed border-white/20">
                        <p className="text-gray-400">You have no locked chats.</p>
                    </div>
                )}
            </div>
            
            <div className="p-4 rounded-lg bg-black/30 border border-red-500/50 mt-8">
                 <h3 className="font-semibold text-red-400">Danger Zone</h3>
                <p className="text-xs text-gray-400 mt-1 mb-3">This action will remove the PIN protection from all your chats at once.</p>
                <button
                    onClick={onResetAllPins}
                    disabled={lockedConversations.length === 0}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg text-white bg-red-800 hover:bg-red-900 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <TrashIcon className="w-5 h-5" />
                    <span>Reset All Locked Chats</span>
                </button>
            </div>
        </div>
    );
};

export default ChatLocksSettings;
