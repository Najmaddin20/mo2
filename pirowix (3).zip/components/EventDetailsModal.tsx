import React from 'react';
import type { ScheduledEvent, User } from '../types';
import { CloseIcon } from './icons';
import EventDetailsContent from './EventDetailsContent';

interface EventDetailsModalProps {
    isOpen: boolean;
    onClose: () => void;
    event: ScheduledEvent;
    currentUser: User;
    onRsvp: (status: 'going' | 'maybe' | 'not-going') => void;
    onInvite: () => void;
    onEdit: (event: ScheduledEvent) => void;
    onCancel: () => void;
    onStartParty: (event: ScheduledEvent) => void;
}

const EventDetailsModal: React.FC<EventDetailsModalProps> = (props) => {
    const { isOpen, onClose, event } = props;

    if (!isOpen) return null;

    // Fix: Create a handler to adapt the onRsvp prop for EventDetailsContent.
    const handleRsvpForContent = (_eventId: number, status: 'going' | 'maybe' | 'not-going') => {
        props.onRsvp(status);
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div 
                className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl w-full max-w-lg flex flex-col max-h-[90vh] animate-fade-in-up"
                onClick={e => e.stopPropagation()}
            >
                <div className="relative h-48 rounded-t-2xl bg-cover bg-center flex-shrink-0" style={{backgroundImage: `url(${event.thumbnail})`}}>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                    <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white bg-black/40 rounded-full p-1.5"><CloseIcon className="w-5 h-5"/></button>
                    <div className="absolute bottom-4 left-4">
                        <h2 className="text-3xl font-bold text-white">{event.title}</h2>
                    </div>
                </div>

                <div className="flex-1 flex flex-col min-h-0">
                   <EventDetailsContent {...props} onRsvp={handleRsvpForContent} />
                </div>
            </div>
        </div>
    );
};

export default EventDetailsModal;