
import React, { useState } from 'react';
import type { Conversation, User, GroupPermission } from '../types';
import { ArrowLeftIcon, SearchIcon, UserAddIcon, EditIcon } from './icons';
import GroupAdminPanel from './GroupAdminPanel';
import GroupMemberManagement from './GroupMemberManagement';

interface GroupProfilePageProps {
    conversation: Conversation;
    currentUser: User;
    onBack: () => void;
    onUpdateGroup: (updates: Partial<Conversation>) => void;
    onDeleteGroup: () => void;
    onLeaveGroup: () => void;
    onKickMember: (userId: number) => void;
    onBanMember: (userId: number) => void;
    onUnbanMember: (userId: number) => void;
    onPromoteMember: (userId: number) => void;
    onDemoteMember: (userId: number) => void;
    onForwardInvite: () => void; // Placeholder for invite flow
}

const GroupProfilePage: React.FC<GroupProfilePageProps> = ({ 
    conversation, currentUser, onBack, onUpdateGroup, onDeleteGroup, onLeaveGroup, 
    onKickMember, onBanMember, onUnbanMember, onPromoteMember, onDemoteMember, onForwardInvite
}) => {
    const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'settings'>('overview');
    
    const amIOwner = conversation.groupOwnerId === currentUser.id;
    const amIAdmin = amIOwner || (conversation.adminIds || []).includes(currentUser.id);
    
    // Permissions check for "Edit Group" access
    const myPermissions = conversation.memberPermissions?.[currentUser.id] || [];
    const canEditInfo = amIOwner || (amIAdmin && myPermissions.includes('edit_info')) || amIAdmin; // Default admins can usually edit

    return (
        <div className="flex flex-col h-full bg-[#0f0f0f] overflow-hidden relative">
            {/* Parallax Header */}
            <div className="relative h-64 flex-shrink-0">
                <div 
                    className="absolute inset-0 bg-cover bg-center" 
                    style={{ 
                        backgroundImage: conversation.friend.profileBanner ? `url(${conversation.friend.profileBanner})` : `url(${conversation.friend.avatar})`,
                        filter: 'blur(20px) brightness(0.4)'
                    }} 
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0f0f0f]" />
                
                {/* Nav Bar */}
                <div className="absolute top-0 left-0 right-0 p-4 z-20 flex justify-between items-center">
                    <button onClick={onBack} className="p-2 bg-black/30 backdrop-blur-md rounded-full text-white hover:bg-black/50 transition-colors">
                        <ArrowLeftIcon className="w-6 h-6" />
                    </button>
                    {canEditInfo && activeTab !== 'settings' && (
                        <button onClick={() => setActiveTab('settings')} className="px-4 py-2 bg-white/10 backdrop-blur-md rounded-full text-white text-sm font-bold hover:bg-white/20 transition-colors flex items-center gap-2">
                            <EditIcon className="w-4 h-4" /> Edit
                        </button>
                    )}
                </div>

                {/* Group Identity */}
                <div className="absolute bottom-0 left-0 right-0 p-6 z-10 flex items-end gap-6">
                    <img 
                        src={conversation.friend.avatar} 
                        className="w-28 h-28 rounded-3xl border-4 border-[#0f0f0f] shadow-2xl object-cover bg-[#1e1e1e]" 
                        style={{ boxShadow: `0 10px 30px -10px ${conversation.theme || '#6C5DD3'}80` }}
                    />
                    <div className="mb-2">
                        <h1 className="text-3xl font-bold text-white drop-shadow-md">{conversation.friend.name}</h1>
                        <p className="text-gray-300 text-sm font-medium opacity-90">
                            {conversation.participants?.length} members • {conversation.isPublic ? 'Public' : 'Private'} Group
                        </p>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-white/10 px-6 bg-[#0f0f0f] z-10 sticky top-0">
                <TabButton label="Overview" active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} theme={conversation.theme} />
                <TabButton label="Members" active={activeTab === 'members'} onClick={() => setActiveTab('members')} theme={conversation.theme} />
                {amIAdmin && <TabButton label="Settings" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} theme={conversation.theme} />}
            </div>

            {/* Tab Content */}
            <div className="flex-1 overflow-hidden relative">
                {activeTab === 'overview' && (
                    <div className="h-full overflow-y-auto p-6 space-y-8 custom-scrollbar">
                        {conversation.description && (
                            <div className="bg-[#18181b] p-5 rounded-2xl border border-white/5">
                                <h3 className="text-xs font-bold text-gray-500 uppercase mb-2">About</h3>
                                <p className="text-gray-200 leading-relaxed whitespace-pre-wrap">{conversation.description}</p>
                            </div>
                        )}

                        <div>
                            <h3 className="text-xs font-bold text-gray-500 uppercase mb-4">Media</h3>
                            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                {conversation.messages.filter(m => m.imageUrl).slice(0, 8).map(m => (
                                    <div key={m.id} className="aspect-square rounded-xl overflow-hidden bg-[#18181b] cursor-pointer hover:opacity-80 transition-opacity">
                                        <img src={m.imageUrl} className="w-full h-full object-cover" />
                                    </div>
                                ))}
                                {conversation.messages.filter(m => m.imageUrl).length === 0 && (
                                    <div className="col-span-3 text-gray-500 text-sm italic">No media shared yet.</div>
                                )}
                            </div>
                        </div>
                        
                        <div className="pt-4">
                            <button onClick={onLeaveGroup} className="w-full py-3 rounded-xl bg-[#18181b] text-red-500 font-bold hover:bg-red-500/10 transition-colors">
                                Leave Group
                            </button>
                        </div>
                    </div>
                )}

                {activeTab === 'members' && (
                    <GroupMemberManagement 
                        conversation={conversation}
                        currentUser={currentUser}
                        onUpdateGroup={onUpdateGroup}
                        onKickUser={onKickMember}
                        onBanUser={onBanMember}
                        onPromote={onPromoteMember}
                        onDemote={onDemoteMember}
                    />
                )}

                {activeTab === 'settings' && (
                    <GroupAdminPanel 
                        conversation={conversation}
                        onUpdateGroup={onUpdateGroup}
                        onDeleteGroup={onDeleteGroup}
                        onUnbanUser={onUnbanMember}
                    />
                )}
            </div>
        </div>
    );
};

const TabButton: React.FC<{ label: string, active: boolean, onClick: () => void, theme?: string }> = ({ label, active, onClick, theme = '#6C5DD3' }) => (
    <button 
        onClick={onClick} 
        className={`px-6 py-4 text-sm font-bold transition-all border-b-2 ${active ? 'text-white' : 'text-gray-500 border-transparent hover:text-gray-300'}`}
        style={active ? { borderColor: theme } : {}}
    >
        {label}
    </button>
);

export default GroupProfilePage;
