
import React, { useState } from 'react';
import type { VoiceRoomUser } from '../types';
import { CloseIcon, CrownIcon, DoorOutIcon, TrashIcon } from './icons';

interface HostLeaveModalProps {
    speakers: VoiceRoomUser[];
    onCancel: () => void;
    onEndRoom: () => void;
    onTransferAndLeave: (newHostId: number) => void;
}

const HostLeaveModal: React.FC<HostLeaveModalProps> = ({ speakers, onCancel, onEndRoom, onTransferAndLeave }) => {
    const [selectedHostId, setSelectedHostId] = useState<number | null>(null);

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-fade-in">
            <div className="bg-[#1e1931] border border-white/10 rounded-2xl shadow-2xl w-full max-w-md p-6 animate-fade-in-up" onClick={e => e.stopPropagation()}>
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-white">Leaving Room?</h2>
                    <button onClick={onCancel} className="text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6"/></button>
                </div>
                
                <p className="text-gray-300 text-sm mb-6">
                    You are the host. You can either assign a new host to keep the room running, or end the room for everyone.
                </p>

                {speakers.length > 0 && (
                    <div className="mb-6">
                        <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Select New Host</label>
                        <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar bg-black/20 rounded-lg p-1">
                            {speakers.map(speaker => (
                                <div 
                                    key={speaker.id} 
                                    onClick={() => setSelectedHostId(speaker.id)}
                                    className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${selectedHostId === speaker.id ? 'bg-purple-600 text-white' : 'hover:bg-white/5 text-gray-300'}`}
                                >
                                    <img src={speaker.avatar} className="w-8 h-8 rounded-full object-cover" />
                                    <span className="text-sm font-medium">{speaker.name}</span>
                                    {selectedHostId === speaker.id && <CrownIcon className="w-4 h-4 ml-auto text-yellow-300" />}
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <div className="flex flex-col gap-3">
                    {speakers.length > 0 && (
                        <button 
                            onClick={() => selectedHostId && onTransferAndLeave(selectedHostId)}
                            disabled={!selectedHostId}
                            className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <DoorOutIcon className="w-4 h-4" /> Assign & Leave
                        </button>
                    )}
                    
                    <button 
                        onClick={onEndRoom}
                        className="w-full py-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 hover:text-red-300 font-semibold text-sm transition-colors flex items-center justify-center gap-2"
                    >
                        <TrashIcon className="w-4 h-4" /> End Room for All
                    </button>
                    
                    <button onClick={onCancel} className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm font-medium">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    );
};

export default HostLeaveModal;