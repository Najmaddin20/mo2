
import React from 'react';
import type { ChatMessage } from '../types';
import { UserAddIcon, DoorOutIcon, PlayIcon, PauseIcon, VideoCameraIcon, CrownIcon, BlockUserIcon, TrashIcon } from './icons';

interface EventMessageProps {
    message: ChatMessage;
}

const EventMessage: React.FC<EventMessageProps> = ({ message }) => {
    if (message.type !== 'event' || !message.eventType) return null;

    const getEventStyle = () => {
        switch (message.eventType) {
            case 'user-join':
                return {
                    icon: <UserAddIcon className="w-3.5 h-3.5" />,
                    color: 'text-emerald-400',
                    text: 'joined'
                };
            case 'user-leave':
                return {
                    icon: <DoorOutIcon className="w-3.5 h-3.5" />,
                    color: 'text-zinc-400',
                    text: 'left'
                };
            case 'user-kick':
                return {
                    icon: <TrashIcon className="w-3.5 h-3.5" />,
                    color: 'text-orange-400',
                    text: 'was kicked'
                };
            case 'user-block':
                 return {
                    icon: <BlockUserIcon className="w-3.5 h-3.5" />,
                    color: 'text-red-400',
                    text: 'was blocked'
                };
            case 'playback-change':
                const isPlaying = message.eventDetails?.action === 'played';
                return {
                    icon: isPlaying ? <PlayIcon className="w-3.5 h-3.5" /> : <PauseIcon className="w-3.5 h-3.5" />,
                    color: isPlaying ? 'text-blue-400' : 'text-amber-400',
                    text: isPlaying ? 'resumed video' : 'paused video'
                };
            case 'video-change':
                return {
                    icon: <VideoCameraIcon className="w-3.5 h-3.5" />,
                    color: 'text-indigo-400',
                    text: 'changed video'
                };
            case 'role-change':
                return {
                    icon: <CrownIcon className="w-3.5 h-3.5" />,
                    color: 'text-yellow-400',
                    text: 'role updated'
                };
            default:
                return {
                    icon: null,
                    color: 'text-gray-400',
                    text: ''
                };
        }
    };

    const style = getEventStyle();
    const displayText = message.message || `${message.user?.name} ${style.text}`;

    return (
        <div className="flex justify-center my-2 w-full px-4 pointer-events-none">
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-black/20 backdrop-blur-sm border border-white/5 text-xs text-gray-400 shadow-sm animate-fade-in-up">
                <span className={style.color}>{style.icon}</span>
                <span className="font-medium">{displayText}</span>
            </div>
        </div>
    );
};

export default EventMessage;
