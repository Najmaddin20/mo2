
import React, { useState, useEffect, useRef, createContext, useContext, useCallback } from 'react';
import type { AudioTrack, RepeatMode } from '../types';
import { PlayFilledIcon, PauseFilledIcon, SkipNextIcon, SkipPreviousIcon, CloseIcon, ChevronDownIcon, VolumeUpIcon, VolumeOffIcon, Replay10Icon, SearchIcon, ShareIcon, DownloadIcon } from './icons';

interface AudioContextType {
    currentTrack: AudioTrack | null;
    isPlaying: boolean;
    currentTime: number;
    duration: number;
    queue: AudioTrack[];
    repeatMode: RepeatMode;
    isShuffle: boolean;
    playTrack: (track: AudioTrack, contextQueue?: AudioTrack[]) => void;
    togglePlay: () => void;
    nextTrack: () => void;
    prevTrack: () => void;
    seek: (time: number) => void;
    setVolume: (volume: number) => void;
    volume: number;
    toggleRepeat: () => void;
    toggleShuffle: () => void;
    closePlayer: () => void;
    expandPlayer: () => void;
    isExpanded: boolean;
    setIsExpanded: (v: boolean) => void;
    isPlaylistOpen: boolean;
    setIsPlaylistOpen: (v: boolean) => void;
    togglePlaylist: () => void;
}

const AudioPlayerContext = createContext<AudioContextType | undefined>(undefined);

export const useAudioPlayer = () => {
    const context = useContext(AudioPlayerContext);
    if (!context) throw new Error('useAudioPlayer must be used within an AudioPlayerProvider');
    return context;
};

// --- Icons Specific to Player ---
const ShuffleIcon = ({ className }: { className?: string }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
);
const RepeatIcon = ({ className, mode }: { className?: string, mode: RepeatMode }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        {mode === 'one' && <text x="10" y="14" fontSize="8" fill="currentColor" stroke="none" fontWeight="bold">1</text>}
    </svg>
);

export const AudioPlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [currentTrack, setCurrentTrack] = useState<AudioTrack | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [queue, setQueue] = useState<AudioTrack[]>([]);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolumeState] = useState(0.8);
    const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
    const [isShuffle, setIsShuffle] = useState(false);
    const [isExpanded, setIsExpanded] = useState(false);
    const [isPlaylistOpen, setIsPlaylistOpen] = useState(false);

    const audioRef = useRef<HTMLAudioElement>(new Audio());

    useEffect(() => {
        const audio = audioRef.current;
        
        const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
        const handleDurationChange = () => setDuration(audio.duration);
        const handleEnded = () => {
            if (repeatMode === 'one') {
                audio.currentTime = 0;
                audio.play();
            } else {
                nextTrack();
            }
        };
        const handleError = (e: Event) => {
            console.error("Audio Playback Error:", e);
            setIsPlaying(false);
        };

        audio.addEventListener('timeupdate', handleTimeUpdate);
        audio.addEventListener('loadedmetadata', handleDurationChange);
        audio.addEventListener('ended', handleEnded);
        audio.addEventListener('error', handleError);

        return () => {
            audio.removeEventListener('timeupdate', handleTimeUpdate);
            audio.removeEventListener('loadedmetadata', handleDurationChange);
            audio.removeEventListener('ended', handleEnded);
            audio.removeEventListener('error', handleError);
        };
    }, [queue, currentTrack, repeatMode, isShuffle]);

    // Helper to safely play
    const safePlay = async () => {
        try {
            await audioRef.current.play();
            setIsPlaying(true);
        } catch (e) {
            console.error("Playback error (safePlay catch):", e);
            setIsPlaying(false);
        }
    };

    const playTrack = useCallback((track: AudioTrack, contextQueue: AudioTrack[] = []) => {
        const audio = audioRef.current;
        
        // If it's the same track, just toggle play/pause
        if (currentTrack?.id === track.id) {
            if (audio.paused) safePlay();
            else {
                audio.pause();
                setIsPlaying(false);
            }
            return;
        }

        setCurrentTrack(track);
        if (contextQueue.length > 0) {
            setQueue(contextQueue);
        } else {
            // If no queue provided, and track not in current queue, replace queue or add it
             if (!queue.find(t => t.id === track.id)) {
                 setQueue([track]);
             }
        }

        audio.src = track.url;
        audio.volume = volume;
        safePlay();
    }, [currentTrack, queue, volume]);

    const togglePlay = useCallback(() => {
        const audio = audioRef.current;
        if (!currentTrack && queue.length > 0) {
            playTrack(queue[0]);
            return;
        }
        if (audio.paused) {
            safePlay();
        } else {
            audio.pause();
            setIsPlaying(false);
        }
    }, [currentTrack, queue, playTrack]);

    const getNextTrack = useCallback(() => {
        if (queue.length === 0 || !currentTrack) return null;
        
        if (isShuffle) {
            // Simple shuffle: pick random that isn't current
            const remaining = queue.filter(t => t.id !== currentTrack.id);
            if (remaining.length === 0) return null;
            return remaining[Math.floor(Math.random() * remaining.length)];
        }
        
        const idx = queue.findIndex(t => t.id === currentTrack.id);
        if (idx === -1 || idx === queue.length - 1) {
            return repeatMode === 'all' ? queue[0] : null;
        }
        return queue[idx + 1];
    }, [queue, currentTrack, isShuffle, repeatMode]);

    const getPrevTrack = useCallback(() => {
        if (queue.length === 0 || !currentTrack) return null;
        const idx = queue.findIndex(t => t.id === currentTrack.id);
        if (idx <= 0) {
            return repeatMode === 'all' ? queue[queue.length - 1] : null;
        }
        return queue[idx - 1];
    }, [queue, currentTrack, repeatMode]);

    const nextTrack = useCallback(() => {
        const next = getNextTrack();
        if (next) playTrack(next);
        else {
            setIsPlaying(false);
            audioRef.current.pause();
            audioRef.current.currentTime = 0;
        }
    }, [getNextTrack, playTrack]);

    const prevTrack = useCallback(() => {
        const audio = audioRef.current;
        if (audio.currentTime > 3) {
            audio.currentTime = 0;
            return;
        }
        const prev = getPrevTrack();
        if (prev) playTrack(prev);
    }, [getPrevTrack, playTrack]);

    const seek = useCallback((time: number) => {
        if(isFinite(time)) {
            audioRef.current.currentTime = time;
            setCurrentTime(time);
        }
    }, []);

    const setVolume = useCallback((vol: number) => {
        setVolumeState(vol);
        audioRef.current.volume = vol;
    }, []);

    const toggleRepeat = useCallback(() => {
        setRepeatMode(prev => prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off');
    }, []);

    const toggleShuffle = useCallback(() => setIsShuffle(p => !p), []);

    const closePlayer = useCallback(() => {
        audioRef.current.pause();
        setIsPlaying(false);
        setCurrentTrack(null);
        setCurrentTime(0);
        setIsExpanded(false);
        setIsPlaylistOpen(false);
    }, []);
    
    const togglePlaylist = useCallback(() => {
        setIsPlaylistOpen(prev => !prev);
    }, []);

    return (
        <AudioPlayerContext.Provider value={{
            currentTrack, isPlaying, currentTime, duration, queue, repeatMode, isShuffle,
            playTrack, togglePlay, nextTrack, prevTrack, seek, setVolume, volume,
            toggleRepeat, toggleShuffle, closePlayer, expandPlayer: () => setIsExpanded(true),
            isExpanded, setIsExpanded, isPlaylistOpen, setIsPlaylistOpen, togglePlaylist
        }}>
            {children}
            {currentTrack && <FullAudioPlayerModal />}
        </AudioPlayerContext.Provider>
    );
};


// --- COMPONENTS ---

const formatTime = (time: number) => {
    if (isNaN(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
};

// 1. Full Screen Player Modal (Desktop / Extended Mobile)
export const FullAudioPlayerModal = () => {
    const { isExpanded, setIsExpanded, currentTrack, isPlaying, togglePlay, nextTrack, prevTrack, currentTime, duration, seek, repeatMode, toggleRepeat, isShuffle, toggleShuffle, queue, playTrack, closePlayer } = useAudioPlayer();
    const [showQueue, setShowQueue] = useState(false);

    if (!isExpanded || !currentTrack) return null;

    return (
        <div className="absolute inset-0 z-[200] bg-black/60 backdrop-blur-3xl flex flex-col animate-slide-in-up h-full w-full">
            {/* Header */}
            <div className="flex justify-between items-center p-6 pt-10 md:pt-6 flex-shrink-0">
                <button onClick={() => setIsExpanded(false)} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors text-white">
                    <ChevronDownIcon className="w-6 h-6" />
                </button>
                <div className="flex flex-col items-center">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{showQueue ? 'Queue' : 'Now Playing'}</span>
                    <span className="text-sm font-semibold text-white truncate max-w-[200px]">{currentTrack.contextId ? 'Chat Audio' : 'Music'}</span>
                </div>
                <button onClick={() => setShowQueue(!showQueue)} className={`p-2 rounded-full transition-colors ${showQueue ? 'text-white' : 'bg-white/10 text-gray-300'}`} style={showQueue ? { backgroundColor: 'var(--theme-color)' } : {}}>
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>

            {/* Content */}
            <div className="flex-1 flex flex-col justify-center px-8 pb-12 max-w-md mx-auto w-full relative min-h-0">
                
                {!showQueue ? (
                    <>
                        {/* Artwork */}
                        <div className="aspect-square w-full bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] mb-8 flex items-center justify-center overflow-hidden relative border border-white/10 group flex-shrink-0">
                             {currentTrack.artwork ? (
                                <img src={currentTrack.artwork} alt="Album Art" className="w-full h-full object-cover" />
                            ) : (
                                <div className="flex items-center justify-center w-full h-full bg-gradient-to-br from-[#2f2b43] to-[#1e1e24] text-white">
                                     <svg className="w-32 h-32 opacity-80" style={{ color: 'var(--theme-color)' }} fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
                                </div>
                            )}
                        </div>

                        {/* Info */}
                        <div className="mb-8 text-center flex-shrink-0">
                            <h2 className="text-2xl font-bold text-white mb-1 truncate">{currentTrack.title}</h2>
                            <p className="text-lg truncate font-medium" style={{ color: 'var(--theme-color)' }}>{currentTrack.artist}</p>
                        </div>

                        {/* Progress */}
                        <div className="mb-8 group/slider flex-shrink-0">
                            <input
                                type="range"
                                min="0"
                                max={duration || 100}
                                value={currentTime}
                                onChange={(e) => seek(Number(e.target.value))}
                                className="w-full h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer hover:h-2 transition-all"
                                style={{ accentColor: 'var(--theme-color)' }}
                            />
                            <div className="flex justify-between text-xs text-gray-400 mt-2 font-mono font-medium">
                                <span>{formatTime(currentTime)}</span>
                                <span>{formatTime(duration)}</span>
                            </div>
                        </div>

                        {/* Controls */}
                        <div className="flex items-center justify-between px-4 flex-shrink-0">
                            <button onClick={toggleShuffle} className={`p-3 rounded-full transition-colors ${isShuffle ? '' : 'text-gray-500 hover:text-white'}`} style={isShuffle ? { color: 'var(--theme-color)' } : {}}>
                                <ShuffleIcon className="w-6 h-6" />
                            </button>
                            <button onClick={prevTrack} className="p-4 text-white hover:scale-110 transition-transform active:scale-95">
                                <SkipPreviousIcon className="w-9 h-9" />
                            </button>
                            <button onClick={togglePlay} className="w-20 h-20 bg-white rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg shadow-white/10 active:scale-95" style={{ color: 'var(--theme-color)' }}>
                                {isPlaying ? <PauseFilledIcon className="w-10 h-10" /> : <PlayFilledIcon className="w-10 h-10 ml-1" />}
                            </button>
                            <button onClick={nextTrack} className="p-4 text-white hover:scale-110 transition-transform active:scale-95">
                                <SkipNextIcon className="w-9 h-9" />
                            </button>
                            <button onClick={toggleRepeat} className={`p-3 rounded-full transition-colors ${repeatMode !== 'off' ? '' : 'text-gray-500 hover:text-white'}`} style={repeatMode !== 'off' ? { color: 'var(--theme-color)' } : {}}>
                                <RepeatIcon mode={repeatMode} className="w-6 h-6" />
                            </button>
                        </div>
                    </>
                ) : (
                    /* Playlist View */
                    <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-2">
                        {queue.map((track, index) => (
                            <div 
                                key={`${track.id}-${index}`} 
                                onClick={() => playTrack(track)}
                                className={`flex items-center gap-4 p-3 rounded-xl cursor-pointer transition-all ${currentTrack.id === track.id ? 'border bg-white/5' : 'hover:bg-white/5 border border-transparent'}`}
                                style={currentTrack.id === track.id ? { borderColor: 'var(--theme-color)' } : {}}
                            >
                                <div className="w-12 h-12 rounded-lg bg-gray-800 flex items-center justify-center flex-shrink-0 overflow-hidden">
                                     {track.artwork ? <img src={track.artwork} className="w-full h-full object-cover"/> : <span className="text-xs text-gray-400">♪</span>}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className={`font-semibold truncate ${currentTrack.id === track.id ? '' : 'text-white'}`} style={currentTrack.id === track.id ? { color: 'var(--theme-color)' } : {}}>{track.title}</p>
                                    <p className="text-xs text-gray-400 truncate">{track.artist}</p>
                                </div>
                                {currentTrack.id === track.id && isPlaying && (
                                    <div className="flex gap-1 h-4 items-end">
                                        <div className="w-1 animate-[bounce_1s_infinite] h-full" style={{ backgroundColor: 'var(--theme-color)' }}></div>
                                        <div className="w-1 animate-[bounce_1.2s_infinite] h-2/3" style={{ backgroundColor: 'var(--theme-color)' }}></div>
                                        <div className="w-1 animate-[bounce_0.8s_infinite] h-full" style={{ backgroundColor: 'var(--theme-color)' }}></div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
             {/* Close Button */}
             <div className="absolute top-6 right-6 md:hidden z-10">
                 <button onClick={closePlayer} className="text-white/50 hover:text-red-400 p-2"><CloseIcon className="w-6 h-6" /></button>
             </div>
        </div>
    );
};

// 2. Context Menu for Playlist Tracks
const TrackContextMenu: React.FC<{ track: AudioTrack; x: number; y: number; onClose: () => void }> = ({ track, x, y, onClose }) => {
    const { setIsPlaylistOpen } = useAudioPlayer();

    const handleFindInChat = () => {
        window.dispatchEvent(new CustomEvent('locate-audio-message', { detail: { messageId: track.id } }));
        setIsPlaylistOpen(false);
        onClose();
    };

    const handleShare = () => {
        if (navigator.share) {
            navigator.share({
                title: 'Shared Audio',
                text: `Check out this audio message from ${track.artist}`,
                url: track.url
            }).catch(console.error);
        } else {
            navigator.clipboard.writeText(track.url);
            alert('Link copied to clipboard');
        }
        onClose();
    };

    const handleDownload = () => {
        const link = document.createElement('a');
        link.href = track.url;
        link.download = `audio_${track.id}.mp3`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        onClose();
    };

    // Adjust position to keep in viewport
    const adjustedY = y + 150 > window.innerHeight ? y - 150 : y;
    
    return (
        <>
            <div className="fixed inset-0 z-[110]" onClick={onClose} />
            <div 
                className="fixed z-[120] bg-[#1e1931]/95 backdrop-blur-md border border-white/10 rounded-xl shadow-2xl p-1 min-w-[160px] animate-fade-in-up"
                style={{ top: adjustedY, left: Math.min(x, window.innerWidth - 170) }}
            >
                <button onClick={handleFindInChat} className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/10 rounded-lg flex items-center gap-3">
                    <SearchIcon className="w-4 h-4 text-gray-400" /> Find in Chat
                </button>
                <button onClick={handleShare} className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/10 rounded-lg flex items-center gap-3">
                    <ShareIcon className="w-4 h-4 text-gray-400" /> Share
                </button>
                <button onClick={handleDownload} className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/10 rounded-lg flex items-center gap-3">
                    <DownloadIcon className="w-4 h-4 text-gray-400" /> Download
                </button>
            </div>
        </>
    );
};

// 3. Playlist Bottom Sheet (Telegram Style)
export const PlaylistBottomSheet: React.FC<{ isOpen: boolean, onClose: () => void, onExpand: () => void }> = ({ isOpen, onClose, onExpand }) => {
    const { currentTrack, isPlaying, togglePlay, nextTrack, prevTrack, queue, playTrack, currentTime, duration, repeatMode, toggleRepeat } = useAudioPlayer();
    const [translateY, setTranslateY] = useState(0);
    const [isDragging, setIsDragging] = useState(false);
    const [contextMenu, setContextMenu] = useState<{ track: AudioTrack, x: number, y: number } | null>(null);
    const [shouldRender, setShouldRender] = useState(isOpen);
    const startY = useRef(0);
    const sheetRef = useRef<HTMLDivElement>(null);

    // Manage mounting/unmounting based on isOpen
    useEffect(() => {
        if (isOpen) {
            setShouldRender(true);
            setTranslateY(0);
        } else {
            const timer = setTimeout(() => setShouldRender(false), 300); // Wait for animation
            return () => clearTimeout(timer);
        }
    }, [isOpen]);

    const handleTouchStart = (e: React.TouchEvent) => {
        // Prevent dragging if context menu is open
        if (contextMenu) return;
        setIsDragging(true);
        startY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const deltaY = e.touches[0].clientY - startY.current;
        setTranslateY(deltaY);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (translateY < -50) {
            onExpand();
            onClose(); 
        } else if (translateY > 100) {
            onClose();
        } else {
            setTranslateY(0);
        }
    };

    const handleContextMenu = (e: React.MouseEvent | React.TouchEvent, track: AudioTrack) => {
        e.preventDefault();
        const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
        const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
        setContextMenu({ track, x: clientX, y: clientY });
    };

    if (!currentTrack || !shouldRender) return null;

    return (
        <>
            {/* Backdrop */}
            <div 
                className={`absolute inset-0 bg-black/60 backdrop-blur-sm z-[90] transition-opacity duration-300 ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
                onClick={onClose}
            />
            
            {/* Sheet */}
            <div 
                ref={sheetRef}
                className={`absolute bottom-0 left-0 right-0 bg-[#111] rounded-t-[2rem] z-[100] transition-all duration-300 ease-out border-t border-white/10 shadow-2xl flex flex-col max-h-[85vh] ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-full'}`}
                style={{ 
                    transform: isOpen ? `translateY(${translateY > 0 ? translateY : 0}px)` : 'translateY(100%)'
                }}
            >
                {/* Drag Handle */}
                <div 
                    className="w-full h-8 flex items-center justify-center cursor-grab active:cursor-grabbing bg-transparent flex-shrink-0"
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="w-12 h-1.5 bg-gray-600 rounded-full opacity-50"></div>
                </div>

                {/* Current Track Header Area */}
                <div className="px-6 pb-6 flex-shrink-0">
                     <div className="flex items-center gap-4 mb-4">
                        <div className="w-16 h-16 rounded-xl bg-gray-800 overflow-hidden flex-shrink-0 shadow-lg">
                            {currentTrack.artwork ? <img src={currentTrack.artwork} className="w-full h-full object-cover"/> : <div className="w-full h-full bg-gradient-to-br from-purple-600 to-blue-600"></div>}
                        </div>
                        <div className="flex-1 min-w-0">
                             <h3 className="text-lg font-bold text-white truncate">{currentTrack.title}</h3>
                             <p className="truncate" style={{ color: 'var(--theme-color)' }}>{currentTrack.artist}</p>
                        </div>
                        <button onClick={onClose} className="p-2 text-gray-500 hover:text-white">
                            <CloseIcon className="w-6 h-6"/>
                        </button>
                     </div>
                     
                     {/* Progress Bar */}
                     <div className="mb-4">
                        <div className="h-1 bg-gray-800 rounded-full overflow-hidden relative">
                            <div className="absolute top-0 left-0 h-full transition-all duration-100" style={{ width: `${(currentTime/duration)*100}%`, backgroundColor: 'var(--theme-color)' }}></div>
                        </div>
                         <div className="flex justify-between text-[10px] text-gray-400 mt-1 font-mono">
                            <span>{formatTime(currentTime)}</span>
                            <span>{formatTime(duration)}</span>
                        </div>
                     </div>

                     {/* Main Controls */}
                     <div className="flex items-center justify-between px-4">
                         <button onClick={toggleRepeat} className={`text-gray-400 ${repeatMode !== 'off' ? '' : ''}`} style={repeatMode !== 'off' ? { color: 'var(--theme-color)' } : {}}><RepeatIcon mode={repeatMode} className="w-5 h-5"/></button>
                         <button onClick={prevTrack} className="text-white"><SkipPreviousIcon className="w-8 h-8"/></button>
                         <button onClick={togglePlay} className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-black shadow-lg">
                            {isPlaying ? <PauseFilledIcon className="w-6 h-6"/> : <PlayFilledIcon className="w-6 h-6 ml-0.5"/>}
                         </button>
                         <button onClick={nextTrack} className="text-white"><SkipNextIcon className="w-8 h-8"/></button>
                         <button className="text-gray-400"><VolumeUpIcon className="w-5 h-5"/></button>
                     </div>
                </div>

                {/* List Header */}
                <div className="px-6 py-2 text-xs font-bold text-gray-500 uppercase tracking-widest border-t border-white/5 bg-[#151517]">
                    Audio in this Chat
                </div>

                {/* Scrollable List */}
                <div className="flex-1 overflow-y-auto p-2 pb-8 custom-scrollbar bg-[#111]">
                    {queue.map((track) => (
                        <div 
                            key={track.id} 
                            onClick={() => playTrack(track)}
                            onContextMenu={(e) => handleContextMenu(e, track)}
                            className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer mb-1 transition-all ${currentTrack.id === track.id ? 'bg-[#1e1e24]' : 'hover:bg-white/5'}`}
                        >
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${currentTrack.id === track.id ? 'text-white' : 'bg-white/10'}`} style={currentTrack.id === track.id ? { backgroundColor: 'var(--theme-color)' } : { color: 'var(--theme-color)' }}>
                                 {currentTrack.id === track.id && isPlaying ? (
                                     <PauseFilledIcon className="w-4 h-4" />
                                 ) : (
                                     <PlayFilledIcon className="w-4 h-4 ml-0.5" />
                                 )}
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className={`font-medium truncate ${currentTrack.id === track.id ? 'text-white' : 'text-gray-200'}`}>{track.title}</p>
                                <p className="text-xs text-gray-500 truncate">{track.artist}</p>
                            </div>
                            <span className="text-xs text-gray-500 font-mono">{formatTime(track.duration)}</span>
                        </div>
                    ))}
                     {/* Spacer for bottom safe area */}
                    <div className="h-6"></div>
                </div>
            </div>
            
            {contextMenu && (
                <TrackContextMenu 
                    track={contextMenu.track} 
                    x={contextMenu.x} 
                    y={contextMenu.y} 
                    onClose={() => setContextMenu(null)} 
                />
            )}
        </>
    )
};

// 4. Chat Header Mini Player (Updated)
export const ChatHeaderMiniPlayer: React.FC<{ activeContextId?: number }> = () => {
    const { currentTrack, isPlaying, togglePlay, closePlayer, togglePlaylist } = useAudioPlayer();
    
    if (!currentTrack) return null;

    return (
        <div className="relative z-20 bg-black/30 backdrop-blur-xl border-b border-white/10 px-4 py-2 animate-slide-in-from-top-right shadow-lg">
                <div className="flex items-center justify-between">
                <div 
                    className="flex items-center gap-3 flex-1 cursor-pointer min-w-0 group" 
                    onClick={togglePlaylist}
                >
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 shadow-md group-active:scale-95 transition-transform" style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' }}>
                        {isPlaying ? (
                                <div className="flex gap-0.5 h-3 items-end">
                                    <div className="w-1 bg-white animate-[bounce_1s_infinite] h-full"></div>
                                    <div className="w-1 bg-white animate-[bounce_1.5s_infinite] h-2/3"></div>
                                    <div className="w-1 bg-white animate-[bounce_0.8s_infinite] h-full"></div>
                                </div>
                        ) : <PlayFilledIcon className="w-4 h-4 text-white" />}
                    </div>
                    <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-white truncate">{currentTrack.title}</p>
                        <p className="text-xs truncate opacity-80" style={{ color: 'var(--theme-color)' }}>{currentTrack.artist}</p>
                    </div>
                </div>

                <div className="flex items-center gap-2 ml-2">
                        <button onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors">
                        {isPlaying ? <PauseFilledIcon className="w-4 h-4" /> : <PlayFilledIcon className="w-4 h-4 ml-0.5" />}
                    </button>
                        <button onClick={(e) => { e.stopPropagation(); closePlayer(); }} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-colors">
                        <CloseIcon className="w-4 h-4" />
                    </button>
                </div>
            </div>
        </div>
    );
};


// 5. Global Mini Player (Overlay for non-chat pages)
export const GlobalAudioPlayer: React.FC<{ hide: boolean }> = ({ hide }) => {
    const { currentTrack, isPlaying, togglePlay, expandPlayer, closePlayer } = useAudioPlayer();

    if (!currentTrack || hide) return null;

    return (
        <div 
            className="fixed top-4 right-4 md:right-auto md:left-1/2 md:-translate-x-1/2 z-[150] w-[calc(100%-32px)] md:w-96 bg-black/60 backdrop-blur-xl border border-white/10 rounded-full p-2 shadow-2xl flex items-center gap-3 animate-fade-in-up cursor-pointer transition-all hover:bg-black/80 hover:scale-[1.02]"
            onClick={expandPlayer}
        >
             <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 animate-[spin_10s_linear_infinite]" style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))', animationPlayState: isPlaying ? 'running' : 'paused' }}>
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
             </div>
             
             <div className="flex-1 min-w-0 flex flex-col justify-center h-full px-1">
                 <p className="text-sm font-bold text-white truncate">{currentTrack.title}</p>
                 <p className="text-xs text-gray-400 truncate">{currentTrack.artist}</p>
             </div>

             <div className="flex items-center gap-2 pr-2">
                 <button onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="w-8 h-8 flex items-center justify-center bg-white text-black rounded-full hover:bg-gray-200 transition-colors">
                    {isPlaying ? <PauseFilledIcon className="w-4 h-4" /> : <PlayFilledIcon className="w-4 h-4 ml-0.5" />}
                 </button>
                  <button onClick={(e) => { e.stopPropagation(); closePlayer(); }} className="p-1.5 text-gray-500 hover:text-red-400 transition-colors">
                    <CloseIcon className="w-5 h-5" />
                </button>
             </div>
        </div>
    );
};
