
import React from 'react';
import { BookmarkIcon } from './icons';

interface SavedMessagesItemProps {
    isSelected: boolean;
    onClick: () => void;
    lastMessage?: string;
    displayTime?: string;
}

const SavedMessagesItem: React.FC<SavedMessagesItemProps> = ({ isSelected, onClick, lastMessage, displayTime }) => {
    return (
        <div 
            className="relative flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-all select-none group overflow-hidden mb-1"
            style={{
                backgroundColor: isSelected ? 'color-mix(in srgb, var(--theme-color), transparent 80%)' : 'transparent',
                borderColor: isSelected ? 'color-mix(in srgb, var(--theme-color), transparent 70%)' : 'transparent',
                borderWidth: '1px'
            }}
            onClick={onClick}
        >
            <div className="relative flex-shrink-0">
                <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center shadow-lg ring-2 ring-transparent group-hover:ring-white/10 transition-all"
                    style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' }}
                >
                    <div className="p-1.5 bg-white/20 rounded-full backdrop-blur-sm">
                        <BookmarkIcon className="w-5 h-5 text-white" />
                    </div>
                </div>
            </div>
            
            <div className="flex-1 min-w-0 flex flex-col justify-center gap-0.5">
                <div className="flex justify-between items-center">
                    <h4 className="font-bold text-white truncate text-[15px]">Saved Messages</h4>
                    {displayTime && <span className="text-[11px] text-gray-500 flex-shrink-0 font-medium">{displayTime}</span>}
                </div>
                
                <div className="flex justify-between items-center mt-0.5">
                    <div className="text-sm truncate pr-2 text-gray-400">
                        {lastMessage || <span className="opacity-60">Forward messages here to save them</span>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SavedMessagesItem;
