
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { 
    SpinnerIcon, FilmIcon, DownloadIcon, TrashIcon, CloseIcon, 
    MagicWandIcon, ImageIcon, PlusIcon, PlayIcon, SettingsIcon, 
    LayoutGridIcon, ClockIcon, CheckIcon, SparklesIcon, VideoCameraIcon
} from './icons';

interface HistoryVideo {
    id: string;
    src: string;
    prompt: string;
    aspectRatio: '16:9' | '9:16';
    timestamp: number;
}

const aspectRatios = [
    { value: "16:9", label: "Landscape", icon: "▭" },
    { value: "9:16", label: "Portrait", icon: "▯" },
];

const resolutions = [
    { value: "720p", label: "HD (720p)" },
    { value: "1080p", label: "FHD (1080p)" },
];

const styles = [
    { id: 'cinematic', label: 'Cinematic', prompt: ', cinematic lighting, highly detailed, dramatic atmosphere, 8k resolution, photorealistic, depth of field, movie still' },
    { id: 'anime', label: 'Anime', prompt: ', anime style, studio ghibli, vibrant colors, detailed background, high quality, 2d animation' },
    { id: '3d', label: '3D Animation', prompt: ', 3d render, unreal engine 5, pixar style, cute, character design, soft lighting' },
    { id: 'cyberpunk', label: 'Cyberpunk', prompt: ', cyberpunk, neon lights, futuristic, high tech, night city, glowing, synthwave, blade runner style' },
    { id: 'nature', label: 'Nature Doc', prompt: ', national geographic, wildlife photography, hyperrealistic, 8k, highly detailed, natural lighting' },
    { id: 'vintage', label: 'Vintage', prompt: ', vintage film look, grain, 1980s style, vhs glitch, retro aesthetic, warm tones' },
];

const loadingTips = [
    "Directing the scene...",
    "Calculating light rays...",
    "Rendering pixels...",
    "Composing the soundtrack...",
    "Applying color grading...",
    "Finalizing the cut...",
];

const VideoStudio: React.FC = () => {
    // State
    const [prompt, setPrompt] = useState('');
    const [enhancedPrompt, setEnhancedPrompt] = useState(''); // Store enhanced version separately or replace
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
    const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
    const [selectedStyle, setSelectedStyle] = useState(styles[0]);
    const [startImage, setStartImage] = useState<File | null>(null);
    const [startImagePreview, setStartImagePreview] = useState<string | null>(null);
    
    const [isLoading, setIsLoading] = useState(false);
    const [isEnhancing, setIsEnhancing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);
    
    const [videoHistory, setVideoHistory] = useState<HistoryVideo[]>([]);
    const [viewingVideo, setViewingVideo] = useState<HistoryVideo | null>(null);
    const [loadingTip, setLoadingTip] = useState(loadingTips[0]);
    const [hasKey, setHasKey] = useState(false);
    const [mobileTab, setMobileTab] = useState<'create' | 'library'>('create');

    const fileInputRef = useRef<HTMLInputElement>(null);

    // Load History & Check Key
    useEffect(() => {
        checkApiKey();
        try {
            const savedHistory = localStorage.getItem('videoStudioHistory');
            if (savedHistory) {
                setVideoHistory(JSON.parse(savedHistory));
            }
        } catch (e) {
            console.error("Failed to load video history", e);
        }
    }, []);
    
    // Tip Rotation
    useEffect(() => {
        let interval: number;
        if (isLoading) {
            setLoadingTip(loadingTips[0]);
            let i = 0;
            interval = window.setInterval(() => {
                i = (i + 1) % loadingTips.length;
                setLoadingTip(loadingTips[i]);
            }, 3500);
        }
        return () => window.clearInterval(interval);
    }, [isLoading]);

    const checkApiKey = async () => {
        const aistudio = (window as any).aistudio;
        if (aistudio) {
            const has = await aistudio.hasSelectedApiKey();
            setHasKey(has);
        }
    };

    const handleConnectKey = async () => {
        const aistudio = (window as any).aistudio;
        if (aistudio) {
            await aistudio.openSelectKey();
            setTimeout(checkApiKey, 1000); 
        }
    };

    const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setStartImage(file);
            const url = URL.createObjectURL(file);
            setStartImagePreview(url);
        }
    };

    const clearImage = () => {
        setStartImage(null);
        setStartImagePreview(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleEnhancePrompt = async () => {
        if (!prompt.trim()) return;
        setIsEnhancing(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Rewrite this video generation prompt to be more descriptive and visual. Keep it under 3 sentences. Prompt: "${prompt}"`,
            });
            if (response.text) {
                setPrompt(response.text.trim());
            }
        } catch (e) {
            console.error("Enhance failed", e);
        } finally {
            setIsEnhancing(false);
        }
    };

    const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
        const base64EncodedDataPromise = new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(file);
        });
        return {
            inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
        };
    };

    const handleGenerate = async () => {
        if (!hasKey) {
            await handleConnectKey();
            return;
        }
        if (!prompt.trim() && !startImage) {
            setError('Please enter a prompt or upload an image.');
            return;
        }
        
        setIsLoading(true);
        setError(null);
        setGeneratedVideo(null);

        const fullPrompt = `${prompt}${selectedStyle.prompt}`;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            let imagePart;
            if (startImage) {
                const part = await fileToGenerativePart(startImage);
                imagePart = {
                    imageBytes: part.inlineData.data,
                    mimeType: part.inlineData.mimeType
                };
            }

            // Config construction
            const config: any = {
                numberOfVideos: 1,
                resolution: resolution,
                aspectRatio: aspectRatio
            };

            // API Call
            let operation = await ai.models.generateVideos({
                model: 'veo-3.1-fast-generate-preview',
                prompt: fullPrompt,
                image: imagePart, // Can be undefined, SDK handles it
                config: config
            });

            // Polling
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 5000));
                operation = await ai.operations.getVideosOperation({operation: operation});
            }

            const generatedVideoData = operation.response?.generatedVideos?.[0];
            
            if (generatedVideoData?.video?.uri) {
                 const downloadLink = generatedVideoData.video.uri;
                 const res = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                 if (!res.ok) throw new Error('Failed to fetch video content');
                 const blob = await res.blob();
                 const videoUrl = URL.createObjectURL(blob);
                 
                 setGeneratedVideo(videoUrl);
                 
                 const newHistoryItem: HistoryVideo = {
                    id: `${Date.now()}-${Math.random()}`,
                    src: videoUrl,
                    prompt: prompt,
                    aspectRatio: aspectRatio,
                    timestamp: Date.now(),
                };
                
                setVideoHistory(prevHistory => {
                    const updatedHistory = [newHistoryItem, ...prevHistory].slice(0, 20);
                    localStorage.setItem('videoStudioHistory', JSON.stringify(updatedHistory));
                    return updatedHistory;
                });

                // Switch to library view on mobile after generation
                if (window.innerWidth < 768) {
                    // optional: could stay on create to show result
                }

            } else {
                throw new Error('No video URI returned.');
            }
        } catch (e) {
            console.error(e);
            let friendlyError = "Generation failed. Please try again.";
            const errorMessage = e instanceof Error ? e.message : String(e);
             if (errorMessage.includes('Requested entity was not found')) {
                friendlyError = "API Key session expired. Please reconnect.";
                setHasKey(false);
            } else if (errorMessage.includes('SAFETY')) {
                friendlyError = "Safety violation detected. Please modify your prompt.";
            }
            setError(friendlyError);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDeleteHistory = (id: string) => {
        const updatedHistory = videoHistory.filter(item => item.id !== id);
        setVideoHistory(updatedHistory);
        localStorage.setItem('videoStudioHistory', JSON.stringify(updatedHistory));
        if (viewingVideo?.id === id) setViewingVideo(null);
    };

    // --- Components ---

    const VideoPreview = ({ src, aspectRatio }: { src: string, aspectRatio: string }) => (
        <div className="relative w-full rounded-2xl overflow-hidden shadow-2xl ring-1 ring-white/10 bg-black">
            <video 
                src={src} 
                controls 
                autoPlay 
                loop
                className="w-full h-full object-contain max-h-[60vh]"
                style={{ aspectRatio: aspectRatio.replace(':', '/') }}
            />
        </div>
    );

    return (
        <div className="h-full flex flex-col text-white bg-[#0f0f0f] relative overflow-hidden">
            {/* Theme Background Glows */}
            <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full blur-[120px] opacity-20 pointer-events-none" style={{ background: 'var(--theme-color)' }}></div>
            <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full blur-[150px] opacity-10 pointer-events-none bg-blue-600"></div>

            {/* Header */}
            <header className="flex-shrink-0 px-4 md:px-8 py-4 border-b border-white/5 bg-black/20 backdrop-blur-md flex justify-between items-center z-20">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shadow-lg shadow-[var(--theme-color)]/20" style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' }}>
                        <FilmIcon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-lg md:text-xl font-bold text-white leading-none tracking-tight">Veo Studio</h1>
                        <p className="text-[10px] md:text-xs text-gray-400 mt-1 font-medium">Generative Video AI</p>
                    </div>
                </div>
                {!hasKey && (
                    <button onClick={handleConnectKey} className="bg-yellow-500/10 text-yellow-400 border border-yellow-500/30 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-yellow-500/20 transition-colors flex items-center gap-2 animate-pulse">
                        <SettingsIcon className="w-3.5 h-3.5"/> Connect Key
                    </button>
                )}
            </header>

            {/* Main Content */}
            <div className="flex-1 flex flex-col lg:flex-row min-h-0 relative z-10">
                
                {/* LEFT PANEL: Controls */}
                <div className={`
                    flex-1 lg:w-[450px] lg:flex-none flex flex-col border-r border-white/5 bg-[#121214]/60 backdrop-blur-xl transition-transform duration-300
                    ${mobileTab === 'create' ? 'flex' : 'hidden lg:flex'}
                `}>
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-6 space-y-6">
                        
                        {/* Image Input Section */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-1 flex items-center gap-2">
                                <ImageIcon className="w-3 h-3" /> Image to Video (Optional)
                            </label>
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className={`
                                    relative w-full h-32 rounded-2xl border-2 border-dashed transition-all cursor-pointer overflow-hidden group
                                    ${startImagePreview 
                                        ? 'border-[var(--theme-color)] bg-black/40' 
                                        : 'border-white/10 hover:border-white/20 bg-white/5 hover:bg-white/10'
                                    }
                                `}
                            >
                                {startImagePreview ? (
                                    <>
                                        <img src={startImagePreview} alt="Start frame" className="w-full h-full object-contain" />
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); clearImage(); }}
                                            className="absolute top-2 right-2 p-1.5 bg-black/60 text-white rounded-full hover:bg-red-500 transition-colors"
                                        >
                                            <CloseIcon className="w-4 h-4" />
                                        </button>
                                        <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-1 rounded-md text-[10px] text-white font-bold">
                                            Start Frame
                                        </div>
                                    </>
                                ) : (
                                    <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 group-hover:text-gray-300">
                                        <PlusIcon className="w-8 h-8 mb-2 opacity-50" />
                                        <span className="text-xs font-medium">Upload Image</span>
                                    </div>
                                )}
                                <input type="file" ref={fileInputRef} onChange={handleImageSelect} accept="image/*" className="hidden" />
                            </div>
                        </div>

                        {/* Prompt Section */}
                        <div className="space-y-2">
                            <div className="flex justify-between items-center">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-1 flex items-center gap-2">
                                    <MagicWandIcon className="w-3 h-3" /> Prompt
                                </label>
                                <button 
                                    onClick={handleEnhancePrompt} 
                                    disabled={isEnhancing || !prompt}
                                    className="text-[10px] font-bold px-2 py-1 rounded-md border transition-colors flex items-center gap-1 disabled:opacity-50"
                                    style={{ color: 'var(--theme-color)', borderColor: 'color-mix(in srgb, var(--theme-color), transparent 80%)', backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 95%)' }}
                                >
                                    <SparklesIcon className={`w-3 h-3 ${isEnhancing ? 'animate-spin' : ''}`} /> 
                                    {isEnhancing ? 'Enhancing...' : 'Enhance'}
                                </button>
                            </div>
                            <textarea
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="Describe your video in detail... e.g. A cyberpunk city street at night with rain falling and neon signs reflecting in puddles."
                                className="w-full bg-black/30 border border-white/10 rounded-2xl p-4 text-sm text-white placeholder-gray-600 focus:outline-none focus:ring-1 focus:ring-[var(--theme-color)] focus:border-[var(--theme-color)] transition-all resize-none h-32 shadow-inner"
                            />
                        </div>

                        {/* Config Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {/* Aspect Ratio */}
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-1">Aspect Ratio</label>
                                <div className="flex gap-2">
                                    {aspectRatios.map(ar => (
                                        <button
                                            key={ar.value}
                                            onClick={() => setAspectRatio(ar.value as any)}
                                            className={`flex-1 py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${aspectRatio === ar.value ? 'text-white shadow-md' : 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10'}`}
                                            style={aspectRatio === ar.value ? { backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 85%)', borderColor: 'var(--theme-color)', color: 'var(--theme-color)' } : {}}
                                        >
                                            <span className="text-sm opacity-80">{ar.icon}</span> {ar.label}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Resolution */}
                            <div className="space-y-2">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-1">Resolution</label>
                                <div className="flex bg-black/30 p-1 rounded-xl border border-white/5">
                                    {resolutions.map(res => (
                                        <button
                                            key={res.value}
                                            onClick={() => setResolution(res.value as any)}
                                            className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all ${resolution === res.value ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                                        >
                                            {res.label}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Style Presets */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-1">Visual Style</label>
                            <div className="grid grid-cols-2 gap-2">
                                {styles.map(style => (
                                    <button
                                        key={style.id}
                                        onClick={() => setSelectedStyle(style)}
                                        className={`text-left px-3 py-2.5 rounded-xl text-xs font-medium border transition-all ${selectedStyle.id === style.id ? 'text-white shadow-sm' : 'bg-white/5 border-transparent text-gray-400 hover:bg-white/10'}`}
                                        style={selectedStyle.id === style.id ? { borderColor: 'var(--theme-color)', backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 90%)' } : {}}
                                    >
                                        {style.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {error && (
                            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs font-medium animate-fade-in flex items-start gap-2">
                                <div className="mt-0.5 min-w-[4px] h-4 bg-red-500 rounded-full"></div>
                                {error}
                            </div>
                        )}
                        
                        <div className="h-4"></div>
                    </div>

                    {/* Footer Button */}
                    <div className="p-4 md:p-6 border-t border-white/5 bg-[#121214]/80 backdrop-blur-md sticky bottom-0 z-10">
                        <button
                            onClick={handleGenerate}
                            disabled={isLoading || (!prompt && !startImage)}
                            className="w-full py-4 rounded-2xl text-white font-bold text-sm shadow-lg hover:shadow-xl transition-all transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 group"
                            style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' }}
                        >
                            {isLoading ? (
                                <>
                                    <SpinnerIcon className="w-5 h-5 animate-spin" />
                                    <span>Generating...</span>
                                </>
                            ) : (
                                <>
                                    <FilmIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                                    <span>Generate Video</span>
                                </>
                            )}
                        </button>
                        {isLoading && <p className="text-[10px] text-center text-gray-500 mt-3 animate-pulse">{loadingTip}</p>}
                    </div>
                </div>

                {/* RIGHT PANEL: Preview & Library */}
                <div className={`
                    flex-1 flex flex-col bg-[#050505] relative
                    ${mobileTab === 'library' ? 'flex' : 'hidden lg:flex'}
                `}>
                    {/* Current Result Display */}
                    {(generatedVideo || isLoading) && (
                        <div className="flex-1 flex flex-col items-center justify-center p-6 relative min-h-[300px] border-b border-white/5">
                            {isLoading ? (
                                <div className="text-center">
                                    <div className="w-24 h-24 rounded-full border-4 border-white/5 border-t-[var(--theme-color)] animate-spin mx-auto mb-6"></div>
                                    <h3 className="text-2xl font-bold text-white mb-2">Creating Scene</h3>
                                    <p className="text-gray-500 text-sm">This usually takes 1-2 minutes.</p>
                                </div>
                            ) : generatedVideo ? (
                                <div className="w-full max-w-4xl animate-fade-in-up">
                                    <VideoPreview src={generatedVideo} aspectRatio={aspectRatio} />
                                    <div className="flex justify-center gap-4 mt-6">
                                        <a href={generatedVideo} download="video.mp4" className="px-6 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold text-xs transition-colors flex items-center gap-2">
                                            <DownloadIcon className="w-4 h-4"/> Download
                                        </a>
                                        <button onClick={() => setGeneratedVideo(null)} className="px-6 py-2.5 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-xl font-bold text-xs transition-colors">
                                            Clear Preview
                                        </button>
                                    </div>
                                </div>
                            ) : null}
                        </div>
                    )}

                    {/* History Grid */}
                    <div className="flex-1 bg-[#0a0a0a] flex flex-col min-h-0">
                        <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center sticky top-0 bg-[#0a0a0a]/90 backdrop-blur-md z-10">
                            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                                <LayoutGridIcon className="w-4 h-4" /> Library
                            </h3>
                            <span className="text-[10px] bg-white/5 text-gray-500 px-2 py-0.5 rounded-full">{videoHistory.length} Videos</span>
                        </div>
                        
                        {videoHistory.length === 0 ? (
                            <div className="flex-1 flex flex-col items-center justify-center text-gray-600 opacity-60 p-8 text-center">
                                <VideoCameraIcon className="w-12 h-12 mb-3" />
                                <p className="text-sm font-medium">Your generated videos will appear here.</p>
                            </div>
                        ) : (
                            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4 overflow-y-auto custom-scrollbar">
                                {videoHistory.map(item => (
                                    <div 
                                        key={item.id} 
                                        className="group relative aspect-video bg-black rounded-xl overflow-hidden cursor-pointer border border-white/5 hover:border-[var(--theme-color)] transition-all hover:shadow-lg hover:shadow-[var(--theme-color)]/10"
                                        onClick={() => setViewingVideo(item)}
                                    >
                                        <video src={item.src} className="w-full h-full object-cover" muted loop onMouseOver={e => e.currentTarget.play()} onMouseOut={e => e.currentTarget.pause()} />
                                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <PlayIcon className="w-8 h-8 text-white" />
                                        </div>
                                        <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-white/80 pointer-events-none">
                                            {item.aspectRatio}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Mobile Tab Bar */}
            <div className="lg:hidden flex border-t border-white/10 bg-[#121214] sticky bottom-0 z-30 safe-area-bottom">
                <button 
                    onClick={() => setMobileTab('create')}
                    className={`flex-1 py-4 flex flex-col items-center gap-1 transition-colors ${mobileTab === 'create' ? 'text-white' : 'text-gray-500'}`}
                >
                    <div style={mobileTab === 'create' ? { color: 'var(--theme-color)' } : {}}>
                        <MagicWandIcon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wide">Create</span>
                </button>
                <button 
                    onClick={() => setMobileTab('library')}
                    className={`flex-1 py-4 flex flex-col items-center gap-1 transition-colors ${mobileTab === 'library' ? 'text-white' : 'text-gray-500'}`}
                >
                    <div style={mobileTab === 'library' ? { color: 'var(--theme-color)' } : {}}>
                        <LayoutGridIcon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wide">Library</span>
                </button>
            </div>

            {/* Detail Modal */}
            {viewingVideo && (
                <div className="fixed inset-0 z-[150] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 animate-fade-in" onClick={() => setViewingVideo(null)}>
                    <div className="bg-[#18181b] w-full max-w-4xl rounded-3xl overflow-hidden border border-white/10 shadow-2xl flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                        <div className="flex-1 bg-black flex items-center justify-center p-4">
                            <video 
                                src={viewingVideo.src} 
                                controls 
                                autoPlay 
                                className="max-w-full max-h-[60vh] rounded-lg shadow-2xl"
                                style={{ aspectRatio: viewingVideo.aspectRatio.replace(':', '/') }}
                            />
                        </div>
                        <div className="p-6 bg-[#18181b] border-t border-white/5">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h3 className="font-bold text-white text-sm uppercase tracking-wide mb-1" style={{ color: 'var(--theme-color)' }}>Prompt</h3>
                                    <p className="text-sm text-gray-300 leading-relaxed line-clamp-3">{viewingVideo.prompt}</p>
                                </div>
                                <button onClick={() => setViewingVideo(null)} className="p-2 bg-white/5 hover:bg-white/10 rounded-full text-white"><CloseIcon className="w-5 h-5"/></button>
                            </div>
                            <div className="flex gap-3">
                                <a href={viewingVideo.src} download={`video-${viewingVideo.timestamp}.mp4`} className="flex-1 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors">
                                    <DownloadIcon className="w-4 h-4"/> Download
                                </a>
                                <button onClick={() => { handleDeleteHistory(viewingVideo.id); setViewingVideo(null); }} className="px-4 py-3 bg-red-500/10 hover:bg-red-500/20 rounded-xl text-red-400 font-bold text-xs transition-colors">
                                    <TrashIcon className="w-4 h-4"/>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default VideoStudio;
