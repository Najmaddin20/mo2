
import React from 'react';
import type { Notification } from '../types';
import { UserAddIcon, CheckIcon, XIcon, CalendarIcon, VideoCameraIcon, BellIcon, AtSymbolIcon, TrashIcon, DoubleCheckIcon } from './icons';

interface NotificationsPanelProps {
    notifications: Notification[];
    onClose: () => void;
    onMarkAsRead: (id: number) => void;
    onMarkAllAsRead: () => void;
    onClearAll: () => void;
    onFriendRequestAction: (notificationId: number, action: 'accept' | 'decline') => void;
}

const getTypeStyles = (type: Notification['type']) => {
    switch (type) {
        case 'friend-request':
            return { icon: UserAddIcon };
        case 'mention':
            return { icon: AtSymbolIcon };
        case 'event-reminder':
            return { icon: CalendarIcon };
        case 'room-invite':
            return { icon: VideoCameraIcon };
        default:
            return { icon: BellIcon };
    }
};

const NotificationItem: React.FC<{ notification: Notification; onMarkAsRead: (id: number) => void; onFriendRequestAction: (notificationId: number, action: 'accept' | 'decline') => void; }> = ({ notification, onMarkAsRead, onFriendRequestAction }) => {
    
    const handleItemClick = () => {
        if (!notification.isRead) {
            onMarkAsRead(notification.id);
        }
    }

    const { icon: Icon } = getTypeStyles(notification.type);

    return (
        <div 
            onClick={handleItemClick} 
            className={`group relative flex gap-4 p-4 rounded-2xl transition-all duration-200 cursor-pointer border border-transparent hover:border-white/5 ${!notification.isRead ? 'bg-white/[0.03]' : 'hover:bg-white/[0.02]'}`}
        >
            {/* Unread Indicator Dot */}
            {!notification.isRead && (
                <div className="absolute left-1 top-1/2 -translate-y-1/2 w-1 h-8 bg-[var(--theme-color)] rounded-r-full shadow-[0_0_10px_var(--theme-color)]"></div>
            )}

            <div className="flex-shrink-0 pt-1">
                {notification.user ? (
                    <div className="relative">
                        <img src={notification.user.avatar} className="w-12 h-12 rounded-full object-cover border-2 border-[#18181b] shadow-lg" alt="" />
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center bg-[#18181b] border-2 border-[#18181b]">
                            <div className="w-full h-full rounded-full flex items-center justify-center bg-[var(--theme-color)] text-white">
                                <Icon className="w-3 h-3" />
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-[var(--theme-color)] bg-opacity-20 border border-[var(--theme-color)] border-opacity-20 text-[var(--theme-color)]">
                        <Icon className="w-6 h-6" />
                    </div>
                )}
            </div>

            <div className="flex-1 min-w-0 flex flex-col justify-center">
                <div className="flex flex-col gap-0.5">
                    <p className="text-sm leading-snug text-gray-300">
                        {notification.user && (
                            <span className="font-bold text-[var(--theme-color)] mr-1.5 text-[15px]">
                                {notification.user.name}
                            </span>
                        )}
                        <span className={notification.user ? "" : "font-medium text-white"}>
                            {notification.message}
                        </span>
                    </p>
                    <span className="text-[11px] text-gray-500 font-medium">{notification.timestamp}</span>
                </div>

                {notification.type === 'friend-request' && (
                    <div className="flex gap-2 mt-3 animate-fade-in">
                        <button 
                            onClick={(e) => { e.stopPropagation(); onFriendRequestAction(notification.id, 'accept'); }} 
                            className="px-4 py-1.5 rounded-lg bg-[var(--theme-color)] text-white text-xs font-bold transition-all hover:opacity-90 shadow-lg shadow-[var(--theme-color)]/20 flex items-center gap-1.5 active:scale-95"
                        >
                            <CheckIcon className="w-3 h-3" /> Accept
                        </button>
                        <button 
                            onClick={(e) => { e.stopPropagation(); onFriendRequestAction(notification.id, 'decline'); }} 
                            className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white text-xs font-bold transition-all border border-white/10 active:scale-95"
                        >
                            Decline
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

const NotificationsPanel: React.FC<NotificationsPanelProps> = ({ notifications, onClose, onMarkAsRead, onMarkAllAsRead, onClearAll, onFriendRequestAction }) => {
    const newNotifications = notifications.filter(n => !n.isRead);
    const earlierNotifications = notifications.filter(n => n.isRead);

    return (
        <div className="absolute top-full right-0 mt-4 w-96 bg-[#050505]/95 backdrop-blur-3xl border border-white/10 rounded-[2rem] shadow-2xl flex flex-col max-h-[75vh] animate-slide-in-from-top-right z-50 overflow-hidden ring-1 ring-white/5">
            
            {/* Header */}
            <header className="flex-shrink-0 px-6 py-5 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
                <div className="flex items-center gap-3">
                    <h3 className="text-lg font-bold text-white tracking-tight">Notifications</h3>
                    {newNotifications.length > 0 && (
                        <span className="bg-[var(--theme-color)] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm shadow-[var(--theme-color)]/20">
                            {newNotifications.length} New
                        </span>
                    )}
                </div>
                <div className="flex items-center gap-1">
                    <button onClick={onMarkAllAsRead} className="p-2 text-gray-500 hover:text-[var(--theme-color)] hover:bg-[var(--theme-color)]/10 rounded-full transition-colors" title="Mark all read">
                        <DoubleCheckIcon className="w-4 h-4" />
                    </button>
                    <button onClick={onClearAll} className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-full transition-colors" title="Clear all">
                        <TrashIcon className="w-4 h-4" />
                    </button>
                </div>
            </header>
            
            {/* List */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
                {notifications.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-64 text-center px-8 opacity-50">
                        <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4">
                            <BellIcon className="w-8 h-8 text-gray-600" />
                        </div>
                        <p className="font-bold text-gray-300 text-base">All caught up!</p>
                        <p className="text-xs text-gray-600 mt-1">No new notifications at the moment.</p>
                    </div>
                ) : (
                    <>
                        {newNotifications.length > 0 && (
                            <div className="animate-fade-in-up">
                                <h4 className="px-4 py-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest opacity-60">New</h4>
                                <div className="space-y-1">
                                    {newNotifications.map(n => <NotificationItem key={n.id} notification={n} onMarkAsRead={onMarkAsRead} onFriendRequestAction={onFriendRequestAction}/>)}
                                </div>
                            </div>
                        )}
                        
                        {earlierNotifications.length > 0 && (
                            <div className="animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
                                <h4 className="px-4 py-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest opacity-60">Earlier</h4>
                                <div className="space-y-1">
                                    {earlierNotifications.map(n => <NotificationItem key={n.id} notification={n} onMarkAsRead={onMarkAsRead} onFriendRequestAction={onFriendRequestAction}/>)}
                                </div>
                            </div>
                        )}
                        <div className="h-4"></div>
                    </>
                )}
            </div>
        </div>
    );
};

export default NotificationsPanel;
