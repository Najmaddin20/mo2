
import React from 'react';

export const WorldMap: React.FC<{ className?: string }> = ({ className }) => (
  <div className={className}>
    <img 
        src="https://upload.wikimedia.org/wikipedia/commons/0/03/BlankMap-World6.svg" 
        alt="World Map" 
        className="w-full h-full object-fill"
        style={{ 
            filter: 'invert(1) hue-rotate(180deg) brightness(1.5) opacity(0.3)',
            pointerEvents: 'none' 
        }} 
        draggable="false"
    />
  </div>
);
