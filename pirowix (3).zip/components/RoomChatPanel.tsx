
import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { Room, User, ChatMessage, RoomUser } from '../types';
import { SendIcon, CloseIcon, AttachmentIcon, EmojiIcon, MicrophoneIcon, ReplyIcon, PinIcon, ForwardIcon, TrashIcon, CopyIcon, DownloadIcon, PlayIcon, TranslateIcon } from './icons';
import VoiceMessageRecorder from './VoiceMessageRecorder';
import AudioPlayer from './AudioPlayer';
import JumpToLatestButton from './JumpToLatestButton';
import EventMessage from './EventMessage';
import { GoogleGenAI } from "@google/genai";

const getReplyPreviewText = (message: ChatMessage): string => {
    const textToTruncate = message.message || message.caption;
    if (textToTruncate) {
        const maxLength = 50;
        const cleanedText = textToTruncate.replace(/\s+/g, ' ').trim();
        if (cleanedText.length > maxLength) {
            return cleanedText.substring(0, maxLength) + '...';
        }
        return cleanedText;
    }
    if (message.voiceMessage) return "🎤 Voice Message";
    if (message.imageUrl) return "🖼️ Image";
    if (message.videoUrl) return "🎬 Video";
    return "Attachment";
};

interface RoomChatPanelProps {
    room: Room;
    currentUser: User;
    onUpdateRoom: (room: Room) => void;
    onViewProfile: (user: User) => void;
    onForward: (message: ChatMessage) => void;
}

// --- Components ---

const ContextMenu: React.FC<{
    contextMenu: { message: ChatMessage, x: number, y: number },
    currentUser: User,
    isPinned: boolean,
    onClose: () => void,
    onReply: () => void,
    onDelete: () => void,
    onPin: () => void,
    onCopy: () => void,
    onForward: () => void,
    onTranslate: () => void,
    canModerate: boolean
}> = ({ contextMenu, currentUser, isPinned, onClose, onReply, onDelete, onPin, onCopy, onForward, onTranslate, canModerate }) => {
    const menuRef = useRef<HTMLDivElement>(null);
    const { message, x, y } = contextMenu;
    const isSentByMe = message.user.id === currentUser.id;
    const canDelete = isSentByMe || canModerate;
    const hasText = !!(message.message || message.caption);

    // Adjust position smart logic
    const [position, setPosition] = useState({ top: y, left: x });

    useEffect(() => {
        if (menuRef.current) {
            const rect = menuRef.current.getBoundingClientRect();
            const screenW = window.innerWidth;
            const screenH = window.innerHeight;
            
            let newLeft = x;
            let newTop = y;

            if (x + rect.width > screenW) newLeft = screenW - rect.width - 16;
            if (y + rect.height > screenH) newTop = screenH - rect.height - 16;
            
            // Mobile adjustment: center horizontally if screen is small
            if (screenW < 640) {
                newLeft = (screenW - rect.width) / 2;
            }

            setPosition({ top: newTop, left: newLeft });
        }
    }, [x, y]);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(e.target as Node)) onClose();
        };
        // We attach to window to ensure we catch clicks anywhere, even inside other portals
        window.addEventListener('mousedown', handleClickOutside);
        return () => {
            window.removeEventListener('mousedown', handleClickOutside);
        };
    }, [onClose]);

    const MenuItem = ({ icon, label, onClick, danger = false }: any) => (
        <button 
            onClick={() => { onClick(); onClose(); }} 
            className={`flex items-center gap-3 w-full px-4 py-3 text-sm transition-all hover:bg-white/10 ${danger ? 'text-red-400' : 'text-white'}`}
        >
            <span className="opacity-70">{icon}</span> <span className="font-medium">{label}</span>
        </button>
    );

    return createPortal(
        <div className="fixed inset-0 z-[9999]" style={{ pointerEvents: 'auto' }}>
            <div className="fixed inset-0 bg-black/10 backdrop-blur-[1px]" onClick={onClose}></div>
            <div 
                ref={menuRef}
                className="fixed w-56 bg-[#18181b]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up ring-1 ring-white/5 transform origin-top-left"
                style={{ top: position.top, left: position.left }}
            >
                <div className="px-4 py-2 bg-white/5 border-b border-white/5 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                    Message Options
                </div>
                <MenuItem icon={<ReplyIcon className="w-4 h-4" />} label="Reply" onClick={onReply} />
                <MenuItem icon={<CopyIcon className="w-4 h-4" />} label="Copy Text" onClick={onCopy} />
                {hasText && <MenuItem icon={<TranslateIcon className="w-4 h-4" />} label="Translate" onClick={onTranslate} />}
                <MenuItem icon={<PinIcon className="w-4 h-4" />} label={isPinned ? "Unpin" : "Pin"} onClick={onPin} />
                <MenuItem icon={<ForwardIcon className="w-4 h-4" />} label="Forward" onClick={onForward} />
                {canDelete && (
                    <>
                        <div className="h-px bg-white/10 mx-4 my-1" />
                        <MenuItem icon={<TrashIcon className="w-4 h-4" />} label="Delete" onClick={onDelete} danger />
                    </>
                )}
            </div>
        </div>,
        document.body
    );
};

const ChatMessageItem = React.forwardRef<HTMLDivElement, {
    message: ChatMessage;
    isSentByCurrentUser: boolean;
    isGroupStart: boolean;
    isGroupEnd: boolean;
    onContextMenu: (e: React.MouseEvent | React.TouchEvent, msg: ChatMessage) => void;
    onViewProfile: (user: User) => void;
    usersInRoom: RoomUser[];
    isPinned: boolean;
    onReplyRequest: (msg: ChatMessage) => void;
    onReplyClick: (id: number) => void;
    translation?: string;
}>(({ message, isSentByCurrentUser, isGroupStart, isGroupEnd, onContextMenu, onViewProfile, usersInRoom, isPinned, onReplyRequest, onReplyClick, translation }, ref) => {
    
    const senderRole = usersInRoom.find(u => u.id === message.user.id)?.role;
    const [isLongPress, setIsLongPress] = useState(false);
    const longPressTimer = useRef<number | undefined>(undefined);

    const roleBadge = senderRole === 'host' ? (
        <span className="ml-2 px-1.5 py-px bg-gradient-to-r from-orange-500 to-red-500 text-white text-[8px] font-bold rounded-sm uppercase tracking-wider shadow-sm">HOST</span>
    ) : senderRole === 'moderator' ? (
        <span className="ml-2 px-1.5 py-px bg-blue-600 text-white text-[8px] font-bold rounded-sm uppercase tracking-wider shadow-sm">MOD</span>
    ) : null;

    const handleMentionClick = (userName: string) => {
        const user = usersInRoom.find(u => u.name === userName);
        if (user) onViewProfile(user);
    };

    const renderText = (text: string) => {
        const parts = text.split(/(@\w+)/g);
        return parts.map((part, i) => {
            if (part.startsWith('@')) {
                return <span key={i} onClick={(e) => { e.stopPropagation(); handleMentionClick(part.substring(1)); }} className="text-[var(--theme-color)] font-bold hover:underline cursor-pointer bg-white/10 rounded px-1">{part}</span>;
            }
            return part;
        });
    };

    const bubbleClasses = isSentByCurrentUser
        ? `rounded-2xl rounded-tr-sm bg-[var(--theme-color)] text-white shadow-lg shadow-[var(--theme-color)]/20`
        : `rounded-2xl rounded-tl-sm bg-white/10 backdrop-blur-md border border-white/10 text-gray-100 shadow-sm`;

    const handleTouchStart = (e: React.TouchEvent) => {
        setIsLongPress(false);
        longPressTimer.current = window.setTimeout(() => {
            setIsLongPress(true);
            onContextMenu(e, message);
        }, 500);
    };

    const handleTouchEnd = () => {
        if (longPressTimer.current) clearTimeout(longPressTimer.current);
    };

    return (
        <div 
            ref={ref} 
            className={`group relative flex gap-2 px-3 py-0.5 ${isSentByCurrentUser ? 'flex-row-reverse' : ''} ${isPinned ? 'bg-yellow-500/5 -mx-3 px-6' : ''} transition-all w-full`}
            onContextMenu={(e) => onContextMenu(e, message)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            onTouchMove={handleTouchEnd}
        >
            {/* Avatar */}
            {!isSentByCurrentUser ? (
                <div className="w-8 flex-shrink-0 flex flex-col justify-end pb-1">
                    {isGroupEnd ? (
                        <img 
                            src={message.user.avatar} 
                            alt={message.user.name} 
                            className="w-8 h-8 rounded-full cursor-pointer object-cover shadow-md ring-2 ring-white/10 hover:ring-white/30 transition-all"
                            onClick={() => onViewProfile(message.user)}
                        />
                    ) : <div className="w-8" />}
                </div>
            ) : null}

            <div className={`flex flex-col max-w-[85%] ${isSentByCurrentUser ? 'items-end' : 'items-start'}`}>
                {/* Sender Name */}
                {!isSentByCurrentUser && isGroupStart && (
                    <div className="flex items-center mb-1 ml-1 mt-1 select-none">
                        <span 
                            className="text-[10px] font-bold text-gray-400 hover:text-white cursor-pointer transition-colors"
                            onClick={() => onViewProfile(message.user)}
                        >
                            {message.user.name}
                        </span>
                        {roleBadge}
                    </div>
                )}

                <div className={`relative px-3.5 py-2.5 text-sm leading-relaxed ${bubbleClasses}`}>
                    {/* Reply Context */}
                    {message.replyTo && (
                        <div 
                            className={`mb-1.5 text-xs p-1.5 rounded-lg bg-black/20 border-l-2 ${isSentByCurrentUser ? 'border-white/50' : 'border-[var(--theme-color)]'} cursor-pointer hover:bg-black/30 transition-colors`}
                            onClick={(e) => { 
                                e.stopPropagation();
                                if (message.replyTo) onReplyClick(message.replyTo.id); 
                            }}
                        >
                            <span className="font-bold block opacity-90 text-[10px] mb-0.5">{message.replyTo.user.name}</span>
                            <span className="truncate block opacity-75 text-[10px]">{getReplyPreviewText(message.replyTo)}</span>
                        </div>
                    )}

                    {/* Media */}
                    {message.imageUrl && <img src={message.imageUrl} alt="Attachment" className="rounded-xl max-h-48 w-full object-cover mb-2 shadow-sm bg-black/20" />}
                    {message.videoUrl && (
                        <div className="relative rounded-xl overflow-hidden mb-2 bg-black shadow-sm">
                            <video src={message.videoUrl} className="max-h-48 w-full object-contain" controls />
                        </div>
                    )}

                    {/* Text */}
                    {message.message && <p className="whitespace-pre-wrap break-words">{renderText(message.message)}</p>}
                    
                    {translation && (
                        <div className="mt-2 pt-2 border-t border-white/10 text-xs italic opacity-90">
                            <div className="flex items-center gap-1 mb-1 text-[10px] uppercase font-bold tracking-wider opacity-70">
                                <TranslateIcon className="w-3 h-3" /> Translated
                            </div>
                            {translation}
                        </div>
                    )}
                    
                    {/* Audio */}
                    {message.voiceMessage && (
                        <AudioPlayer 
                            src={message.voiceMessage.url} 
                            duration={message.voiceMessage.duration}
                            waveform={message.voiceMessage.waveform}
                            isSent={isSentByCurrentUser}
                        />
                    )}

                    {/* Timestamp */}
                    <div className={`flex items-center justify-end gap-1 mt-1 select-none opacity-60 text-[9px] font-medium`}>
                        <span>{message.timestamp}</span>
                        {isPinned && <PinIcon className="w-2 h-2"/>}
                    </div>
                </div>
            </div>

            {/* Quick Action (Desktop) */}
            <div className={`invisible group-hover:visible flex items-center self-center opacity-0 group-hover:opacity-100 transition-all duration-200 ${isSentByCurrentUser ? 'mr-1 flex-row-reverse' : 'ml-1'}`}>
                 <button 
                    onClick={() => onReplyRequest(message)}
                    className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white backdrop-blur-md border border-white/5 shadow-sm transition-transform hover:scale-110"
                    title="Reply"
                 >
                     <ReplyIcon className="w-3 h-3" />
                 </button>
            </div>
        </div>
    );
});

const RoomChatPanel: React.FC<RoomChatPanelProps> = ({ room, currentUser, onUpdateRoom, onViewProfile, onForward }) => {
    const [text, setText] = useState('');
    const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
    const [isRecording, setIsRecording] = useState(false);
    const [contextMenu, setContextMenu] = useState<{ message: ChatMessage, x: number, y: number } | null>(null);
    const [showScrollButton, setShowScrollButton] = useState(false);
    const [newMessages, setNewMessages] = useState(0);
    const [translations, setTranslations] = useState<Record<number, string>>({});
    
    const scrollRef = useRef<HTMLDivElement>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const messageRefs = useRef<Map<number, HTMLDivElement>>(new Map());
    
    const currentUserRole = room.users.find(u => u.id === currentUser.id)?.role;
    const canModerate = currentUserRole === 'host' || currentUserRole === 'moderator';
    const pinnedMessage = (room.chatMessages || []).find(m => m.id === room.pinnedMessageId);

    const scrollToMessage = (id: number) => {
        const el = messageRefs.current.get(id);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Highlight effect
            el.style.transition = 'background-color 0.3s';
            const originalBg = el.style.backgroundColor;
            el.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
            setTimeout(() => {
                el.style.backgroundColor = originalBg;
            }, 1000);
        }
    };

    // Scroll Logic
    const scrollToBottom = (smooth = true) => {
        messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
        setNewMessages(0);
    };

    useEffect(() => {
        scrollToBottom(false);
    }, []);

    useEffect(() => {
        const lastMessage = room.chatMessages?.[room.chatMessages.length - 1];
        if (lastMessage && lastMessage.user.id === currentUser.id) {
            scrollToBottom();
        } else if (scrollRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
            const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
            if (isNearBottom) {
                scrollToBottom();
            } else {
                setNewMessages(prev => prev + 1);
            }
        }
    }, [room.chatMessages, currentUser.id]);

    const handleScroll = () => {
        if (scrollRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
            const isNearBottom = scrollHeight - scrollTop - clientHeight < 150;
            setShowScrollButton(!isNearBottom);
            if (isNearBottom) setNewMessages(0);
        }
    };

    const handleSend = () => {
        if (!text.trim()) return;
        
        const newMessage: ChatMessage = {
            id: Date.now(),
            user: currentUser,
            message: text.trim(),
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
            replyTo: replyingTo || undefined,
            type: 'user'
        };
        
        onUpdateRoom({ 
            ...room, 
            chatMessages: [...(room.chatMessages || []), newMessage] 
        });
        
        setText('');
        setReplyingTo(null);
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.focus();
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const handleContextMenu = (e: React.MouseEvent | React.TouchEvent, message: ChatMessage) => {
        e.preventDefault();
        if ('stopPropagation' in e) e.stopPropagation();
        
        const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
        const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
        setContextMenu({ message, x: clientX, y: clientY });
    };

    const handleTranslate = async (message: ChatMessage) => {
        if (!message.message && !message.caption) return;
        const textToTranslate = message.message || message.caption || "";
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Translate the following text to Persian (Farsi). Only return the translated text. Text: "${textToTranslate}"`,
            });
            if (response.text) {
                setTranslations(prev => ({ ...prev, [message.id]: response.text }));
            }
        } catch (e) {
            console.error("Translation failed", e);
        }
    };

    const handleAction = (action: 'reply' | 'copy' | 'pin' | 'delete' | 'forward' | 'translate') => {
        if (!contextMenu) return;
        const { message } = contextMenu;
        
        switch (action) {
            case 'reply':
                setReplyingTo(message);
                textareaRef.current?.focus();
                break;
            case 'copy':
                navigator.clipboard.writeText(message.message || '');
                break;
            case 'pin':
                onUpdateRoom({ ...room, pinnedMessageId: room.pinnedMessageId === message.id ? undefined : message.id });
                break;
            case 'delete':
                const newMessages = (room.chatMessages || []).filter(m => m.id !== message.id);
                const newPinnedId = room.pinnedMessageId === message.id ? undefined : room.pinnedMessageId;
                onUpdateRoom({ ...room, chatMessages: newMessages, pinnedMessageId: newPinnedId });
                break;
             case 'forward':
                onForward(message);
                break;
             case 'translate':
                handleTranslate(message);
                break;
        }
        setContextMenu(null);
    };

    const handleSendVoice = (blobUrl: string, duration: number, waveform: number[]) => {
        const voiceMsg: ChatMessage = {
            id: Date.now(),
            user: currentUser,
            message: '',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
            voiceMessage: { url: blobUrl, duration, waveform },
            type: 'user',
            replyTo: replyingTo || undefined
        };
         onUpdateRoom({ 
            ...room, 
            chatMessages: [...(room.chatMessages || []), voiceMsg] 
        });
        setIsRecording(false);
        setReplyingTo(null);
    };

    return (
        <div className="flex flex-col h-full relative bg-transparent overflow-hidden">
            
            {/* Pinned Message Banner */}
            {pinnedMessage && (
                <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between bg-black/40 border-b border-white/5 px-4 py-2 backdrop-blur-lg cursor-pointer hover:bg-black/60 transition-all shadow-md" onClick={() => scrollToMessage(pinnedMessage.id)}>
                    <div className="flex items-center gap-3 overflow-hidden">
                        <div className="w-0.5 h-8 bg-[var(--theme-color)] rounded-full flex-shrink-0 shadow-[0_0_10px_var(--theme-color)]"></div>
                        <div className="flex flex-col min-w-0">
                            <span className="text-[9px] font-bold text-[var(--theme-color)] uppercase tracking-wider flex items-center gap-1">
                                <PinIcon className="w-3 h-3" /> Pinned
                            </span>
                            <span className="text-xs text-white font-medium truncate">{getReplyPreviewText(pinnedMessage)}</span>
                        </div>
                    </div>
                    {canModerate && (
                        <button onClick={(e) => { e.stopPropagation(); onUpdateRoom({ ...room, pinnedMessageId: undefined }); }} className="p-1.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors">
                            <CloseIcon className="w-3 h-3" />
                        </button>
                    )}
                </div>
            )}

            {/* Messages List */}
            <div 
                ref={scrollRef}
                className={`flex-1 overflow-y-auto custom-scrollbar ${pinnedMessage ? 'pt-14' : 'pt-2'} px-2 pb-24`}
                onScroll={handleScroll}
            >
                <div className="flex flex-col justify-end min-h-full space-y-1">
                    <div className="flex-1"></div>
                    
                    {(room.chatMessages || []).map((msg, index, arr) => {
                        if (msg.type === 'event') {
                            return <EventMessage key={msg.id} message={msg} />;
                        }
                        
                        const prevMsg = arr[index - 1];
                        const nextMsg = arr[index + 1];
                        const isPrevSameUser = prevMsg?.type === 'user' && prevMsg.user.id === msg.user.id;
                        const isNextSameUser = nextMsg?.type === 'user' && nextMsg.user.id === msg.user.id;
                        const isGroupStart = !isPrevSameUser || (prevMsg?.type === 'event'); 
                        const isGroupEnd = !isNextSameUser || (nextMsg?.type === 'event');

                        return (
                            <ChatMessageItem
                                key={msg.id}
                                ref={(el) => { if(el) messageRefs.current.set(msg.id, el); }}
                                message={msg}
                                isSentByCurrentUser={msg.user.id === currentUser.id}
                                isGroupStart={isGroupStart}
                                isGroupEnd={isGroupEnd}
                                onContextMenu={handleContextMenu}
                                onViewProfile={onViewProfile}
                                usersInRoom={room.users}
                                isPinned={room.pinnedMessageId === msg.id}
                                onReplyRequest={(m) => { setReplyingTo(m); textareaRef.current?.focus(); }}
                                onReplyClick={scrollToMessage}
                                translation={translations[msg.id]}
                            />
                        );
                    })}
                    <div ref={messagesEndRef} />
                </div>
            </div>

            {/* Fixed Glass Footer Input */}
            <div className="absolute bottom-0 left-0 right-0 z-30 flex flex-col justify-end pointer-events-none">
                {/* Gradient fade behind input */}
                <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black via-black/50 to-transparent pointer-events-none"></div>

                <div className="p-3 relative z-10 flex flex-col gap-2">
                    
                    {/* Jump Button Positioned Above Input */}
                    <div className={`flex justify-end transition-all duration-300 transform ${showScrollButton ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
                        <JumpToLatestButton 
                            isVisible={true} 
                            newMessagesCount={newMessages} 
                            onClick={() => scrollToBottom(true)} 
                            className="shadow-xl bg-black/60 hover:bg-black/80 border border-white/10 backdrop-blur-xl !p-2.5"
                        />
                    </div>

                    {/* Unified Input Capsule */}
                    <div className="flex flex-col bg-black/40 backdrop-blur-2xl border border-white/10 shadow-2xl transition-all duration-300 rounded-2xl overflow-hidden ring-1 ring-white/5 pointer-events-auto">
                        
                        {/* Integrated Reply Preview (Inside the capsule) */}
                        {replyingTo && (
                            <div 
                                className="flex items-center justify-between bg-white/5 border-b border-white/5 p-2 px-3 animate-slide-in-up cursor-pointer hover:bg-white/10 transition-colors"
                                onClick={() => scrollToMessage(replyingTo.id)}
                            >
                                <div className="flex items-center gap-3 min-w-0">
                                    <div className="w-0.5 h-6 bg-[var(--theme-color)] rounded-full"></div>
                                    <div className="flex flex-col min-w-0">
                                        <span className="text-[10px] font-bold text-[var(--theme-color)]">Replying to {replyingTo.user.name}</span>
                                        <span className="text-xs text-gray-300 truncate max-w-[200px] sm:max-w-xs">{getReplyPreviewText(replyingTo)}</span>
                                    </div>
                                </div>
                                <button onClick={(e) => { e.stopPropagation(); setReplyingTo(null); }} className="p-1 hover:bg-white/10 rounded-full text-gray-400 hover:text-white transition-colors">
                                    <CloseIcon className="w-4 h-4" />
                                </button>
                            </div>
                        )}

                        {/* Input Row */}
                        <div className="flex items-end gap-2 p-1.5">
                            <button className="p-2.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors flex-shrink-0">
                                <AttachmentIcon className="w-5 h-5" />
                            </button>

                            <div className="flex-1 py-2">
                                <textarea
                                    ref={textareaRef}
                                    value={text}
                                    onChange={(e) => {
                                        setText(e.target.value);
                                        e.target.style.height = 'auto';
                                        e.target.style.height = Math.min(e.target.scrollHeight, 100) + 'px';
                                    }}
                                    onKeyDown={handleKeyDown}
                                    placeholder="Message..."
                                    rows={1}
                                    className="w-full bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none text-[15px] max-h-[100px] min-h-[24px] leading-relaxed custom-scrollbar"
                                />
                            </div>

                            <div className="flex items-end gap-1">
                                <button className="p-2.5 text-gray-400 hover:text-yellow-400 hover:bg-white/5 rounded-full transition-colors flex-shrink-0">
                                    <EmojiIcon className="w-5 h-5" />
                                </button>

                                {text.trim() ? (
                                    <button 
                                        onClick={handleSend} 
                                        className="p-2.5 text-white rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center justify-center flex-shrink-0"
                                        style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' }}
                                    >
                                        <SendIcon className="w-5 h-5 ml-0.5" />
                                    </button>
                                ) : (
                                    <button 
                                        onClick={() => setIsRecording(true)} 
                                        className="p-2.5 bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 rounded-full flex items-center justify-center transition-all flex-shrink-0"
                                    >
                                        <MicrophoneIcon className="w-5 h-5" />
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {contextMenu && (
                <ContextMenu
                    contextMenu={contextMenu}
                    currentUser={currentUser}
                    isPinned={room.pinnedMessageId === contextMenu.message.id}
                    onClose={() => setContextMenu(null)}
                    onReply={() => handleAction('reply')}
                    onCopy={() => handleAction('copy')}
                    onPin={() => handleAction('pin')}
                    onDelete={() => handleAction('delete')}
                    onForward={() => handleAction('forward')}
                    onTranslate={() => handleAction('translate')}
                    canModerate={canModerate}
                />
            )}
            
            {isRecording && (
                <div className="absolute bottom-0 left-0 right-0 z-40 p-2 bg-black/90 backdrop-blur-2xl border-t border-white/10 pb-safe">
                    <VoiceMessageRecorder isRecording={true} onCancel={() => setIsRecording(false)} onSend={handleSendVoice} />
                </div>
            )}
        </div>
    );
};

export default RoomChatPanel;
