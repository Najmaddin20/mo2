
import React, { useState, useEffect, useRef } from 'react';
import type { VoiceRoom, User, InviteLink } from '../types';
import { 
    CloseIcon, PublicIcon, PrivateIcon, ClockIcon, 
    CrownIcon, ShieldIcon, UserAddIcon, BlockUserIcon, 
    CheckIcon, XIcon, SettingsIcon, PaletteIcon, LockClosedIcon, EyeIcon, EyeOffIcon,
    LinkIcon, CopyIcon, PlusCircleIcon, TrashIcon, CalendarIcon, PlayIcon, StopIcon
} from './icons';

interface VoiceRoomSettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    room: VoiceRoom;
    onUpdateSettings: (settings: Partial<Pick<VoiceRoom, 'isPrivate' | 'password' | 'topic' | 'topics' | 'timer' | 'openMicMode' | 'inviteLinks'>>) => void;
    onUpdateTheme: (theme: VoiceRoom['theme']) => void;
    onTransferHost: (userId: number) => void;
    onUnblockUser: (userId: number) => void;
    onAcceptRequest: (userId: number) => void;
    onDeclineRequest: (userId: number) => void;
}

const themes: { id: VoiceRoom['theme'], name: string, gradient: string, border: string, hex: string }[] = [
    { id: 'cosmic', name: 'Cosmic', gradient: 'bg-gradient-to-br from-indigo-900 to-purple-900', border: 'border-purple-500', hex: '#8b5cf6' },
    { id: 'sunset', name: 'Sunset', gradient: 'bg-gradient-to-br from-orange-700 to-red-800', border: 'border-orange-500', hex: '#f97316' },
    { id: 'forest', name: 'Forest', gradient: 'bg-gradient-to-br from-green-800 to-teal-900', border: 'border-green-500', hex: '#10b981' },
    { id: 'ocean', name: 'Ocean', gradient: 'bg-gradient-to-br from-blue-800 to-cyan-900', border: 'border-blue-500', hex: '#3b82f6' },
    { id: 'midnight', name: 'Midnight', gradient: 'bg-gradient-to-br from-slate-900 to-indigo-950', border: 'border-indigo-500', hex: '#6366f1' },
    { id: 'rose', name: 'Rose', gradient: 'bg-gradient-to-br from-rose-800 to-pink-900', border: 'border-pink-500', hex: '#f43f5e' },
    { id: 'amber', name: 'Amber', gradient: 'bg-gradient-to-br from-amber-700 to-yellow-900', border: 'border-amber-500', hex: '#f59e0b' },
];

type Tab = 'general' | 'security' | 'theme' | 'invites' | 'moderation';

const VoiceRoomSettingsModal: React.FC<VoiceRoomSettingsModalProps> = ({ 
    isOpen, onClose, room, onUpdateSettings, onUpdateTheme, 
    onUnblockUser, onTransferHost, onAcceptRequest, onDeclineRequest 
}) => {
    const [activeTab, setActiveTab] = useState<Tab>('general');
    const [topic, setTopic] = useState(room.topic);
    const [isPrivate, setIsPrivate] = useState(room.isPrivate || false);
    const [password, setPassword] = useState(room.password || '');
    const [showPassword, setShowPassword] = useState(false);
    
    // Tag State
    const [tagsList, setTagsList] = useState<string[]>(room.topics || []);
    const [tagInput, setTagInput] = useState('');

    const [theme, setTheme] = useState<VoiceRoom['theme']>(room.theme || 'cosmic');
    const [openMicMode, setOpenMicMode] = useState(room.openMicMode || false);
    const [transferTarget, setTransferTarget] = useState<number | null>(null);
    const [showTransferConfirm, setShowTransferConfirm] = useState(false);
    
    // Timer State for Setup
    const [startTimerOnSave, setStartTimerOnSave] = useState(false);
    const [newTimerDuration, setNewTimerDuration] = useState(15);

    // Mobile Sheet State
    const [isMobileExpanded, setIsMobileExpanded] = useState(false);
    const [startY, setStartY] = useState<number | null>(null);
    const sheetRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            setTopic(room.topic);
            setIsPrivate(room.isPrivate || false);
            setPassword(room.password || '');
            setTagsList(room.topics || []);
            setTagInput('');
            setTheme(room.theme || 'cosmic');
            setOpenMicMode(room.openMicMode || false);
            setTransferTarget(null);
            setShowTransferConfirm(false);
            setStartTimerOnSave(false); // Reset timer toggle
            setActiveTab('general');
            setIsMobileExpanded(false);
        }
    }, [room, isOpen]);

    const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const trimmed = tagInput.trim();
            if (trimmed && !tagsList.includes(trimmed)) {
                setTagsList([...tagsList, trimmed]);
                setTagInput('');
            }
        } else if (e.key === 'Backspace' && !tagInput && tagsList.length > 0) {
            setTagsList(tagsList.slice(0, -1));
        }
    };

    const removeTag = (tagToRemove: string) => {
        setTagsList(tagsList.filter(tag => tag !== tagToRemove));
    };

    const handleThemeSelect = (newTheme: VoiceRoom['theme']) => {
        setTheme(newTheme);
        onUpdateTheme(newTheme);
    };

    const handleSave = () => {
        const updates: Partial<Pick<VoiceRoom, 'isPrivate' | 'password' | 'topic' | 'topics' | 'timer' | 'openMicMode' | 'inviteLinks'>> = { 
            isPrivate, 
            topic,
            password: isPrivate && password ? password : undefined,
            topics: tagsList,
            openMicMode,
        };

        // Apply timer only if toggle is ON and no active timer exists (or overwriting)
        if (startTimerOnSave) {
            updates.timer = { endsAt: Date.now() + newTimerDuration * 60 * 1000 };
        }

        onUpdateSettings(updates);
        onClose();
    };

    const handleConfirmTransfer = () => {
        if (transferTarget) {
            onTransferHost(transferTarget);
            onClose();
        }
        setShowTransferConfirm(false);
    };

    // Active Timer Actions (Immediate)
    const handleCancelTimer = () => {
        onUpdateSettings({ timer: undefined });
    };

    const handleExtendTimer = () => {
        if (room.timer) {
            // Add 15 minutes to the existing end time
            onUpdateSettings({ timer: { endsAt: room.timer.endsAt + 15 * 60 * 1000 } });
        }
    };

    // Password Strength
    const getPasswordStrength = (pass: string) => {
        if (!pass) return 0;
        let score = 0;
        if (pass.length > 4) score += 25;
        if (pass.length > 7) score += 25;
        if (/[0-9]/.test(pass)) score += 25;
        if (/[^A-Za-z0-9]/.test(pass)) score += 25;
        return score;
    };

    const strength = getPasswordStrength(password);
    
    const getStrengthColor = (s: number) => {
        if (s <= 25) return 'bg-red-500';
        if (s <= 50) return 'bg-orange-500';
        if (s <= 75) return 'bg-yellow-500';
        return 'bg-green-500';
    };

    const getStrengthLabel = (s: number) => {
        if (s === 0) return '';
        if (s <= 25) return 'Weak';
        if (s <= 50) return 'Medium';
        if (s <= 75) return 'Good';
        return 'Strong';
    };

    // --- Link Logic ---
    const createLink = (type: 'one-time' | 'public') => {
        const mockCreator = room.speakers.find(s => s.role === 'host') || room.speakers[0];
        
        const newLink: InviteLink = {
            id: Date.now().toString(),
            code: Math.random().toString(36).substring(2, 8).toUpperCase(),
            type,
            createdBy: mockCreator,
            usedBy: [],
            createdAt: Date.now(),
            isActive: true
        };
        
        const updatedLinks = [...(room.inviteLinks || []), newLink];
        onUpdateSettings({ inviteLinks: updatedLinks });
    };

    const deleteLink = (linkId: string) => {
        const updatedLinks = (room.inviteLinks || []).filter(l => l.id !== linkId);
        onUpdateSettings({ inviteLinks: updatedLinks });
    };

    // Mobile Sheet Handlers
    const handleTouchStart = (e: React.TouchEvent) => {
        setStartY(e.touches[0].clientY);
    };

    const handleTouchEnd = (e: React.TouchEvent) => {
        if (startY === null) return;
        const deltaY = startY - e.changedTouches[0].clientY;
        
        if (deltaY > 50 && !isMobileExpanded) {
            setIsMobileExpanded(true); 
        } else if (deltaY < -50) {
            if (isMobileExpanded) {
                setIsMobileExpanded(false);
            } else {
                onClose();
            }
        }
        setStartY(null);
    };

    if (!isOpen) return null;

    const speakersToChooseFrom = room.speakers.filter(s => s.role !== 'host');
    const requests = room.joinRequests || [];
    const bannedUsers = room.blockedUsers || [];
    const currentThemeColor = themes.find(t => t.id === theme)?.hex || '#8b5cf6';

    const NavItem = ({ id, label, icon }: { id: Tab, label: string, icon: React.ReactNode }) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all duration-200 text-sm font-medium ${
                activeTab === id 
                ? 'bg-[#6C5DD3] text-white shadow-lg shadow-purple-500/20' 
                : 'text-gray-400 hover:bg-white/5 hover:text-white'
            }`}
        >
            {icon}
            <span>{label}</span>
            {id === 'moderation' && (requests.length > 0) && (
                <span className="ml-auto bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center animate-pulse">
                    {requests.length}
                </span>
            )}
        </button>
    );

    const MobileTabItem = ({ id, label, icon }: { id: Tab, label: string, icon: React.ReactNode }) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex-1 flex flex-col items-center justify-center gap-1 py-3 border-b-2 transition-all ${
                activeTab === id 
                ? 'border-white text-white' 
                : 'border-transparent text-white/50'
            }`}
        >
            <div className={activeTab === id ? 'text-white' : 'text-white/50'}>{icon}</div>
            <span className="text-[10px] font-bold uppercase tracking-wide">{label}</span>
            {id === 'moderation' && requests.length > 0 && (
                 <span className="absolute top-2 right-1/4 w-2 h-2 bg-red-500 rounded-full animate-pulse border border-[#121214]"></span>
            )}
        </button>
    );

    return (
        <>
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] md:hidden transition-opacity duration-300" onClick={onClose} />

            <div className="hidden md:flex fixed inset-0 bg-black/80 backdrop-blur-md items-center justify-center z-[100] p-4 animate-fade-in" onClick={onClose}>
                <div className="bg-[#121214] w-full h-full md:w-[850px] md:h-[600px] md:rounded-3xl shadow-2xl flex flex-col md:flex-row overflow-hidden border border-white/10 transition-all duration-300" onClick={e => e.stopPropagation()}>
                    <aside className="hidden md:flex flex-col w-64 bg-[#0f0f10] border-r border-white/5 p-6 relative">
                        <div className="mb-8">
                            <h2 className="text-xl font-bold text-white">Room Settings</h2>
                            <p className="text-xs text-gray-500 mt-1">Manage your voice space</p>
                        </div>
                        <nav className="flex-1 flex flex-col gap-2 overflow-y-auto hide-scrollbar">
                            <NavItem id="general" label="General" icon={<SettingsIcon className="w-5 h-5"/>} />
                            <NavItem id="security" label="Security" icon={<LockClosedIcon className="w-5 h-5"/>} />
                            <NavItem id="theme" label="Theme" icon={<PaletteIcon className="w-5 h-5"/>} />
                            <NavItem id="invites" label="Invites" icon={<LinkIcon className="w-5 h-5"/>} />
                            <NavItem id="moderation" label="Moderation" icon={<ShieldIcon className="w-5 h-5"/>} />
                        </nav>
                        
                        {/* Fixed Footer Buttons */}
                        <div className="mt-6 pt-4 border-t border-white/5 space-y-3">
                            <button onClick={handleSave} className="w-full py-3 rounded-xl bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] text-white font-bold text-sm shadow-lg hover:shadow-purple-500/30 transition-all transform active:scale-95">
                                Save Changes
                            </button>
                            <button onClick={onClose} className="w-full py-2 rounded-xl text-gray-500 font-bold text-xs hover:text-white transition-all">
                                Cancel
                            </button>
                        </div>
                    </aside>
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-8 bg-[#121214] h-full">
                        {renderContent()}
                    </div>
                </div>
            </div>

            <div 
                ref={sheetRef}
                className={`md:hidden fixed bottom-0 left-0 right-0 z-[101] bg-[#121214] rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)] transition-all duration-500 ease-out flex flex-col border-t border-white/10 ${isMobileExpanded ? 'h-[92vh]' : 'h-[60vh]'}`}
                style={{ background: `linear-gradient(to bottom, ${currentThemeColor}20, #121214 40%)` }}
                onClick={e => e.stopPropagation()}
            >
                <div className="w-full flex items-center justify-center pt-3 pb-1 cursor-grab active:cursor-grabbing touch-none" onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd} onClick={() => setIsMobileExpanded(!isMobileExpanded)}>
                    <div className="w-12 h-1.5 bg-white/20 rounded-full" />
                </div>
                <div className="flex justify-between items-center px-6 py-3 shrink-0">
                    <h2 className="text-lg font-bold text-white">Settings</h2>
                    <button onClick={onClose} className="p-2 bg-white/5 rounded-full text-gray-400 hover:text-white active:scale-95 transition-transform"><CloseIcon className="w-5 h-5" /></button>
                </div>
                <div className="flex border-b border-white/5 shrink-0 px-2 relative overflow-x-auto hide-scrollbar">
                    <MobileTabItem id="general" label="General" icon={<SettingsIcon className="w-5 h-5"/>} />
                    <MobileTabItem id="security" label="Security" icon={<LockClosedIcon className="w-5 h-5"/>} />
                    <MobileTabItem id="theme" label="Theme" icon={<PaletteIcon className="w-5 h-5"/>} />
                    <MobileTabItem id="invites" label="Invites" icon={<LinkIcon className="w-5 h-5"/>} />
                    <MobileTabItem id="moderation" label="Moderation" icon={<ShieldIcon className="w-5 h-5"/>} />
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar p-5 pb-24">
                    {renderContent()}
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-[#121214]/95 backdrop-blur-lg border-t border-white/10">
                    <button onClick={handleSave} className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] text-white font-bold text-base shadow-lg active:scale-95 transition-transform">
                        Save Changes
                    </button>
                </div>
            </div>
            
            {showTransferConfirm && transferTarget && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[110] flex items-center justify-center p-4" onClick={() => setShowTransferConfirm(false)}>
                    <div className="bg-zinc-900 border border-white/10 p-6 rounded-2xl space-y-4 max-w-sm shadow-2xl animate-fade-in-up" onClick={e => e.stopPropagation()}>
                        <h3 className="text-lg font-bold text-white">Confirm Host Transfer</h3>
                        <p className="text-sm text-gray-300">
                            Are you sure you want to make <span className="font-bold text-white">{speakersToChooseFrom.find(s=>s.id === transferTarget)?.name}</span> the new host?
                            <br/><br/>
                            <span className="text-red-400 text-xs">You will become a speaker and lose host privileges.</span>
                        </p>
                        <div className="flex justify-end gap-3">
                            <button onClick={() => setShowTransferConfirm(false)} className="px-4 py-2 text-sm rounded-lg bg-white/5 text-white hover:bg-white/10">Cancel</button>
                            <button onClick={handleConfirmTransfer} className="px-4 py-2 text-sm rounded-lg bg-orange-600 text-white font-bold hover:bg-orange-700 shadow-lg">Confirm Transfer</button>
                        </div>
                    </div>
                </div>
            )}
             <style>{`
                .input-style { appearance: none; border-radius: 0.75rem; position: relative; display: block; width: 100%; padding: 0.875rem 1rem; background-color: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: white; font-size: 0.875rem; transition: all 0.2s; } 
                .input-style:focus { outline: none; border-color: #6C5DD3; background-color: rgba(0,0,0,0.4); }
                .input-label { display: block; margin-bottom: 0.5rem; font-size: 0.75rem; font-weight: 700; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.05em; }
             `}</style>
        </>
    );

    function renderContent() {
        return (
            <>
                {/* General Tab */}
                {activeTab === 'general' && (
                    <div className="space-y-6 animate-fade-in">
                        <Section title="Room Details">
                            <Input label="Room Topic" value={topic} onChange={setTopic} />
                            <div>
                                <label className="input-label">Tags (Enter to add)</label>
                                <div className="w-full bg-[#1c1c1e] border border-white/10 rounded-xl px-2 py-2 flex flex-wrap items-center gap-2 focus-within:border-[#6C5DD3] transition-colors">
                                    {tagsList.map((tag, index) => (
                                        <div key={index} className="flex items-center gap-1 bg-white/10 text-white text-xs px-2 py-1 rounded-md border border-white/5 animate-fade-in">
                                            <span>{tag}</span>
                                            <button type="button" onClick={() => removeTag(tag)} className="text-gray-400 hover:text-white hover:bg-white/20 rounded-full p-0.5 transition-colors">
                                                <XIcon className="w-3 h-3" />
                                            </button>
                                        </div>
                                    ))}
                                    <input type="text" value={tagInput} onChange={(e) => setTagInput(e.target.value)} onKeyDown={handleTagKeyDown} className="flex-1 bg-transparent outline-none text-sm text-white placeholder-gray-600 min-w-[120px] py-1 px-2" placeholder={tagsList.length === 0 ? "Type tag..." : "Add another..."} />
                                </div>
                            </div>
                        </Section>

                        <Section title="Microphone Behavior">
                            <ToggleSwitch label="Open Mic Mode" description="If enabled, listeners can speak without raising their hand." enabled={openMicMode} onToggle={() => setOpenMicMode(p => !p)} />
                        </Section>

                        {speakersToChooseFrom.length > 0 && (
                            <Section title="Ownership">
                                <label className="input-label flex items-center gap-2"><CrownIcon className="w-4 h-4 text-yellow-500" /> Transfer Host</label>
                                <div className="flex gap-2 items-center bg-white/5 p-3 rounded-xl border border-white/5">
                                    <select value={transferTarget || ''} onChange={(e) => setTransferTarget(Number(e.target.value))} className="bg-transparent text-white w-full outline-none text-sm">
                                        <option value="" className="bg-[#121214]">Select a speaker...</option>
                                        {speakersToChooseFrom.map(s => <option key={s.id} value={s.id} className="bg-[#121214]">{s.name}</option>)}
                                    </select>
                                    <button onClick={() => setShowTransferConfirm(true)} disabled={!transferTarget} className="px-4 py-1.5 text-xs font-bold rounded-lg text-white bg-orange-600 hover:bg-orange-700 disabled:opacity-50 whitespace-nowrap transition-colors">
                                        Transfer
                                    </button>
                                </div>
                            </Section>
                        )}
                    </div>
                )}

                {/* Security Tab */}
                {activeTab === 'security' && (
                    <div className="space-y-6 animate-fade-in">
                        
                        <Section title="Privacy & Security">
                            <div className="flex bg-[#1c1c1e] p-1 rounded-xl border border-white/5 mb-4">
                                <VisibilityButton icon={<PublicIcon className="w-4 h-4 mr-2" />} label="Public" active={!isPrivate} onClick={() => setIsPrivate(false)} />
                                <VisibilityButton icon={<PrivateIcon className="w-4 h-4 mr-2" />} label="Private Lock" active={isPrivate} onClick={() => setIsPrivate(true)} />
                            </div>
                            
                            <div className={`transition-all duration-500 overflow-hidden ${isPrivate ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0'}`}>
                                <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-3">
                                    <label className="input-label flex justify-between">
                                        <span>Set Room Password</span>
                                        <span className={`text-[10px] font-bold uppercase ${password ? 'opacity-100' : 'opacity-0'}`}>Strength: <span className={`${password ? 'text-white' : ''}`}>{getStrengthLabel(strength)}</span></span>
                                    </label>
                                    
                                    <div className="relative">
                                        <input 
                                            type={showPassword ? "text" : "password"} 
                                            value={password} 
                                            onChange={e => setPassword(e.target.value)} 
                                            placeholder="Enter a strong password..." 
                                            className="input-style pr-10"
                                        />
                                        <button 
                                            type="button"
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white cursor-pointer transition-colors"
                                        >
                                            {showPassword ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                                        </button>
                                    </div>

                                    {/* Strength Meter */}
                                    <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden">
                                        <div className={`h-full transition-all duration-500 ease-out ${getStrengthColor(strength)}`} style={{ width: `${strength}%` }}></div>
                                    </div>
                                    
                                    <p className="text-[10px] text-gray-500">
                                        Use at least 8 characters, including numbers and symbols.
                                    </p>
                                </div>
                            </div>
                        </Section>

                        <Section title="Room Timer">
                            {room.timer ? (
                                <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                                    <div className="flex items-center justify-between mb-4">
                                        <div>
                                            <h4 className="text-white font-bold text-sm">Active Session</h4>
                                            <p className="text-[10px] text-yellow-400 mt-1 flex items-center gap-1">
                                                <ClockIcon className="w-3 h-3" /> Timer Running
                                            </p>
                                        </div>
                                        <button 
                                            onClick={handleCancelTimer}
                                            className="p-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-full transition-colors"
                                            title="Stop Timer"
                                        >
                                            <StopIcon className="w-5 h-5" />
                                        </button>
                                    </div>
                                    <button 
                                        onClick={handleExtendTimer}
                                        className="w-full py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
                                    >
                                        <PlusCircleIcon className="w-4 h-4" /> Extend (+15m)
                                    </button>
                                </div>
                            ) : (
                                <div className="bg-[#1c1c1e] p-4 rounded-2xl border border-white/5">
                                    <div className="flex items-center justify-between mb-4">
                                        <label className="input-label mb-0">Start Timer on Save</label>
                                        <div 
                                            onClick={() => setStartTimerOnSave(!startTimerOnSave)}
                                            className={`relative w-11 h-6 flex items-center rounded-full p-1 duration-300 ease-in-out cursor-pointer ${startTimerOnSave ? 'bg-[#6C5DD3]' : 'bg-gray-600'}`}
                                        >
                                            <div className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${startTimerOnSave ? 'translate-x-5' : ''}`}></div>
                                        </div>
                                    </div>
                                    
                                    <div className={`transition-all duration-300 overflow-hidden ${startTimerOnSave ? 'max-h-20 opacity-100' : 'max-h-0 opacity-50'}`}>
                                        <div className="flex-1 bg-black/30 rounded-xl px-4 py-2 flex items-center border border-white/10">
                                            <input 
                                                type="range" min="5" max="120" step="5" 
                                                value={newTimerDuration} 
                                                onChange={(e) => setNewTimerDuration(Number(e.target.value))} 
                                                className="flex-1 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#6C5DD3]"
                                            />
                                            <span className="ml-3 text-sm font-bold text-white w-10 text-right">{newTimerDuration}m</span>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </Section>
                    </div>
                )}

                {/* Theme Tab */}
                {activeTab === 'theme' && (
                    <div className="space-y-6 animate-fade-in">
                        <Section title="Room Appearance">
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                {themes.map(th => (
                                    <button 
                                        key={th.id} 
                                        onClick={() => handleThemeSelect(th.id)} 
                                        className={`relative h-24 rounded-xl overflow-hidden border-2 transition-all group ${theme === th.id ? `${th.border} shadow-lg shadow-purple-500/20 scale-105` : 'border-transparent opacity-60 hover:opacity-100'}`}
                                    >
                                        <div className={`absolute inset-0 ${th.gradient}`}></div>
                                        <span className="absolute bottom-2 left-0 right-0 text-center text-xs font-bold text-white uppercase tracking-wider">{th.name}</span>
                                        {theme === th.id && <div className="absolute top-2 right-2 bg-white text-black rounded-full p-0.5"><CheckIcon className="w-3 h-3" /></div>}
                                    </button>
                                ))}
                            </div>
                        </Section>
                    </div>
                )}

                {/* Invites Tab */}
                {activeTab === 'invites' && (
                    <div className="space-y-6 animate-fade-in">
                        <Section title="Create Invite Link">
                            <div className="grid grid-cols-2 gap-3">
                                <button onClick={() => createLink('public')} className="flex flex-col items-center justify-center p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all active:scale-95">
                                    <div className="p-2 bg-blue-500/20 text-blue-400 rounded-full mb-2"><PublicIcon className="w-5 h-5"/></div>
                                    <span className="text-xs font-bold text-white">Public Link</span>
                                    <span className="text-[10px] text-gray-500">Permanent</span>
                                </button>
                                <button onClick={() => createLink('one-time')} className="flex flex-col items-center justify-center p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all active:scale-95">
                                    <div className="p-2 bg-orange-500/20 text-orange-400 rounded-full mb-2"><PlusCircleIcon className="w-5 h-5"/></div>
                                    <span className="text-xs font-bold text-white">One-Time Link</span>
                                    <span className="text-[10px] text-gray-500">Expires after use</span>
                                </button>
                            </div>
                        </Section>

                        <Section title="Active Invites">
                            {(!room.inviteLinks || room.inviteLinks.length === 0) ? (
                                <div className="text-center text-gray-500 text-xs py-4 italic">No active invites.</div>
                            ) : (
                                <div className="space-y-3">
                                    {room.inviteLinks.map((link) => (
                                        <div key={link.id} className="bg-[#1c1c1e] p-3 rounded-xl border border-white/5 flex flex-col gap-2">
                                            <div className="flex justify-between items-start">
                                                <div className="flex items-center gap-2">
                                                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${link.type === 'public' ? 'bg-blue-500/20 text-blue-400' : 'bg-orange-500/20 text-orange-400'}`}>
                                                        {link.type}
                                                    </span>
                                                    <span className="text-xs text-gray-400 font-mono">{link.code}</span>
                                                </div>
                                                <button onClick={() => deleteLink(link.id)} className="text-gray-500 hover:text-red-400 p-1"><TrashIcon className="w-4 h-4"/></button>
                                            </div>
                                            
                                            <div className="flex items-center justify-between mt-1 border-t border-white/5 pt-2">
                                                <div className="flex items-center gap-2">
                                                    <img src={link.createdBy.avatar} className="w-5 h-5 rounded-full border border-white/10" />
                                                    <span className="text-[10px] text-gray-400">Created by {link.createdBy.name}</span>
                                                </div>
                                                <button 
                                                    onClick={() => navigator.clipboard.writeText(`https://syncwatch.app/join/${link.code}`)} 
                                                    className="flex items-center gap-1 text-[10px] font-bold text-purple-400 hover:text-purple-300"
                                                >
                                                    <CopyIcon className="w-3 h-3" /> Copy
                                                </button>
                                            </div>

                                            {link.usedBy.length > 0 && (
                                                <div className="text-[10px] text-gray-500 bg-black/20 p-2 rounded flex items-center gap-2 mt-1">
                                                    <CheckIcon className="w-3 h-3 text-green-500"/> Used by: 
                                                    <div className="flex -space-x-1">
                                                        {link.usedBy.slice(0,3).map(u => <img key={u.id} src={u.avatar} className="w-4 h-4 rounded-full border border-black" title={u.name} />)}
                                                    </div>
                                                    {link.usedBy.length > 3 && <span>+{link.usedBy.length - 3} others</span>}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </Section>
                    </div>
                )}

                {/* Moderation Tab */}
                {activeTab === 'moderation' && (
                    <div className="space-y-8 animate-fade-in">
                        
                        {/* Join Requests Section */}
                        <div>
                            <div className="flex items-center justify-between mb-3 px-1">
                                <h3 className="text-sm font-bold text-gray-300 flex items-center gap-2">
                                    <UserAddIcon className="w-4 h-4 text-blue-400"/> Join Requests
                                </h3>
                                {requests.length > 0 && <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full font-bold shadow-sm shadow-blue-500/30">{requests.length}</span>}
                            </div>
                            
                            <div className="space-y-3">
                                {requests.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-12 text-gray-500 bg-[#1c1c1e] rounded-2xl border border-dashed border-white/10">
                                        <CheckIcon className="w-10 h-10 mb-3 opacity-20" />
                                        <p className="text-sm font-medium">All caught up!</p>
                                        <p className="text-xs opacity-60">No pending requests.</p>
                                    </div>
                                ) : (
                                    requests.map(user => (
                                        <div key={user.id} className="flex items-center justify-between p-4 bg-[#1c1c1e] rounded-2xl border border-white/5 hover:border-white/10 transition-all animate-slide-in-up shadow-sm">
                                            <div className="flex items-center gap-4">
                                                <div className="relative">
                                                    <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full object-cover border-2 border-[#2c2c2e]" />
                                                    <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white p-0.5 rounded-full border-2 border-[#1c1c1e]"><UserAddIcon className="w-3 h-3"/></div>
                                                </div>
                                                <div>
                                                    <p className="text-sm font-bold text-white">{user.name}</p>
                                                    <p className="text-[10px] text-gray-400 mt-0.5">{user.bio || 'No bio available'}</p>
                                                </div>
                                            </div>
                                            <div className="flex gap-2">
                                                <button onClick={() => onAcceptRequest(user.id)} className="px-4 py-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors font-bold text-xs shadow-lg shadow-green-500/20">
                                                    Accept
                                                </button>
                                                <button onClick={() => onDeclineRequest(user.id)} className="px-4 py-2 bg-[#2c2c2e] text-gray-300 rounded-xl hover:bg-red-500/20 hover:text-red-400 transition-colors font-bold text-xs border border-white/5">
                                                    Decline
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>

                        {/* Banned Users Section */}
                        <div>
                            <h3 className="text-sm font-bold text-gray-300 mb-3 flex items-center gap-2 px-1">
                                <BlockUserIcon className="w-4 h-4 text-red-400"/> Banned Users
                            </h3>

                            {bannedUsers.length === 0 ? (
                                <div className="bg-[#1c1c1e]/50 border border-white/5 rounded-2xl p-4 text-center">
                                    <p className="text-xs text-gray-500">No banned users.</p>
                                </div>
                            ) : (
                                <div className="divide-y divide-white/5 bg-[#1c1c1e] rounded-2xl border border-white/5">
                                    {bannedUsers.map(user => {
                                        const details = room.bannedDetails?.find(d => d.userId === user.id);
                                        return (
                                            <div key={user.id} className="flex items-center justify-between p-3 hover:bg-white/[0.02] transition-colors first:rounded-t-2xl last:rounded-b-2xl">
                                                <div className="flex items-center gap-3 opacity-80">
                                                    <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover grayscale border border-white/10" />
                                                    <div className="flex flex-col">
                                                        <span className="text-sm font-bold text-white">{user.name}</span>
                                                        {details ? (
                                                            <span className="text-[10px] text-gray-400">
                                                                Banned by <span className="text-white font-medium">{details.bannedBy.name}</span> • {details.timestamp}
                                                            </span>
                                                        ) : (
                                                            <span className="text-[10px] text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded w-fit mt-0.5">BANNED</span>
                                                        )}
                                                    </div>
                                                </div>
                                                <button 
                                                    onClick={() => onUnblockUser(user.id)} 
                                                    className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors"
                                                >
                                                    Unban
                                                </button>
                                            </div>
                                        )
                                    })}
                                </div>
                            )}
                        </div>

                    </div>
                )}
            </>
        );
    }
};

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-[#18181b] border border-white/5 rounded-2xl p-5">
        <h3 className="text-sm font-bold text-white mb-4 border-b border-white/5 pb-2">{title}</h3>
        <div className="space-y-4">{children}</div>
    </div>
);

const Input: React.FC<{ label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string; }> = ({ label, value, onChange, type, placeholder }) => (
    <div>
        <label className="input-label">{label}</label>
        <input type={type || 'text'} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="input-style" />
    </div>
);

const VisibilityButton: React.FC<{label: string, icon: React.ReactNode, active: boolean, onClick: () => void}> = ({ label, icon, active, onClick }) => (
    <button type="button" onClick={onClick} className={`flex-1 flex items-center justify-center p-3 rounded-lg transition-all ${active ? 'bg-[#6C5DD3] text-white shadow-md' : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5'}`}>
        {icon}<span className="font-bold text-sm">{label}</span>
    </button>
);

const ToggleSwitch: React.FC<{label: string, description: string, enabled: boolean, onToggle: () => void}> = ({label, description, enabled, onToggle}) => (
    <div className="flex items-center justify-between p-3 rounded-xl bg-black/20 border border-white/5 cursor-pointer" onClick={onToggle}>
        <div>
            <p className="font-bold text-white text-sm">{label}</p>
            <p className="text-xs text-gray-400 mt-0.5">{description}</p>
        </div>
        <div className={`relative w-11 h-6 flex items-center rounded-full p-1 duration-300 ease-in-out ${enabled ? 'bg-[#6C5DD3]' : 'bg-gray-600'}`}>
            <div className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${enabled ? 'translate-x-5' : ''}`}></div>
        </div>
    </div>
);

export default VoiceRoomSettingsModal;
