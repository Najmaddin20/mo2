
import React, { useMemo, useState } from 'react';
import type { Friend, Conversation, User, CallState } from '../types';
import { ArrowLeftIcon, PhoneIcon, MoreVertIcon, BellIcon, ImageIcon, VideoCameraIcon, FileIcon, LinkIcon, MicrophoneIcon, SearchIcon, CloseIcon, CheckIcon, BlockUserIcon, ShareIcon, FileZipIcon, DownloadIcon, PlayIcon } from './icons';
import ImageViewerModal from './ImageViewerModal';
import ConfirmationModal from './ConfirmationModal';

interface UserInfoPanelProps {
  user: Friend;
  conversation: Conversation;
  onBack: () => void;
  onStartCall: (friend: Friend, type: CallState) => void;
  onBlockUser: (user: User) => void;
  onUnblockUser: (user: User) => void;
  blockedUsers: User[];
}

const statusStyles = {
    online: { text: 'Online', color: 'text-green-400', bg: 'bg-green-500' },
    ingame: { text: 'In a Room', color: 'text-purple-400', bg: 'bg-purple-500' },
    offline: { text: 'Offline', color: 'text-gray-400', bg: 'bg-gray-500' },
};

const QuickActionButton: React.FC<{ icon: React.ReactNode, label: string, onClick: () => void, disabled?: boolean }> = ({ icon, label, onClick, disabled }) => (
    <button 
        onClick={onClick} 
        disabled={disabled}
        className="flex flex-col items-center gap-2 group w-full disabled:opacity-50"
    >
        <div className="w-12 h-12 rounded-2xl bg-white/5 group-hover:bg-white/10 border border-white/5 flex items-center justify-center text-gray-300 group-hover:text-white transition-all shadow-lg active:scale-95">
            {icon}
        </div>
        <span className="text-xs font-medium text-gray-400 group-hover:text-gray-200 transition-colors">{label}</span>
    </button>
);

const MediaItem: React.FC<{ src: string, type: 'image' | 'video' }> = ({ src, type }) => (
    <div className="aspect-square rounded-xl overflow-hidden relative group cursor-pointer bg-black/40 border border-white/5">
        {type === 'image' ? (
            <img src={src} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="media" />
        ) : (
            <video src={src} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
        )}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            {type === 'video' && <div className="bg-black/50 p-2 rounded-full"><PlayIcon className="w-4 h-4 text-white" /></div>}
        </div>
    </div>
);

const InfoCard: React.FC<{ title: string, children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-[#1e1e24]/60 backdrop-blur-md border border-white/5 rounded-2xl p-4 shadow-sm">
        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">{title}</h3>
        {children}
    </div>
);

// Helper to categorize content
const extractSharedContent = (messages: any[]) => {
    const media = messages.filter(m => m.imageUrl || m.videoUrl).map(m => ({
        id: m.id,
        src: m.imageUrl || m.videoUrl!,
        type: m.imageUrl ? 'image' : 'video' as 'image' | 'video'
    }));
    
    const links = messages.filter(m => {
        const text = m.message || m.caption || '';
        return text.match(/https?:\/\/[^\s]+/);
    }).map(m => ({
        id: m.id,
        url: m.message?.match(/https?:\/\/[^\s]+/)?.[0] || m.caption?.match(/https?:\/\/[^\s]+/)?.[0] || '',
        timestamp: m.timestamp
    }));

    const files = messages.filter(m => m.fileInfo).map(m => ({
        id: m.id,
        name: m.fileInfo.name,
        size: m.fileInfo.size,
        timestamp: m.timestamp
    }));

    const voice = messages.filter(m => m.voiceMessage).map(m => ({
        id: m.id,
        duration: m.voiceMessage.duration,
        timestamp: m.timestamp
    }));

    return { media, links, files, voice };
};

const UserInfoPanel: React.FC<UserInfoPanelProps> = ({ user, conversation, onBack, onStartCall, onBlockUser, onUnblockUser, blockedUsers }) => {
    const [notifications, setNotifications] = useState(true);
    const [isAvatarViewerOpen, setIsAvatarViewerOpen] = useState(false);
    const [showBlockConfirm, setShowBlockConfirm] = useState(false);
    const [activeTab, setActiveTab] = useState<'media' | 'links' | 'files' | 'voice' | 'groups'>('media');

    const isBlocked = useMemo(() => blockedUsers.some(b => b.id === user.id), [blockedUsers, user.id]);
    
    const { media, links, files, voice } = useMemo(() => extractSharedContent(conversation.messages), [conversation.messages]);

    const status = statusStyles[user.status];

    const formatBytes = (bytes: number) => {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    };

    return (
        <>
            <div className="flex flex-col h-full bg-[#0f0f0f] text-white overflow-hidden relative">
                
                {/* Parallax Header */}
                <div className="relative h-72 w-full flex-shrink-0 overflow-hidden">
                    <div 
                        className="absolute inset-0 bg-cover bg-center transform scale-105"
                        style={{ 
                            backgroundImage: user.profileBanner ? `url(${user.profileBanner})` : `url(${user.avatar})`,
                            filter: 'blur(10px) brightness(0.6)'
                        }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0f0f0f]/60 to-[#0f0f0f]"></div>
                    
                    {/* Navigation */}
                    <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-10">
                        <button onClick={onBack} className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white hover:bg-black/40 transition-colors">
                            <ArrowLeftIcon className="w-6 h-6" />
                        </button>
                        <button className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white hover:bg-black/40 transition-colors">
                            <MoreVertIcon className="w-6 h-6" />
                        </button>
                    </div>

                    {/* Profile Info Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 flex flex-col items-center z-10 translate-y-6">
                        <div className="relative group cursor-pointer" onClick={() => setIsAvatarViewerOpen(true)}>
                            <div className="w-28 h-28 rounded-full p-1 bg-[#0f0f0f]">
                                <img src={user.avatar} className="w-full h-full rounded-full object-cover border-4 border-[#0f0f0f] shadow-2xl" />
                            </div>
                            <div className={`absolute bottom-2 right-2 w-5 h-5 ${status.bg} rounded-full border-4 border-[#0f0f0f]`}></div>
                        </div>
                        <h1 className="text-2xl font-bold mt-2 text-white shadow-lg">{user.name}</h1>
                        <p className={`text-sm font-medium ${status.color}`}>{status.text}</p>
                    </div>
                </div>

                {/* Scrollable Content */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 pt-8 space-y-6">
                    
                    {/* Quick Actions */}
                    <div className="grid grid-cols-4 gap-2">
                        <QuickActionButton 
                            icon={<PhoneIcon className="w-5 h-5" />} 
                            label="Audio" 
                            onClick={() => onStartCall(user, 'outgoing-voice')} 
                            disabled={isBlocked}
                        />
                        <QuickActionButton 
                            icon={<VideoCameraIcon className="w-5 h-5" />} 
                            label="Video" 
                            onClick={() => onStartCall(user, 'outgoing-video')} 
                            disabled={isBlocked}
                        />
                        <QuickActionButton 
                            icon={<SearchIcon className="w-5 h-5" />} 
                            label="Search" 
                            onClick={() => { /* TODO: Implement Search in Chat */ }} 
                        />
                        <QuickActionButton 
                            icon={notifications ? <BellIcon className="w-5 h-5" /> : <BellIcon className="w-5 h-5 opacity-50" />} 
                            label={notifications ? 'Mute' : 'Unmute'} 
                            onClick={() => setNotifications(!notifications)} 
                        />
                    </div>

                    {/* Info & Bio */}
                    <InfoCard title="About">
                        {user.bio ? (
                            <p className="text-sm text-gray-200 leading-relaxed">{user.bio}</p>
                        ) : (
                            <p className="text-sm text-gray-500 italic">No bio available.</p>
                        )}
                        <div className="mt-4 pt-4 border-t border-white/5 flex flex-col gap-3">
                            <div className="flex items-center gap-3 text-sm">
                                <div className="p-1.5 bg-white/5 rounded-md text-gray-400"><LinkIcon className="w-4 h-4" /></div>
                                <span className="text-blue-400 hover:underline cursor-pointer">@{user.name.toLowerCase().replace(/\s/g, '')}</span>
                            </div>
                        </div>
                    </InfoCard>

                    {/* Shared Content Tabs */}
                    <div className="bg-[#1e1e24]/60 backdrop-blur-md border border-white/5 rounded-2xl shadow-sm overflow-hidden">
                        <div className="flex overflow-x-auto hide-scrollbar border-b border-white/5 p-2 gap-1">
                            {['media', 'links', 'files', 'voice', 'groups'].map((tab) => (
                                <button 
                                    key={tab}
                                    onClick={() => setActiveTab(tab as any)}
                                    className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide whitespace-nowrap transition-all ${activeTab === tab ? 'bg-white/10 text-white' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'}`}
                                >
                                    {tab}
                                </button>
                            ))}
                        </div>
                        
                        <div className="p-4 min-h-[200px]">
                            {activeTab === 'media' && (
                                media.length > 0 ? (
                                    <div className="grid grid-cols-3 gap-2">
                                        {media.map(item => <MediaItem key={item.id} src={item.src} type={item.type} />)}
                                    </div>
                                ) : <EmptyState label="No media shared" />
                            )}

                            {activeTab === 'links' && (
                                links.length > 0 ? (
                                    <div className="space-y-2">
                                        {links.map(link => (
                                            <div key={link.id} className="flex items-center gap-3 p-3 rounded-xl bg-black/20 hover:bg-black/40 transition-colors group">
                                                <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><LinkIcon className="w-5 h-5"/></div>
                                                <div className="flex-1 min-w-0">
                                                    <a href={link.url} target="_blank" rel="noreferrer" className="text-sm text-blue-400 hover:underline truncate block font-medium">{link.url}</a>
                                                    <p className="text-[10px] text-gray-500">{new Date(link.timestamp).toLocaleDateString()}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : <EmptyState label="No links shared" />
                            )}

                            {activeTab === 'files' && (
                                files.length > 0 ? (
                                    <div className="space-y-2">
                                        {files.map(file => (
                                            <div key={file.id} className="flex items-center gap-3 p-3 rounded-xl bg-black/20 hover:bg-black/40 transition-colors">
                                                <div className="p-2 bg-orange-500/20 text-orange-400 rounded-lg"><FileIcon className="w-5 h-5"/></div>
                                                <div className="flex-1 min-w-0">
                                                    <p className="text-sm text-white truncate font-medium">{file.name}</p>
                                                    <p className="text-[10px] text-gray-500">{formatBytes(file.size)} • {new Date(file.timestamp).toLocaleDateString()}</p>
                                                </div>
                                                <button className="p-2 hover:bg-white/10 rounded-full text-gray-400 hover:text-white"><DownloadIcon className="w-4 h-4"/></button>
                                            </div>
                                        ))}
                                    </div>
                                ) : <EmptyState label="No files shared" />
                            )}

                            {activeTab === 'voice' && (
                                voice.length > 0 ? (
                                    <div className="space-y-2">
                                        {voice.map(v => (
                                            <div key={v.id} className="flex items-center gap-3 p-3 rounded-xl bg-black/20 hover:bg-black/40 transition-colors">
                                                <div className="p-2 bg-purple-500/20 text-purple-400 rounded-lg"><MicrophoneIcon className="w-5 h-5"/></div>
                                                <div className="flex-1">
                                                    <p className="text-sm text-white font-medium">Voice Message</p>
                                                    <p className="text-[10px] text-gray-500">{v.duration}s • {new Date(v.timestamp).toLocaleDateString()}</p>
                                                </div>
                                                <button className="p-2 hover:bg-white/10 rounded-full text-white"><PlayIcon className="w-4 h-4"/></button>
                                            </div>
                                        ))}
                                    </div>
                                ) : <EmptyState label="No voice notes" />
                            )}

                            {activeTab === 'groups' && (
                                <div className="space-y-2">
                                    <div className="flex items-center gap-3 p-3 rounded-xl bg-black/20 hover:bg-black/40 transition-colors cursor-pointer border border-white/5">
                                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold shadow-lg">M</div>
                                        <div className="flex-1">
                                            <p className="text-sm font-bold text-white">Movie Night</p>
                                            <p className="text-xs text-gray-400">3 members including {user.name}</p>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Danger Zone / Settings */}
                    <div className="pt-4 space-y-3">
                        <button 
                            onClick={() => isBlocked ? onUnblockUser(user) : setShowBlockConfirm(true)} 
                            className={`w-full py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${isBlocked ? 'bg-blue-500/10 text-blue-400 hover:bg-blue-500/20' : 'bg-red-500/10 text-red-400 hover:bg-red-500/20'}`}
                        >
                            {isBlocked ? <CheckIcon className="w-4 h-4" /> : <BlockUserIcon className="w-4 h-4" />}
                            {isBlocked ? 'Unblock User' : 'Block User'}
                        </button>
                        
                        <button className="w-full py-3.5 rounded-xl bg-white/5 text-gray-400 font-bold text-sm flex items-center justify-center gap-2 hover:bg-white/10 transition-all">
                            <ShareIcon className="w-4 h-4" /> Share Contact
                        </button>
                    </div>
                    
                    <div className="h-4"></div>
                </div>
            </div>

            <ImageViewerModal
                isOpen={isAvatarViewerOpen}
                onClose={() => setIsAvatarViewerOpen(false)}
                imageUrl={user.avatar}
                imageName={`${user.name}_avatar.jpg`}
            />
            
            <ConfirmationModal
                isOpen={showBlockConfirm}
                onClose={() => setShowBlockConfirm(false)}
                onConfirm={() => {
                    onBlockUser(user);
                    setShowBlockConfirm(false);
                }}
                title={`Block ${user.name}?`}
                message={`${user.name} will no longer be able to message or call you. They won't be notified.`}
                confirmText="Block"
            />
        </>
    );
};

const EmptyState: React.FC<{ label: string }> = ({ label }) => (
    <div className="flex flex-col items-center justify-center py-8 text-gray-500">
        <p className="text-sm">{label}</p>
    </div>
);

export default UserInfoPanel;
