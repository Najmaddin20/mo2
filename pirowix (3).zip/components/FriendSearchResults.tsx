
import React from 'react';
import type { User, Friend } from '../types';
import { SpinnerIcon, UserAddIcon, ChatIcon, CheckIcon, UserIcon } from './icons';

interface FriendSearchResultsProps {
    isLoading: boolean;
    query: string;
    results: { myFriends: Friend[], global: User[] };
    requestedUsers: Set<number>;
    onAddToggle: (user: User) => void;
    onStartChat: (friendId: number) => void;
}

const FriendSearchResults: React.FC<FriendSearchResultsProps> = ({ isLoading, query, results, requestedUsers, onAddToggle, onStartChat }) => {
    return (
        <div className="absolute top-full left-0 right-0 mt-3 bg-[#121214]/80 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl z-40 max-h-[450px] overflow-y-auto custom-scrollbar animate-fade-in-up ring-1 ring-white/5">
            {isLoading && (
                <div className="flex flex-col justify-center items-center p-12">
                    <SpinnerIcon className="w-8 h-8 animate-spin mb-3 text-[var(--theme-color)]" />
                    <span className="text-xs font-medium tracking-wider opacity-80" style={{ color: 'var(--theme-color)' }}>SEARCHING UNIVERSE...</span>
                </div>
            )}
            
            {!isLoading && query && results.myFriends.length === 0 && results.global.length === 0 && (
                <div className="flex flex-col items-center justify-center p-12 text-center text-gray-400">
                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                        <UserIcon className="w-8 h-8 opacity-50" />
                    </div>
                    <p className="font-medium text-lg text-white">No results found</p>
                    <p className="text-sm mt-1 opacity-60">Try searching for a different name or ID.</p>
                </div>
            )}

            {!isLoading && (
                <div className="p-2 space-y-2">
                    {results.myFriends.length > 0 && (
                        <div className="mb-2">
                            <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 px-4 mt-2">My Friends</h3>
                            <div className="space-y-1">
                                {results.myFriends.map(friend => (
                                    <UserItem key={friend.id} user={friend} action="chat" onAction={() => onStartChat(friend.id)} />
                                ))}
                            </div>
                        </div>
                    )}

                    {results.global.length > 0 && (
                        <div>
                            <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 px-4 mt-2">Discover People</h3>
                            <div className="space-y-1">
                                {results.global.map(user => (
                                    <UserItem 
                                        key={user.id} 
                                        user={user} 
                                        action={requestedUsers.has(user.id) ? 'requested' : 'add'} 
                                        onAction={() => onAddToggle(user)} 
                                    />
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

const UserItem: React.FC<{ user: User, action: 'chat' | 'add' | 'requested', onAction: () => void }> = ({ user, action, onAction }) => {
    const isRequested = action === 'requested';
    const isChat = action === 'chat';
    const isAdd = action === 'add';
    
    return (
        <div className="group flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition-all duration-200 border border-transparent hover:border-white/5">
            <div className="flex items-center gap-4 min-w-0">
                <div className="relative">
                    <img 
                        src={user.avatar} 
                        alt={user.name} 
                        className="w-12 h-12 rounded-full object-cover border-2 border-transparent group-hover:border-white/10 transition-colors bg-[#1e1e1e] shadow-sm" 
                    />
                    {isChat && (
                        <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 border-2 border-[#121214] rounded-full"></div>
                    )}
                </div>
                <div className="min-w-0 flex flex-col gap-0.5">
                    <p className="font-bold text-white text-sm truncate group-hover:opacity-80 transition-colors" style={isChat ? {} : {}}>{user.name}</p>
                    <p className="text-xs text-gray-500 truncate max-w-[140px]">
                        {user.bio || `User ID: ${user.id}`}
                    </p>
                </div>
            </div>
            
            {isChat && (
                <button
                    onClick={onAction}
                    className="h-9 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold transition-all flex items-center gap-2 active:scale-95 shadow-sm border border-white/5 hover:border-white/10"
                >
                    <ChatIcon className="w-4 h-4" />
                    <span className="hidden sm:inline">Chat</span>
                </button>
            )}

            {isAdd && (
                <button
                    onClick={onAction}
                    className="h-9 px-4 rounded-lg text-white text-xs font-bold transition-all flex items-center gap-2 active:scale-95 transform shadow-lg hover:shadow-purple-500/20"
                    style={{ backgroundColor: 'var(--theme-color)' }}
                >
                    <UserAddIcon className="w-4 h-4" />
                    <span>Add</span>
                </button>
            )}

            {isRequested && (
                <button
                    onClick={onAction}
                    className="h-9 px-4 rounded-lg border border-white/10 bg-transparent text-gray-400 text-xs font-bold transition-all flex items-center gap-2 cursor-default opacity-70"
                >
                    <CheckIcon className="w-4 h-4 text-green-400" />
                    <span>Sent</span>
                </button>
            )}
        </div>
    );
};

export default FriendSearchResults;
