
import React, { useState, useEffect } from 'react';
import { PlayFilledIcon, PauseFilledIcon, MusicNoteIcon } from './icons';
import { useAudioPlayer } from './AudioPlayerSystem';
import type { AudioTrack } from '../types';

interface MusicMessageBubbleProps {
    track: AudioTrack;
    isSent: boolean;
    fileSize: number;
    fileName: string;
}

const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
};

const MusicMessageBubble: React.FC<MusicMessageBubbleProps> = ({ track, isSent, fileSize, fileName }) => {
    const { currentTrack, isPlaying, togglePlay, playTrack, currentTime, duration: totalDuration } = useAudioPlayer();
    
    const isCurrent = currentTrack?.id === track.id;
    const isActivePlaying = isCurrent && isPlaying;
    const progress = isCurrent && totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0;

    const handlePlayClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (isCurrent) {
            togglePlay();
        } else {
            playTrack(track);
        }
    };

    const formatExtension = fileName.split('.').pop()?.toUpperCase() || 'AUDIO';

    // Colors
    const bubbleBg = isSent ? '' : 'bg-[#2f2b43]';
    const bubbleStyle = isSent ? { backgroundColor: 'var(--theme-color)' } : {};
    const iconBg = isSent ? 'bg-white/20 text-white' : 'bg-black/20 text-[var(--theme-color)]';
    const textColor = isSent ? 'text-white' : 'text-gray-200';
    const subTextColor = isSent ? 'text-white/70' : 'text-gray-400';
    const progressColor = isSent ? 'bg-white' : 'bg-[var(--theme-color)]';
    const progressTrackColor = isSent ? 'bg-white/30' : 'bg-white/10';

    return (
        <div 
            className={`flex items-center gap-3 p-3 rounded-xl w-full min-w-[260px] max-w-[300px] transition-all duration-200 ${bubbleBg} shadow-sm relative overflow-hidden group`}
            style={bubbleStyle}
        >
            <button 
                onClick={handlePlayClick}
                className={`relative w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-xl shadow-md transition-transform hover:scale-105 active:scale-95 backdrop-blur-sm ${iconBg}`}
            >
                 {isActivePlaying ? <PauseFilledIcon className="w-5 h-5" /> : <PlayFilledIcon className="w-5 h-5 ml-0.5" />}
            </button>

            <div className="flex-1 flex flex-col justify-center gap-1 min-w-0 relative z-10">
                <div className="flex justify-between items-start">
                    <p className={`font-bold text-sm truncate ${textColor}`}>{fileName}</p>
                </div>
                
                <div className="flex items-center justify-between text-[10px] font-medium tracking-wide">
                    <span className={subTextColor}>{formatBytes(fileSize)}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${isSent ? 'bg-white/20 text-white' : 'bg-black/20 text-gray-400'}`}>{formatExtension}</span>
                </div>

                {/* Progress Bar */}
                <div className={`h-1 w-full rounded-full overflow-hidden mt-1 ${progressTrackColor}`}>
                    <div 
                        className={`h-full transition-all duration-100 ease-linear ${progressColor}`}
                        style={{ width: `${progress}%` }}
                    />
                </div>
            </div>
            
            {/* Decorative Icon */}
            <div className="absolute -right-2 -bottom-4 opacity-10 pointer-events-none">
                <MusicNoteIcon className={`w-16 h-16 ${isSent ? 'text-white' : 'text-gray-500'}`} />
            </div>
        </div>
    );
};

export default MusicMessageBubble;
