import React from 'react';

const SkeletonCard: React.FC = () => (
    <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden shadow-lg">
        <div className="w-full h-48 bg-white/10 animate-pulse"></div>
        <div className="p-4 space-y-3">
            <div className="w-3/4 h-5 bg-white/10 rounded animate-pulse"></div>
            <div className="w-1/2 h-4 bg-white/10 rounded animate-pulse"></div>
            <div className="flex -space-x-2 mt-3 pt-2">
                <div className="w-8 h-8 rounded-full bg-white/10 border-2 border-[#2c2c38] animate-pulse"></div>
                <div className="w-8 h-8 rounded-full bg-white/10 border-2 border-[#2c2c38] animate-pulse"></div>
                <div className="w-8 h-8 rounded-full bg-white/10 border-2 border-[#2c2c38] animate-pulse"></div>
            </div>
        </div>
    </div>
);

const DashboardSkeleton: React.FC = () => {
    return (
        <div>
            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                <div className="w-48 h-8 bg-white/10 rounded animate-pulse"></div>
                <div className="w-full sm:w-32 h-10 bg-white/10 rounded-lg animate-pulse"></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                    <SkeletonCard key={i} />
                ))}
            </div>
        </div>
    );
};

export default DashboardSkeleton;