
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import ReactPlayer from 'react-player';
import type { Room, User, ChatMessage, VideoQueueItem, SuggestedVideo, Friend, RoomUser, UserRole } from '../types';
import { PlayIcon, PauseIcon, VolumeUpIcon, VolumeOffIcon, SettingsIcon, UsersIcon, QueueIcon, ChatIcon, CloseIcon, LightbulbIcon, SkipNextIcon, TheaterModeIcon, HeadphonesIcon, ArrowLeftIcon, LinkIcon, ReplyIcon, SkipPreviousIcon, Replay10Icon, Forward10Icon, PlayFilledIcon, PauseFilledIcon, UpvoteIcon, MoreVertIcon, TrashIcon, FullscreenEnterIcon, FullscreenExitIcon, MicrophoneIcon, MicrophoneOffIcon, StarIcon, FilmReelIcon } from './icons';
import RoomSettingsModal from './RoomSettingsModal';
import NowPlayingManager, { MobileNowPlayingPanel } from './NowPlayingManager';
import VideoSuggestions from './VideoSuggestions';
import EmojiReactions from './EmojiReactions';
import RoomChatPanel from './RoomChatPanel';
import ForwardMessageModal from './ForwardMessageModal';
import RoomRating from './RoomRating';

const VideoPlayer: React.FC<{
    room: Room;
    canControlPlayback: boolean;
    isTheaterMode: boolean;
    playerRef: React.RefObject<any>;
    volume: number;
    isMuted: boolean;
    isReady: boolean;
    onReady: () => void;
    onProgress: (state: { played: number; playedSeconds: number }) => void;
    onDuration: (duration: number) => void;
    onPlay: (_e?: any) => void;
    onPause: (_e?: any) => void;
    onSeek: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onVolumeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onToggleMute: () => void;
    onTogglePlay: () => void;
    onSeekForward: () => void;
    onSeekBackward: () => void;
    currentTime: number;
    duration: number;
    isFullscreen: boolean;
    onToggleFullscreen: () => void;
}> = (props) => {
    const {
        room, canControlPlayback, isTheaterMode, playerRef, volume, isMuted,
        isReady, onReady, onProgress, onDuration, onPlay, onPause,
        onSeek, onVolumeChange, onToggleMute, onTogglePlay, onSeekForward, onSeekBackward,
        currentTime, duration, isFullscreen, onToggleFullscreen
    } = props;
    
    const [playerError, setPlayerError] = useState<string | null>(null);

    const formatTime = (time: number) => {
        if (isNaN(time) || time < 0) return '00:00';
        const minutes = Math.floor(time / 60);
        const seconds = Math.floor(time % 60);
        return `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    };
    
    const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

    return (
        <div className={`relative bg-black rounded-none md:rounded-3xl overflow-hidden group w-full h-full flex flex-col justify-center items-center shadow-2xl ring-1 ring-white/10 ${isTheaterMode ? 'z-50' : ''}`}>
            {!playerError ? (
                <ReactPlayer
                    ref={playerRef}
                    url={room.videoUrl}
                    playing={room.isPlaying}
                    volume={volume}
                    muted={isMuted}
                    onReady={onReady}
                    onProgress={onProgress}
                    onDuration={onDuration}
                    onPlay={onPlay}
                    onPause={onPause}
                    onError={(e) => {
                        console.error("ReactPlayer Error:", e);
                        setPlayerError("Playback Error. The video might be restricted.");
                    }}
                    width="100%"
                    height="100%"
                    className="absolute top-0 left-0"
                    controls={false}
                    style={{ position: 'absolute', top: 0, left: 0 }}
                    config={{
                        youtube: {
                            playerVars: { 
                                showinfo: 0, 
                                controls: 0, 
                                modestbranding: 1, 
                                rel: 0, 
                                playsinline: 1,
                                origin: window.location.origin,
                                enablejsapi: 1
                            }
                        },
                        file: {
                            attributes: {
                                controlsList: 'nodownload'
                            }
                        }
                    }}
                />
            ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900 text-white z-20">
                    <p className="text-red-400 font-semibold mb-2">⚠️ {playerError}</p>
                    <p className="text-sm text-gray-400">Try a different video link.</p>
                </div>
            )}

            {!isReady && !playerError && <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md text-white z-20 pointer-events-none font-bold animate-pulse">Loading content...</div>}
            
            <div 
                className="absolute inset-0 z-10" 
                onClick={canControlPlayback ? onTogglePlay : undefined}
                style={{ cursor: canControlPlayback ? 'pointer' : 'default' }}
            ></div>

            {!room.isPlaying && isReady && !playerError && (
                <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
                    <div className="bg-black/40 backdrop-blur-md rounded-full p-6 shadow-2xl ring-1 ring-white/20 animate-fade-in-up">
                        <PlayFilledIcon className="w-12 h-12 text-white" />
                    </div>
                </div>
            )}
            
            {!isTheaterMode && (
                 <div className={`absolute bottom-0 left-0 right-0 p-4 md:p-6 bg-gradient-to-t from-black/90 via-black/60 to-transparent transition-opacity duration-300 z-20 ${!room.isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                    <div className="flex items-center gap-4 text-xs text-white font-mono mb-3">
                        <span>{formatTime(currentTime)}</span>
                        <div className="w-full group/progress relative flex items-center">
                            <input
                                type="range"
                                min="0"
                                max="100"
                                step="0.1"
                                value={progressPercent}
                                onChange={onSeek}
                                disabled={!canControlPlayback}
                                className="w-full h-[4px] group-hover/progress:h-[6px] appearance-none cursor-pointer player-slider progress-slider transition-all relative z-30"
                                style={{ background: `linear-gradient(to right, var(--theme-color) ${progressPercent}%, rgba(255,255,255,0.2) ${progressPercent}%)`, borderRadius: '3px' }}
                            />
                        </div>
                        <span>{formatTime(duration)}</span>
                    </div>
                    <div className="flex justify-between items-center relative z-30">
                        <div className="flex items-center gap-4 w-1/3">
                            <button onClick={onTogglePlay} disabled={!canControlPlayback} className="text-white hover:text-[var(--theme-color)] transition-colors disabled:opacity-50">
                                {room.isPlaying ? <PauseFilledIcon className="w-8 h-8" /> : <PlayFilledIcon className="w-8 h-8" />}
                            </button>
                            <div className="flex items-center group/volume gap-2">
                                <button onClick={onToggleMute} className="text-white hover:text-[var(--theme-color)]">
                                    {isMuted || volume === 0 ? <VolumeOffIcon className="w-5 h-5" /> : <VolumeUpIcon className="w-5 h-5" />}
                                </button>
                                <input
                                    type="range"
                                    min="0" max="1" step="0.01"
                                    value={isMuted ? 0 : volume}
                                    onChange={onVolumeChange}
                                    className="w-0 group-hover/volume:w-24 h-1 appearance-none cursor-pointer player-slider volume-slider transition-all overflow-hidden ml-1"
                                    style={{ background: `linear-gradient(to right, #ffffff ${isMuted ? 0 : volume * 100}%, rgba(255,255,255,0.2) ${isMuted ? 0 : volume * 100}%)`, borderRadius: '2px' }}
                                />
                            </div>
                        </div>
        
                        <div className="flex items-center gap-6 justify-center w-1/3">
                            <button onClick={onSeekBackward} disabled={!canControlPlayback} className="text-white/70 hover:text-white disabled:opacity-30 transition-transform hover:scale-110 active:scale-95">
                                <Replay10Icon className="w-8 h-8" />
                            </button>
                            <button onClick={onSeekForward} disabled={!canControlPlayback} className="text-white/70 hover:text-white disabled:opacity-30 transition-transform hover:scale-110 active:scale-95">
                                <Forward10Icon className="w-8 h-8" />
                            </button>
                        </div>
        
                        <div className="w-1/3 flex justify-end">
                            <button onClick={onToggleFullscreen} className="text-white/70 hover:text-white">
                                {isFullscreen ? <FullscreenExitIcon className="w-6 h-6" /> : <FullscreenEnterIcon className="w-6 h-6" />}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const UserList: React.FC<{ 
    users: RoomUser[], 
    currentUser: User,
    currentUserRole?: UserRole,
    onViewProfile: (user: User) => void; 
    onSetUserRole: (userId: number, role: UserRole) => void;
    onKickUser: (userId: number) => void;
}> = ({ users, currentUser, currentUserRole, onViewProfile, onSetUserRole, onKickUser }) => {
    const [activeMenu, setActiveMenu] = useState<number | null>(null);

    const canManage = currentUserRole === 'host';
    const canModerate = currentUserRole === 'host' || currentUserRole === 'moderator';

    const handleAction = (action: () => void) => {
        action();
        setActiveMenu(null);
    };
    
    const roles: UserRole[] = ['moderator', 'dj', 'member'];
    
    const roleColors: Record<UserRole, string> = {
        host: 'text-orange-400',
        moderator: 'text-blue-400',
        dj: 'text-green-400',
        member: 'text-gray-400',
    };

    return (
        <div className="space-y-2 p-2">
            {users.map(user => (
                <div key={user.id} className="flex items-center p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all group">
                    <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full cursor-pointer object-cover border border-white/10" onClick={() => onViewProfile(user)} />
                    <div className="ml-3 flex-1 min-w-0 cursor-pointer" onClick={() => onViewProfile(user)}>
                        <p className="font-bold text-white truncate text-sm">{user.name}</p>
                        <p className={`text-[10px] font-bold uppercase tracking-wider ${roleColors[user.role]}`}>{user.role}</p>
                    </div>
                    {canModerate && user.id !== currentUser.id && user.role !== 'host' && (!canManage && user.role === 'moderator') === false && (
                        <div className="relative">
                            <button onClick={() => setActiveMenu(activeMenu === user.id ? null : user.id)} className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
                                <MoreVertIcon className="w-5 h-5" />
                            </button>
                            {activeMenu === user.id && (
                                <div className="absolute right-0 mt-2 w-48 bg-[#18181b]/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl z-20 animate-fade-in-up overflow-hidden">
                                    {canManage && roles.map(role => (
                                        <button key={role} onClick={() => handleAction(() => onSetUserRole(user.id, role))} className="w-full text-left px-4 py-3 text-sm text-gray-200 hover:bg-white/10 capitalize transition-colors">
                                            Make {role}
                                        </button>
                                    ))}
                                    <div className="h-px bg-white/10 my-1"></div>
                                    <button onClick={() => handleAction(() => onKickUser(user.id))} className="w-full text-left px-4 py-3 text-sm hover:bg-red-500/10 text-red-400 flex items-center gap-2 transition-colors font-bold">
                                        <TrashIcon className="w-4 h-4" />
                                        Kick User
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

const VideoQueuePanel: React.FC<{ room: Room; onUpdateRoom: (room: Room) => void; canManageQueue: boolean; }> = ({ room, onUpdateRoom, canManageQueue }) => {
    const handleAddVideo = (e: React.FormEvent) => {
        e.preventDefault();
        alert("Feature to add video to queue is coming soon!");
    }
    const handleVote = (id: number) => {
        alert(`You voted for video ${id}! (This is a mock-up)`);
    }
    
    return (
        <div className="flex flex-col h-full p-2">
            <div className="flex-1 space-y-2 overflow-y-auto pr-1 pb-4 custom-scrollbar">
                {(room.videoQueue || []).length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-gray-500 text-center px-4 opacity-60">
                        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                            <QueueIcon className="w-8 h-8 text-gray-500"/>
                        </div>
                        <p className="font-bold">The queue is empty</p>
                        <p className="text-xs mt-1">Add videos to watch next!</p>
                    </div>
                )}
                {(room.videoQueue || []).map(item => (
                    <div key={item.id} className="flex items-center gap-3 bg-white/5 border border-white/5 p-2 rounded-xl group hover:bg-white/10 transition-colors">
                        <div className="relative w-24 h-16 flex-shrink-0 rounded-lg overflow-hidden">
                            <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="font-bold text-white text-sm line-clamp-2 leading-tight">{item.title}</p>
                            <p className="text-xs text-gray-500 mt-1">Added by {item.addedBy.name}</p>
                        </div>
                        <button onClick={() => handleVote(item.id)} className="flex flex-col items-center p-2 rounded-lg hover:bg-white/10 text-gray-400 hover:text-[var(--theme-color)] transition-colors">
                           <UpvoteIcon className="w-5 h-5" />
                            <span className="text-xs font-bold">{item.votes}</span>
                        </button>
                    </div>
                ))}
            </div>
            {canManageQueue && (
                 <form onSubmit={handleAddVideo} className="mt-auto flex-shrink-0 flex items-center gap-2 pt-4 border-t border-white/10">
                    <input type="text" placeholder="Paste a video URL..." className="flex-1 w-full bg-white/5 text-white px-4 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-[var(--theme-color)] text-sm placeholder-gray-500 transition-colors backdrop-blur-sm" />
                    <button type="submit" className="px-5 py-3 rounded-xl bg-[var(--theme-color)] hover:brightness-110 text-white font-bold text-sm transition-all shadow-lg">Add</button>
                </form>
            )}
        </div>
    );
}

const VoiceChatPanel: React.FC<{ room: Room; currentUser: User; onUpdateRoom: (room: Room) => void; onClose?: () => void }> = ({ room, currentUser, onUpdateRoom, onClose }) => {
    const isInVoice = (room.voiceParticipants || []).some(p => p.id === currentUser.id);
    const isMobileModal = !!onClose;

    const toggleVoice = () => {
        const currentlyIn = (room.voiceParticipants || []).some(p => p.id === currentUser.id);
        let newParticipants;
        if (currentlyIn) {
            newParticipants = (room.voiceParticipants || []).filter(p => p.id !== currentUser.id);
        } else {
            newParticipants = [...(room.voiceParticipants || []), currentUser];
        }
        onUpdateRoom({ ...room, voiceParticipants: newParticipants });
    };

    return (
        <div className={`bg-black/20 backdrop-blur-xl ${isMobileModal ? 'h-full' : 'border border-white/10 rounded-3xl w-full h-full'} p-5 flex flex-col gap-4 shadow-lg`}>
            <div className="flex justify-between items-center shrink-0">
                <div className="flex items-center gap-3">
                    {onClose && (
                         <button onClick={onClose} className="p-2 -ml-2 text-white rounded-full hover:bg-white/10 transition-colors">
                            <ArrowLeftIcon className="w-6 h-6" />
                        </button>
                    )}
                    <div className="flex items-center gap-2">
                         {!onClose && <div className="p-1.5 bg-purple-500/20 rounded-lg"><HeadphonesIcon className="w-4 h-4 text-purple-400"/></div>}
                        <h3 className="font-bold text-white text-sm uppercase tracking-wider">Voice Chat</h3>
                    </div>
                </div>
                {isInVoice ? (
                    <span className="text-[10px] uppercase tracking-wider text-green-400 font-bold flex items-center bg-green-500/10 border border-green-500/20 px-2 py-0.5 rounded-full"><span className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1.5 animate-pulse"></span>Live</span>
                ) : (
                    <span className="text-[10px] uppercase tracking-wider text-gray-500 font-bold bg-white/5 border border-white/10 px-2 py-0.5 rounded-full">Idle</span>
                )}
            </div>
            
            <div className={`flex-1 min-h-0 ${isInVoice ? (isMobileModal ? 'overflow-y-auto' : 'overflow-x-auto') : 'flex items-center justify-center'}`}>
                {isInVoice ? (
                    <div className={`${isMobileModal ? 'grid grid-cols-3 sm:grid-cols-4 gap-4 p-2' : 'flex items-center gap-3 pb-2 hide-scrollbar'}`}>
                        {(room.voiceParticipants || []).map(p => (
                            <div key={p.id} className={`flex flex-col items-center gap-2 ${isMobileModal ? '' : 'min-w-[60px]'} animate-fade-in-up group`}>
                                <div className="relative">
                                    <img src={p.avatar} alt={p.name} className={`${isMobileModal ? 'w-16 h-16' : 'w-12 h-12'} rounded-full border-2 border-white/10 ring-2 ring-transparent group-hover:ring-[var(--theme-color)] transition-all shadow-lg object-cover`} />
                                    <div className={`absolute bottom-0 right-0 ${isMobileModal ? 'w-5 h-5' : 'w-3.5 h-3.5'} bg-[#121214] rounded-full flex items-center justify-center border border-green-500/30`}>
                                        <div className={`${isMobileModal ? 'w-2.5 h-2.5' : 'w-2 h-2'} bg-green-500 rounded-full animate-pulse`}></div>
                                    </div>
                                </div>
                                <p className="text-[10px] font-bold text-gray-300 truncate max-w-full text-center bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-sm">{p.name}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className={`flex flex-col items-center justify-center text-center ${isMobileModal ? 'py-10 space-y-6 opacity-60 h-full' : 'flex-row gap-3 opacity-50 py-2'}`}>
                        <div className={`${isMobileModal ? 'w-24 h-24 bg-white/5' : 'p-2 bg-white/5'} rounded-full flex items-center justify-center border border-white/5`}>
                            <HeadphonesIcon className={`${isMobileModal ? 'w-10 h-10' : 'w-5 h-5'} text-gray-500`} />
                        </div>
                        <div>
                            {isMobileModal && <h4 className="text-xl font-bold text-white mb-1">Join the Conversation</h4>}
                            <p className="text-xs text-gray-400">Hop in to talk!</p>
                        </div>
                    </div>
                )}
            </div>

            <div className="shrink-0 pt-1">
                 <button 
                    onClick={toggleVoice} 
                    className={`w-full ${isMobileModal ? 'py-4' : 'py-3'} text-xs font-bold uppercase tracking-widest rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 transform active:scale-95 ${isInVoice ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20' : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:brightness-110 shadow-purple-500/20'}`}
                >
                    {isInVoice ? (
                        <>
                            <MicrophoneOffIcon className="w-4 h-4" /> Disconnect
                        </>
                    ) : (
                        <>
                            <MicrophoneIcon className="w-4 h-4" /> Join Voice
                        </>
                    )}
                </button>
            </div>
        </div>
    )
}

interface WatchRoomProps {
  room: Room;
  currentUser: User;
  onLeave: () => void;
  onBlockUser: (userId: number) => void;
  onUnblockUser: (userId: number) => void;
  onUpdateRoomSettings: (roomId: number, newSettings: Partial<Pick<Room, 'isPublic' | 'password' | 'playbackPermissions'>>) => void;
  onUpdateRoom: (room: Room) => void;
  onKickUser: (userId: number) => void;
  onAcceptRequest: (userId: number) => void;
  onDeclineRequest: (userId: number) => void;
  suggestedVideos: SuggestedVideo[];
  friends: Friend[];
  onAddFriend: (userId: number) => { status: 'success' } | { status: 'error', message: string };
  onRateRoom: (roomId: number, rating: number) => void;
  onForwardMessage: (friendIds: number[], message: ChatMessage, comment: string) => void;
  onShareRoom: (friendId: number, room: Room) => void;
  onViewProfile: (user: User) => void;
}

const WatchRoom: React.FC<WatchRoomProps> = (props) => {
    const { room, currentUser, onLeave, onUnblockUser, onUpdateRoomSettings, onUpdateRoom, suggestedVideos, friends, onRateRoom, onForwardMessage, onShareRoom, onKickUser, onAcceptRequest, onDeclineRequest, onViewProfile } = props;
    
    const currentUserRole = useMemo(() => room.users.find(u => u.id === currentUser.id)?.role, [room.users, currentUser.id]);
    const canControlPlayback = useMemo(() => currentUserRole === 'host' || room.playbackPermissions === 'all', [currentUserRole, room.playbackPermissions]);
    const canManageQueue = useMemo(() => ['host', 'dj', 'moderator'].includes(currentUserRole || ''), [currentUserRole]);
    const canManageSettings = useMemo(() => currentUserRole === 'host', [currentUserRole]);
    const isHost = currentUserRole === 'host';
    
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isTheaterMode, setIsTheaterMode] = useState(false);
    const [isVoiceChatOpen, setIsVoiceChatOpen] = useState(false);
    const [forwardingMessage, setForwardingMessage] = useState<ChatMessage | null>(null);
    const [sharingToFriend, setSharingToFriend] = useState<boolean>(false);
    const [hasRated, setHasRated] = useState(false);
    
    // Mobile Rating Modal State
    const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);

    const [activeDesktopTab, setActiveDesktopTab] = useState<'chat' | 'queue' | 'users' | 'suggestions'>('chat');
    const [activeMobileTab, setActiveMobileTab] = useState<'chat' | 'queue' | 'users' | 'suggestions' | 'control'>('chat');
    
    const playerRef = useRef<any>(null);
    const [volume, setVolume] = useState(0.8);
    const [isMuted, setIsMuted] = useState(false);
    const [duration, setDuration] = useState(0);
    const [currentTime, setCurrentTime] = useState(0); // Local state for UI
    const [isPlayerReady, setIsPlayerReady] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    
    const playerContainerRef = useRef<HTMLDivElement>(null);
    const progressUpdateIntervalRef = useRef<number | undefined>(undefined);
    const [showTheaterControls, setShowTheaterControls] = useState(true);
    const theaterControlsTimer = useRef<number | undefined>(undefined);

    const handleUserRate = (rating: number) => {
        onRateRoom(room.id, rating);
        setHasRated(true);
        setIsRatingModalOpen(false); // Close mobile modal if open
    };

    const handleToggleFullscreen = useCallback(() => {
        const elem = playerContainerRef.current;
        if (!elem) return;

        if (!document.fullscreenElement) {
            elem.requestFullscreen().catch(err => {
                console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
            });
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    }, []);

    useEffect(() => {
        const onFullscreenChange = () => {
            setIsFullscreen(!!document.fullscreenElement);
        };
        document.addEventListener('fullscreenchange', onFullscreenChange);
        return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
    }, []);


    // Sync playback for non-hosts
    useEffect(() => {
        if (playerRef.current && isPlayerReady && currentUserRole !== 'host') {
            const playerCurrentTime = playerRef.current.getCurrentTime() || 0;
            const serverTime = room.playbackPosition || 0;
            if (Math.abs(playerCurrentTime - serverTime) > 3) { // Sync if off by >3 seconds
                playerRef.current.seekTo(serverTime, 'seconds');
            }
        }
    }, [room.playbackPosition, isPlayerReady, currentUserRole]);

    const handlePlayerReady = useCallback(() => setIsPlayerReady(true), []);
    
    const handleTogglePlay = useCallback(() => {
        if (!canControlPlayback || !isPlayerReady) return;
        onUpdateRoom({ ...room, isPlaying: !room.isPlaying });
    }, [canControlPlayback, isPlayerReady, room, onUpdateRoom]);

    const handlePlay = useCallback((_e?: any) => {
        if (canControlPlayback && !room.isPlaying) onUpdateRoom({ ...room, isPlaying: true });
    }, [canControlPlayback, room, onUpdateRoom]);

    const handlePause = useCallback((_e?: any) => {
        if (canControlPlayback && room.isPlaying) onUpdateRoom({ ...room, isPlaying: false });
    }, [canControlPlayback, room, onUpdateRoom]);

    const handleProgress = useCallback((state: { played: number; playedSeconds: number }) => {
        setCurrentTime(state.playedSeconds);
        if (currentUserRole === 'host' && isPlayerReady && room.isPlaying) {
            if (!progressUpdateIntervalRef.current) {
                progressUpdateIntervalRef.current = window.setTimeout(() => {
                    onUpdateRoom({ ...room, playbackPosition: state.playedSeconds });
                    progressUpdateIntervalRef.current = undefined;
                }, 2000);
            }
        }
    }, [currentUserRole, isPlayerReady, room, onUpdateRoom]);

    useEffect(() => () => {
        if (progressUpdateIntervalRef.current) clearTimeout(progressUpdateIntervalRef.current);
    }, []);
    
    const handleDuration = useCallback((duration: number) => { setDuration(duration); }, []);

    const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        if (!canControlPlayback || !duration) return;
        const newProgress = parseFloat(e.target.value); 
        const newTime = duration * (newProgress / 100);
        playerRef.current?.seekTo(newTime, 'seconds');
        setCurrentTime(newTime); 
        onUpdateRoom({ ...room, playbackPosition: newTime, isPlaying: true });
    }, [canControlPlayback, duration, room, onUpdateRoom]);

    const handleVolumeChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const newVolume = Number(e.target.value);
        setVolume(newVolume);
        setIsMuted(newVolume === 0);
    }, []);
    
    const handleSeekAmount = useCallback((amount: number) => {
        if (!canControlPlayback || !playerRef.current || !duration) return;
        const newTime = Math.max(0, Math.min(duration, (playerRef.current.getCurrentTime() || 0) + amount));
        playerRef.current.seekTo(newTime, 'seconds');
        setCurrentTime(newTime);
        onUpdateRoom({ ...room, playbackPosition: newTime });
    }, [canControlPlayback, duration, room, onUpdateRoom]);

    const toggleMute = useCallback(() => { setIsMuted(prev => !prev); }, []);

    const hideControls = useCallback(() => {
        if (room.isPlaying) setShowTheaterControls(false);
    }, [room.isPlaying]);

    const showControlsAndAutoHide = useCallback(() => {
        setShowTheaterControls(true);
        if (theaterControlsTimer.current !== undefined) clearTimeout(theaterControlsTimer.current);
        theaterControlsTimer.current = window.setTimeout(hideControls, 3000);
    }, [hideControls]);
    
    useEffect(() => {
        if (isTheaterMode) {
            if (room.isPlaying) {
                showControlsAndAutoHide();
            } else {
                setShowTheaterControls(true);
                if (theaterControlsTimer.current !== undefined) clearTimeout(theaterControlsTimer.current);
            }
        }
        return () => {
            if (theaterControlsTimer.current !== undefined) clearTimeout(theaterControlsTimer.current);
        };
    }, [isTheaterMode, room.isPlaying, showControlsAndAutoHide]);
    
    const handleAddToQueue = (video: SuggestedVideo) => {
      const newQueueItem: VideoQueueItem = {
        id: Date.now(),
        title: video.title,
        url: video.url,
        thumbnail: video.thumbnail,
        addedBy: currentUser,
        votes: 1,
      };
      const updatedQueue = [...(room.videoQueue || []), newQueueItem];
      onUpdateRoom({ ...room, videoQueue: updatedQueue });
      setActiveDesktopTab('queue');
      setActiveMobileTab('queue');
    };

    const handleSkipNext = useCallback(() => {
        if (!canManageQueue || !room.videoQueue || room.videoQueue.length === 0) return;
        const nextVideo = room.videoQueue[0];
        const updatedRoom = {
            ...room,
            nowPlaying: nextVideo.title,
            videoUrl: nextVideo.url,
            videoQueue: room.videoQueue.slice(1),
            playbackPosition: 0,
            isPlaying: true,
        }
        onUpdateRoom(updatedRoom);
    }, [canManageQueue, room, onUpdateRoom]);
    
    const handleReplay = useCallback(() => {
        if (!canControlPlayback) return;
        playerRef.current?.seekTo(0);
        setCurrentTime(0);
        onUpdateRoom({ ...room, playbackPosition: 0, isPlaying: true });
    }, [canControlPlayback, room, onUpdateRoom]);
    
    const handleSetUserRole = useCallback((userId: number, role: UserRole) => {
        const updatedUsers = room.users.map(u => u.id === userId ? { ...u, role } : u);
        onUpdateRoom({ ...room, users: updatedUsers });
    }, [room, onUpdateRoom]);
    
    const tabs = [
        { id: 'chat', label: 'Chat', icon: <ChatIcon className="w-5 h-5"/> },
        { id: 'queue', label: 'Queue', icon: <QueueIcon className="w-5 h-5"/>, count: room.videoQueue?.length || 0 },
        { id: 'users', label: 'Users', icon: <UsersIcon className="w-5 h-5"/>, count: room.users.length },
        { id: 'suggestions', label: 'Suggest', icon: <LightbulbIcon className="w-5 h-5"/> },
        ...(isHost ? [{ id: 'control', label: 'Control', icon: <FilmReelIcon className="w-5 h-5"/> }] : []),
    ];

    const DesktopTabButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string; count?: number; }> = ({ active, onClick, icon, label, count }) => (
        <button 
            onClick={onClick} 
            className={`
                flex-1 flex items-center justify-center gap-2 py-2.5 px-2 rounded-xl transition-all duration-300 relative group
                ${active 
                    ? 'bg-white/10 text-white shadow-lg backdrop-blur-md border border-white/10' 
                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
                }
            `}
        >
            <div className={`transition-colors ${active ? 'text-[var(--theme-color)]' : 'group-hover:text-white'}`}>
                {icon}
            </div>
            <span className="text-xs font-bold tracking-wide hidden xl:block">{label}</span>
            
            {count !== undefined && count > 0 && (
                <span className={`
                    absolute top-1 right-1 flex h-2 w-2
                `}>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[var(--theme-color)] opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[var(--theme-color)]"></span>
                </span>
            )}
        </button>
    );

    const MobileTabButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string; count?: number; }> = ({ active, onClick, icon, label, count }) => (
        <button onClick={onClick} className={`flex-1 flex flex-col items-center justify-center p-3 transition-all relative ${active ? 'text-[var(--theme-color)]' : 'text-gray-400 hover:text-gray-200'}`}>
            <div className={`transition-transform duration-300 ${active ? 'scale-110' : ''}`}>
                {icon}
            </div>
            {active && <div className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-[var(--theme-color)] rounded-t-full shadow-[0_0_8px_var(--theme-color)]"></div>}
            {count !== undefined && count > 0 && <div className="absolute top-2 right-1/4 w-4 h-4 bg-[var(--theme-color)] text-white text-[10px] font-bold rounded-full flex items-center justify-center border border-[#121212] shadow-sm">{count}</div>}
       </button>
   );

    const DesktopLayout = () => (
        <div className="hidden h-full md:flex flex-row w-full overflow-hidden">
            {/* Main Content Area (Video + Widgets) */}
            <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 relative z-10 ${isTheaterMode ? 'w-full' : ''}`}>
                 <div className="flex-1 overflow-y-auto custom-scrollbar p-4 lg:p-6">
                    <div className={`flex flex-col gap-6 max-w-[1800px] mx-auto ${isTheaterMode ? 'h-full justify-center' : ''}`}>
                        {/* Header */}
                        <div className={`flex-shrink-0 flex justify-between items-center gap-4 ${isTheaterMode ? 'absolute top-6 right-6 z-50 w-auto p-0' : ''}`}>
                            {!isTheaterMode && (
                                 <div className="min-w-0">
                                    <h2 className="text-2xl font-bold text-white truncate drop-shadow-md">{room.nowPlaying}</h2>
                                    <p className="text-gray-400 text-sm font-medium">Hosted by {room.users.find(u => u.role === 'host')?.name}</p>
                                </div>
                            )}
                            
                            <div className="flex items-center gap-2">
                                <button onClick={() => setSharingToFriend(true)} className={`p-2.5 rounded-xl transition-colors backdrop-blur-md border border-white/10 ${isTheaterMode ? 'bg-black/50 hover:bg-black/70 text-white' : 'bg-white/10 hover:bg-white/20 text-gray-200'}`} title="Share"><LinkIcon className="w-5 h-5"/></button>
                                <button onClick={() => setIsTheaterMode(!isTheaterMode)} className={`p-2.5 rounded-xl transition-colors backdrop-blur-md border border-white/10 ${isTheaterMode ? 'bg-black/50 hover:bg-black/70 text-white' : 'bg-white/10 hover:bg-white/20 text-gray-200'}`} title={isTheaterMode ? "Exit Theater Mode" : "Theater Mode"}><TheaterModeIcon className="w-5 h-5"/></button>
                                {!isTheaterMode && (
                                    <>
                                        {canManageSettings && <button onClick={() => setIsSettingsOpen(true)} className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-gray-200 backdrop-blur-md border border-white/10" title="Settings"><SettingsIcon className="w-5 h-5"/></button>}
                                        <button onClick={onLeave} className="px-5 py-2.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 font-bold rounded-xl transition-colors border border-red-500/20 backdrop-blur-md">Leave</button>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* Video Player */}
                        <div className={`relative w-full ${isTheaterMode ? 'h-full flex-1' : 'aspect-video'} rounded-3xl overflow-hidden shadow-2xl shadow-black/50 ring-1 ring-white/10 transform transition-all duration-500`} onMouseMove={isTheaterMode ? showControlsAndAutoHide : undefined} ref={playerContainerRef}>
                            <VideoPlayer
                                room={room}
                                canControlPlayback={canControlPlayback}
                                isTheaterMode={isTheaterMode}
                                playerRef={playerRef}
                                volume={volume}
                                isMuted={isMuted}
                                isReady={isPlayerReady}
                                onReady={handlePlayerReady}
                                onProgress={handleProgress}
                                onDuration={handleDuration}
                                onPlay={handlePlay}
                                onPause={handlePause}
                                onSeek={handleSeek}
                                onVolumeChange={handleVolumeChange}
                                onToggleMute={toggleMute}
                                onTogglePlay={handleTogglePlay}
                                onSeekForward={() => handleSeekAmount(10)}
                                onSeekBackward={() => handleSeekAmount(-10)}
                                currentTime={currentTime}
                                duration={duration}
                                isFullscreen={isFullscreen}
                                onToggleFullscreen={handleToggleFullscreen}
                            />
                             {isTheaterMode && (
                                <div className={`absolute inset-0 bg-black/40 flex items-center justify-center gap-8 transition-opacity duration-300 z-30 ${showTheaterControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                                    {canControlPlayback && <button onClick={handleReplay} className="text-white p-4 bg-white/10 border border-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition-all transform hover:scale-110"><ReplyIcon className="w-8 h-8" /></button>}
                                    {canControlPlayback && <button onClick={handleTogglePlay} className="text-white p-6 bg-white/10 border border-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition-all transform hover:scale-110">{room.isPlaying ? <PauseIcon className="w-12 h-12" /> : <PlayIcon className="w-12 h-12" />}</button>}
                                    {canManageQueue && room.videoQueue && room.videoQueue.length > 0 && <button onClick={handleSkipNext} className="text-white p-4 bg-white/10 border border-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition-all transform hover:scale-110"><SkipNextIcon className="w-8 h-8" /></button>}
                                </div>
                            )}
                            {isTheaterMode && (
                                <div className={`absolute bottom-6 right-6 transition-opacity duration-300 z-30 ${showTheaterControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                                    <button onClick={handleToggleFullscreen} className="text-white p-3 bg-black/50 backdrop-blur-md border border-white/10 rounded-full hover:bg-black/70">
                                        {isFullscreen ? <FullscreenExitIcon className="w-6 h-6" /> : <FullscreenEnterIcon className="w-6 h-6" />}
                                    </button>
                                </div>
                            )}
                            <EmojiReactions />
                        </div>

                         {/* Bottom Widgets */}
                        {!isTheaterMode && (
                            <div className="w-full mt-6 grid grid-cols-1 xl:grid-cols-12 gap-6 pb-10">
                                 {/* Left Column: Rating & Now Playing */}
                                 <div className="xl:col-span-7 flex flex-col gap-4">
                                     {currentUserRole === 'host' && <NowPlayingManager room={room} onSkipNext={handleSkipNext} />}
                                     
                                     {/* Replaced Accordion Rating with dedicated card */}
                                     <div className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-3xl p-5 flex items-center justify-between shadow-lg relative overflow-hidden">
                                         {/* Decorative background glow */}
                                         <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--theme-color)] opacity-5 blur-[50px] pointer-events-none"></div>

                                         <div className="flex flex-col gap-2 relative z-10">
                                             <div>
                                                 <h3 className="text-white font-bold text-lg leading-tight">Rate this Room</h3>
                                                 <p className="text-gray-400 text-xs font-medium">
                                                     {hasRated ? "Thanks for your feedback!" : "How are you enjoying the party?"}
                                                 </p>
                                             </div>
                                             
                                             {/* Raters Avatars */}
                                             <div className="flex items-center gap-3">
                                                 <div className="flex -space-x-2">
                                                     {/* Mocking raters with room users for display purposes, as backend data isn't real */}
                                                     {room.users.slice(0, 3).map((u, i) => (
                                                         <img 
                                                             key={u.id} 
                                                             src={u.avatar} 
                                                             className="inline-block h-6 w-6 rounded-full ring-2 ring-[#18181b] object-cover" 
                                                             alt={u.name}
                                                             style={{ zIndex: 3 - i }}
                                                         />
                                                     ))}
                                                 </div>
                                                 {(room.totalRatings || 0) > 3 && (
                                                     <span className="text-[10px] text-gray-500 font-medium">
                                                         +{ (room.totalRatings || 0) - 3 } others rated
                                                     </span>
                                                 )}
                                             </div>
                                         </div>
                                         
                                         <div className="relative z-10">
                                             {hasRated ? (
                                                 <RoomRating rating={room.rating} totalRatings={room.totalRatings} size="lg" />
                                             ) : (
                                                 <RoomRating rating={room.rating} totalRatings={room.totalRatings} onRate={handleUserRate} interactive size="lg" />
                                             )}
                                         </div>
                                     </div>
                                 </div>

                                 {/* Right Column: Voice Chat */}
                                 <div className="xl:col-span-5 h-full">
                                    <VoiceChatPanel room={room} currentUser={currentUser} onUpdateRoom={onUpdateRoom} />
                                 </div>
                            </div>
                        )}
                    </div>
                 </div>
            </div>

            {/* Right Panel (Chat) */}
            <div className={`flex flex-col w-80 lg:w-96 xl:w-[24rem] 2xl:w-[28rem] bg-black/20 backdrop-blur-2xl border-l border-white/5 flex-shrink-0 transition-all duration-500 ease-in-out relative z-20 ${isTheaterMode ? 'mr-[-28rem] opacity-0' : 'mr-0 opacity-100'} shadow-2xl`}>
                 {/* Tabs Header */}
                 <div className="p-4 pb-2 flex-shrink-0 z-10">
                     <div className="flex items-center bg-black/40 p-1 rounded-2xl border border-white/5 shadow-inner">
                         {tabs.filter(t => t.id !== 'control').map(tab => (
                            <DesktopTabButton 
                                key={tab.id}
                                active={activeDesktopTab === tab.id}
                                onClick={() => setActiveDesktopTab(tab.id as any)}
                                icon={tab.icon}
                                label={tab.label}
                                count={tab.count}
                            />
                         ))}
                    </div>
                </div>

                 <div className="flex-1 min-h-0 relative">
                     <div className="absolute inset-0 overflow-hidden flex flex-col">
                        {/* Use display:none instead of unmounting to prevent audio interruption */}
                        <div className={`h-full w-full flex flex-col ${activeDesktopTab === 'chat' ? 'flex' : 'hidden'}`}>
                            <RoomChatPanel room={room} currentUser={currentUser} onUpdateRoom={onUpdateRoom} onViewProfile={onViewProfile} onForward={setForwardingMessage} />
                        </div>
                        {activeDesktopTab === 'queue' && <VideoQueuePanel room={room} onUpdateRoom={onUpdateRoom} canManageQueue={canManageQueue} />}
                        {activeDesktopTab === 'users' && (
                            <div className="flex-1 overflow-y-auto custom-scrollbar">
                                <UserList users={room.users} currentUser={currentUser} currentUserRole={currentUserRole} onViewProfile={onViewProfile} onSetUserRole={handleSetUserRole} onKickUser={onKickUser} />
                            </div>
                        )}
                        {activeDesktopTab === 'suggestions' && <VideoSuggestions suggestions={suggestedVideos} onAddToQueue={handleAddToQueue} />}
                     </div>
                 </div>
            </div>
        </div>
    );
    
    const MobileLayout = () => (
         <div className={`md:hidden h-full w-full flex flex-col overflow-hidden relative ${isTheaterMode ? 'bg-black justify-center' : ''}`}>
            {!isTheaterMode && (
                <header className="flex-shrink-0 p-3 flex items-center justify-between z-20 bg-black/60 backdrop-blur-lg border-b border-white/10 absolute top-0 left-0 right-0">
                    <div className="flex items-center gap-3 min-w-0">
                        <button onClick={onLeave} className="text-white p-2 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md"><ArrowLeftIcon className="w-5 h-5" /></button>
                        <h2 className="text-sm font-bold text-white truncate pr-2 drop-shadow-md">{room.name}</h2>
                    </div>
                    <div className="flex items-center gap-1">
                        {!hasRated && (
                            <button onClick={() => setIsRatingModalOpen(true)} className="p-2 text-yellow-400 hover:text-yellow-300 bg-white/5 rounded-full">
                                <StarIcon className="w-5 h-5" />
                            </button>
                        )}
                        <button onClick={() => setIsVoiceChatOpen(true)} className="p-2 text-gray-200 hover:text-white bg-white/5 rounded-full"><HeadphonesIcon className="w-5 h-5" /></button>
                        <button onClick={() => setIsTheaterMode(true)} className="p-2 text-gray-200 hover:text-white bg-white/5 rounded-full"><TheaterModeIcon className="w-5 h-5" /></button>
                        {canManageSettings && <button onClick={() => setIsSettingsOpen(true)} className="p-2 text-gray-200 hover:text-white bg-white/5 rounded-full"><SettingsIcon className="w-5 h-5" /></button>}
                    </div>
                </header>
            )}
             
             {/* Video Section */}
             <div className={`flex-shrink-0 w-full ${isTheaterMode ? 'h-full flex items-center bg-black z-30' : 'aspect-video bg-black pt-[60px] z-10'}`}>
                 <div className={`relative w-full ${isTheaterMode ? 'h-full' : 'h-full rounded-b-2xl overflow-hidden shadow-2xl'}`} onClick={isTheaterMode ? showControlsAndAutoHide : undefined} ref={playerContainerRef}>
                    <VideoPlayer
                        room={room} canControlPlayback={canControlPlayback} isTheaterMode={isTheaterMode} playerRef={playerRef}
                        volume={volume} isMuted={isMuted}
                        isReady={isPlayerReady} onReady={handlePlayerReady} onProgress={handleProgress}
                        onDuration={handleDuration} onPlay={handlePlay} onPause={handlePause}
                        onSeek={handleSeek} onVolumeChange={handleVolumeChange} onToggleMute={toggleMute}
                        onTogglePlay={handleTogglePlay} 
                        onSeekForward={() => handleSeekAmount(10)}
                        onSeekBackward={() => handleSeekAmount(-10)}
                        currentTime={currentTime} duration={duration}
                        isFullscreen={isFullscreen}
                        onToggleFullscreen={handleToggleFullscreen}
                    />
                    {isTheaterMode && (
                        <div className={`absolute inset-0 bg-black/40 flex items-center justify-center gap-6 transition-opacity duration-300 z-30 ${showTheaterControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                            {canControlPlayback && <button onClick={handleTogglePlay} className="text-white p-4 bg-white/10 border border-white/10 rounded-full backdrop-blur-md">{room.isPlaying ? <PauseIcon className="w-10 h-10" /> : <PlayIcon className="w-10 h-10" />}</button>}
                        </div>
                    )}
                    <EmojiReactions />
                    {isTheaterMode && (
                        <>
                            <button onClick={() => setIsTheaterMode(false)} className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white z-30 backdrop-blur-md border border-white/10" title="Exit Theater Mode"><CloseIcon className="w-6 h-6" /></button>
                            <div className={`absolute bottom-6 right-6 transition-opacity duration-300 z-30 ${showTheaterControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                                <button onClick={handleToggleFullscreen} className="text-white p-3 bg-black/50 rounded-full backdrop-blur-md border border-white/10">
                                    {isFullscreen ? <FullscreenExitIcon className="w-6 h-6" /> : <FullscreenEnterIcon className="w-6 h-6" />}
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>

            {/* Tabbed Content */}
            {!isTheaterMode && (
                 <div className="flex-1 flex flex-col min-h-0 bg-transparent relative z-0">
                    <div className="flex border-b border-white/10 flex-shrink-0 bg-black/40 backdrop-blur-md">
                        {tabs.map(tab => (
                            <MobileTabButton 
                                key={tab.id}
                                active={activeMobileTab === tab.id}
                                onClick={() => setActiveMobileTab(tab.id as any)}
                                icon={tab.icon}
                                label={tab.label}
                                count={tab.count}
                            />
                        ))}
                    </div>
                     <div className="flex-1 min-h-0 relative">
                        <div className="absolute inset-0 overflow-hidden flex flex-col">
                            {/* Use display:none instead of unmounting to prevent audio interruption */}
                            <div className={`h-full w-full flex flex-col ${activeMobileTab === 'chat' ? 'flex' : 'hidden'}`}>
                                <RoomChatPanel room={room} currentUser={currentUser} onUpdateRoom={onUpdateRoom} onViewProfile={onViewProfile} onForward={setForwardingMessage}/>
                            </div>
                            {activeMobileTab === 'queue' && <VideoQueuePanel room={room} onUpdateRoom={onUpdateRoom} canManageQueue={canManageQueue} />}
                            {activeMobileTab === 'users' && (
                                <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
                                    <UserList users={room.users} currentUser={currentUser} currentUserRole={currentUserRole} onViewProfile={onViewProfile} onSetUserRole={handleSetUserRole} onKickUser={onKickUser} />
                                </div>
                            )}
                            {activeMobileTab === 'suggestions' && <VideoSuggestions suggestions={suggestedVideos} onAddToQueue={handleAddToQueue} />}
                            
                            {/* Mobile Control Tab for Host */}
                            {isHost && activeMobileTab === 'control' && (
                                <MobileNowPlayingPanel room={room} onSkipNext={handleSkipNext} />
                            )}
                        </div>
                     </div>
                 </div>
            )}
        </div>
    );

    return (
        <div className="h-full w-full overflow-hidden relative">
            <DesktopLayout />
            <MobileLayout />
            
            {forwardingMessage && <ForwardMessageModal isOpen={!!forwardingMessage} onClose={() => setForwardingMessage(null)} friends={friends} onForward={(friendIds, comment) => { onForwardMessage(friendIds, forwardingMessage!, comment || ''); setForwardingMessage(null); }} />}
            {sharingToFriend && <ForwardMessageModal isOpen={sharingToFriend} onClose={() => setSharingToFriend(false)} friends={friends} isSharingRoom onForward={(friendIds, comment) => { onShareRoom(friendIds[0], room); setSharingToFriend(false); }} />}


            {isVoiceChatOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[60] animate-fade-in md:hidden flex flex-col justify-end pb-safe">
                    <div className="bg-[#121214] rounded-t-3xl overflow-hidden h-[60vh] border-t border-white/10 shadow-2xl">
                        <VoiceChatPanel room={room} currentUser={currentUser} onUpdateRoom={onUpdateRoom} onClose={() => setIsVoiceChatOpen(false)} />
                    </div>
                </div>
            )}
            
            {/* Mobile Rating Modal */}
            {isRatingModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[70] flex items-center justify-center p-4 animate-fade-in" onClick={() => setIsRatingModalOpen(false)}>
                    <div className="bg-[#18181b] border border-white/10 rounded-3xl p-6 w-full max-w-xs text-center shadow-2xl animate-fade-in-up" onClick={e => e.stopPropagation()}>
                        <h3 className="text-xl font-bold text-white mb-2">Rate Room</h3>
                        <p className="text-gray-400 text-sm mb-6">How are you enjoying {room.name}?</p>
                        <div className="flex justify-center mb-6">
                            <RoomRating interactive onRate={handleUserRate} size="lg" />
                        </div>
                        <button onClick={() => setIsRatingModalOpen(false)} className="text-gray-500 text-sm font-bold">Maybe Later</button>
                    </div>
                </div>
            )}
            
            {canManageSettings && <RoomSettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} room={room} onUpdateSettings={onUpdateRoomSettings} onUnblockUser={onUnblockUser} onAcceptRequest={onAcceptRequest} onDeclineRequest={onDeclineRequest} />}
             <style>{`
                .custom-scrollbar::-webkit-scrollbar { width: 4px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 2px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.3); }
            `}</style>
        </div>
    );
};

export default WatchRoom;
