
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { SelectIcon, PlusIcon, CheckIcon, LockClosedIcon, MagicWandIcon } from './icons';
import type { ChatBackground } from '../types';

interface ChatAppearanceSettingsProps {
    currentBackground: ChatBackground;
    onBackgroundChange: (bg: ChatBackground) => void;
    isUserPremium: boolean;
    onOpenPremium: () => void;
}

const categories = [
    { 
        id: 'gradients', 
        label: 'Gradients', 
        items: [
            { id: 'midnight', name: 'Midnight', className: 'chat-bg-midnight', isPremium: true },
            { id: 'aurora', name: 'Aurora', className: 'chat-bg-aurora', isPremium: true },
            { id: 'sunset', name: 'Sunset', className: 'chat-bg-sunset', isPremium: true },
            { id: 'nebula', name: 'Nebula', className: 'chat-bg-nebula', isPremium: true },
            { id: 'royal', name: 'Royal', className: 'chat-bg-royal', isPremium: true },
            { id: 'warmth', name: 'Warmth', className: 'chat-bg-warmth', isPremium: true },
        ]
    },
    { 
        id: 'patterns', 
        label: 'Patterns', 
        items: [
            { id: 'glass', name: 'Glass', className: 'chat-bg-glass', isPremium: false },
            { id: 'default', name: 'Classic Dots', className: 'chat-bg', isPremium: true },
            { id: 'hex', name: 'Hexagons', className: 'chat-bg-hex', isPremium: true },
            { id: 'blueprint', name: 'Blueprint', className: 'chat-bg-blueprint', isPremium: true },
            { id: 'minimal', name: 'Minimal Grid', className: 'chat-bg-minimal', isPremium: true },
            { id: 'circuit', name: 'Circuit', className: 'chat-bg-circuit', isPremium: true },
            { id: 'carbon', name: 'Carbon', className: 'chat-bg-carbon', isPremium: true },
        ]
    },
    { 
        id: 'artistic', 
        label: 'Artistic', 
        items: [
            { id: 'space', name: 'Cosmic', className: 'chat-bg-space', isPremium: true },
            { id: 'dnd', name: 'Fantasy Map', className: 'chat-bg-dnd', isPremium: true },
            { id: 'dark-mosaic', name: 'Mosaic', className: 'chat-bg-dark-mosaic', isPremium: true },
            { id: 'social', name: 'Social', className: 'chat-bg-social', isPremium: true },
            { id: 'abstract', name: 'Abstract', className: 'chat-bg-abstract', isPremium: true },
        ]
    }
];

const PreviewBubble: React.FC<{ isSent: boolean; text: string }> = ({ isSent, text }) => (
    <div className={`flex w-full ${isSent ? 'justify-end' : 'justify-start'}`}>
        <div 
            className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm shadow-sm ${
                isSent 
                    ? 'text-white rounded-tr-sm' 
                    : 'bg-[#2f2b43] text-gray-200 rounded-tl-sm'
            }`}
            style={isSent ? { backgroundColor: 'var(--theme-color)' } : undefined}
        >
            {text}
        </div>
    </div>
);

const ChatAppearanceSettings: React.FC<ChatAppearanceSettingsProps> = ({ currentBackground, onBackgroundChange, isUserPremium, onOpenPremium }) => {
    const [activeTab, setActiveTab] = useState('gradients');
    // Preview State: Defaults to current background, but can change temporarily for preview
    const [previewBackground, setPreviewBackground] = useState<ChatBackground>(currentBackground);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Ensure preview stays in sync if currentBackground changes externally
    useEffect(() => {
        setPreviewBackground(currentBackground);
    }, [currentBackground]);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const result = e.target?.result as string;
                if(result) {
                    const bgValue = `url(${result})`;
                    const newBg: ChatBackground = { type: 'custom', value: bgValue };
                    setPreviewBackground(newBg);
                    onBackgroundChange(newBg);
                }
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSelectBackground = (type: 'class' | 'custom', value: string, isPremium: boolean = false) => {
        // 1. Update Preview immediately so user can see it
        if (type === 'custom') {
             // For custom, check premium first before file input
             if (!isUserPremium) {
                 onOpenPremium();
                 return;
             }
             if (value === 'trigger-input') {
                 fileInputRef.current?.click();
             }
        } else {
            // Show preview
            setPreviewBackground({ type: 'class', value });
            
            // 2. Apply if allowed, otherwise just show preview (lock logic is handled in UI)
            if (!isPremium || isUserPremium) {
                onBackgroundChange({ type: 'class', value });
            }
        }
    };

    const isSelected = (className: string) => {
        return currentBackground.type === 'class' && currentBackground.value === className;
    };
    
    const isPreviewing = (className: string) => {
         return previewBackground.type === 'class' && previewBackground.value === className;
    }

    const isCustomSelected = currentBackground.type === 'custom';
    
    // Check if the currently PREVIEWED background is locked for the user
    const isPreviewLocked = useMemo(() => {
        if (previewBackground.type === 'custom') return !isUserPremium;
        const theme = categories.flatMap(c => c.items).find(i => i.className === previewBackground.value);
        return theme?.isPremium && !isUserPremium;
    }, [previewBackground, isUserPremium]);

    const getPreviewStyle = () => {
        if (previewBackground.type === 'custom') {
            return { backgroundImage: previewBackground.value, backgroundSize: 'cover', backgroundPosition: 'center' };
        }
        return {};
    };

    return (
        <div className="space-y-8">
            {/* Live Preview */}
            <div className="relative">
                <div className="flex items-center justify-between mb-4">
                     <h2 className="text-xl font-bold text-white">Live Preview</h2>
                     {isPreviewLocked && (
                         <span className="text-xs font-bold text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded-md border border-yellow-400/20 animate-pulse">
                             Premium Theme Preview
                         </span>
                     )}
                </div>
               
                <div 
                    className={`w-full h-64 rounded-3xl border border-white/10 overflow-hidden relative flex flex-col justify-end p-4 gap-3 shadow-2xl transition-all duration-500 ${previewBackground.type === 'class' ? previewBackground.value : ''}`}
                    style={getPreviewStyle()}
                >
                    {/* Mock Header */}
                    <div className="absolute top-0 left-0 right-0 p-4 bg-black/20 backdrop-blur-md border-b border-white/5 flex items-center gap-3 z-10">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-cyan-300"></div>
                        <div className="h-2.5 w-24 bg-white/20 rounded-full"></div>
                    </div>
                    
                    {/* Lock Overlay if Previewing Locked Content */}
                    {isPreviewLocked && (
                        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-20 flex flex-col items-center justify-center text-center p-6 animate-fade-in">
                            <LockClosedIcon className="w-12 h-12 text-yellow-400 mb-3 drop-shadow-lg" />
                            <h3 className="text-lg font-bold text-white mb-1">Unlock this Theme</h3>
                            <p className="text-xs text-gray-300 mb-4 max-w-xs">Get Premium to use this background in your chats.</p>
                            <button 
                                onClick={onOpenPremium}
                                className="px-6 py-2.5 bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold rounded-xl shadow-lg hover:shadow-yellow-500/30 transition-transform active:scale-95 text-sm flex items-center gap-2"
                            >
                                <MagicWandIcon className="w-4 h-4" /> Unlock Now
                            </button>
                        </div>
                    )}

                    <div className="relative z-0 w-full flex flex-col gap-3">
                         <PreviewBubble isSent={false} text="Hey! Do you like this new wallpaper?" />
                         <PreviewBubble isSent={true} text="Yeah, it looks amazing! ✨" />
                    </div>
                </div>
            </div>

            {/* Background Selection */}
            <div>
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-white">Choose Background</h2>
                    {!isUserPremium && (
                         <button onClick={onOpenPremium} className="text-xs font-bold text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded-md hover:bg-yellow-400/20 transition-colors border border-yellow-400/20">
                             Go Premium
                         </button>
                    )}
                </div>

                {/* Tabs */}
                <div className="flex p-1 bg-black/30 rounded-xl mb-6 border border-white/5 overflow-x-auto hide-scrollbar">
                    {categories.map(cat => (
                        <button
                            key={cat.id}
                            onClick={() => setActiveTab(cat.id)}
                            className={`flex-1 py-2 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                                activeTab === cat.id 
                                    ? 'bg-[var(--theme-color)] text-white shadow-lg shadow-[var(--theme-color)]/20' 
                                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                            }`}
                        >
                            {cat.label}
                        </button>
                    ))}
                    <button
                        onClick={() => setActiveTab('custom')}
                        className={`flex-1 py-2 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                            activeTab === 'custom'
                                ? 'bg-[var(--theme-color)] text-white shadow-lg shadow-[var(--theme-color)]/20' 
                                : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                    >
                        Custom
                    </button>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 animate-fade-in pb-10">
                    {activeTab === 'custom' ? (
                        <div className="col-span-full">
                            <div 
                                onClick={() => handleSelectBackground('custom', 'trigger-input', true)}
                                className={`relative aspect-video w-full rounded-2xl border-2 border-dashed transition-all cursor-pointer group overflow-hidden flex flex-col items-center justify-center gap-3 ${isCustomSelected ? 'border-[var(--theme-color)] bg-[var(--theme-color)]/10' : 'border-white/20 hover:border-white/40 hover:bg-white/5'}`}
                            >
                                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" disabled={!isUserPremium} />
                                
                                {currentBackground.type === 'custom' ? (
                                    <>
                                        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: currentBackground.value }}></div>
                                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            <span className="bg-black/60 px-4 py-2 rounded-full text-sm font-bold backdrop-blur-md">{!isUserPremium ? 'Unlock to Change' : 'Change Image'}</span>
                                        </div>
                                    </>
                                ) : (
                                    <>
                                        <div className="p-4 bg-white/5 rounded-full group-hover:scale-110 transition-transform">
                                            <PlusIcon className="w-8 h-8 text-gray-400 group-hover:text-white" />
                                        </div>
                                        <p className="text-sm text-gray-400 font-medium">Upload from device</p>
                                    </>
                                )}
                                
                                {isCustomSelected && (
                                    <div className="absolute top-3 right-3 bg-[var(--theme-color)] text-white p-1 rounded-full shadow-lg">
                                        <CheckIcon className="w-4 h-4" />
                                    </div>
                                )}
                                
                                {!isUserPremium && (
                                     <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm text-white/80 p-1.5 rounded-full shadow-lg z-10">
                                        <LockClosedIcon className="w-4 h-4" />
                                    </div>
                                )}
                            </div>
                            <p className="text-xs text-gray-500 mt-3 text-center">
                                Supported formats: JPG, PNG, WEBP. Max size: 5MB.
                            </p>
                        </div>
                    ) : (
                        categories.find(c => c.id === activeTab)?.items.map(bg => {
                             const selected = isSelected(bg.className);
                             const previewing = isPreviewing(bg.className);
                             const locked = bg.isPremium && !isUserPremium;

                             return (
                                <button 
                                    key={bg.id}
                                    onClick={() => handleSelectBackground('class', bg.className, bg.isPremium)}
                                    className={`
                                        relative aspect-[3/4] sm:aspect-square w-full rounded-2xl overflow-hidden border-2 transition-all group
                                        ${selected 
                                            ? 'border-[var(--theme-color)] shadow-[0_0_20px_color-mix(in srgb, var(--theme-color), transparent 70%)] scale-[1.02]' 
                                            : previewing 
                                                ? 'border-white/50 scale-[1.01]'
                                                : 'border-transparent hover:border-white/30'
                                        }
                                    `}
                                >
                                    <div className={`absolute inset-0 ${bg.className}`}></div>
                                    
                                    {/* Label */}
                                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent text-left">
                                        <span className="text-xs font-bold text-white shadow-sm">{bg.name}</span>
                                    </div>

                                    {/* Selected Indicator */}
                                    {selected && (
                                        <div className="absolute top-3 right-3 bg-[var(--theme-color)] text-white p-1 rounded-full shadow-lg animate-bounce-in">
                                            <CheckIcon className="w-3 h-3" />
                                        </div>
                                    )}

                                    {/* Lock Indicator */}
                                    {locked && (
                                        <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm text-yellow-400 p-1.5 rounded-full shadow-lg z-10">
                                            <LockClosedIcon className="w-3.5 h-3.5" />
                                        </div>
                                    )}
                                    
                                    {/* Hover Overlay if Locked */}
                                    {locked && (
                                         <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                             <span className="text-[10px] font-bold bg-black/60 text-white px-2 py-1 rounded-md backdrop-blur-md">Preview</span>
                                         </div>
                                    )}
                                </button>
                            );
                        })
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChatAppearanceSettings;
