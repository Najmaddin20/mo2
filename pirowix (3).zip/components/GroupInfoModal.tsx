
import React, { useState, useRef } from 'react';
import type { Conversation, User } from '../types';
import { CloseIcon, CameraIcon, TrashIcon, CrownIcon, MoreVertIcon, BlockUserIcon, UserAddIcon, EditIcon } from './icons';

interface GroupInfoModalProps {
    isOpen: boolean;
    onClose: () => void;
    conversation: Conversation;
    currentUser: User;
    onUpdateGroup: (updates: Partial<Conversation>) => void;
    onDeleteGroup: () => void;
    onLeaveGroup: () => void;
    onPromoteMember: (userId: number) => void;
    onDemoteMember: (userId: number) => void;
    onKickMember: (userId: number) => void;
}

const GroupInfoModal: React.FC<GroupInfoModalProps> = ({ 
    isOpen, onClose, conversation, currentUser, onUpdateGroup, onDeleteGroup, onLeaveGroup, onPromoteMember, onDemoteMember, onKickMember 
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [groupName, setGroupName] = useState(conversation.friend.name);
    const [description, setDescription] = useState(conversation.description || '');
    const [activeTab, setActiveTab] = useState<'members' | 'media'>('members');
    const [memberMenuOpen, setMemberMenuOpen] = useState<number | null>(null);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const amIOwner = conversation.groupOwnerId === currentUser.id;
    const amIAdmin = amIOwner || (conversation.adminIds || []).includes(currentUser.id);

    const handleSave = () => {
        onUpdateGroup({ 
            friend: { ...conversation.friend, name: groupName }, 
            description 
        });
        setIsEditing(false);
    };

    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            onUpdateGroup({ friend: { ...conversation.friend, avatar: url } });
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md" onClick={onClose}>
            <div className="bg-[#18181b] w-full max-w-md rounded-3xl shadow-2xl border border-white/10 overflow-hidden flex flex-col max-h-[85vh]" onClick={e => e.stopPropagation()}>
                
                {/* Header Image / Avatar */}
                <div className="relative h-32 bg-gradient-to-br from-indigo-600 to-purple-700 flex items-end justify-center pb-6 shrink-0">
                    <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-black/30 rounded-full text-white hover:bg-black/50 transition-colors">
                        <CloseIcon className="w-5 h-5" />
                    </button>
                    
                    <div className="relative translate-y-1/2 group">
                        <img src={conversation.friend.avatar} alt={groupName} className="w-24 h-24 rounded-full border-4 border-[#18181b] object-cover bg-black" />
                        {amIAdmin && (
                            <button 
                                onClick={() => fileInputRef.current?.click()}
                                className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <CameraIcon className="w-6 h-6 text-white" />
                            </button>
                        )}
                        <input type="file" ref={fileInputRef} onChange={handleAvatarChange} className="hidden" accept="image/*" />
                    </div>
                </div>

                {/* Info Section */}
                <div className="pt-12 px-6 pb-4 text-center shrink-0">
                    {isEditing ? (
                        <div className="space-y-3">
                            <input 
                                value={groupName} 
                                onChange={e => setGroupName(e.target.value)} 
                                className="bg-white/10 text-center text-xl font-bold text-white rounded-lg w-full p-1 focus:outline-none focus:ring-2 focus:ring-purple-500" 
                            />
                            <textarea 
                                value={description} 
                                onChange={e => setDescription(e.target.value)} 
                                className="bg-white/10 text-center text-sm text-gray-300 rounded-lg w-full p-2 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500"
                                placeholder="Group Description"
                            />
                            <div className="flex justify-center gap-2">
                                <button onClick={handleSave} className="px-4 py-1.5 bg-green-500 text-white rounded-md text-sm font-bold">Save</button>
                                <button onClick={() => setIsEditing(false)} className="px-4 py-1.5 bg-white/10 text-white rounded-md text-sm font-bold">Cancel</button>
                            </div>
                        </div>
                    ) : (
                        <>
                            <h2 className="text-2xl font-bold text-white flex items-center justify-center gap-2">
                                {groupName}
                                {amIAdmin && <button onClick={() => setIsEditing(true)}><EditIcon className="w-4 h-4 text-gray-500 hover:text-white" /></button>}
                            </h2>
                            <p className="text-sm text-gray-400 mt-1">{description || `${(conversation.participants || []).length} members`}</p>
                        </>
                    )}
                </div>

                {/* Tabs */}
                <div className="flex border-b border-white/10 shrink-0">
                    <button onClick={() => setActiveTab('members')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'members' ? 'text-purple-400 border-b-2 border-purple-400' : 'text-gray-400 hover:text-white'}`}>Members</button>
                    <button onClick={() => setActiveTab('media')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'media' ? 'text-purple-400 border-b-2 border-purple-400' : 'text-gray-400 hover:text-white'}`}>Media</button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                    {activeTab === 'members' && (
                        <div className="space-y-2">
                            {conversation.participants?.map(member => {
                                const isOwner = member.id === conversation.groupOwnerId;
                                const isAdmin = (conversation.adminIds || []).includes(member.id);
                                const isMe = member.id === currentUser.id;

                                return (
                                    <div key={member.id} className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors group">
                                        <div className="flex items-center gap-3">
                                            <img src={member.avatar} alt={member.name} className="w-10 h-10 rounded-full" />
                                            <div>
                                                <p className="font-bold text-white text-sm flex items-center gap-1">
                                                    {member.name}
                                                    {isOwner && <CrownIcon className="w-3 h-3 text-yellow-500" />}
                                                    {isAdmin && !isOwner && <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded">ADMIN</span>}
                                                </p>
                                                <p className="text-xs text-gray-500">{isMe ? 'You' : ((member as any).status || 'offline')}</p>
                                            </div>
                                        </div>

                                        {amIAdmin && !isMe && (
                                            <div className="relative">
                                                <button onClick={() => setMemberMenuOpen(memberMenuOpen === member.id ? null : member.id)} className="p-1.5 text-gray-400 hover:text-white rounded-full">
                                                    <MoreVertIcon className="w-5 h-5" />
                                                </button>
                                                {memberMenuOpen === member.id && (
                                                    <div className="absolute right-0 mt-1 w-40 bg-[#222] border border-white/10 rounded-xl shadow-xl z-20 overflow-hidden animate-fade-in-up">
                                                        {!isOwner && (
                                                            <button onClick={() => { isAdmin ? onDemoteMember(member.id) : onPromoteMember(member.id); setMemberMenuOpen(null); }} className="w-full text-left px-4 py-2 text-xs text-white hover:bg-white/10">
                                                                {isAdmin ? 'Dismiss as Admin' : 'Make Admin'}
                                                            </button>
                                                        )}
                                                        <button onClick={() => { onKickMember(member.id); setMemberMenuOpen(null); }} className="w-full text-left px-4 py-2 text-xs text-red-400 hover:bg-red-500/10">
                                                            Remove from Group
                                                        </button>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                            <button className="w-full py-3 mt-2 flex items-center justify-center gap-2 text-sm font-bold text-purple-400 bg-purple-500/10 rounded-xl hover:bg-purple-500/20 transition-colors">
                                <UserAddIcon className="w-4 h-4" /> Add Members
                            </button>
                        </div>
                    )}
                    
                    {activeTab === 'media' && (
                        <div className="grid grid-cols-3 gap-2">
                            {conversation.messages.filter(m => m.imageUrl).map(m => (
                                <div key={m.id} className="aspect-square bg-black rounded-lg overflow-hidden">
                                    <img src={m.imageUrl} className="w-full h-full object-cover" />
                                </div>
                            ))}
                             {conversation.messages.filter(m => m.imageUrl).length === 0 && (
                                <p className="col-span-3 text-center text-gray-500 py-8 text-sm">No media shared yet.</p>
                             )}
                        </div>
                    )}
                </div>

                {/* Footer Actions */}
                <div className="p-4 border-t border-white/10 bg-black/20 shrink-0">
                    {amIOwner ? (
                        <button onClick={onDeleteGroup} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/10 text-red-500 font-bold text-sm hover:bg-red-500/20 transition-colors">
                            <TrashIcon className="w-5 h-5" /> Delete Group
                        </button>
                    ) : (
                        <button onClick={onLeaveGroup} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/10 text-red-500 font-bold text-sm hover:bg-red-500/20 transition-colors">
                            <BlockUserIcon className="w-5 h-5" /> Leave Group
                        </button>
                    )}
                </div>
            </div>
             {memberMenuOpen && <div className="fixed inset-0 z-10" onClick={() => setMemberMenuOpen(null)} />}
        </div>
    );
};

export default GroupInfoModal;
