
import React, { useState, useEffect } from 'react';
import { CloseIcon } from './icons';

interface VoiceRoomPasswordPromptModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (password: string) => void;
    onRequestJoin: (roomId: number) => void;
    roomName: string;
    roomId: number;
    error?: string;
}

const VoiceRoomPasswordPromptModal: React.FC<VoiceRoomPasswordPromptModalProps> = ({ isOpen, onClose, onSubmit, onRequestJoin, roomName, roomId, error }) => {
    const [password, setPassword] = useState('');

    useEffect(() => {
        if (!isOpen) {
            setPassword('');
        }
    }, [isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(password);
    };

    const handleRequest = () => {
        onRequestJoin(roomId);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl p-8 space-y-6 w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-white">{error ? 'Access Denied' : 'Enter Password'}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6" /></button>
                </div>
                
                {error ? (
                    <div>
                        <p className="text-red-400 text-center mb-4">{error}</p>
                        <p className="text-gray-300 text-center mb-6">You can request access from the room host.</p>
                        <button
                            onClick={handleRequest}
                            className="w-full flex justify-center py-3 px-4 text-sm font-semibold rounded-lg text-white bg-gradient-to-r from-blue-500 to-cyan-500 hover:bg-gradient-to-l"
                        >
                            Request to Join
                        </button>
                    </div>
                ) : (
                    <>
                        <p className="text-gray-300">The room "{roomName}" is private.</p>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="input-style"
                                    placeholder="Room Password"
                                    autoFocus
                                    required
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full flex justify-center py-3 px-4 text-sm font-semibold rounded-lg text-white bg-gradient-to-r from-[#6C5DD3] to-[#8A79F7] hover:bg-gradient-to-l"
                            >
                                Join Room
                            </button>
                        </form>
                        
                        <div className="relative flex py-2 items-center">
                            <div className="flex-grow border-t border-white/10"></div>
                            <span className="flex-shrink-0 mx-4 text-gray-500 text-xs uppercase">Or</span>
                            <div className="flex-grow border-t border-white/10"></div>
                        </div>

                        <button
                            onClick={handleRequest}
                            className="w-full flex justify-center py-3 px-4 text-sm font-semibold rounded-lg text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
                        >
                            Request to Join
                        </button>
                    </>
                )}
            </div>
            <style>{`.input-style { appearance: none; border-radius: 0.5rem; position: relative; display: block; width: 100%; padding: 0.75rem 1rem; background-color: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); color: white; } .input-style:focus { outline: none; box-shadow: 0 0 0 2px #6C5DD3; }`}</style>
        </div>
    );
};

export default VoiceRoomPasswordPromptModal;