
import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Friend } from '../types';
import { CloseIcon, UsersIcon, CheckIcon, SearchIcon, CameraIcon, PaletteIcon, PublicIcon, PrivateIcon } from './icons';

interface CreateGroupModalProps {
    isOpen: boolean;
    onClose: () => void;
    friends: Friend[];
    onCreate: (groupData: { name: string, participantIds: number[], description?: string, theme?: string, avatar?: string, isPrivate?: boolean }) => void;
}

const THEME_COLORS = [
    { id: 'purple', hex: '#8A79F7', bg: 'bg-purple-500', border: 'border-purple-500', text: 'text-purple-400', gradient: 'from-purple-600 to-indigo-600', shadow: 'shadow-purple-500/40', ring: 'ring-purple-500' },
    { id: 'blue', hex: '#3B82F6', bg: 'bg-blue-500', border: 'border-blue-500', text: 'text-blue-400', gradient: 'from-blue-500 to-cyan-500', shadow: 'shadow-blue-500/40', ring: 'ring-blue-500' },
    { id: 'green', hex: '#10B981', bg: 'bg-emerald-500', border: 'border-emerald-500', text: 'text-emerald-400', gradient: 'from-emerald-500 to-teal-500', shadow: 'shadow-emerald-500/40', ring: 'ring-emerald-500' },
    { id: 'red', hex: '#EF4444', bg: 'bg-red-500', border: 'border-red-500', text: 'text-red-400', gradient: 'from-red-500 to-orange-500', shadow: 'shadow-red-500/40', ring: 'ring-red-500' },
    { id: 'pink', hex: '#EC4899', bg: 'bg-pink-500', border: 'border-pink-500', text: 'text-pink-400', gradient: 'from-pink-500 to-rose-500', shadow: 'shadow-pink-500/40', ring: 'ring-pink-500' },
    { id: 'orange', hex: '#F97316', bg: 'bg-orange-500', border: 'border-orange-500', text: 'text-orange-400', gradient: 'from-orange-500 to-yellow-500', shadow: 'shadow-orange-500/40', ring: 'ring-orange-500' },
];

const CreateGroupModal: React.FC<CreateGroupModalProps> = ({ isOpen, onClose, friends, onCreate }) => {
    // Animation State
    const [isVisible, setIsVisible] = useState(false);
    const [isMounting, setIsMounting] = useState(false);

    // Form State
    const [groupName, setGroupName] = useState('');
    const [description, setDescription] = useState('');
    const [selectedTheme, setSelectedTheme] = useState(THEME_COLORS[0]);
    const [isPrivate, setIsPrivate] = useState(true);
    const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
    
    // Member Selection State
    const [selectedFriends, setSelectedFriends] = useState<Set<number>>(new Set());
    const [searchTerm, setSearchTerm] = useState('');
    
    // Mobile Sheet State
    const [isExpanded, setIsExpanded] = useState(false);
    const [isDragging, setIsDragging] = useState(false);
    const [translateY, setTranslateY] = useState(0);
    const dragStartY = useRef<number>(0);
    const sheetRef = useRef<HTMLDivElement>(null);
    const contentRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const filteredFriends = useMemo(() => 
        friends.filter(f => f.name.toLowerCase().includes(searchTerm.toLowerCase())),
    [friends, searchTerm]);

    // Handle Entry/Exit Animations
    useEffect(() => {
        if (isOpen) {
            setIsMounting(true);
            setTimeout(() => setIsVisible(true), 10); // Small delay to trigger CSS transition
            
            // Reset form
            setTranslateY(0);
            setIsExpanded(false);
            setGroupName('');
            setDescription('');
            setSelectedFriends(new Set());
            setSearchTerm('');
            setAvatarPreview(null);
            setSelectedTheme(THEME_COLORS[0]);
            setIsPrivate(true);
        } else {
            setIsVisible(false);
            setTimeout(() => setIsMounting(false), 300); // Wait for animation to finish
        }
    }, [isOpen]);

    const handleClose = () => {
        setIsVisible(false);
        setTimeout(() => {
            onClose();
        }, 300);
    };

    const toggleFriend = (id: number) => {
        setSelectedFriends(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) newSet.delete(id);
            else newSet.add(id);
            return newSet;
        });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            setAvatarPreview(url);
        }
    };

    const handleCreate = (e: React.FormEvent) => {
        e.preventDefault();
        if (groupName.trim() && selectedFriends.size > 0) {
            onCreate({
                name: groupName.trim(),
                participantIds: Array.from(selectedFriends) as number[],
                description: description.trim(),
                theme: selectedTheme.hex,
                avatar: avatarPreview || undefined,
                isPrivate
            });
            onClose();
        }
    };

    // Touch Handlers (Mobile)
    const handleTouchStart = (e: React.TouchEvent) => {
        const target = e.target as HTMLElement;
        const isContentScroll = contentRef.current && contentRef.current.contains(target);
        // Allow drag if tapping header or if content is scrolled to top
        const isAtTop = contentRef.current ? contentRef.current.scrollTop <= 0 : true;

        if (isContentScroll && !isAtTop) return;
        
        setIsDragging(true);
        dragStartY.current = e.touches[0].clientY;
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (!isDragging) return;
        const deltaY = e.touches[0].clientY - dragStartY.current;
        
        // Don't allow dragging up if already expanded fully
        if (isExpanded && deltaY < 0) return;
        
        setTranslateY(deltaY);
    };

    const handleTouchEnd = () => {
        setIsDragging(false);
        if (translateY > 150) {
            handleClose(); // Close if dragged down far enough
        } else if (translateY < -50 && !isExpanded) {
            setIsExpanded(true); // Expand if dragged up
            setTranslateY(0);
        } else if (translateY > 50 && isExpanded) {
            setIsExpanded(false); // Collapse if dragged down slightly
            setTranslateY(0);
        } else {
            setTranslateY(0); // Reset
        }
    };

    if (!isMounting && !isOpen) return null;

    // --- Desktop Layout Components ---

    const DesktopLayout = () => (
        <div 
            className={`hidden md:flex w-full max-w-5xl h-[700px] bg-[#0f0f0f]/60 backdrop-blur-3xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden ring-1 ring-white/5 transition-all duration-300 transform ${isVisible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}
            onClick={(e) => e.stopPropagation()}
        >
            {/* Left Column: Group Info */}
            <div className="w-[40%] bg-black/20 p-8 flex flex-col border-r border-white/5 relative">
                <h2 className="text-3xl font-bold text-white mb-2">Create Group</h2>
                <p className="text-sm text-gray-400 mb-10">Build your community and start watching together.</p>

                <div className="flex-1 flex flex-col items-center">
                    {/* Avatar Uploader with Theme Glow */}
                    <div 
                        className="relative group cursor-pointer mb-10"
                        onClick={() => fileInputRef.current?.click()}
                    >
                        <div className={`absolute inset-0 rounded-full blur-2xl opacity-40 transition-colors duration-500 ${selectedTheme.bg}`}></div>
                        <div className={`relative w-32 h-32 rounded-full flex items-center justify-center overflow-hidden border-4 transition-all duration-300 ${avatarPreview ? 'border-white/20' : `border-dashed border-white/20 bg-white/5 group-hover:border-white/40`}`}>
                            {avatarPreview ? (
                                <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
                            ) : (
                                <CameraIcon className="w-10 h-10 text-gray-500 group-hover:text-white transition-colors" />
                            )}
                        </div>
                        <div className={`absolute bottom-0 right-0 p-2.5 rounded-full text-white shadow-xl transform group-hover:scale-110 transition-all bg-gradient-to-r ${selectedTheme.gradient}`}>
                            <CameraIcon className="w-5 h-5" />
                        </div>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                    </div>

                    {/* Inputs */}
                    <div className="w-full space-y-6">
                        <div className="group focus-within:text-white text-gray-400 transition-colors">
                            <label className="text-xs font-bold uppercase tracking-wider mb-2 block ml-1">Group Name</label>
                            <input 
                                type="text" 
                                value={groupName}
                                onChange={(e) => setGroupName(e.target.value)}
                                placeholder="e.g. Movie Night 🎬"
                                className={`w-full bg-white/5 text-white px-4 py-3.5 rounded-2xl border border-white/10 focus:outline-none focus:border-white/30 focus:bg-white/10 transition-all text-sm placeholder-gray-600 font-medium focus:ring-1 ${selectedTheme.ring} ring-opacity-50`}
                                autoFocus
                            />
                        </div>
                        
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1">Description <span className="text-gray-600 font-normal lowercase opacity-60">(optional)</span></label>
                            <textarea 
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                placeholder="What's this group about?"
                                rows={3}
                                className={`w-full bg-white/5 text-white px-4 py-3.5 rounded-2xl border border-white/10 focus:outline-none focus:border-white/30 focus:bg-white/10 transition-all text-sm placeholder-gray-600 resize-none focus:ring-1 ${selectedTheme.ring} ring-opacity-50`}
                            />
                        </div>

                        {/* Privacy & Theme Row */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block ml-1">Access</label>
                                <div className="flex bg-black/30 p-1 rounded-xl border border-white/5">
                                    <button onClick={() => setIsPrivate(false)} className={`flex-1 py-1.5 rounded-lg flex items-center justify-center transition-all ${!isPrivate ? 'bg-white text-black shadow-md' : 'text-gray-500 hover:text-white'}`}>
                                        <PublicIcon className="w-4 h-4" />
                                    </button>
                                    <button onClick={() => setIsPrivate(true)} className={`flex-1 py-1.5 rounded-lg flex items-center justify-center transition-all ${isPrivate ? 'bg-white text-black shadow-md' : 'text-gray-500 hover:text-white'}`}>
                                        <PrivateIcon className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block ml-1">Theme</label>
                                <div className="flex justify-between bg-black/30 p-1.5 rounded-xl border border-white/5 items-center">
                                    {THEME_COLORS.map(theme => (
                                        <button
                                            key={theme.id}
                                            type="button"
                                            onClick={() => setSelectedTheme(theme)}
                                            className={`w-6 h-6 rounded-full ${theme.bg} flex items-center justify-center transition-transform ${selectedTheme.id === theme.id ? 'scale-125 ring-2 ring-white ring-offset-1 ring-offset-[#18181b]' : 'hover:scale-110 opacity-60 hover:opacity-100'}`}
                                        />
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Column: Members */}
            <div className="w-[60%] flex flex-col bg-white/[0.02] relative">
                <div className="p-8 pb-4 flex justify-between items-end">
                    <div>
                        <h3 className="text-xl font-bold text-white">Add Members</h3>
                        <p className="text-sm text-gray-400 mt-1">{selectedFriends.size} friends selected</p>
                    </div>
                    <button onClick={handleClose} className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>

                {/* Search */}
                <div className="px-8 py-4">
                    <div className="relative group">
                        <SearchIcon className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 transition-colors ${selectedTheme.text}`} />
                        <input 
                            type="text" 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Search friends..."
                            className={`w-full bg-black/40 text-white pl-12 pr-4 py-3.5 text-sm rounded-2xl border border-white/10 focus:outline-none focus:border-white/30 transition-all focus:ring-1 ${selectedTheme.ring} ring-opacity-50`}
                        />
                    </div>
                </div>

                {/* Friend List */}
                <div className="flex-1 overflow-y-auto custom-scrollbar px-6 pb-28">
                    <div className="space-y-2">
                        {filteredFriends.map(friend => {
                            const isSelected = selectedFriends.has(friend.id);
                            return (
                                <div 
                                    key={friend.id} 
                                    onClick={() => toggleFriend(friend.id)}
                                    className={`flex items-center gap-4 p-3 rounded-2xl cursor-pointer transition-all border ${isSelected ? `bg-${selectedTheme.id}-500/10 ${selectedTheme.border} border-opacity-30` : 'hover:bg-white/5 border-transparent'}`}
                                >
                                    <div className="relative">
                                        <img src={friend.avatar} className="w-12 h-12 rounded-full object-cover bg-[#1e1e1e]" alt={friend.name} />
                                        {isSelected && (
                                            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#121214] ${selectedTheme.bg}`}>
                                                <CheckIcon className="w-3 h-3 text-white" />
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <span className={`text-sm font-bold block truncate ${isSelected ? 'text-white' : 'text-gray-300'}`}>{friend.name}</span>
                                        <span className="text-xs text-gray-500 truncate block">{friend.status}</span>
                                    </div>
                                </div>
                            )
                        })}
                        {filteredFriends.length === 0 && (
                            <div className="flex flex-col items-center justify-center py-20 text-gray-500 opacity-60">
                                <UsersIcon className="w-12 h-12 mb-2" />
                                <p className="text-sm">No friends found.</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Footer Action */}
                <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-[#0f0f0f] to-transparent pt-16 pointer-events-none flex justify-end">
                    <button 
                        onClick={handleCreate}
                        disabled={!groupName.trim() || selectedFriends.size === 0}
                        className={`pointer-events-auto px-10 py-4 bg-gradient-to-r ${selectedTheme.gradient} text-white font-bold rounded-2xl shadow-xl ${selectedTheme.shadow} hover:shadow-2xl hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3`}
                    >
                        <UsersIcon className="w-5 h-5" />
                        Create Group
                    </button>
                </div>
            </div>
        </div>
    );

    // --- Mobile Layout Components ---

    const MobileLayout = () => (
        <div className="flex flex-col h-full relative">
            {/* Drag Handle */}
            <div 
                className="w-full h-12 flex items-center justify-center flex-shrink-0 touch-none bg-white/[0.02] border-b border-white/5 relative z-10 rounded-t-[2rem]"
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
            >
                <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar pb-28 px-5" ref={contentRef}>
                <div className="flex justify-between items-center mb-6 mt-2">
                    <h2 className="text-2xl font-bold text-white">New Group</h2>
                    <button onClick={handleClose} className="p-2 bg-white/5 rounded-full text-gray-400"><CloseIcon className="w-5 h-5"/></button>
                </div>

                {/* Avatar & Name (Horizontal Layout) */}
                <div className="flex items-center gap-5 mb-8">
                    <div 
                        className="relative w-20 h-20 rounded-full bg-white/5 border-2 border-dashed border-white/20 flex-shrink-0 flex items-center justify-center overflow-hidden"
                        onClick={() => fileInputRef.current?.click()}
                    >
                        {avatarPreview ? (
                            <img src={avatarPreview} className="w-full h-full object-cover" alt="Preview" />
                        ) : (
                            <CameraIcon className="w-6 h-6 text-gray-500" />
                        )}
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                    </div>
                    <div className="flex-1">
                        <label className={`text-[10px] font-bold uppercase tracking-wide mb-1.5 block ${selectedTheme.text}`}>Group Name</label>
                        <input 
                            type="text" 
                            value={groupName}
                            onChange={(e) => setGroupName(e.target.value)}
                            placeholder="Enter name..."
                            className={`w-full bg-transparent border-b border-white/20 py-2 text-lg font-bold text-white placeholder-gray-600 focus:outline-none focus:${selectedTheme.border} transition-colors rounded-none`}
                        />
                    </div>
                </div>

                {/* Settings (Theme & Access) */}
                <div className="space-y-6 mb-8">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wide mb-3 block">Theme</label>
                            <div className="flex gap-2">
                                {THEME_COLORS.slice(0, 4).map(theme => (
                                    <button
                                        key={theme.id}
                                        type="button"
                                        onClick={() => setSelectedTheme(theme)}
                                        className={`w-8 h-8 rounded-full ${theme.bg} flex-shrink-0 flex items-center justify-center transition-all ${selectedTheme.id === theme.id ? 'ring-2 ring-white ring-offset-2 ring-offset-[#121214] scale-110' : 'opacity-50'}`}
                                    >
                                        {selectedTheme.id === theme.id && <CheckIcon className="w-3 h-3 text-white" />}
                                    </button>
                                ))}
                            </div>
                        </div>
                        
                        <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wide mb-3 block">Access</label>
                            <div className="flex bg-white/5 p-1 rounded-xl border border-white/5">
                                <button onClick={() => setIsPrivate(false)} className={`flex-1 py-1.5 rounded-lg flex items-center justify-center transition-all ${!isPrivate ? 'bg-white text-black' : 'text-gray-500'}`}><PublicIcon className="w-4 h-4"/></button>
                                <button onClick={() => setIsPrivate(true)} className={`flex-1 py-1.5 rounded-lg flex items-center justify-center transition-all ${isPrivate ? 'bg-white text-black' : 'text-gray-500'}`}><PrivateIcon className="w-4 h-4"/></button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Members Section */}
                <div>
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-sm font-bold text-white">Select Members</h3>
                        <span className={`text-xs font-bold text-white ${selectedTheme.bg} px-2 py-0.5 rounded-full`}>{selectedFriends.size}</span>
                    </div>

                    {/* Selected Horizontal Scroll */}
                    {selectedFriends.size > 0 && (
                        <div className="flex gap-4 overflow-x-auto hide-scrollbar mb-6 pb-2 px-1">
                            {Array.from(selectedFriends).map((id: number) => {
                                const friend = friends.find(f => f.id === id);
                                if (!friend) return null;
                                return (
                                    <div key={id} className="flex flex-col items-center gap-2 animate-fade-in flex-shrink-0">
                                        <div className="relative">
                                            <img src={friend.avatar} className={`w-14 h-14 rounded-full object-cover border-2 ${selectedTheme.border}`} alt={friend.name} />
                                            <button onClick={() => toggleFriend(id)} className="absolute -top-1 -right-1 bg-[#2a2a2d] rounded-full p-1 border border-white/10">
                                                <CloseIcon className="w-2.5 h-2.5 text-gray-400" />
                                            </button>
                                        </div>
                                        <span className="text-[10px] text-white w-16 truncate text-center font-medium">{friend.name.split(' ')[0]}</span>
                                    </div>
                                );
                            })}
                        </div>
                    )}

                    {/* Search & List */}
                    <div className="bg-white/5 rounded-2xl p-1 mb-4 border border-white/5 focus-within:border-white/20 transition-colors">
                        <div className="flex items-center px-3">
                            <SearchIcon className="w-4 h-4 text-gray-500 mr-2"/>
                            <input 
                                type="text" 
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Filter friends..." 
                                className="bg-transparent w-full py-3 text-sm text-white placeholder-gray-500 focus:outline-none"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        {filteredFriends.map(friend => (
                            <div key={friend.id} onClick={() => toggleFriend(friend.id)} className="flex items-center justify-between p-3 rounded-2xl active:bg-white/5 transition-colors">
                                <div className="flex items-center gap-3">
                                    <img src={friend.avatar} className="w-12 h-12 rounded-full bg-[#1e1e1e]" alt={friend.name} />
                                    <div>
                                        <p className="text-sm font-bold text-white">{friend.name}</p>
                                        <p className="text-xs text-gray-500">{friend.status}</p>
                                    </div>
                                </div>
                                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${selectedFriends.has(friend.id) ? `${selectedTheme.bg} ${selectedTheme.border}` : 'border-gray-600'}`}>
                                    {selectedFriends.has(friend.id) && <CheckIcon className="w-3.5 h-3.5 text-white" />}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Sticky Button */}
            <div className="absolute bottom-0 left-0 right-0 p-5 bg-[#121214]/80 backdrop-blur-xl border-t border-white/10">
                <button 
                    onClick={handleCreate}
                    disabled={!groupName.trim() || selectedFriends.size === 0}
                    className={`w-full py-4 rounded-2xl bg-gradient-to-r ${selectedTheme.gradient} text-white font-bold text-base shadow-lg ${selectedTheme.shadow} disabled:opacity-50 transition-all active:scale-95 flex items-center justify-center gap-2`}
                >
                    Create Group ({selectedFriends.size + 1})
                </button>
            </div>
        </div>
    );

    return (
        <>
            {/* Desktop Overlay */}
            <div 
                className={`hidden md:flex fixed inset-0 bg-black/80 backdrop-blur-md items-center justify-center z-[60] p-4 transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
                onClick={handleClose}
            >
                <div onClick={(e) => e.stopPropagation()}>
                    <DesktopLayout />
                </div>
            </div>

            {/* Mobile Overlay & Sheet */}
            <div className={`md:hidden fixed inset-0 z-[60] ${isVisible ? 'pointer-events-auto' : 'pointer-events-none'}`}>
                <div 
                    className={`absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
                    onClick={handleClose}
                />
                
                <div 
                    ref={sheetRef}
                    className={`absolute bottom-0 left-0 right-0 bg-[#0f0f0f]/90 backdrop-blur-3xl rounded-t-[2rem] shadow-2xl border-t border-white/10 flex flex-col transition-transform duration-300 cubic-bezier(0.2, 0.8, 0.2, 1) ${isVisible ? 'translate-y-0' : 'translate-y-full'} ${isExpanded ? 'h-[95vh]' : 'h-[85vh]'}`}
                    style={{ 
                        transform: isVisible ? `translateY(${Math.max(0, translateY)}px)` : 'translateY(100%)',
                        transition: isDragging ? 'none' : 'transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)'
                    }}
                    onClick={(e) => e.stopPropagation()}
                >
                    <MobileLayout />
                </div>
            </div>
        </>
    );
};

export default CreateGroupModal;
