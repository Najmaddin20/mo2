
import React, { useState, useRef, useEffect, useMemo } from 'react';
import type { User, Conversation, DirectMessage, ChatBackground, AudioTrack } from '../types';
import { SendIcon, ArrowLeftIcon, MicrophoneIcon, CloseIcon, ReplyIcon, AttachmentIcon, EmojiIcon, SearchIcon, BookmarkIcon, CloudIcon, ChevronDownIcon } from './icons';
import VoiceMessageRecorder from './VoiceMessageRecorder';
import { DirectMessageItem } from './DirectMessageItem';
import MessageActionOverlay from './MessageActionOverlay';
import { ChatHeaderMiniPlayer, useAudioPlayer, PlaylistBottomSheet } from './AudioPlayerSystem';
import DateSeparator from './DateSeparator';
import JumpToLatestButton from './JumpToLatestButton';

interface SavedMessagesChatProps {
    currentUser: User;
    conversation: Conversation;
    onSendMessage: (message: Omit<DirectMessage, 'id' | 'senderId' | 'timestamp' | 'displayTime'>) => void;
    onBack: () => void;
    chatBackground: ChatBackground;
    onDeleteMessage: (msgIds: number[]) => void;
    onJoinRoom: (roomId: number) => void;
    onJoinVoiceRoom: (roomId: number) => void;
    onViewMedia: (media: DirectMessage) => void;
    onForwardMessage: (toFriendId: number, message: DirectMessage) => void;
}

const SavedMessagesChat: React.FC<SavedMessagesChatProps> = (props) => {
    const { currentUser, conversation, onSendMessage, onBack, chatBackground, onDeleteMessage, onViewMedia, onForwardMessage, onJoinRoom, onJoinVoiceRoom } = props;

    const [text, setText] = useState('');
    const [voiceMode, setVoiceMode] = useState<'idle' | 'recording'>('idle');
    const [replyingTo, setReplyingTo] = useState<DirectMessage | null>(null);
    const [actionMenuMessage, setActionMenuMessage] = useState<DirectMessage | null>(null);
    
    // Search State
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<number[]>([]); // Indices of messages
    const [currentResultIndex, setCurrentResultIndex] = useState(0);
    
    const chatEndRef = useRef<HTMLDivElement>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const searchInputRef = useRef<HTMLInputElement>(null);
    const messageRefs = useRef<Map<number, HTMLDivElement>>(new Map());

    const { isPlaylistOpen, setIsPlaylistOpen, expandPlayer } = useAudioPlayer();
    const [showScrollButton, setShowScrollButton] = useState(false);

    const scrollToBottom = (smooth = true) => {
        chatEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
        setShowScrollButton(false);
    };

    useEffect(() => {
        if (!isSearchOpen) {
            scrollToBottom(false);
        }
    }, [conversation.messages.length, isSearchOpen]);

    useEffect(() => {
        if (isSearchOpen) {
            setTimeout(() => searchInputRef.current?.focus(), 100);
        } else {
            setSearchQuery('');
            setSearchResults([]);
        }
    }, [isSearchOpen]);

    // Search Logic
    useEffect(() => {
        if (!searchQuery.trim()) {
            setSearchResults([]);
            setCurrentResultIndex(0);
            return;
        }

        const results: number[] = [];
        // Search in reverse to find newest first, or normal order? Let's do normal order (oldest to newest)
        conversation.messages.forEach((msg, idx) => {
            const content = (msg.message || msg.caption || '').toLowerCase();
            if (content.includes(searchQuery.toLowerCase())) {
                results.push(idx);
            }
        });

        setSearchResults(results);
        setCurrentResultIndex(results.length > 0 ? results.length - 1 : 0); // Default to latest match
        
        if (results.length > 0) {
            scrollToMessage(conversation.messages[results[results.length - 1]].id);
        }
    }, [searchQuery, conversation.messages]);

    const scrollToMessage = (messageId: number) => {
        const el = messageRefs.current.get(messageId);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Optional highlight effect
            el.classList.add('bg-white/10', 'transition-colors', 'duration-500');
            setTimeout(() => el.classList.remove('bg-white/10'), 1500);
        }
    };

    const handleNextResult = () => {
        if (searchResults.length === 0) return;
        const nextIndex = (currentResultIndex + 1) % searchResults.length;
        setCurrentResultIndex(nextIndex);
        scrollToMessage(conversation.messages[searchResults[nextIndex]].id);
    };

    const handlePrevResult = () => {
        if (searchResults.length === 0) return;
        const prevIndex = (currentResultIndex - 1 + searchResults.length) % searchResults.length;
        setCurrentResultIndex(prevIndex);
        scrollToMessage(conversation.messages[searchResults[prevIndex]].id);
    };

    const handleScroll = () => {
        if (chatContainerRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
            setShowScrollButton(scrollHeight - scrollTop - clientHeight > 150);
        }
    };

    const handleSend = () => {
        if (!text.trim()) return;
        onSendMessage({ message: text.trim(), replyTo: replyingTo || undefined });
        setText('');
        setReplyingTo(null);
    };
    
    const handleSendVoice = (url: string, duration: number, waveform: number[]) => {
        onSendMessage({ message: '', voiceMessage: { url, duration, waveform }, replyTo: replyingTo || undefined });
        setVoiceMode('idle');
    }

    const audioQueue: AudioTrack[] = useMemo(() => {
        return conversation.messages
            .filter(msg => msg.voiceMessage)
            .map(msg => ({
                id: msg.id.toString(),
                url: msg.voiceMessage!.url,
                title: 'Voice Note',
                artist: 'Saved Messages',
                duration: msg.voiceMessage!.duration,
                waveform: msg.voiceMessage!.waveform,
                contextId: currentUser.id
            }));
    }, [conversation.messages, currentUser.id]);

    const messagesWithSeparators = useMemo(() => {
        const result: (DirectMessage | { type: 'date-separator', date: string })[] = [];
        let lastDate: Date | null = null;
        conversation.messages.forEach(message => {
            const messageDate = new Date(message.timestamp);
            const isSame = lastDate && 
                lastDate.getFullYear() === messageDate.getFullYear() &&
                lastDate.getMonth() === messageDate.getMonth() &&
                lastDate.getDate() === messageDate.getDate();
            if (!isSame) {
                const dateStr = messageDate.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
                result.push({ type: 'date-separator', date: dateStr });
                lastDate = messageDate;
            }
            result.push(message);
        });
        return result;
    }, [conversation.messages]);

    return (
        <div className="flex flex-col h-full relative overflow-hidden bg-black/20 backdrop-blur-xl">
             {/* Unique Saved Messages Header */}
            <header className="flex-shrink-0 flex flex-col bg-white/5 backdrop-blur-xl border-b border-white/5 z-10 shadow-sm">
                <div className="flex items-center justify-between p-3 px-4 h-16">
                    {isSearchOpen ? (
                        <div className="flex-1 flex items-center gap-3 animate-fade-in">
                            <button onClick={() => setIsSearchOpen(false)} className="p-2 -ml-2 text-gray-400 hover:text-white rounded-full hover:bg-white/10 transition-colors">
                                <ArrowLeftIcon className="w-5 h-5" />
                            </button>
                            <div className="flex-1 relative group">
                                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-[var(--theme-color)]" />
                                <input 
                                    ref={searchInputRef}
                                    type="text" 
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    placeholder="Search..." 
                                    className="w-full bg-black/20 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-[var(--theme-color)] transition-all"
                                />
                            </div>
                            {searchResults.length > 0 && (
                                <div className="flex items-center gap-2 pl-2">
                                    <span className="text-xs font-mono text-gray-400 whitespace-nowrap min-w-[40px] text-center">
                                        {currentResultIndex + 1} of {searchResults.length}
                                    </span>
                                    <div className="flex bg-black/20 rounded-lg border border-white/10">
                                        <button onClick={handlePrevResult} className="p-1.5 hover:bg-white/10 rounded-l-lg text-gray-300 hover:text-white border-r border-white/10">
                                            <ChevronDownIcon className="w-4 h-4 rotate-180" />
                                        </button>
                                        <button onClick={handleNextResult} className="p-1.5 hover:bg-white/10 rounded-r-lg text-gray-300 hover:text-white">
                                            <ChevronDownIcon className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    ) : (
                        <>
                            <div className="flex items-center gap-4">
                                <button onClick={(e) => { e.stopPropagation(); onBack(); }} className="md:hidden p-2 -ml-2 text-gray-300 hover:text-white rounded-full hover:bg-white/10 transition-colors"><ArrowLeftIcon className="w-6 h-6" /></button>
                                
                                <div className="flex items-center gap-3">
                                    <div 
                                        className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg shadow-[var(--theme-color)]/20"
                                        style={{ background: 'linear-gradient(135deg, var(--theme-color), color-mix(in srgb, var(--theme-color), black 20%))' }}
                                    >
                                        <BookmarkIcon className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-white text-lg leading-tight">Saved Messages</h3>
                                        <p className="text-xs font-medium opacity-80" style={{ color: 'var(--theme-color)' }}>Personal Cloud</p>
                                    </div>
                                </div>
                            </div>
                            
                            <button onClick={() => setIsSearchOpen(true)} className="p-2 text-gray-400 hover:text-white rounded-full hover:bg-white/5 transition-colors">
                                <SearchIcon className="w-6 h-6" />
                            </button>
                        </>
                    )}
                </div>
            </header>

            <ChatHeaderMiniPlayer activeContextId={currentUser.id} />

            <div 
                ref={chatContainerRef}
                className="flex-1 overflow-y-auto p-4 pb-32 space-y-1 custom-scrollbar"
                style={{ 
                    backgroundImage: `radial-gradient(circle at 50% 50%, color-mix(in srgb, var(--theme-color), transparent 95%) 0%, transparent 70%)`,
                    backgroundAttachment: 'fixed'
                }}
                onScroll={handleScroll}
            >
                {conversation.messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full min-h-[60vh] text-center animate-fade-in select-none opacity-80">
                        <div className="w-32 h-32 rounded-full flex items-center justify-center mb-6 border border-white/5" style={{ background: 'linear-gradient(135deg, color-mix(in srgb, var(--theme-color), transparent 90%), transparent)' }}>
                             <div style={{ color: 'var(--theme-color)' }}>
                                <CloudIcon className="w-16 h-16 opacity-80" />
                             </div>
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-3">Your Personal Cloud</h3>
                        <p className="text-gray-400 max-w-xs mb-8 text-sm leading-relaxed">
                            Save messages here, forward content from other chats, or store media and links to access them later.
                        </p>
                    </div>
                ) : (
                    messagesWithSeparators.map((item, idx) => {
                        if ('type' in item && item.type === 'date-separator') {
                            return <DateSeparator key={`sep-${idx}`} dateString={item.date} />;
                        }
                        const msg = item as DirectMessage;
                        
                        return (
                            <div key={msg.id} className="flex justify-end w-full mb-1">
                                <div 
                                    ref={(el) => { if (el) messageRefs.current.set(msg.id, el); }}
                                    onContextMenu={(e) => { e.preventDefault(); setActionMenuMessage(msg); }} 
                                    className="max-w-[85%]"
                                >
                                    <DirectMessageItem 
                                        message={msg} 
                                        isSent={true} 
                                        friend={conversation.friend}
                                        currentUser={currentUser}
                                        selectionMode={false}
                                        onOpenContextMenu={() => setActionMenuMessage(msg)}
                                        onAddReaction={() => {}}
                                        onJoinRoom={onJoinRoom}
                                        onJoinVoiceRoom={onJoinVoiceRoom}
                                        onReplyClick={() => {}}
                                        onViewMedia={onViewMedia}
                                        onCancelUpload={() => onDeleteMessage([msg.id])}
                                        getReplyPreviewText={(m) => m.message}
                                        onReplyRequest={setReplyingTo}
                                        audioContextQueue={audioQueue}
                                    />
                                </div>
                            </div>
                        );
                    })
                )}
                <div ref={chatEndRef} />
            </div>

             <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center pointer-events-none">
                 <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />
                 <div className="w-full max-w-4xl flex flex-col gap-2 pb-4 px-4 relative z-10 pointer-events-auto">
                    <div className="flex justify-end mb-2">
                        <JumpToLatestButton isVisible={showScrollButton} newMessagesCount={0} onClick={() => scrollToBottom()} />
                    </div>

                    {replyingTo && (
                        <div className="bg-[#1e1e24] border-l-4 p-2 rounded-r-lg flex justify-between items-center mb-1 shadow-lg animate-slide-in-up" style={{ borderLeftColor: 'var(--theme-color)' }}>
                            <div className="text-xs text-gray-300">
                                <span className="font-bold block" style={{ color: 'var(--theme-color)' }}>Replying</span>
                                <span className="truncate block max-w-xs opacity-80">{replyingTo.message || 'Media'}</span>
                            </div>
                            <button onClick={() => setReplyingTo(null)}><CloseIcon className="w-4 h-4 text-gray-400" /></button>
                        </div>
                    )}

                    <div className="bg-[#1e1e24] border border-white/10 rounded-xl p-2 shadow-2xl flex items-end gap-2 ring-1 ring-white/5 focus-within:ring-1 focus-within:bg-[#23232a] transition-all" style={{ '--tw-ring-color': 'var(--theme-color)' } as React.CSSProperties}>
                        {voiceMode === 'recording' ? (
                            <VoiceMessageRecorder isRecording={true} onCancel={() => setVoiceMode('idle')} onSend={handleSendVoice} />
                        ) : (
                            <>
                                <button className="p-2 text-gray-400 hover:text-blue-400 hover:bg-white/5 rounded-lg transition-colors"><AttachmentIcon className="w-6 h-6" /></button>
                                <textarea 
                                    value={text} 
                                    onChange={e => setText(e.target.value)}
                                    placeholder="Note to self..."
                                    className="flex-1 bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none py-2.5 px-2 text-[15px] max-h-[100px] min-h-[44px]"
                                    rows={1}
                                    onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                                />
                                <button className="p-2 text-gray-400 hover:text-yellow-400 hover:bg-white/5 rounded-lg transition-colors"><EmojiIcon className="w-6 h-6" /></button>
                                {text.trim() ? (
                                    <button onClick={handleSend} className="w-10 h-10 text-white rounded-lg flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all" style={{ backgroundColor: 'var(--theme-color)' }}><SendIcon className="w-5 h-5 ml-0.5" /></button>
                                ) : (
                                    <button onClick={() => setVoiceMode('recording')} className="w-10 h-10 bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg flex items-center justify-center transition-all"><MicrophoneIcon className="w-5 h-5" /></button>
                                )}
                            </>
                        )}
                    </div>
                 </div>
             </div>

            {actionMenuMessage && (
                <MessageActionOverlay 
                    message={actionMenuMessage} 
                    isSent={true}
                    isPinned={false}
                    onClose={() => setActionMenuMessage(null)}
                    onReply={() => setReplyingTo(actionMenuMessage)}
                    onEdit={() => {}}
                    onCopy={() => navigator.clipboard.writeText(actionMenuMessage.message)}
                    onPin={() => {}}
                    onDelete={() => onDeleteMessage([actionMenuMessage.id])}
                    onForward={() => onForwardMessage(0, actionMenuMessage)}
                    onSelect={() => {}}
                    onAddReaction={() => {}}
                    currentUser={currentUser}
                    friend={conversation.friend}
                    onJoinRoom={() => {}}
                    onJoinVoiceRoom={() => {}}
                    onReplyClick={() => {}}
                    onViewMedia={onViewMedia}
                    getReplyPreviewText={(m) => m.message}
                />
            )}

            <PlaylistBottomSheet 
                isOpen={isPlaylistOpen} 
                onClose={() => setIsPlaylistOpen(false)} 
                onExpand={() => {
                    setIsPlaylistOpen(false);
                    expandPlayer();
                }}
            />
        </div>
    );
};

export default SavedMessagesChat;
