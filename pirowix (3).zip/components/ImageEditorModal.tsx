
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { CloseIcon, CheckIcon, CropIcon, RotateRightIcon, FlipHorizontalIcon, SunIcon, ContrastIcon, DropIcon, SliderIcon, MagicWandIcon, UndoIcon, EyeIcon } from './icons';

interface ImageEditorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (editedFile: File) => void;
    imageFile: File;
}

type Tab = 'filters' | 'adjust' | 'crop';

const aspectRatios = [
    { label: 'Free', value: 0 },
    { label: '1:1', value: 1 },
    { label: '16:9', value: 16 / 9 },
    { label: '4:3', value: 4 / 3 },
    { label: '9:16', value: 9 / 16 },
    { label: '3:4', value: 3 / 4 },
    { label: '2:3', value: 2 / 3 },
];

const filters = [
    { name: 'Original', filter: '' },
    { name: 'Vivid', filter: 'contrast(110%) saturate(130%)' },
    { name: 'Warm', filter: 'sepia(30%) saturate(120%)' },
    { name: 'Cool', filter: 'hue-rotate(180deg) saturate(80%)' },
    { name: 'Fade', filter: 'opacity(80%) brightness(110%) contrast(90%)' },
    { name: 'Mono', filter: 'grayscale(100%)' },
    { name: 'Noir', filter: 'grayscale(100%) contrast(140%)' },
    { name: 'Sepia', filter: 'sepia(100%)' },
    { name: 'Cyber', filter: 'hue-rotate(90deg) contrast(120%)' },
];

const ImageEditorModal: React.FC<ImageEditorModalProps> = ({ isOpen, onClose, onSave, imageFile }) => {
    const [activeTab, setActiveTab] = useState<Tab>('filters');
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const [imageBitmap, setImageBitmap] = useState<HTMLImageElement | null>(null);
    const [isComparing, setIsComparing] = useState(false);
    const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
    
    // Editor State
    const [rotation, setRotation] = useState(0);
    const [flipH, setFlipH] = useState(false);
    const [flipV, setFlipV] = useState(false);
    
    // Adjustments
    const [brightness, setBrightness] = useState(100);
    const [contrast, setContrast] = useState(100);
    const [saturation, setSaturation] = useState(100);
    const [blur, setBlur] = useState(0);
    const [hue, setHue] = useState(0);
    
    const [selectedFilter, setSelectedFilter] = useState(filters[0]);
    
    // Crop State
    const [scale, setScale] = useState(1);
    const [offsetX, setOffsetX] = useState(0);
    const [offsetY, setOffsetY] = useState(0);
    const [aspectRatio, setAspectRatio] = useState(0);

    useEffect(() => {
        if (isOpen && imageFile) {
            const img = new Image();
            img.src = URL.createObjectURL(imageFile);
            img.onload = () => {
                setImageBitmap(img);
                resetState();
            };
        }
    }, [isOpen, imageFile]);

    useEffect(() => {
        if (!containerRef.current) return;
        const observer = new ResizeObserver(entries => {
            const { width, height } = entries[0].contentRect;
            setContainerSize({ width, height });
        });
        observer.observe(containerRef.current);
        return () => observer.disconnect();
    }, []);

    const resetState = () => {
        setRotation(0); setFlipH(false); setFlipV(false);
        setBrightness(100); setContrast(100); setSaturation(100); setBlur(0); setHue(0);
        setScale(1); setOffsetX(0); setOffsetY(0); setAspectRatio(0);
        setSelectedFilter(filters[0]);
    };

    const stageSize = useMemo(() => {
        if (!containerSize.width || !containerSize.height) return { width: 0, height: 0 };
        
        const padding = 40; // Margin around the editor
        const availableWidth = containerSize.width - padding;
        const availableHeight = containerSize.height - padding;
        
        let targetAR = aspectRatio;
        if (targetAR === 0) {
            // Free mode: match image aspect ratio or fit container if no image loaded yet
            targetAR = imageBitmap ? imageBitmap.width / imageBitmap.height : availableWidth / availableHeight;
        }

        let w, h;
        if (availableWidth / availableHeight > targetAR) {
            // Container is wider than target, constrain by height
            h = availableHeight;
            w = h * targetAR;
        } else {
            // Container is taller than target, constrain by width
            w = availableWidth;
            h = w / targetAR;
        }
        
        return { width: w, height: h };
    }, [containerSize, aspectRatio, imageBitmap]);

    // Draw Loop
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas || !imageBitmap || !stageSize.width) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Update canvas resolution to match display size
        canvas.width = stageSize.width;
        canvas.height = stageSize.height;

        // Clear & Setup
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.save();

        if (isComparing) {
            // Draw Original Centered (fitted to canvas)
            const imgRatio = imageBitmap.width / imageBitmap.height;
            const canvasRatio = canvas.width / canvas.height;
            let drawWidth, drawHeight;

            if (imgRatio > canvasRatio) {
                drawWidth = canvas.width;
                drawHeight = canvas.width / imgRatio;
            } else {
                drawHeight = canvas.height;
                drawWidth = canvas.height * imgRatio;
            }
            
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.drawImage(imageBitmap, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
        } else {
            // Transformations
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.translate(offsetX, offsetY);
            ctx.scale(scale, scale);
            ctx.rotate((rotation * Math.PI) / 180);
            ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);

            // Combine Filter + Adjustments
            const manualFilter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) blur(${blur}px) hue-rotate(${hue}deg)`;
            ctx.filter = `${selectedFilter.filter} ${manualFilter}`.trim();

            // Calculate Fit Dimensions for 'contain' style within crop area
            const imgRatio = imageBitmap.width / imageBitmap.height;
            const canvasRatio = canvas.width / canvas.height;
            let drawWidth, drawHeight;

            if (imgRatio > canvasRatio) {
                drawWidth = canvas.width;
                drawHeight = canvas.width / imgRatio;
            } else {
                drawHeight = canvas.height;
                drawWidth = canvas.height * imgRatio;
            }

            ctx.drawImage(imageBitmap, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
        }

        ctx.restore();

    }, [imageBitmap, rotation, flipH, flipV, brightness, contrast, saturation, blur, hue, scale, offsetX, offsetY, aspectRatio, selectedFilter, isComparing, stageSize]);

    // Handlers for Pan (Mouse Drag)
    const isDragging = useRef(false);
    const lastPos = useRef({ x: 0, y: 0 });

    const handleMouseDown = (e: React.MouseEvent) => {
        isDragging.current = true;
        lastPos.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDragging.current) return;
        const dx = e.clientX - lastPos.current.x;
        const dy = e.clientY - lastPos.current.y;
        setOffsetX(prev => prev + dx);
        setOffsetY(prev => prev + dy);
        lastPos.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
        isDragging.current = false;
    };

    const handleSave = () => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        canvas.toBlob((blob) => {
            if (blob) {
                const editedFile = new File([blob], imageFile.name, { type: imageFile.type });
                onSave(editedFile);
                onClose();
            }
        }, imageFile.type, 0.95);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[200] bg-[#050505] flex flex-col animate-fade-in font-sans text-white">
            {/* Top Toolbar */}
            <header className="flex justify-between items-center p-4 bg-[#121214]/80 backdrop-blur-xl border-b border-white/5 z-20">
                <button onClick={onClose} className="p-2 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-white/5">
                    <CloseIcon className="w-6 h-6" />
                </button>
                <div className="flex gap-2">
                    <button 
                        onClick={resetState} 
                        className="p-2 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-white/5"
                        title="Reset All"
                    >
                        <UndoIcon className="w-5 h-5" />
                    </button>
                    <button 
                        onMouseDown={() => setIsComparing(true)}
                        onMouseUp={() => setIsComparing(false)}
                        onMouseLeave={() => setIsComparing(false)}
                        onTouchStart={() => setIsComparing(true)}
                        onTouchEnd={() => setIsComparing(false)}
                        className={`p-2 transition-colors rounded-full hover:bg-white/5 ${isComparing ? 'text-white' : 'text-gray-400 hover:text-white'}`}
                        style={isComparing ? { color: 'var(--theme-color)' } : {}}
                        title="Hold to Compare"
                    >
                        <EyeIcon className="w-5 h-5" />
                    </button>
                </div>
                <button 
                    onClick={handleSave} 
                    className="px-6 py-2 text-white rounded-xl font-bold text-sm hover:shadow-lg transition-all flex items-center gap-2 active:scale-95"
                    style={{ background: 'linear-gradient(to right, var(--theme-color), color-mix(in srgb, var(--theme-color), white 20%))', boxShadow: '0 10px 15px -3px color-mix(in srgb, var(--theme-color), transparent 80%)' }}
                >
                    <CheckIcon className="w-4 h-4" /> Save
                </button>
            </header>

            {/* Canvas Workspace */}
            <div 
                ref={containerRef}
                className="flex-1 relative bg-[#050505] overflow-hidden flex items-center justify-center cursor-move touch-none select-none"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
            >
                {/* Checkerboard Background within Stage */}
                <div 
                    style={{ width: stageSize.width, height: stageSize.height, position: 'relative', boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.85)' }}
                    className="transition-all duration-300"
                >
                    <div className="absolute inset-0 opacity-10 pointer-events-none -z-10" style={{
                        backgroundImage: 'linear-gradient(45deg, #222 25%, transparent 25%), linear-gradient(-45deg, #222 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #222 75%), linear-gradient(-45deg, transparent 75%, #222 75%)',
                        backgroundSize: '20px 20px',
                        backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
                    }}></div>

                    <canvas ref={canvasRef} className="w-full h-full block" />
                    
                    {/* Crop Grid Overlay */}
                    {activeTab === 'crop' && !isComparing && (
                        <div className="absolute inset-0 border border-white/50 pointer-events-none transition-opacity duration-300">
                            <div className="w-full h-full grid grid-cols-3 grid-rows-3">
                                {[...Array(9)].map((_, i) => <div key={i} className="border border-white/20"></div>)}
                            </div>
                            {/* Corner Markers */}
                            <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-white"></div>
                            <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-white"></div>
                            <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-white"></div>
                            <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-white"></div>
                        </div>
                    )}
                    
                    {isComparing && (
                        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/70 backdrop-blur-md px-4 py-1.5 rounded-full text-xs font-bold border border-white/10 pointer-events-none text-white z-10">
                            Original
                        </div>
                    )}
                </div>
            </div>

            {/* Bottom Controls */}
            <div className="bg-[#121214]/95 backdrop-blur-xl border-t border-white/5 pb-safe transition-all z-20">
                {/* Tool Specific Controls */}
                <div className="p-4 min-h-[160px] flex flex-col justify-center">
                    
                    {activeTab === 'crop' && (
                        <div className="w-full space-y-5 animate-fade-in">
                            {/* Dimensions & Info */}
                            <div className="flex justify-center items-center gap-4 text-xs text-gray-400 font-mono">
                                <span>Source: {imageBitmap?.width} x {imageBitmap?.height}</span>
                                <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
                                <span>Crop: {Math.round(stageSize.width)} x {Math.round(stageSize.height)}</span>
                            </div>

                            <div className="flex justify-center gap-3 overflow-x-auto pb-2 hide-scrollbar px-4">
                                {aspectRatios.map(ratio => (
                                    <button
                                        key={ratio.label}
                                        onClick={() => setAspectRatio(ratio.value)}
                                        className={`flex flex-col items-center gap-1 p-2 rounded-xl border transition-all min-w-[60px] group ${aspectRatio === ratio.value ? '' : 'bg-white/5 border-transparent hover:bg-white/10'}`}
                                        style={aspectRatio === ratio.value ? { backgroundColor: 'color-mix(in srgb, var(--theme-color), transparent 90%)', borderColor: 'var(--theme-color)' } : {}}
                                    >
                                        <AspectRatioIcon ratio={ratio.label} isActive={aspectRatio === ratio.value} />
                                        <span className={`text-[10px] font-bold ${aspectRatio === ratio.value ? '' : 'text-gray-400 group-hover:text-white'}`} style={aspectRatio === ratio.value ? { color: 'var(--theme-color)' } : {}}>
                                            {ratio.label}
                                        </span>
                                    </button>
                                ))}
                            </div>

                            <div className="flex items-center gap-4 px-4 max-w-md mx-auto w-full">
                                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider w-8">Zoom</span>
                                <div className="flex-1 relative h-6 flex items-center">
                                    <input 
                                        type="range" 
                                        min="0.1" max="3" step="0.05" 
                                        value={scale} 
                                        onChange={(e) => setScale(parseFloat(e.target.value))}
                                        className="w-full h-1 bg-gray-700 rounded-full appearance-none cursor-pointer hover:opacity-90" 
                                        style={{ accentColor: 'var(--theme-color)' }}
                                    />
                                </div>
                                <span className="text-[10px] font-mono w-8 text-right" style={{ color: 'var(--theme-color)' }}>{Math.round(scale * 100)}%</span>
                            </div>

                            <div className="flex justify-center gap-4">
                                <button onClick={() => setRotation(r => (r + 90) % 360)} className="p-2 bg-white/5 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors" title="Rotate"><RotateRightIcon className="w-5 h-5" /></button>
                                <button onClick={() => setFlipH(!flipH)} className={`p-2 rounded-lg transition-colors ${flipH ? 'text-white' : 'bg-white/5 text-gray-300 hover:bg-white/10'}`} style={flipH ? { backgroundColor: 'var(--theme-color)' } : {}} title="Flip Horizontal"><FlipHorizontalIcon className="w-5 h-5" /></button>
                            </div>
                        </div>
                    )}

                    {activeTab === 'filters' && (
                        <div className="flex gap-4 overflow-x-auto w-full px-4 pb-2 hide-scrollbar snap-x animate-fade-in">
                            {filters.map(filter => (
                                <button
                                    key={filter.name}
                                    onClick={() => setSelectedFilter(filter)}
                                    className="flex flex-col items-center gap-2 group snap-center min-w-[70px]"
                                >
                                    <div 
                                        className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shadow-lg ${selectedFilter.name === filter.name ? 'ring-2 scale-105' : 'border-transparent opacity-70 group-hover:opacity-100 group-hover:scale-105'}`}
                                        style={selectedFilter.name === filter.name ? { borderColor: 'var(--theme-color)', '--tw-ring-color': 'color-mix(in srgb, var(--theme-color), transparent 80%)' } as React.CSSProperties : {}}
                                    >
                                        <img 
                                            src={imageBitmap?.src} 
                                            className="w-full h-full object-cover" 
                                            style={{ filter: filter.filter }} 
                                            alt={filter.name}
                                        />
                                    </div>
                                    <span className={`text-[10px] font-bold uppercase tracking-wide ${selectedFilter.name === filter.name ? '' : 'text-gray-500 group-hover:text-white'}`} style={selectedFilter.name === filter.name ? { color: 'var(--theme-color)' } : {}}>{filter.name}</span>
                                </button>
                            ))}
                        </div>
                    )}

                    {activeTab === 'adjust' && (
                        <div className="w-full max-w-lg mx-auto space-y-4 px-4 animate-fade-in">
                            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                                <AdjustmentSlider label="Brightness" icon={<SunIcon className="w-4 h-4"/>} value={brightness} min={50} max={150} onChange={setBrightness} />
                                <AdjustmentSlider label="Contrast" icon={<ContrastIcon className="w-4 h-4"/>} value={contrast} min={50} max={150} onChange={setContrast} />
                                <AdjustmentSlider label="Saturation" icon={<DropIcon className="w-4 h-4"/>} value={saturation} min={0} max={200} onChange={setSaturation} />
                                <AdjustmentSlider label="Blur" icon={<BlurIcon className="w-4 h-4"/>} value={blur} min={0} max={10} step={0.5} onChange={setBlur} />
                            </div>
                        </div>
                    )}
                </div>

                {/* Tab Navigation */}
                <div className="flex justify-around border-t border-white/5 bg-black/20">
                    <NavTab active={activeTab === 'filters'} onClick={() => setActiveTab('filters')} icon={<MagicWandIcon className="w-5 h-5" />} label="Filters" />
                    <NavTab active={activeTab === 'adjust'} onClick={() => setActiveTab('adjust')} icon={<SliderIcon className="w-5 h-5" />} label="Adjust" />
                    <NavTab active={activeTab === 'crop'} onClick={() => setActiveTab('crop')} icon={<CropIcon className="w-5 h-5" />} label="Crop" />
                </div>
            </div>
        </div>
    );
};

const AspectRatioIcon: React.FC<{ ratio: string, isActive: boolean }> = ({ ratio, isActive }) => {
    let w = 20, h = 20;
    if (ratio === '16:9') { w = 24; h = 14; }
    else if (ratio === '4:3') { w = 22; h = 16; }
    else if (ratio === '9:16') { w = 14; h = 24; }
    else if (ratio === '3:4') { w = 16; h = 22; }
    else if (ratio === '2:3') { w = 16; h = 24; }
    
    return (
        <div className="w-8 h-8 flex items-center justify-center">
            <div 
                style={{ width: w, height: h, borderColor: isActive ? 'var(--theme-color)' : undefined, backgroundColor: isActive ? 'color-mix(in srgb, var(--theme-color), transparent 80%)' : undefined }} 
                className={`border-2 rounded-sm transition-colors ${isActive ? '' : 'border-gray-500'}`}
            ></div>
        </div>
    );
}

const NavTab: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string }> = ({ active, onClick, icon, label }) => (
    <button 
        onClick={onClick} 
        className={`flex-1 py-3 flex flex-col items-center gap-1 transition-all relative ${active ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}
    >
        <div 
            className={`p-1.5 rounded-xl transition-colors ${active ? 'text-white shadow-lg' : 'bg-transparent'}`}
            style={active ? { backgroundColor: 'var(--theme-color)', boxShadow: '0 10px 15px -3px color-mix(in srgb, var(--theme-color), transparent 80%)' } : {}}
        >
            {icon}
        </div>
        <span className={`text-[10px] font-bold uppercase tracking-wider`} style={active ? { color: 'var(--theme-color)' } : {}}>{label}</span>
        {active && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-0.5 bg-current" style={{ color: 'var(--theme-color)', boxShadow: '0 0 10px currentColor' }}></div>}
    </button>
);

const AdjustmentSlider: React.FC<{ label: string, icon: React.ReactNode, value: number, min: number, max: number, step?: number, onChange: (val: number) => void }> = ({ label, icon, value, min, max, step = 1, onChange }) => (
    <div className="space-y-1.5">
        <div className="flex justify-between text-xs text-gray-400">
            <div className="flex items-center gap-1.5">
                {icon}
                <span className="font-medium">{label}</span>
            </div>
            <span className="font-mono" style={{ color: 'var(--theme-color)' }}>{value}</span>
        </div>
        <input 
            type="range" 
            min={min} max={max} step={step} 
            value={value} 
            onChange={(e) => onChange(Number(e.target.value))} 
            className="w-full h-1 bg-gray-700 rounded-full appearance-none cursor-pointer hover:opacity-90"
            style={{ accentColor: 'var(--theme-color)' }}
        />
    </div>
);

// BlurIcon placeholder in case it's not in icons.tsx
const BlurIcon = ({ className }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
        <circle cx="12" cy="12" r="10" strokeDasharray="4 4"/>
        <circle cx="12" cy="12" r="4" />
    </svg>
);

export default ImageEditorModal;
